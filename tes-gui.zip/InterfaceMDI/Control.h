

// CONTROL.h
#ifndef _CONTROL_H_
#define _CONTROL_H_    //#endif  // _CONTROL_H_ //

// �ṹ���� CONTROL.CPP ��ʵ��
#ifdef  _CONTROL_CPP_    //#endif  // _CONTROL_CPP_ //
#define CONTROL_EXTERN 
#else 
#define CONTROL_EXTERN extern 
#endif  // _CONTROL_CPP_ //


#include <Windows.h>

HWND CreateControl(HWND hWnd, LPCTSTR lpClassName="Edit",  const int id =1 , RECT* rp=0L , int sty=0 );      
HWND CreateControlW(HWND hWnd, LPCWSTR lpClassName=L"Edit",  const int id =1 , RECT* rp=0L , int sty=0 );     // gui.cpp     



#if WC_LISTVIEW_MGR|1 

int AddListViewColumns(HWND hListView, const wchar_t* szHeadings);
int AddListViewItems(HWND hListView, const wchar_t* szItem);





#endif  // WC_LISTVIEW_MGR




#if TOOLTIPS_CLASS_MGR|1

// bool AddTool(HWND hWnd, int uID, HWND hTooltip, LPSTR wtip);




#endif  // TOOLTIPS_CLASS_MGR




#endif  // _CONTROL_H_ //


