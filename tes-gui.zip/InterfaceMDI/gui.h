

// GUI.h
#ifndef _GUI_H_
#define _GUI_H_    //#endif  // _GUI_H_ //

// �ṹ���� GUI.CPP ��ʵ��
#ifdef  _GUI_CPP_    //#endif  // _GUI_CPP_ //
#define GUI_EXTERN 
#else 
#define GUI_EXTERN extern 
#endif  // _GUI_CPP_ //

#include <Windows.h>


INT_PTR CALLBACK DialogProc_UI(HWND hdlg, UINT uMsg, WPARAM wParam, LPARAM lParam);



HWND CreatePan(HWND hWnd);    // CreatePanel, VS�Ը����Ʒ���   


// bool AddTool(HWND hWnd, int uID, HWND hTooltip, LPSTR wtip);



int UpdateCmd(HWND hWnd);

int MakeCmd(HWND hdlg); 

















#endif  // _GUI_H_ //


