




#define  _TOOLTIPS_CPP_   

//InitCommonControlsEx: comctl32.lib; //#include <commctrl.h>

#define WINVER 0x0500  // #include <WinUser.h>:  TITLEBARINFO

#include <Windows.h>
#include "res/resource.h"  

#include <commctrl.h>  // LIB: comctl32.lib

#include "ToolTips.h"  
#include "../qTrace.h"



// http://cn.voidcc.com/question/p-gozcmjry-nc.html

// �汾5.x�� TOOLINFO �Ĵ�С��汾6.x��ͬ, ʹ��COMCTL 5 ����Windows XP +, ��Ӧ�ó�ʼ��TOOLINFO��follwing����, 

// TOOLINFO ti;   ti.cbSize = sizeof(TOOLINFO) - 4; 

// ����, ��Ӧ�������Ӿ�����������嵥�ļ��� pragam ָ��: 

#pragma comment(linker, "\"/manifestdependency:type='win32'    \
name='Microsoft.Windows.Common-Controls' version='6.0.0.0'     \
processorArchitecture='*' publicKeyToken='6595b64144ccf1df' language='*'\"") 









#if TOOLTIPS_MGR|1


// ���Ӵ������� tip  -- Unicode �汾�й��� 

bool AddTool(HWND hWnd,RECT* rc, HWND hTip, const char* szTip){
TOOLINFO ti={0}; ti.cbSize=sizeof(ti);    //ti.hinst=hinst;
ti.uFlags=TTF_SUBCLASS|TTF_TRANSPARENT|TTF_IDISHWND;    // |TTF_ABSOLUTE; //TTF_TRACK|;
ti.hwnd=hWnd;          // ������  If lpszText=LPSTR_TEXTCALLBACK, TTN_GETDISPINFO.    
ti.uId=(UINT)hWnd;     // ������  TTF_IDISHWND, handle to the tool.    

ti.lpszText = (char*)szTip;

if(rc) ti.rect=*rc; else GetClientRect(hWnd, &ti.rect); 

if(!SendMessageW(hTip,TTM_ADDTOOL,0,(LPARAM)&ti))   { qTrace("TTM_ADDTOOLW"); return false;}    

return true;
}




// ���Ӵ�����ؼ� tip  -- Unicode �汾�޹��� 

bool AddTool(HWND hWnd, int uID, HWND hTooltip, LPCTSTR wtip) {
TOOLINFO ti = { 0 }; ti.cbSize = sizeof(TOOLINFO);    // ti.hinst=hinst;  ��  string ID  ��Ҫ
ti.uFlags = TTF_SUBCLASS | TTF_IDISHWND;              //      | TTF_TRACK|TTF_ABSOLUTE  ;  //  | TTF_TRANSPARENT;   //  |TTF_CENTERTIP
ti.hwnd = 0;                                          // ������  If lpszText=LPSTR_TEXTCALLBACK, TTN_GETDISPINFO. 
ti.uId = (UINT)GetDlgItem(hWnd, uID);                 // ������  TTF_IDISHWND, handle to the tool.  
ti.lpszText = (LPTSTR)wtip;
if (!SendMessage(hTooltip, TTM_ADDTOOL, 0, (LPARAM)&ti)) { qTrace("TTM_ADDTOOL"); return false; }    // TTM_SETMAXTIPWIDTH 
return true;
}



bool AddTool(HWND hWnd,UINT uID, HWND htip,LPCWSTR wtip){
TOOLINFOW ti={0}; ti.cbSize=sizeof(TOOLINFOW); //ti.hinst=hinst;
ti.uFlags=TTF_SUBCLASS|TTF_IDISHWND;    // |TTF_ABSOLUTE|TTF_TRANSPARENT; //TTF_TRACK|;
ti.hwnd = 0;                            // ������  If lpszText=LPSTR_TEXTCALLBACK, TTN_GETDISPINFO. 
ti.uId=(UINT)GetDlgItem(hWnd,uID);      // ������  TTF_IDISHWND, handle to the tool.  // uID;  
ti.lpszText=(LPWSTR)wtip;                       // GetClientRect(hOwner,& ti.rect);//no effect when TTF_IDISHWND; //ti.rect.left=ti.rect.top=ti.rect.bottom=ti.rect.right=0; 
if(!SendMessage(htip,TTM_ADDTOOLW,0,(LPARAM)&ti))  { MessageBox(0,"TTM_ADDTOOLW","error",0); return false; }    

// int ipc=SendMessage(htip,TTM_SETMAXTIPWIDTH,0,5); 
return true;
}




//UpdateTip.  ע�� TTN_GETDISPINFO


void UpdateTip(HWND hWnd, UINT uID, HWND hTooltip, const char* newTip) {
    TOOLINFO ti; ti.cbSize = sizeof(TOOLINFO);   // ti.uFlags= TTF_SUBCLASS | TTF_IDISHWND;   // ti.uFlags= TTF_SUBCLASS | TTF_IDISHWND| TTF_TRACK;//|TTF_ABSOLUTE;  //  | TTF_TRANSPARENT;   //  |TTF_CENTERTIP
    ti.hwnd = 0;    // GetDlgItem(hWnd, uID);    // =hWnd, ����ָ�� hWnd ��ʧ��!   TTF_IDISHWND Ҳ����! 
ti.uId = (UINT)GetDlgItem(hWnd, uID);            // ��  �����Ƿ�ָ�� ti.uFlags
    ti.lpszText = (char*) newTip;
    SendMessage(hTooltip, TTM_UPDATETIPTEXT, 0, (LPARAM)&ti);
}



void UpdateTip(HWND hWnd, UINT uID, HWND hTooltip, LPCWSTR newTip) {
    TOOLINFOW ti; ti.cbSize = sizeof(TOOLINFOW);
    ti.hwnd = 0;
    ti.uId = (UINT)GetDlgItem(hWnd, uID);
    ti.lpszText = (LPWSTR) newTip;
    SendMessageW(hTooltip, TTM_UPDATETIPTEXTW, 0, (LPARAM)&ti);
}




void UpdateTip(HWND hItem, HWND hTooltip, const char* newTip) {
    TOOLINFO ti; ti.cbSize = sizeof(TOOLINFO);   // ti.uFlags= TTF_SUBCLASS | TTF_IDISHWND;   // ti.uFlags= TTF_SUBCLASS | TTF_IDISHWND| TTF_TRACK;//|TTF_ABSOLUTE;  //  | TTF_TRANSPARENT;   //  |TTF_CENTERTIP
    ti.hwnd = 0;    // GetDlgItem(hWnd, uID);    // =hWnd, ����ָ�� hWnd ��ʧ��!   TTF_IDISHWND Ҳ����! 
ti.uId = (UINT)hItem;            // ��  �����Ƿ�ָ�� ti.uFlags
    ti.lpszText = (char*) newTip;
    SendMessage(hTooltip, TTM_UPDATETIPTEXT, 0, (LPARAM)&ti);
}



void UpdateTip(HWND hItem, HWND hTooltip, LPCWSTR newTip) {
    TOOLINFOW ti; ti.cbSize = sizeof(TOOLINFOW);
    ti.hwnd = 0;
    ti.uId = (UINT)hItem;
    ti.lpszText = (LPWSTR) newTip;
    SendMessageW(hTooltip, TTM_UPDATETIPTEXTW, 0, (LPARAM)&ti);
}


















//  TTM_TRACKPOSITION 






// ���ӻ�����ʾ. ע�� WndProc ��Ҫ������Ϣ  


bool AddTool(HWND hTip,HWND hWnd){

TOOLINFO ti;

ti.cbSize = sizeof(TOOLINFO);
ti.uFlags = TTF_IDISHWND | TTF_TRACK | TTF_ABSOLUTE;
ti.hwnd   = hWnd;
ti.uId    = (UINT)hWnd;
ti.hinst  = 0;
ti.lpszText  = LPSTR_TEXTCALLBACK;
ti.rect.left = ti.rect.top = ti.rect.bottom = ti.rect.right = 0;   //  TTF_IDISHWND ʹ rect ��Ч 
    
    // Add the tool to the control, displaying an error if needed.
if(!SendMessage(hTip,TTM_ADDTOOL,0,(LPARAM)&ti)){ MessageBox(0,"Couldn't create the tooltip control.", "Error",MB_OK);
return false;
}
    

SendMessage(hTip,TTM_TRACKACTIVATE,(WPARAM)TRUE,(LPARAM)&ti);

return true; 
}


#endif     //  TOOLTIPS_MGR




// ToolTip �ƺ����ʺ����Ӵ���  

HWND  CreateToolTip(HWND hWnd,UINT uID, LPWSTR szTip){ //=0,  =0, =NULL;


HWND hWndTT= CreateWindowExW(WS_EX_TOPMOST,TOOLTIPS_CLASSW,NULL,  WS_POPUP, 0,0,0,0,  0,0,0,0);     // |TTS_NOPREFIX|TTS_ALWAYSTIP ,   //|TTS_BALLOON |TTM_RELAYEVENT  
      

// ʹ�� LPSTR_TEXTCALLBACK:                      
TOOLINFOW ti={0}; ti.cbSize=sizeof(TOOLINFOW);  
ti.uFlags = TTF_TRACK|TTF_ABSOLUTE|TTF_IDISHWND;      
ti.hwnd=hWnd;          // ��Ӧ  ��Ϣ�Ĵ��ڡ� 
ti.lpszText=szTip;     // =LPSTR_TEXTCALLBACK,  ti.hwnd ����  TTN_NEEDTEXT=TTN_GETDISPINFO notification message.  

// switch (lpnmhdr->code) {    case TTN_GETDISPINFO:   lpttd = (LPNMTTDISPINFO)lpnmhdr;    SendMessage(lpnmhdr->hwndFrom, TTM_SETMAXTIPWIDTH, 0, 300);  
// lpttd->lpszText = szLongMessage;     return 0;   ...... } 

SendMessage(hWndTT,TTM_TRACKACTIVATE,(WPARAM)TRUE,(LPARAM)&ti);


return hWndTT;
}




// AddToolTip, ���hOwner: uID, ������ʾszTip. [2007-3-11 ���� 12:01:21]//
// d:\Msdn\2000JUL\1033\Shellcc.chm::/shellcc/CommCtls/ToolTip/UsingTooltips;
// #pragma comment(lib, "comctl32.lib")
// �÷�ʾ��:
// case WM_MOUSEMOVE:  if(bToolTipVisible) SendMessage(g_hwndTT,TTM_TRACKPOSITION,0,(LPARAM)MAKELPARAM(GET_X_LPARAM(lParam)+15,GET_Y_LPARAM(lParam)+15));

HWND WINAPI AddToolTip(HWND hOwner,UINT uID, LPWSTR szTip){ //=0, =NULL;

// INITCOMMONCONTROLSEX icex;icex.dwSize=sizeof(icex);icex.dwICC =ICC_BAR_CLASSES;  \
if(!InitCommonControlsEx(&icex)) return NULL;  // Load the tooltip class from the DLL.

HWND hwndTT=CreateWindowExW(WS_EX_TOPMOST,TOOLTIPS_CLASSW,NULL,
                          WS_POPUP|TTS_NOPREFIX|TTS_ALWAYSTIP ,0,0,0,0,  //|TTS_BALLOON |TTM_RELAYEVENT  
                          hOwner,(HMENU)NULL,(HINSTANCE)NULL,NULL);
// Prepare TOOLINFO structure for use as tracking tooltip.
TOOLINFOW ti={0}; ti.cbSize=sizeof(TOOLINFOW); // ti.hinst=hinst;
ti.uFlags=TTF_SUBCLASS;  // |TTF_ABSOLUTE | TTF_TRACK;
if(uID!=0)  ti.uFlags|=TTF_TRANSPARENT|TTF_IDISHWND;  

ti.hwnd=hOwner;  // If lpszText includes the LPSTR_TEXTCALLBACK value, this member identifies the window that receives the TTN_GETDISPINFO notification messages.  

if(uID!=0) ti.uId=(UINT)GetDlgItem(hOwner,uID);  else  ti.uId=0x01; 

ti.lpszText=szTip;  // L"���ش���"; 


//GetClientRect(hOwner,&ti.rect);  // no effect when TTF_IDISHWND; //ti.rect.left=ti.rect.top=ti.rect.bottom=ti.rect.right=0; 

int icx=GetSystemMetrics(SM_CXSIZE);  // 25
TITLEBARINFO tin={sizeof(tin),0}; GetTitleBarInfo(hOwner,&tin);
RECT r=tin.rcTitleBar;   int iw=r.right-r.left, ih=r.bottom-r.top;
SetRect(&ti.rect,iw-icx, -ih,  iw,0);


if(!SendMessage(hwndTT,TTM_ADDTOOLW,0,(LPARAM)&ti)) { MessageBox(NULL,"TTM_ADDTOOLW","error",0); }    
//int ipc=SendMessage(hwndTT,TTM_SETMAXTIPWIDTH,0,5); 
return hwndTT;

ti.uId=(UINT)GetDlgItem(hOwner, 0x40);  // ITEM_COMBO
ti.lpszText=L"�����ı�!"; 
if(!SendMessage(hwndTT,TTM_ADDTOOLW,0,(LPARAM)&ti)) {MessageBox(NULL,"TTM_ADDTOOLW","error",0);  return NULL;}    
ti.uId=(UINT)GetDlgItem(hOwner, 0x0B);  // ITEM_CLIENT  
ti.lpszText=L"���س���ѡ��!"; 
if(!SendMessage(hwndTT,TTM_ADDTOOLW,0,(LPARAM)&ti)) {MessageBox(NULL,"TTM_ADDTOOLW","error",0); return NULL;}    

//SendMessage(hwndTT,TTM_SETDELAYTIME,TTDT_AUTOMATIC,-1);

SendMessage(hwndTT,TTM_TRACKACTIVATE,(WPARAM)TRUE,(LPARAM)&ti);  // Activate (display) the tracking tooltip;
//bToolTipVisible=TRUE;
return(hwndTT);    
}





//.................. ToolTip ..................//


//TTN_GETDISPINFO
//    lpnmtdi = (LPNMTTDISPINFO)lParam;
//#define TTN_NEEDTEXT TTN_GETDISPINFO


void UpdateTip(HWND htip,HWND hOwner,UINT uID, LPWSTR wnew){
TOOLINFOW ti;ti.cbSize=sizeof(TOOLINFOW);//ti.uFlags = TTF_SUBCLASS|TTF_ABSOLUTE;//|TTF_IDISHWND;//; //TTF_SUBCLASS; //
ti.uId=(UINT)GetDlgItem(hOwner,uID);  //uid;//UINT uid = 0; //uID;//  
ti.lpszText=wnew;//GetClientRect(hWnd, &ti.rect);//All items in the client area;//ti.rect.bottom=20;  // GET COORDINATES OF THE MAIN CLIENT AREA;// Tooltip control will cover the whole window; 
SendMessageW(htip,TTM_UPDATETIPTEXTW,0,(LPARAM)&ti);		
}




//------------------ ToolTip ------------------//
