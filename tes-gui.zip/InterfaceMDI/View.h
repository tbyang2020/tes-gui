
 




#pragma warning(disable:4996)



#define DBG_LOG 

#ifndef _VIEW_H_
#define _VIEW_H_    // #endif  // _VIEW_H_ //

// �ṹ���� VIEW.CPP ��ʵ��
#ifdef  _VIEW_CPP_    // #define _VIEW_CPP_ // #include "View.h"
#define VIEW_EXTERN 
#else 
#define VIEW_EXTERN extern 
#endif  // _QDB_CPP_ //



#include <Windows.h>

#include "InterfaceMDI.h"

HWND  GetCCWnd( int id );   // ȡ�� Client Child ����  
  

HWND CreateDoc(HWND hWnd, int dType=DT_DIB, void*data=0, int uID=0);  // DT_TEXT=0,  DT_DIB= 1  ... 



 
#endif  // _VIEW_H_ //





