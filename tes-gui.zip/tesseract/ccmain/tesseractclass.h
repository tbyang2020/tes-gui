




#ifndef TESSERACT_CCMAIN_TESSERACTCLASS_H__
#define TESSERACT_CCMAIN_TESSERACTCLASS_H__


#include "ratngs.h"


#include "intproto.h"






class PAGE_RES;

 

#include "bbgrid.h"

#include "gap_map.h"




#include "ccstruct.h"


#if    TESSERACT_TEXTORD_TEXTORD_H_DEBUG| 1





namespace tesseract {

    // A simple class that can be used by BBGrid to hold a word and an expanded
    // bounding box that makes it easy to find words to put diacritics.
    class WordWithBox {
    public:
        WordWithBox() : word_(NULL) {}
        explicit WordWithBox(WERD* word)
            : word_(word), bounding_box_(word->bounding_box()) {
            int height = bounding_box_.height();
            bounding_box_.pad(height, height);
        }

        const TBOX& bounding_box() const { return bounding_box_; }
        // Returns the bounding box of only the good blobs.
        TBOX true_bounding_box() const { return word_->true_bounding_box(); }
        C_BLOB_LIST* RejBlobs() const { return word_->rej_cblob_list(); }
        const WERD* word() const { return word_; }

    private:
        // Borrowed pointer to a real word somewhere that must outlive this class.
        WERD* word_;
        // Cached expanded bounding box of the word, padded all round by its height.
        TBOX bounding_box_;
    };

    // Make it usable by BBGrid.
    CLISTIZEH(WordWithBox)
        typedef BBGrid<WordWithBox, WordWithBox_CLIST, WordWithBox_C_IT> WordGrid;
    typedef GridSearch<WordWithBox, WordWithBox_CLIST, WordWithBox_C_IT> WordSearch;

    class Textord {
    public:
        explicit Textord(CCStruct* ccstruct);
        ~Textord();

        // Make the textlines and words inside each block.
        // binary_pix is mandatory and is the binarized input after line removal.
        // grey_pix is optional, but if present must match the binary_pix in size,
        // and must be a *real* grey image instead of binary_pix * 255.
        // thresholds_pix is expected to be present iff grey_pix is present and
        // can be an integer factor reduction of the grey_pix. It represents the
        // thresholds that were used to create the binary_pix from the grey_pix.
        // diacritic_blobs contain small confusing components that should be added
        // to the appropriate word(s) in case they are really diacritics.
        void TextordPage(PageSegMode pageseg_mode, const FCOORD& reskew, int width,
            int height, Pix* binary_pix, Pix* thresholds_pix,
            Pix* grey_pix, bool use_box_bottoms,
            BLOBNBOX_LIST* diacritic_blobs, BLOCK_LIST* blocks,
            TO_BLOCK_LIST* to_blocks);

        // If we were supposed to return only a single textline, and there is more
        // than one, clean up and leave only the best.
        void CleanupSingleRowResult(PageSegMode pageseg_mode, PAGE_RES* page_res);

        bool use_cjk_fp_model() const {
            return use_cjk_fp_model_;
        }
        void set_use_cjk_fp_model(bool flag) {
            use_cjk_fp_model_ = flag;
        }

        // tospace.cpp ///////////////////////////////////////////
        void to_spacing(
            ICOORD page_tr,        //topright of page
            TO_BLOCK_LIST* blocks  //blocks on page
        );
        ROW* make_prop_words(TO_ROW* row,     // row to make
            FCOORD rotation  // for drawing
        );
        ROW* make_blob_words(TO_ROW* row,     // row to make
            FCOORD rotation  // for drawing
        );
        // tordmain.cpp ///////////////////////////////////////////
        void find_components(Pix* pix, BLOCK_LIST* blocks, TO_BLOCK_LIST* to_blocks);
        void filter_blobs(ICOORD page_tr, TO_BLOCK_LIST* blocks, BOOL8 testing_on);

    private:


    public:
        // For underlying memory management and other utilities.
        CCStruct* ccstruct_;

        // The size of the input image.
        ICOORD page_tr_;

        bool use_cjk_fp_model_;

        // makerow.cpp ///////////////////////////////////////////
        // Make the textlines inside each block.
        void MakeRows(PageSegMode pageseg_mode, const FCOORD& skew,
            int width, int height, TO_BLOCK_LIST* to_blocks);
        // Make the textlines inside a single block.
        void MakeBlockRows(int min_spacing, int max_spacing,
            const FCOORD& skew, TO_BLOCK* block,
            ScrollView* win);

    public:
        void compute_block_xheight(TO_BLOCK* block, float gradient);
        void compute_row_xheight(TO_ROW* row,          // row to do
            const FCOORD& rotation,
            float gradient,       // global skew
            int block_line_size);
        void make_spline_rows(TO_BLOCK* block,   // block to do
            float gradient,    // gradient to fit
            BOOL8 testing_on);
    private:
        //// oldbasel.cpp ////////////////////////////////////////
        void make_old_baselines(TO_BLOCK* block,   // block to do
            BOOL8 testing_on,  // correct orientation
            float gradient);
        void correlate_lines(TO_BLOCK* block, float gradient);
        void correlate_neighbours(TO_BLOCK* block,  // block rows are in.
            TO_ROW** rows,    // rows of block.
            int rowcount);    // no of rows to do.
        int correlate_with_stats(TO_ROW** rows,  // rows of block.
            int rowcount,   // no of rows to do.
            TO_BLOCK* block);
        void find_textlines(TO_BLOCK* block,  // block row is in
            TO_ROW* row,      // row to do
            int degree,       // required approximation
            QSPLINE* spline);  // starting spline
// tospace.cpp ///////////////////////////////////////////
//DEBUG USE ONLY
        void block_spacing_stats(TO_BLOCK* block,
            GAPMAP* gapmap,
            BOOL8& old_text_ord_proportional,
            //resulting estimate
            inT16& block_space_gap_width,
            //resulting estimate
            inT16& block_non_space_gap_width
        );
        void row_spacing_stats(TO_ROW* row,
            GAPMAP* gapmap,
            inT16 block_idx,
            inT16 row_idx,
            //estimate for block
            inT16 block_space_gap_width,
            //estimate for block
            inT16 block_non_space_gap_width
        );
        void old_to_method(TO_ROW* row,
            STATS* all_gap_stats,
            STATS* space_gap_stats,
            STATS* small_gap_stats,
            inT16 block_space_gap_width,
            //estimate for block
            inT16 block_non_space_gap_width
        );
        BOOL8 isolated_row_stats(TO_ROW* row,
            GAPMAP* gapmap,
            STATS* all_gap_stats,
            BOOL8 suspected_table,
            inT16 block_idx,
            inT16 row_idx);
        inT16 stats_count_under(STATS* stats, inT16 threshold);
        void improve_row_threshold(TO_ROW* row, STATS* all_gap_stats);
        BOOL8 make_a_word_break(TO_ROW* row,   // row being made
            TBOX blob_box, // for next_blob // how many blanks?
            inT16 prev_gap,
            TBOX prev_blob_box,
            inT16 real_current_gap,
            inT16 within_xht_current_gap,
            TBOX next_blob_box,
            inT16 next_gap,
            uinT8& blanks,
            BOOL8& fuzzy_sp,
            BOOL8& fuzzy_non,
            BOOL8& prev_gap_was_a_space,
            BOOL8& break_at_next_gap);
        BOOL8 narrow_blob(TO_ROW* row, TBOX blob_box);
        BOOL8 wide_blob(TO_ROW* row, TBOX blob_box);
        BOOL8 suspected_punct_blob(TO_ROW* row, TBOX box);
        void peek_at_next_gap(TO_ROW* row,
            BLOBNBOX_IT box_it,
            TBOX& next_blob_box,
            inT16& next_gap,
            inT16& next_within_xht_gap);
        void mark_gap(TBOX blob,    //blob following gap
            inT16 rule,  // heuristic id
            inT16 prev_gap,
            inT16 prev_blob_width,
            inT16 current_gap,
            inT16 next_blob_width,
            inT16 next_gap);
        float find_mean_blob_spacing(WERD* word);
        BOOL8 ignore_big_gap(TO_ROW* row,
            inT32 row_length,
            GAPMAP* gapmap,
            inT16 left,
            inT16 right);
        //get bounding box
        TBOX reduced_box_next(TO_ROW* row,     //current row
            BLOBNBOX_IT* it  //iterator to blobds
        );
        TBOX reduced_box_for_blob(BLOBNBOX* blob, TO_ROW* row, inT16* left_above_xht);
        // tordmain.cpp ///////////////////////////////////////////
        float filter_noise_blobs(BLOBNBOX_LIST* src_list,
            BLOBNBOX_LIST* noise_list,
            BLOBNBOX_LIST* small_list,
            BLOBNBOX_LIST* large_list);
        // Fixes the block so it obeys all the rules:
        // Must have at least one ROW.
        // Must have at least one WERD.
        // WERDs contain a fake blob.
        void cleanup_nontext_block(BLOCK* block);
        void cleanup_blocks(bool clean_noise, BLOCK_LIST* blocks);
        BOOL8 clean_noise_from_row(ROW* row);
        void clean_noise_from_words(ROW* row);
        // Remove outlines that are a tiny fraction in either width or height
        // of the word height.
        void clean_small_noise_from_words(ROW* row);
        // Groups blocks by rotation, then, for each group, makes a WordGrid and calls
        // TransferDiacriticsToWords to copy the diacritic blobs to the most
        // appropriate words in the group of blocks. Source blobs are not touched.
        void TransferDiacriticsToBlockGroups(BLOBNBOX_LIST* diacritic_blobs,
            BLOCK_LIST* blocks);
        // Places a copy of blobs that are near a word (after applying rotation to the
        // blob) in the most appropriate word, unless there is doubt, in which case a
        // blob can end up in two words. Source blobs are not touched.
        void TransferDiacriticsToWords(BLOBNBOX_LIST* diacritic_blobs,
            const FCOORD& rotation, WordGrid* word_grid);

    public:
        // makerow.cpp ///////////////////////////////////////////
        BOOL_VAR_H(textord_single_height_mode, false,
            "Script has no xheight, so use a single mode for horizontal text");
        // tospace.cpp ///////////////////////////////////////////
        BOOL_VAR_H(tosp_old_to_method, false, "Space stats use prechopping?");
        BOOL_VAR_H(tosp_old_to_constrain_sp_kn, false,
            "Constrain relative values of inter and intra-word gaps for "
            "old_to_method.");
        BOOL_VAR_H(tosp_only_use_prop_rows, true,
            "Block stats to use fixed pitch rows?");
        BOOL_VAR_H(tosp_force_wordbreak_on_punct, false,
            "Force word breaks on punct to break long lines in non-space "
            "delimited langs");
        BOOL_VAR_H(tosp_use_pre_chopping, false,
            "Space stats use prechopping?");
        BOOL_VAR_H(tosp_old_to_bug_fix, false,
            "Fix suspected bug in old code");
        BOOL_VAR_H(tosp_block_use_cert_spaces, true,
            "Only stat OBVIOUS spaces");
        BOOL_VAR_H(tosp_row_use_cert_spaces, true,
            "Only stat OBVIOUS spaces");
        BOOL_VAR_H(tosp_narrow_blobs_not_cert, true,
            "Only stat OBVIOUS spaces");
        BOOL_VAR_H(tosp_row_use_cert_spaces1, true,
            "Only stat OBVIOUS spaces");
        BOOL_VAR_H(tosp_recovery_isolated_row_stats, true,
            "Use row alone when inadequate cert spaces");
        BOOL_VAR_H(tosp_only_small_gaps_for_kern, false, "Better guess");
        BOOL_VAR_H(tosp_all_flips_fuzzy, false, "Pass ANY flip to context?");
        BOOL_VAR_H(tosp_fuzzy_limit_all, true,
            "Don't restrict kn->sp fuzzy limit to tables");
        BOOL_VAR_H(tosp_stats_use_xht_gaps, true,
            "Use within xht gap for wd breaks");
        BOOL_VAR_H(tosp_use_xht_gaps, true,
            "Use within xht gap for wd breaks");
        BOOL_VAR_H(tosp_only_use_xht_gaps, false,
            "Only use within xht gap for wd breaks");
        BOOL_VAR_H(tosp_rule_9_test_punct, false,
            "Don't chng kn to space next to punct");
        BOOL_VAR_H(tosp_flip_fuzz_kn_to_sp, true, "Default flip");
        BOOL_VAR_H(tosp_flip_fuzz_sp_to_kn, true, "Default flip");
        BOOL_VAR_H(tosp_improve_thresh, false,
            "Enable improvement heuristic");
        INT_VAR_H(tosp_debug_level, 0, "Debug data");
        INT_VAR_H(tosp_enough_space_samples_for_median, 3,
            "or should we use mean");
        INT_VAR_H(tosp_redo_kern_limit, 10,
            "No.samples reqd to reestimate for row");
        INT_VAR_H(tosp_few_samples, 40,
            "No.gaps reqd with 1 large gap to treat as a table");
        INT_VAR_H(tosp_short_row, 20,
            "No.gaps reqd with few cert spaces to use certs");
        INT_VAR_H(tosp_sanity_method, 1, "How to avoid being silly");
        double_VAR_H(tosp_old_sp_kn_th_factor, 2.0,
            "Factor for defining space threshold in terms of space and "
            "kern sizes");
        double_VAR_H(tosp_threshold_bias1, 0,
            "how far between kern and space?");
        double_VAR_H(tosp_threshold_bias2, 0,
            "how far between kern and space?");
        double_VAR_H(tosp_narrow_fraction, 0.3,
            "Fract of xheight for narrow");
        double_VAR_H(tosp_narrow_aspect_ratio, 0.48,
            "narrow if w/h less than this");
        double_VAR_H(tosp_wide_fraction, 0.52, "Fract of xheight for wide");
        double_VAR_H(tosp_wide_aspect_ratio, 0.0,
            "wide if w/h less than this");
        double_VAR_H(tosp_fuzzy_space_factor, 0.6,
            "Fract of xheight for fuzz sp");
        double_VAR_H(tosp_fuzzy_space_factor1, 0.5,
            "Fract of xheight for fuzz sp");
        double_VAR_H(tosp_fuzzy_space_factor2, 0.72,
            "Fract of xheight for fuzz sp");
        double_VAR_H(tosp_gap_factor, 0.83, "gap ratio to flip sp->kern");
        double_VAR_H(tosp_kern_gap_factor1, 2.0,
            "gap ratio to flip kern->sp");
        double_VAR_H(tosp_kern_gap_factor2, 1.3,
            "gap ratio to flip kern->sp");
        double_VAR_H(tosp_kern_gap_factor3, 2.5,
            "gap ratio to flip kern->sp");
        double_VAR_H(tosp_ignore_big_gaps, -1, "xht multiplier");
        double_VAR_H(tosp_ignore_very_big_gaps, 3.5, "xht multiplier");
        double_VAR_H(tosp_rep_space, 1.6, "rep gap multiplier for space");
        double_VAR_H(tosp_enough_small_gaps, 0.65,
            "Fract of kerns reqd for isolated row stats");
        double_VAR_H(tosp_table_kn_sp_ratio, 2.25,
            "Min difference of kn & sp in table");
        double_VAR_H(tosp_table_xht_sp_ratio, 0.33,
            "Expect spaces bigger than this");
        double_VAR_H(tosp_table_fuzzy_kn_sp_ratio, 3.0,
            "Fuzzy if less than this");
        double_VAR_H(tosp_fuzzy_kn_fraction, 0.5, "New fuzzy kn alg");
        double_VAR_H(tosp_fuzzy_sp_fraction, 0.5, "New fuzzy sp alg");
        double_VAR_H(tosp_min_sane_kn_sp, 1.5,
            "Don't trust spaces less than this time kn");
        double_VAR_H(tosp_init_guess_kn_mult, 2.2,
            "Thresh guess - mult kn by this");
        double_VAR_H(tosp_init_guess_xht_mult, 0.28,
            "Thresh guess - mult xht by this");
        double_VAR_H(tosp_max_sane_kn_thresh, 5.0,
            "Multiplier on kn to limit thresh");
        double_VAR_H(tosp_flip_caution, 0.0,
            "Don't autoflip kn to sp when large separation");
        double_VAR_H(tosp_large_kerning, 0.19,
            "Limit use of xht gap with large kns");
        double_VAR_H(tosp_dont_fool_with_small_kerns, -1,
            "Limit use of xht gap with odd small kns");
        double_VAR_H(tosp_near_lh_edge, 0,
            "Don't reduce box if the top left is non blank");
        double_VAR_H(tosp_silly_kn_sp_gap, 0.2,
            "Don't let sp minus kn get too small");
        double_VAR_H(tosp_pass_wide_fuzz_sp_to_context, 0.75,
            "How wide fuzzies need context");
        // tordmain.cpp ///////////////////////////////////////////
        BOOL_VAR_H(textord_no_rejects, false, "Don't remove noise blobs");
        BOOL_VAR_H(textord_show_blobs, false, "Display unsorted blobs");
        BOOL_VAR_H(textord_show_boxes, false, "Display boxes");
        INT_VAR_H(textord_max_noise_size, 7, "Pixel size of noise");
        INT_VAR_H(textord_baseline_debug, 0, "Baseline debug level");
        double_VAR_H(textord_blob_size_bigile, 95, "Percentile for large blobs");
        double_VAR_H(textord_noise_area_ratio, 0.7,
            "Fraction of bounding box for noise");
        double_VAR_H(textord_blob_size_smallile, 20, "Percentile for small blobs");
        double_VAR_H(textord_initialx_ile, 0.75, "Ile of sizes for xheight guess");
        double_VAR_H(textord_initialasc_ile, 0.90, "Ile of sizes for xheight guess");
        INT_VAR_H(textord_noise_sizefraction, 10, "Fraction of size for maxima");
        double_VAR_H(textord_noise_sizelimit, 0.5, "Fraction of x for big t count");
        INT_VAR_H(textord_noise_translimit, 16, "Transitions for normal blob");
        double_VAR_H(textord_noise_normratio, 2.0, "Dot to norm ratio for deletion");
        BOOL_VAR_H(textord_noise_rejwords, true, "Reject noise-like words");
        BOOL_VAR_H(textord_noise_rejrows, true, "Reject noise-like rows");
        double_VAR_H(textord_noise_syfract, 0.2, "xh fract error for norm blobs");
        double_VAR_H(textord_noise_sxfract, 0.4,
            "xh fract width error for norm blobs");
        double_VAR_H(textord_noise_hfract, 1.0 / 64,
            "Height fraction to discard outlines as speckle noise");
        INT_VAR_H(textord_noise_sncount, 1, "super norm blobs to save row");
        double_VAR_H(textord_noise_rowratio, 6.0, "Dot to norm ratio for deletion");
        BOOL_VAR_H(textord_noise_debug, FALSE, "Debug row garbage detector");
        double_VAR_H(textord_blshift_maxshift, 0.00, "Max baseline shift");
        double_VAR_H(textord_blshift_xfraction, 9.99, "Min size of baseline shift");
    };
}  // namespace tesseract.












#endif  // TESSERACT_TEXTORD_TEXTORD_H__

 







#if    TESSERACT_CSTRUCT_BOXWORD_H_DEBUG|1


#include "genericvector.h"
#include "rect.h"
#include "unichar.h"

class BLOCK;
class DENORM;
struct TWERD;
class UNICHARSET;
class WERD;
class WERD_CHOICE;
class WERD_RES;

namespace tesseract {

    // Class to hold an array of bounding boxes for an output word and
    // the bounding box of the whole word.
    class BoxWord {
    public:
        BoxWord();
        explicit BoxWord(const BoxWord& src);
        ~BoxWord();

        BoxWord& operator=(const BoxWord& src);

        void CopyFrom(const BoxWord& src);

        // Factory to build a BoxWord from a TWERD using the DENORMs on each blob to
        // switch back to original image coordinates.
        static BoxWord* CopyFromNormalized(TWERD* tessword);

        // Clean up the bounding boxes from the polygonal approximation by
        // expanding slightly, then clipping to the blobs from the original_word
        // that overlap. If not null, the block provides the inverse rotation.
        void ClipToOriginalWord(const BLOCK* block, WERD* original_word);

        // Merges the boxes from start to end, not including end, and deletes
        // the boxes between start and end.
        void MergeBoxes(int start, int end);

        // Inserts a new box before the given index.
        // Recomputes the bounding box.
        void InsertBox(int index, const TBOX& box);

        // Changes the box at the given index to the new box.
        // Recomputes the bounding box.
        void ChangeBox(int index, const TBOX& box);

        // Deletes the box with the given index, and shuffles up the rest.
        // Recomputes the bounding box.
        void DeleteBox(int index);

        // Deletes all the boxes stored in BoxWord.
        void DeleteAllBoxes();

        // This and other putatively are the same, so call the (permanent) callback
        // for each blob index where the bounding boxes match.
        // The callback is deleted on completion.
        void ProcessMatchedBlobs(const TWERD& other, TessCallback1<int>* cb) const;

        const TBOX& bounding_box() const {
            return bbox_;
        }
        int length() const { return length_; }
        const TBOX& BlobBox(int index) const {
            return boxes_[index];
        }

    private:
        void ComputeBoundingBox();

        TBOX bbox_;
        int length_;
        GenericVector<TBOX> boxes_;
    };

}  // namespace tesseract.


#endif  // TESSERACT_CSTRUCT_BOXWORD_H__


 







#if    ADAPTIVE_H_DEBUG|1


typedef struct
{
    uinT16 ProtoId;
    uinT16 dummy;
    PROTO_STRUCT Proto;
}


TEMP_PROTO_STRUCT;
typedef TEMP_PROTO_STRUCT* TEMP_PROTO;

typedef struct
{
    uinT8 NumTimesSeen;
    uinT8 ProtoVectorSize;
    PROTO_ID MaxProtoId;
    LIST ContextsSeen;
    BIT_VECTOR Protos;
    int FontinfoId;  // font information inferred from pre-trained templates
} TEMP_CONFIG_STRUCT;
typedef TEMP_CONFIG_STRUCT* TEMP_CONFIG;

typedef struct
{
    UNICHAR_ID* Ambigs;
    int FontinfoId;  // font information inferred from pre-trained templates
} PERM_CONFIG_STRUCT;
typedef PERM_CONFIG_STRUCT* PERM_CONFIG;

typedef union
{
    TEMP_CONFIG Temp;
    PERM_CONFIG Perm;
} ADAPTED_CONFIG;

typedef struct
{
    uinT8 NumPermConfigs;
    uinT8 MaxNumTimesSeen;  // maximum number of times any TEMP_CONFIG was seen
    uinT8 dummy[2];         // (cut at matcher_min_examples_for_prototyping)
    BIT_VECTOR PermProtos;
    BIT_VECTOR PermConfigs;
    LIST TempProtos;
    ADAPTED_CONFIG Config[MAX_NUM_CONFIGS];
} ADAPT_CLASS_STRUCT;
typedef ADAPT_CLASS_STRUCT* ADAPT_CLASS;

typedef struct
{
    INT_TEMPLATES Templates;
    int NumNonEmptyClasses;
    uinT8 NumPermClasses;
    uinT8 dummy[3];
    ADAPT_CLASS Class[MAX_NUM_CLASSES];
} ADAPT_TEMPLATES_STRUCT;
typedef ADAPT_TEMPLATES_STRUCT* ADAPT_TEMPLATES;

/*----------------------------------------------------------------------------
          Public Function Prototypes
----------------------------------------------------------------------------*/
#define NumNonEmptyClassesIn(Template) ((Template)->NumNonEmptyClasses)

#define IsEmptyAdaptedClass(Class) ((Class)->NumPermConfigs == 0 &&      \
(Class)->TempProtos == NIL_LIST)

#define ConfigIsPermanent(Class,ConfigId)		\
(test_bit ((Class)->PermConfigs, ConfigId))

#define MakeConfigPermanent(Class,ConfigId)	\
(SET_BIT ((Class)->PermConfigs, ConfigId))

#define MakeProtoPermanent(Class,ProtoId)	\
(SET_BIT ((Class)->PermProtos, ProtoId))

#define TempConfigFor(Class,ConfigId)	\
((Class)->Config[ConfigId].Temp)

#define PermConfigFor(Class,ConfigId)	\
((Class)->Config[ConfigId].Perm)

#define IncreaseConfidence(TempConfig)	\
((TempConfig)->NumTimesSeen++)

void AddAdaptedClass(ADAPT_TEMPLATES Templates,
    ADAPT_CLASS Class,
    CLASS_ID ClassId);

void FreeTempProto(void* arg);

void FreeTempConfig(TEMP_CONFIG Config);

ADAPT_CLASS NewAdaptedClass();

void free_adapted_class(ADAPT_CLASS adapt_class);

void free_adapted_templates(ADAPT_TEMPLATES templates);

TEMP_CONFIG NewTempConfig(int MaxProtoId, int FontinfoId);

TEMP_PROTO NewTempProto();

ADAPT_CLASS ReadAdaptedClass(FILE* File);

PERM_CONFIG ReadPermConfig(FILE* File);

TEMP_CONFIG ReadTempConfig(FILE* File);

void WriteAdaptedClass(FILE* File, ADAPT_CLASS Class, int NumConfigs);

void WritePermConfig(FILE* File, PERM_CONFIG Config);

void WriteTempConfig(FILE* File, TEMP_CONFIG Config);

#endif

  






#if    CUTOFFS_H_MODE|1



typedef uinT16 CLASS_CUTOFF_ARRAY[MAX_NUM_CLASSES];

/**----------------------------------------------------------------------------
          Public Function Prototypes
----------------------------------------------------------------------------**/

/*
#if defined(__STDC__) || defined(__cplusplus)
# define _ARGS(s) s
#else
# define _ARGS(s) ()
#endif*/

/* cutoffs.c
void ReadNewCutoffs
  _ARGS((char *Filename,
  CLASS_CUTOFF_ARRAY Cutoffs));
#undef _ARGS
*/
#endif
 









#if    INTMATCHER_H_DEBUG|1



// Character fragments could be present in the trained templaes
// but turned on/off on the language-by-language basis or depending
// on particular properties of the corpus (e.g. when we expect the
// images to have low exposure).
extern BOOL_VAR_H(disable_character_fragments, FALSE,
                  "Do not include character fragments in the"
                  " results of the classifier");

extern INT_VAR_H(classify_integer_matcher_multiplier, 10,
                 "Integer Matcher Multiplier  0-255:   ");


namespace tesseract {
struct UnicharRating;
}

struct CP_RESULT_STRUCT {
  CP_RESULT_STRUCT() : Rating(0.0f), Class(0) {}

  FLOAT32 Rating;
  CLASS_ID Class;
};

/*----------------------------------------------------------------------------
            Variables
-----------------------------------------------------------------------------*/

extern INT_VAR_H(classify_adapt_proto_thresh, 230,
                 "Threshold for good protos during adaptive 0-255:   ");

extern INT_VAR_H(classify_adapt_feature_thresh, 230,
                 "Threshold for good features during adaptive 0-255:   ");

/**----------------------------------------------------------------------------
          Public Function Prototypes
----------------------------------------------------------------------------**/

#define  SE_TABLE_BITS    9
#define  SE_TABLE_SIZE  512

struct ScratchEvidence {
  uinT8 feature_evidence_[MAX_NUM_CONFIGS];
  int sum_feature_evidence_[MAX_NUM_CONFIGS];
  uinT8 proto_evidence_[MAX_NUM_PROTOS][MAX_PROTO_INDEX];

  void Clear(const INT_CLASS class_template);
  void ClearFeatureEvidence(const INT_CLASS class_template);
  void NormalizeSums(INT_CLASS ClassTemplate, inT16 NumFeatures,
                     inT32 used_features);
  void UpdateSumOfProtoEvidences(
    INT_CLASS ClassTemplate, BIT_VECTOR ConfigMask, inT16 NumFeatures);
};


class IntegerMatcher {
 public:
  // Integer Matcher Theta Fudge (0-255).
  static const int kIntThetaFudge = 128;
  // Bits in Similarity to Evidence Lookup (8-9).
  static const int kEvidenceTableBits = 9;
  // Integer Evidence Truncation Bits (8-14).
  static const int kIntEvidenceTruncBits = 14;
  // Similarity to Evidence Table Exponential Multiplier.
  static const float kSEExponentialMultiplier;
  // Center of Similarity Curve.
  static const float kSimilarityCenter;

  IntegerMatcher() : classify_debug_level_(0) {}

  void Init(tesseract::IntParam *classify_debug_level);

  void Match(INT_CLASS ClassTemplate,
             BIT_VECTOR ProtoMask,
             BIT_VECTOR ConfigMask,
             inT16 NumFeatures,
             const INT_FEATURE_STRUCT* Features,
             tesseract::UnicharRating* Result,
             int AdaptFeatureThreshold,
             int Debug,
             bool SeparateDebugWindows);

  // Applies the CN normalization factor to the given rating and returns
  // the modified rating.
  float ApplyCNCorrection(float rating, int blob_length,
                          int normalization_factor, int matcher_multiplier);

  int FindGoodProtos(INT_CLASS ClassTemplate,
                     BIT_VECTOR ProtoMask,
                     BIT_VECTOR ConfigMask,
                     uinT16 BlobLength,
                     inT16 NumFeatures,
                     INT_FEATURE_ARRAY Features,
                     PROTO_ID *ProtoArray,
                     int AdaptProtoThreshold,
                     int Debug);

  int FindBadFeatures(INT_CLASS ClassTemplate,
                      BIT_VECTOR ProtoMask,
                      BIT_VECTOR ConfigMask,
                      uinT16 BlobLength,
                      inT16 NumFeatures,
                      INT_FEATURE_ARRAY Features,
                      FEATURE_ID *FeatureArray,
                      int AdaptFeatureThreshold,
                      int Debug);

 private:
  int UpdateTablesForFeature(
      INT_CLASS ClassTemplate,
      BIT_VECTOR ProtoMask,
      BIT_VECTOR ConfigMask,
      int FeatureNum,
      const INT_FEATURE_STRUCT* Feature,
      ScratchEvidence *evidence,
      int Debug);

  int FindBestMatch(INT_CLASS ClassTemplate,
                    const ScratchEvidence &tables,
                    tesseract::UnicharRating* Result);

#ifndef GRAPHICS_DISABLED
  void DebugFeatureProtoError(
      INT_CLASS ClassTemplate,
      BIT_VECTOR ProtoMask,
      BIT_VECTOR ConfigMask,
      const ScratchEvidence &tables,
      inT16 NumFeatures,
      int Debug);

  void DisplayProtoDebugInfo(
      INT_CLASS ClassTemplate,
      BIT_VECTOR ProtoMask,
      BIT_VECTOR ConfigMask,
      const ScratchEvidence &tables,
      bool SeparateDebugWindows);

  void DisplayFeatureDebugInfo(
      INT_CLASS ClassTemplate,
      BIT_VECTOR ProtoMask,
      BIT_VECTOR ConfigMask,
      inT16 NumFeatures,
      const INT_FEATURE_STRUCT* Features,
      int AdaptFeatureThreshold,
      int Debug,
      bool SeparateDebugWindows);
#endif


 private:
  uinT8 similarity_evidence_table_[SE_TABLE_SIZE];
  uinT32 evidence_table_mask_;
  uinT32 mult_trunc_shift_bits_;
  uinT32 table_trunc_shift_bits_;
  tesseract::IntParam *classify_debug_level_;
  uinT32 evidence_mult_mask_;
};

/**----------------------------------------------------------------------------
          Private Function Prototypes
----------------------------------------------------------------------------**/
void IMDebugConfiguration(INT_FEATURE FeatureNum,
                          uinT16 ActualProtoNum,
                          uinT8 Evidence,
                          BIT_VECTOR ConfigMask,
                          uinT32 ConfigWord);

void IMDebugConfigurationSum(INT_FEATURE FeatureNum,
                             uinT8 *FeatureEvidence,
                             inT32 ConfigCount);

void HeapSort (int n, register int ra[], register int rb[]);

/**----------------------------------------------------------------------------
        Global Data Definitions and Declarations
----------------------------------------------------------------------------**/
#endif


 




#if  DICT_DAWG_H_DEBUG|1

/*----------------------------------------------------------------------
              I n c l u d e s
----------------------------------------------------------------------*/


#ifndef __GNUC__
#ifdef _WIN32
#define NO_EDGE                (inT64) 0xffffffffffffffffi64
#endif  /*_WIN32*/
#else
#define NO_EDGE                (inT64) 0xffffffffffffffffll
#endif /*__GNUC__*/

/*----------------------------------------------------------------------
              T y p e s
----------------------------------------------------------------------*/
//class UNICHARSET;

typedef uinT64 EDGE_RECORD;
typedef EDGE_RECORD *EDGE_ARRAY;
typedef inT64 EDGE_REF;
typedef inT64 NODE_REF;
typedef EDGE_REF *NODE_MAP;

namespace tesseract {

struct NodeChild {
  UNICHAR_ID unichar_id;
  EDGE_REF edge_ref;
  NodeChild(UNICHAR_ID id, EDGE_REF ref): unichar_id(id), edge_ref(ref) {}
  NodeChild(): unichar_id(INVALID_UNICHAR_ID), edge_ref(NO_EDGE) {}
};

typedef GenericVector<NodeChild> NodeChildVector;
typedef GenericVector<int> SuccessorList;
typedef GenericVector<SuccessorList *> SuccessorListsVector;

enum DawgType {
  DAWG_TYPE_PUNCTUATION,
  DAWG_TYPE_WORD,
  DAWG_TYPE_NUMBER,
  DAWG_TYPE_PATTERN,

  DAWG_TYPE_COUNT  // number of enum entries
};

/*----------------------------------------------------------------------
              C o n s t a n t s
----------------------------------------------------------------------*/

#define FORWARD_EDGE           (inT32) 0
#define BACKWARD_EDGE          (inT32) 1
#define MAX_NODE_EDGES_DISPLAY (inT64) 100
#define MARKER_FLAG            (inT64) 1
#define DIRECTION_FLAG         (inT64) 2
#define WERD_END_FLAG          (inT64) 4
#define LETTER_START_BIT       0
#define NUM_FLAG_BITS          3
#define REFFORMAT "%lld"

static const bool kDawgSuccessors[DAWG_TYPE_COUNT][DAWG_TYPE_COUNT] = {
  { 0, 1, 1, 0 },  // for DAWG_TYPE_PUNCTUATION
  { 1, 0, 0, 0 },  // for DAWG_TYPE_WORD
  { 1, 0, 0, 0 },  // for DAWG_TYPE_NUMBER
  { 0, 0, 0, 0 },  // for DAWG_TYPE_PATTERN
};

static const char kWildcard[] = "*";


/*----------------------------------------------------------------------
              C l a s s e s   a n d   S t r u c t s
----------------------------------------------------------------------*/
//
/// Abstract class (an interface) that declares methods needed by the
/// various tesseract classes to operate on SquishedDawg and Trie objects.
///
/// This class initializes all the edge masks (since their usage by
/// SquishedDawg and Trie is identical) and implements simple accessors
/// for each of the fields encoded in an EDGE_RECORD.
/// This class also implements word_in_dawg() and check_for_words()
/// (since they use only the public methods of SquishedDawg and Trie
/// classes that are inherited from the Dawg base class).
//
class Dawg {
 public:
  /// Magic number to determine endianness when reading the Dawg from file.
  static const inT16 kDawgMagicNumber = 42;
  /// A special unichar id that indicates that any appropriate pattern
  /// (e.g.dicitonary word, 0-9 digit, etc) can be inserted instead
  /// Used for expressing patterns in punctuation and number Dawgs.
  static const UNICHAR_ID kPatternUnicharID = 0;

  inline DawgType type() const { return type_; }
  inline const STRING &lang() const { return lang_; }
  inline PermuterType permuter() const { return perm_; }

  virtual ~Dawg() {}

  /// Returns true if the given word is in the Dawg.
  bool word_in_dawg(const WERD_CHOICE &word) const;

  // Returns true if the given word prefix is not contraindicated by the dawg.
  // If requires_complete is true, then the exact complete word must be present.
  bool prefix_in_dawg(const WERD_CHOICE &prefix, bool requires_complete) const;

  /// Checks the Dawg for the words that are listed in the requested file.
  /// Returns the number of words in the given file missing from the Dawg.
  int check_for_words(const char *filename,
                      const UNICHARSET &unicharset,
                      bool enable_wildcard) const;

  // For each word in the Dawg, call the given (permanent) callback with the
  // text (UTF-8) version of the word.
  void iterate_words(const UNICHARSET &unicharset,
                     TessCallback1<const WERD_CHOICE *> *cb) const;

  // For each word in the Dawg, call the given (permanent) callback with the
  // text (UTF-8) version of the word.
  void iterate_words(const UNICHARSET &unicharset,
                     TessCallback1<const char *> *cb) const;

  // Pure virtual function that should be implemented by the derived classes.

  /// Returns the edge that corresponds to the letter out of this node.
  virtual EDGE_REF edge_char_of(NODE_REF node, UNICHAR_ID unichar_id,
                                bool word_end) const = 0;

  /// Fills the given NodeChildVector with all the unichar ids (and the
  /// corresponding EDGE_REFs) for which there is an edge out of this node.
  virtual void unichar_ids_of(NODE_REF node, NodeChildVector *vec,
                              bool word_end) const = 0;

  /// Returns the next node visited by following the edge
  /// indicated by the given EDGE_REF.
  virtual NODE_REF next_node(EDGE_REF edge_ref) const = 0;

  /// Returns true if the edge indicated by the given EDGE_REF
  /// marks the end of a word.
  virtual bool end_of_word(EDGE_REF edge_ref) const = 0;

  /// Returns UNICHAR_ID stored in the edge indicated by the given EDGE_REF.
  virtual UNICHAR_ID edge_letter(EDGE_REF edge_ref) const = 0;

  /// Prints the contents of the node indicated by the given NODE_REF.
  /// At most max_num_edges will be printed.
  virtual void print_node(NODE_REF node, int max_num_edges) const = 0;

  /// Fills vec with unichar ids that represent the character classes
  /// of the given unichar_id.
  virtual void unichar_id_to_patterns(UNICHAR_ID unichar_id,
                                      const UNICHARSET &unicharset,
                                      GenericVector<UNICHAR_ID> *vec) const {
    (void)unichar_id;
    (void)unicharset;
    (void)vec;
  }

  /// Returns the given EDGE_REF if the EDGE_RECORD that it points to has
  /// a self loop and the given unichar_id matches the unichar_id stored in the
  /// EDGE_RECORD, returns NO_EDGE otherwise.
  virtual EDGE_REF pattern_loop_edge(
      EDGE_REF edge_ref, UNICHAR_ID unichar_id, bool word_end) const {
    (void)edge_ref;
    (void)unichar_id;
    (void)word_end;
    return false;
  }

 protected:
  Dawg() {}

  /// Returns the next node visited by following this edge.
  inline NODE_REF next_node_from_edge_rec(const EDGE_RECORD &edge_rec) const {
    return ((edge_rec & next_node_mask_) >> next_node_start_bit_);
  }
  /// Returns the marker flag of this edge.
  inline bool marker_flag_from_edge_rec(const EDGE_RECORD &edge_rec) const {
    return (edge_rec & (MARKER_FLAG << flag_start_bit_)) != 0;
  }
  /// Returns the direction flag of this edge.
  inline int direction_from_edge_rec(const EDGE_RECORD &edge_rec) const {
    return ((edge_rec & (DIRECTION_FLAG << flag_start_bit_))) ?
      BACKWARD_EDGE : FORWARD_EDGE;
  }
  /// Returns true if this edge marks the end of a word.
  inline bool end_of_word_from_edge_rec(const EDGE_RECORD &edge_rec) const {
    return (edge_rec & (WERD_END_FLAG << flag_start_bit_)) != 0;
  }
  /// Returns UNICHAR_ID recorded in this edge.
  inline UNICHAR_ID unichar_id_from_edge_rec(
      const EDGE_RECORD &edge_rec) const {
    return ((edge_rec & letter_mask_) >> LETTER_START_BIT);
  }
  /// Sets the next node link for this edge in the Dawg.
  inline void set_next_node_in_edge_rec(
      EDGE_RECORD *edge_rec, EDGE_REF value) {
    *edge_rec &= (~next_node_mask_);
    *edge_rec |= ((value << next_node_start_bit_) & next_node_mask_);
  }
  /// Sets this edge record to be the last one in a sequence of edges.
  inline void set_marker_flag_in_edge_rec(EDGE_RECORD *edge_rec) {
    *edge_rec |= (MARKER_FLAG << flag_start_bit_);
  }
  /// Sequentially compares the given values of unichar ID, next node
  /// and word end marker with the values in the given EDGE_RECORD.
  /// Returns: 1 if at any step the given input value exceeds
  ///            that of edge_rec (and all the values already
  ///            checked are the same)
  ///          0 if edge_rec_match() returns true
  ///         -1 otherwise
  inline int given_greater_than_edge_rec(NODE_REF next_node,
                                         bool word_end,
                                         UNICHAR_ID unichar_id,
                                         const EDGE_RECORD &edge_rec) const {
    UNICHAR_ID curr_unichar_id = unichar_id_from_edge_rec(edge_rec);
    NODE_REF curr_next_node = next_node_from_edge_rec(edge_rec);
    bool curr_word_end = end_of_word_from_edge_rec(edge_rec);
    if (edge_rec_match(next_node, word_end, unichar_id, curr_next_node,
                       curr_word_end, curr_unichar_id)) return 0;
    if (unichar_id > curr_unichar_id) return 1;
    if (unichar_id == curr_unichar_id) {
      if (next_node > curr_next_node) return 1;
      if (next_node == curr_next_node) {
        if (word_end > curr_word_end) return 1;
      }
    }
    return -1;
  }
  /// Returns true if all the values are equal (any value matches
  /// next_node if next_node == NO_EDGE, any value matches word_end
  /// if word_end is false).
  inline bool edge_rec_match(NODE_REF next_node,
                             bool word_end,
                             UNICHAR_ID unichar_id,
                             NODE_REF other_next_node,
                             bool other_word_end,
                             UNICHAR_ID other_unichar_id) const {
    return ((unichar_id == other_unichar_id) &&
            (next_node == NO_EDGE || next_node == other_next_node) &&
            (!word_end || (word_end == other_word_end)));
  }

  /// Sets type_, lang_, perm_, unicharset_size_.
  /// Initializes the values of various masks from unicharset_size_.
  void init(DawgType type, const STRING &lang,
            PermuterType perm, int unicharset_size, int debug_level);

  /// Matches all of the words that are represented by this string.
  /// If wilcard is set to something other than INVALID_UNICHAR_ID,
  /// the *'s in this string are interpreted as wildcards.
  /// WERD_CHOICE param is not passed by const so that wildcard searches
  /// can modify it and work without having to copy WERD_CHOICEs.
  bool match_words(WERD_CHOICE *word, inT32 index,
                   NODE_REF node, UNICHAR_ID wildcard) const;

  // Recursively iterate over all words in a dawg (see public iterate_words).
  void iterate_words_rec(const WERD_CHOICE &word_so_far,
                         NODE_REF to_explore,
                         TessCallback1<const WERD_CHOICE *> *cb) const;

  // Member Variables.
  DawgType type_;
  STRING lang_;
  /// Permuter code that should be used if the word is found in this Dawg.
  PermuterType perm_;
  // Variables to construct various edge masks. Formerly:
  // #define NEXT_EDGE_MASK (inT64) 0xfffffff800000000i64
  // #define FLAGS_MASK     (inT64) 0x0000000700000000i64
  // #define LETTER_MASK    (inT64) 0x00000000ffffffffi64
  int unicharset_size_;
  int flag_start_bit_;
  int next_node_start_bit_;
  uinT64 next_node_mask_;
  uinT64 flags_mask_;
  uinT64 letter_mask_;
  // Level of debug statements to print to stdout.
  int debug_level_;
};

//
// DawgPosition keeps track of where we are in the primary dawg we're searching
// as well as where we may be in the "punctuation dawg" which may provide
// surrounding context.
//
// Example:
//   punctuation dawg  -- space is the "pattern character"
//     " "     // no punctuation
//     "' '"   // leading and trailing apostrophes
//     " '"    // trailing apostrophe
//   word dawg:
//     "cat"
//     "cab"
//     "cat's"
//
//  DawgPosition(dawg_index, dawg_ref, punc_index, punc_ref, rtp)
//
//  DawgPosition(-1, NO_EDGE, p, pe, false)
//    We're in the punctuation dawg, no other dawg has been started.
//    (1) If there's a pattern edge as a punc dawg child of us,
//        for each punc-following dawg starting with ch, produce:
//        Result: DawgPosition(k, w, p', false)
//    (2) If there's a valid continuation in the punc dawg, produce:
//        Result: DawgPosition(-k, NO_EDGE, p', false)
//
//  DawgPosition(k, w, -1, NO_EDGE, false)
//    We're in dawg k.  Going back to punctuation dawg is not an option.
//    Follow ch in dawg k.
//
//  DawgPosition(k, w, p, pe, false)
//    We're in dawg k.  Continue in dawg k and/or go back to the punc dawg.
//    If ending, check that the punctuation dawg is also ok to end here.
//
//  DawgPosition(k, w, p, pe true)
//    We're back in the punctuation dawg.  Continuing there is the only option.
struct DawgPosition {
  DawgPosition()
      : dawg_index(-1), dawg_ref(NO_EDGE), punc_ref(NO_EDGE),
        back_to_punc(false) {}
  DawgPosition(int dawg_idx, EDGE_REF dawgref,
               int punc_idx, EDGE_REF puncref,
               bool backtopunc)
      : dawg_index(dawg_idx), dawg_ref(dawgref),
        punc_index(punc_idx), punc_ref(puncref),
        back_to_punc(backtopunc) {
  }
  bool operator==(const DawgPosition &other) {
    return dawg_index == other.dawg_index &&
        dawg_ref == other.dawg_ref &&
        punc_index == other.punc_index &&
        punc_ref == other.punc_ref &&
        back_to_punc == other.back_to_punc;
  }

  inT8 dawg_index;
  EDGE_REF dawg_ref;
  inT8 punc_index;
  EDGE_REF punc_ref;
  // Have we returned to the punc dawg at the end of the word?
  bool back_to_punc;
};

class DawgPositionVector : public GenericVector<DawgPosition> {
 public:
  /// Overload clear() in order to avoid allocating/deallocating memory
  /// when clearing the vector and re-inserting entries into it later.
  void clear() { size_used_ = 0; }
  /// Adds an entry for the given dawg_index with the given node to the vec.
  /// Returns false if the same entry already exists in the vector,
  /// true otherwise.
  inline bool add_unique(const DawgPosition &new_pos,
                         bool debug,
                         const char *debug_msg) {
    for (int i = 0; i < size_used_; ++i) {
      if (data_[i] == new_pos) return false;
    }
    push_back(new_pos);
    if (debug) {
      tprintf("%s[%d, " REFFORMAT "] [punc: " REFFORMAT "%s]\n",
              debug_msg, new_pos.dawg_index, new_pos.dawg_ref,
              new_pos.punc_ref, new_pos.back_to_punc ? " returned" : "");
    }
    return true;
  }
};

//
/// Concrete class that can operate on a compacted (squished) Dawg (read,
/// search and write to file). This class is read-only in the sense that
/// new words can not be added to an instance of SquishedDawg.
/// The underlying representation of the nodes and edges in SquishedDawg
/// is stored as a contiguous EDGE_ARRAY (read from file or given as an
/// argument to the constructor).
//
class SquishedDawg : public Dawg {
 public:
  SquishedDawg(FILE *file, DawgType type, const STRING &lang,
               PermuterType perm, int debug_level) {
    read_squished_dawg(file, type, lang, perm, debug_level);
    num_forward_edges_in_node0 = num_forward_edges(0);
  }
  SquishedDawg(const char* filename, DawgType type,
               const STRING &lang, PermuterType perm, int debug_level) {
    FILE *file = fopen(filename, "rb");
    if (file == NULL) {
      tprintf("Failed to open dawg file %s\n", filename);
      exit(1);
    }
    read_squished_dawg(file, type, lang, perm, debug_level);
    num_forward_edges_in_node0 = num_forward_edges(0);
    fclose(file);
  }
  SquishedDawg(EDGE_ARRAY edges, int num_edges, DawgType type,
               const STRING &lang, PermuterType perm,
               int unicharset_size, int debug_level) :
    edges_(edges), num_edges_(num_edges) {
    init(type, lang, perm, unicharset_size, debug_level);
    num_forward_edges_in_node0 = num_forward_edges(0);
    if (debug_level > 3) print_all("SquishedDawg:");
  }
  ~SquishedDawg();

  int NumEdges() { return num_edges_; }

  /// Returns the edge that corresponds to the letter out of this node.
  EDGE_REF edge_char_of(NODE_REF node, UNICHAR_ID unichar_id,
                        bool word_end) const;

  /// Fills the given NodeChildVector with all the unichar ids (and the
  /// corresponding EDGE_REFs) for which there is an edge out of this node.
  void unichar_ids_of(NODE_REF node, NodeChildVector *vec,
                      bool word_end) const {
    EDGE_REF edge = node;
    if (!edge_occupied(edge) || edge == NO_EDGE) return;
    assert(forward_edge(edge));  // we don't expect any backward edges to
    do {                         // be present when this function is called
      if (!word_end || end_of_word_from_edge_rec(edges_[edge])) {
        vec->push_back(NodeChild(unichar_id_from_edge_rec(edges_[edge]), edge));
      }
    } while (!last_edge(edge++));
  }

  /// Returns the next node visited by following the edge
  /// indicated by the given EDGE_REF.
  NODE_REF next_node(EDGE_REF edge) const {
    return next_node_from_edge_rec((edges_[edge]));
  }

  /// Returns true if the edge indicated by the given EDGE_REF
  /// marks the end of a word.
  bool end_of_word(EDGE_REF edge_ref) const {
    return end_of_word_from_edge_rec((edges_[edge_ref]));
  }

  /// Returns UNICHAR_ID stored in the edge indicated by the given EDGE_REF.
  UNICHAR_ID edge_letter(EDGE_REF edge_ref) const {
    return unichar_id_from_edge_rec((edges_[edge_ref]));
  }

  /// Prints the contents of the node indicated by the given NODE_REF.
  /// At most max_num_edges will be printed.
  void print_node(NODE_REF node, int max_num_edges) const;

  /// Writes the squished/reduced Dawg to a file.
  void write_squished_dawg(FILE *file);

  /// Opens the file with the given filename and writes the
  /// squished/reduced Dawg to the file.
  void write_squished_dawg(const char *filename) {
    FILE *file = fopen(filename, "wb");
    if (file == NULL) {
      tprintf("Error opening %s\n", filename);
      exit(1);
    }
    this->write_squished_dawg(file);
    fclose(file);
  }

 private:
  /// Sets the next node link for this edge.
  inline void set_next_node(EDGE_REF edge_ref, EDGE_REF value) {
    set_next_node_in_edge_rec(&(edges_[edge_ref]), value);
  }
  /// Sets the edge to be empty.
  inline void set_empty_edge(EDGE_REF edge_ref) {
    (edges_[edge_ref] = next_node_mask_);
  }
  /// Goes through all the edges and clears each one out.
  inline void clear_all_edges() {
    for (int edge = 0; edge < num_edges_; edge++) set_empty_edge(edge);
  }
  /// Clears the last flag of this edge.
  inline void clear_marker_flag(EDGE_REF edge_ref) {
     (edges_[edge_ref] &= ~(MARKER_FLAG << flag_start_bit_));
  }
  /// Returns true if this edge is in the forward direction.
  inline bool forward_edge(EDGE_REF edge_ref) const {
    return (edge_occupied(edge_ref) &&
            (FORWARD_EDGE == direction_from_edge_rec(edges_[edge_ref])));
  }
  /// Returns true if this edge is in the backward direction.
  inline bool backward_edge(EDGE_REF edge_ref) const {
    return (edge_occupied(edge_ref) &&
            (BACKWARD_EDGE == direction_from_edge_rec(edges_[edge_ref])));
  }
  /// Returns true if the edge spot in this location is occupied.
  inline bool edge_occupied(EDGE_REF edge_ref) const {
    return (edges_[edge_ref] != next_node_mask_);
  }
  /// Returns true if this edge is the last edge in a sequence.
  inline bool last_edge(EDGE_REF edge_ref) const {
    return (edges_[edge_ref] & (MARKER_FLAG << flag_start_bit_)) != 0;
  }

  /// Counts and returns the number of forward edges in this node.
  inT32 num_forward_edges(NODE_REF node) const;

  /// Reads SquishedDawg from a file.
  void read_squished_dawg(FILE *file, DawgType type, const STRING &lang,
                          PermuterType perm, int debug_level);

  /// Prints the contents of an edge indicated by the given EDGE_REF.
  void print_edge(EDGE_REF edge) const;

  /// Prints the contents of the SquishedDawg.
  void print_all(const char* msg) {
    tprintf("\n__________________________\n%s\n", msg);
    for (int i = 0; i < num_edges_; ++i) print_edge(i);
    tprintf("__________________________\n");
  }
  /// Constructs a mapping from the memory node indices to disk node indices.
  NODE_MAP build_node_map(inT32 *num_nodes) const;


  // Member variables.
  EDGE_ARRAY edges_;
  int num_edges_;
  int num_forward_edges_in_node0;
};

}  // namespace tesseract



#endif  // DICT_DAWG_H_


 



 



#if   STOPPER_H_DEBUG|1
 
/*----------------------------------------------------------------------------
          Include Files and Type Defines
----------------------------------------------------------------------------*/



typedef uinT8 BLOB_WIDTH;

struct DANGERR_INFO {
  DANGERR_INFO() :
    begin(-1), end(-1), dangerous(false), correct_is_ngram(false),
    leftmost(INVALID_UNICHAR_ID) {}
  DANGERR_INFO(int b, int e, bool d, bool n, UNICHAR_ID l) :
    begin(b), end(e), dangerous(d), correct_is_ngram(n), leftmost(l) {}
  int begin;
  int end;
  bool dangerous;
  bool correct_is_ngram;
  UNICHAR_ID leftmost;   // in the replacement, what's the leftmost character?
};

typedef GenericVector<DANGERR_INFO> DANGERR;


#endif

 






#if    TRIE_H_DEBUG|1



//class UNICHARSET;

// Note: if we consider either NODE_REF or EDGE_INDEX to ever exceed
// max int32, we will need to change GenericVector to use int64 for size
// and address indices. This does not seem to be needed immediately,
// since currently the largest number of edges limit used by tesseract
// (kMaxNumEdges in wordlist2dawg.cpp) is far less than max int32.
// There are also int casts below to satisfy the WIN32 compiler that would
// need to be changed.
// It might be cleanest to change the types of most of the Trie/Dawg related
// typedefs to int and restrict the casts to extracting these values from
// the 64 bit EDGE_RECORD.
typedef inT64 EDGE_INDEX;  // index of an edge in a given node
typedef bool *NODE_MARKER;
typedef GenericVector<EDGE_RECORD> EDGE_VECTOR;

struct TRIE_NODE_RECORD {
  EDGE_VECTOR forward_edges;
  EDGE_VECTOR backward_edges;
};
typedef GenericVector<TRIE_NODE_RECORD *> TRIE_NODES;

namespace tesseract {

/**
 * Concrete class for Trie data structure that allows to store a list of
 * words (extends Dawg base class) as well as dynamically add new words.
 * This class stores a vector of pointers to TRIE_NODE_RECORDs, each of
 * which has a vector of forward and backward edges.
 */
class Trie : public Dawg {
 public:
  enum RTLReversePolicy {
    RRP_DO_NO_REVERSE,
    RRP_REVERSE_IF_HAS_RTL,
    RRP_FORCE_REVERSE,
  };

  // Minimum number of concrete characters at the beginning of user patterns.
  static const int kSaneNumConcreteChars = 0;
  // Various unicode whitespace characters are used to denote unichar patterns,
  // (character classifier would never produce these whitespace characters as a
  // valid classification).
  static const char kAlphaPatternUnicode[];
  static const char kDigitPatternUnicode[];
  static const char kAlphanumPatternUnicode[];
  static const char kPuncPatternUnicode[];
  static const char kLowerPatternUnicode[];
  static const char kUpperPatternUnicode[];

  static const char *get_reverse_policy_name(
      RTLReversePolicy reverse_policy);

  // max_num_edges argument allows limiting the amount of memory this
  // Trie can consume (if a new word insert would cause the Trie to
  // contain more edges than max_num_edges, all the edges are cleared
  // so that new inserts can proceed).
  Trie(DawgType type, const STRING &lang, PermuterType perm,
       int unicharset_size, int debug_level) {
    init(type, lang, perm, unicharset_size, debug_level);
    num_edges_ = 0;
    deref_node_index_mask_ = ~letter_mask_;
    new_dawg_node();  // need to allocate node 0
    initialized_patterns_ = false;
  }
  virtual ~Trie() { nodes_.delete_data_pointers(); }

  // Reset the Trie to empty.
  void clear();

  /** Returns the edge that corresponds to the letter out of this node. */
  EDGE_REF edge_char_of(NODE_REF node_ref, UNICHAR_ID unichar_id,
                        bool word_end) const {
    EDGE_RECORD *edge_ptr;
    EDGE_INDEX edge_index;
    if (!edge_char_of(node_ref, NO_EDGE, FORWARD_EDGE, word_end, unichar_id,
                      &edge_ptr, &edge_index)) return NO_EDGE;
    return make_edge_ref(node_ref, edge_index);
  }

  /**
   * Fills the given NodeChildVector with all the unichar ids (and the
   * corresponding EDGE_REFs) for which there is an edge out of this node.
   */
  void unichar_ids_of(NODE_REF node, NodeChildVector *vec,
                      bool word_end) const {
    const EDGE_VECTOR &forward_edges =
      nodes_[static_cast<int>(node)]->forward_edges;
    for (int i = 0; i < forward_edges.size(); ++i) {
      if (!word_end || end_of_word_from_edge_rec(forward_edges[i])) {
        vec->push_back(NodeChild(unichar_id_from_edge_rec(forward_edges[i]),
                                 make_edge_ref(node, i)));
      }
    }
  }

  /**
   * Returns the next node visited by following the edge
   * indicated by the given EDGE_REF.
   */
  NODE_REF next_node(EDGE_REF edge_ref) const {
    if (edge_ref == NO_EDGE || num_edges_ == 0) return NO_EDGE;
    return next_node_from_edge_rec(*deref_edge_ref(edge_ref));
  }

  /**
   * Returns true if the edge indicated by the given EDGE_REF
   * marks the end of a word.
   */
  bool end_of_word(EDGE_REF edge_ref) const {
    if (edge_ref == NO_EDGE || num_edges_ == 0) return false;
    return end_of_word_from_edge_rec(*deref_edge_ref(edge_ref));
  }

  /** Returns UNICHAR_ID stored in the edge indicated by the given EDGE_REF. */
  UNICHAR_ID edge_letter(EDGE_REF edge_ref) const {
    if (edge_ref == NO_EDGE || num_edges_ == 0) return INVALID_UNICHAR_ID;
    return unichar_id_from_edge_rec(*deref_edge_ref(edge_ref));
  }
  // Sets the UNICHAR_ID in the given edge_rec to unicharset_size_, marking
  // the edge dead.
  void KillEdge(EDGE_RECORD* edge_rec) const {
    *edge_rec &= ~letter_mask_;
    *edge_rec |= (unicharset_size_ << LETTER_START_BIT);
  }
  bool DeadEdge(const EDGE_RECORD& edge_rec) const {
    return unichar_id_from_edge_rec(edge_rec) == unicharset_size_;
  }

  // Prints the contents of the node indicated by the given NODE_REF.
  // At most max_num_edges will be printed.
  void print_node(NODE_REF node, int max_num_edges) const;

  // Writes edges from nodes_ to an EDGE_ARRAY and creates a SquishedDawg.
  // Eliminates redundant edges and returns the pointer to the SquishedDawg.
  // Note: the caller is responsible for deallocating memory associated
  // with the returned SquishedDawg pointer.
  SquishedDawg *trie_to_dawg();

  // Reads a list of words from the given file and adds into the Trie.
  // Calls WERD_CHOICE::reverse_unichar_ids_if_rtl() according to the reverse
  // policy and information in the unicharset.
  // Returns false on error.
  bool read_and_add_word_list(const char *filename,
                              const UNICHARSET &unicharset,
                              Trie::RTLReversePolicy reverse);

  // Reads a list of words from the given file, applying the reverse_policy,
  // according to information in the unicharset.
  // Returns false on error.
  bool read_word_list(const char *filename,
                      const UNICHARSET &unicharset,
                      Trie::RTLReversePolicy reverse_policy,
                      GenericVector<STRING>* words);
  // Adds a list of words previously read using read_word_list to the trie
  // using the given unicharset to convert to unichar-ids.
  // Returns false on error.
  bool add_word_list(const GenericVector<STRING>& words,
                     const UNICHARSET &unicharset);

  // Inserts the list of patterns from the given file into the Trie.
  // The pattern list file should contain one pattern per line in UTF-8 format.
  //
  // Each pattern can contain any non-whitespace characters, however only the
  // patterns that contain characters from the unicharset of the corresponding
  // language will be useful.
  // The only meta character is '\'. To be used in a pattern as an ordinary
  // string it should be escaped with '\' (e.g. string "C:\Documents" should
  // be written in the patterns file as "C:\\Documents").
  // This function supports a very limited regular expression syntax. One can
  // express a character, a certain character class and a number of times the
  // entity should be repeated in the pattern.
  //
  // To denote a character class use one of:
  // \c - unichar for which UNICHARSET::get_isalpha() is true (character)
  // \d - unichar for which UNICHARSET::get_isdigit() is true
  // \n - unichar for which UNICHARSET::get_isdigit() and
  //      UNICHARSET::isalpha() are true
  // \p - unichar for which UNICHARSET::get_ispunct() is true
  // \a - unichar for which UNICHARSET::get_islower() is true
  // \A - unichar for which UNICHARSET::get_isupper() is true
  //
  // \* could be specified after each character or pattern to indicate that
  // the character/pattern can be repeated any number of times before the next
  // character/pattern occurs.
  //
  // Examples:
  // 1-8\d\d-GOOG-411 will be expanded to strings:
  // 1-800-GOOG-411, 1-801-GOOG-411, ... 1-899-GOOG-411.
  //
  // http://www.\n\*.com will be expanded to strings like:
  // http://www.a.com http://www.a123.com ... http://www.ABCDefgHIJKLMNop.com
  //
  // Note: In choosing which patterns to include please be aware of the fact
  // providing very generic patterns will make tesseract run slower.
  // For example \n\* at the beginning of the pattern will make Tesseract
  // consider all the combinations of proposed character choices for each
  // of the segmentations, which will be unacceptably slow.
  // Because of potential problems with speed that could be difficult to
  // identify, each user pattern has to have at least kSaneNumConcreteChars
  // concrete characters from the unicharset at the beginning.
  bool read_pattern_list(const char *filename, const UNICHARSET &unicharset);

  // Initializes the values of *_pattern_ unichar ids.
  // This function should be called before calling read_pattern_list().
  void initialize_patterns(UNICHARSET *unicharset);

  // Fills in the given unichar id vector with the unichar ids that represent
  // the patterns of the character classes of the given unichar_id.
  void unichar_id_to_patterns(UNICHAR_ID unichar_id,
                              const UNICHARSET &unicharset,
                              GenericVector<UNICHAR_ID> *vec) const;

  // Returns the given EDGE_REF if the EDGE_RECORD that it points to has
  // a self loop and the given unichar_id matches the unichar_id stored in the
  // EDGE_RECORD, returns NO_EDGE otherwise.
  virtual EDGE_REF pattern_loop_edge(EDGE_REF edge_ref,
                                     UNICHAR_ID unichar_id,
                                     bool word_end) const {
    if (edge_ref == NO_EDGE) return NO_EDGE;
    EDGE_RECORD *edge_rec = deref_edge_ref(edge_ref);
    return (marker_flag_from_edge_rec(*edge_rec) &&
            unichar_id == unichar_id_from_edge_rec(*edge_rec) &&
            word_end == end_of_word_from_edge_rec(*edge_rec)) ?
            edge_ref : NO_EDGE;
  }

  // Adds a word to the Trie (creates the necessary nodes and edges).
  //
  // If repetitions vector is not NULL, each entry in the vector indicates
  // whether the unichar id with the corresponding index in the word is allowed
  // to repeat an unlimited number of times. For each entry that is true, MARKER
  // flag of the corresponding edge created for this unichar id is set to true).
  //
  // Return true if add succeeded, false otherwise (e.g. when a word contained
  // an invalid unichar id or the trie was getting too large and was cleared).
  bool add_word_to_dawg(const WERD_CHOICE &word,
                        const GenericVector<bool> *repetitions);
  bool add_word_to_dawg(const WERD_CHOICE &word) {
    return add_word_to_dawg(word, NULL);
  }

 protected:
  // The structure of an EDGE_REF for Trie edges is as follows:
  // [LETTER_START_BIT, flag_start_bit_):
  //                             edge index in *_edges in a TRIE_NODE_RECORD
  // [flag_start_bit, 30th bit]: node index in nodes (TRIE_NODES vector)
  //
  // With this arrangement there are enough bits to represent edge indices
  // (each node can have at most unicharset_size_ forward edges and
  // the position of flag_start_bit is set to be log2(unicharset_size_)).
  // It is also possible to accommodate a maximum number of nodes that is at
  // least as large as that of the SquishedDawg representation (in SquishedDawg
  // each EDGE_RECORD has 32-(flag_start_bit+NUM_FLAG_BITS) bits to represent
  // the next node index).
  //

  // Returns the pointer to EDGE_RECORD after decoding the location
  // of the edge from the information in the given EDGE_REF.
  // This function assumes that EDGE_REF holds valid node/edge indices.
  inline EDGE_RECORD *deref_edge_ref(EDGE_REF edge_ref) const {
    int edge_index = static_cast<int>(
      (edge_ref & letter_mask_) >> LETTER_START_BIT);
    int node_index = static_cast<int>(
      (edge_ref & deref_node_index_mask_) >> flag_start_bit_);
    TRIE_NODE_RECORD *node_rec = nodes_[node_index];
    return &(node_rec->forward_edges[edge_index]);
  }
  /** Constructs EDGE_REF from the given node_index and edge_index. */
  inline EDGE_REF make_edge_ref(NODE_REF node_index,
                                EDGE_INDEX edge_index) const {
    return ((node_index << flag_start_bit_) |
            (edge_index << LETTER_START_BIT));
  }
  /** Sets up this edge record to the requested values. */
  inline void link_edge(EDGE_RECORD *edge, NODE_REF nxt, bool repeats,
                        int direction, bool word_end, UNICHAR_ID unichar_id) {
    EDGE_RECORD flags = 0;
    if (repeats) flags |= MARKER_FLAG;
    if (word_end) flags |= WERD_END_FLAG;
    if (direction == BACKWARD_EDGE) flags |= DIRECTION_FLAG;
    *edge = ((nxt << next_node_start_bit_) |
             (static_cast<EDGE_RECORD>(flags) << flag_start_bit_) |
             (static_cast<EDGE_RECORD>(unichar_id) << LETTER_START_BIT));
  }
  /** Prints the given EDGE_RECORD. */
  inline void print_edge_rec(const EDGE_RECORD &edge_rec) const {
    tprintf("|" REFFORMAT "|%s%s%s|%d|", next_node_from_edge_rec(edge_rec),
            marker_flag_from_edge_rec(edge_rec) ? "R," : "",
            (direction_from_edge_rec(edge_rec) == FORWARD_EDGE) ? "F" : "B",
            end_of_word_from_edge_rec(edge_rec) ? ",E" : "",
            unichar_id_from_edge_rec(edge_rec));
  }
  // Returns true if the next node in recorded the given EDGE_RECORD
  // has exactly one forward edge.
  inline bool can_be_eliminated(const EDGE_RECORD &edge_rec) {
    NODE_REF node_ref = next_node_from_edge_rec(edge_rec);
    return (node_ref != NO_EDGE &&
            nodes_[static_cast<int>(node_ref)]->forward_edges.size() == 1);
  }

  // Prints the contents of the Trie.
  // At most max_num_edges will be printed for each node.
  void print_all(const char* msg, int max_num_edges) {
    tprintf("\n__________________________\n%s\n", msg);
    for (int i = 0; i < nodes_.size(); ++i) print_node(i, max_num_edges);
    tprintf("__________________________\n");
  }

  // Finds the edge with the given direction, word_end and unichar_id
  // in the node indicated by node_ref. Fills in the pointer to the
  // EDGE_RECORD and the index of the edge with the the values
  // corresponding to the edge found. Returns true if an edge was found.
  bool edge_char_of(NODE_REF node_ref, NODE_REF next_node,
                    int direction, bool word_end, UNICHAR_ID unichar_id,
                    EDGE_RECORD **edge_ptr, EDGE_INDEX *edge_index) const;

  // Adds an single edge linkage between node1 and node2 in the direction
  // indicated by direction argument.
  bool add_edge_linkage(NODE_REF node1, NODE_REF node2, bool repeats,
                        int direction, bool word_end,
                        UNICHAR_ID unichar_id);

  // Adds forward edge linkage from node1 to node2 and the corresponding
  // backward edge linkage in the other direction.
  bool add_new_edge(NODE_REF node1, NODE_REF node2,
                    bool repeats, bool word_end, UNICHAR_ID unichar_id) {
    return (add_edge_linkage(node1, node2, repeats, FORWARD_EDGE,
                             word_end, unichar_id) &&
            add_edge_linkage(node2, node1, repeats, BACKWARD_EDGE,
                             word_end, unichar_id));
  }

  // Sets the word ending flags in an already existing edge pair.
  // Returns true on success.
  void add_word_ending(EDGE_RECORD *edge,
                       NODE_REF the_next_node,
                       bool repeats,
                       UNICHAR_ID unichar_id);

  // Allocates space for a new node in the Trie.
  NODE_REF new_dawg_node();

  // Removes a single edge linkage to between node1 and node2 in the
  // direction indicated by direction argument.
  void remove_edge_linkage(NODE_REF node1, NODE_REF node2, int direction,
                           bool word_end, UNICHAR_ID unichar_id);

  // Removes forward edge linkage from node1 to node2 and the corresponding
  // backward edge linkage in the other direction.
  void remove_edge(NODE_REF node1, NODE_REF node2,
                   bool word_end, UNICHAR_ID unichar_id) {
    remove_edge_linkage(node1, node2, FORWARD_EDGE, word_end, unichar_id);
    remove_edge_linkage(node2, node1, BACKWARD_EDGE, word_end, unichar_id);
  }

  // Compares edge1 and edge2 in the given node to see if they point to two
  // next nodes that could be collapsed. If they do, performs the reduction
  // and returns true.
  bool eliminate_redundant_edges(NODE_REF node, const EDGE_RECORD &edge1,
                                 const EDGE_RECORD &edge2);

  // Assuming that edge_index indicates the first edge in a group of edges
  // in this node with a particular letter value, looks through these edges
  // to see if any of them can be collapsed. If so does it. Returns to the
  // caller when all edges with this letter have been reduced.
  // Returns true if further reduction is possible with this same letter.
  bool reduce_lettered_edges(EDGE_INDEX edge_index,
                             UNICHAR_ID unichar_id,
                             NODE_REF node,
                             EDGE_VECTOR* backward_edges,
                             NODE_MARKER reduced_nodes);

  /** 
   * Order num_edges of consequtive EDGE_RECORDS in the given EDGE_VECTOR in
   * increasing order of unichar ids. This function is normally called
   * for all edges in a single node, and since number of edges in each node
   * is usually quite small, selection sort is used.
   */
  void sort_edges(EDGE_VECTOR *edges);

  /** Eliminates any redundant edges from this node in the Trie. */
  void reduce_node_input(NODE_REF node, NODE_MARKER reduced_nodes);

  // Returns the pattern unichar id for the given character class code.
  UNICHAR_ID character_class_to_pattern(char ch);

  // Member variables
  TRIE_NODES nodes_;              // vector of nodes in the Trie
  uinT64 num_edges_;              // sum of all edges (forward and backward)
  uinT64 deref_direction_mask_;   // mask for EDGE_REF to extract direction
  uinT64 deref_node_index_mask_;  // mask for EDGE_REF to extract node index
  // Freelist of edges in the root backwards node that were previously zeroed.
  GenericVector<EDGE_INDEX> root_back_freelist_;
  // Variables for translating character class codes denoted in user patterns
  // file to the unichar ids used to represent them in a Trie.
  bool initialized_patterns_;
  UNICHAR_ID alpha_pattern_;
  UNICHAR_ID digit_pattern_;
  UNICHAR_ID alphanum_pattern_;
  UNICHAR_ID punc_pattern_;
  UNICHAR_ID lower_pattern_;
  UNICHAR_ID upper_pattern_;
};
}  // namespace tesseract

#endif

 





#if  TESSERACT_WORDREC_PARAMS_TRAINING_FEATDEF_H_DEBUG|1



namespace tesseract {

// Maximum number of unichars in the small and medium sized words
static const int kMaxSmallWordUnichars = 3;
static const int kMaxMediumWordUnichars = 6;

// Raw features extracted from a single OCR hypothesis.
// The features are normalized (by outline length or number of unichars as
// appropriate) real-valued quantities with unbounded range and
// unknown distribution.
// Normalization / binarization of these features is done at a later stage.
// Note: when adding new fields to this enum make sure to modify
// kParamsTrainingFeatureTypeName
enum kParamsTrainingFeatureType {
  // Digits
  PTRAIN_DIGITS_SHORT,             // 0
  PTRAIN_DIGITS_MED,               // 1
  PTRAIN_DIGITS_LONG,              // 2
  // Number or pattern (NUMBER_PERM, USER_PATTERN_PERM)
  PTRAIN_NUM_SHORT,                // 3
  PTRAIN_NUM_MED,                  // 4
  PTRAIN_NUM_LONG,                 // 5
  // Document word (DOC_DAWG_PERM)
  PTRAIN_DOC_SHORT,                // 6
  PTRAIN_DOC_MED,                  // 7
  PTRAIN_DOC_LONG,                 // 8
  // Word (SYSTEM_DAWG_PERM, USER_DAWG_PERM, COMPOUND_PERM)
  PTRAIN_DICT_SHORT,               // 9
  PTRAIN_DICT_MED,                 // 10
  PTRAIN_DICT_LONG,                // 11
  // Frequent word (FREQ_DAWG_PERM)
  PTRAIN_FREQ_SHORT,               // 12
  PTRAIN_FREQ_MED,                 // 13
  PTRAIN_FREQ_LONG,                // 14
  PTRAIN_SHAPE_COST_PER_CHAR,      // 15
  PTRAIN_NGRAM_COST_PER_CHAR,      // 16
  PTRAIN_NUM_BAD_PUNC,             // 17
  PTRAIN_NUM_BAD_CASE,             // 18
  PTRAIN_XHEIGHT_CONSISTENCY,      // 19
  PTRAIN_NUM_BAD_CHAR_TYPE,        // 20
  PTRAIN_NUM_BAD_SPACING,          // 21
  PTRAIN_NUM_BAD_FONT,             // 22
  PTRAIN_RATING_PER_CHAR,          // 23

  PTRAIN_NUM_FEATURE_TYPES
};

static const char * const kParamsTrainingFeatureTypeName[] = {
    "PTRAIN_DIGITS_SHORT",             // 0
    "PTRAIN_DIGITS_MED",               // 1
    "PTRAIN_DIGITS_LONG",              // 2
    "PTRAIN_NUM_SHORT",                // 3
    "PTRAIN_NUM_MED",                  // 4
    "PTRAIN_NUM_LONG",                 // 5
    "PTRAIN_DOC_SHORT",                // 6
    "PTRAIN_DOC_MED",                  // 7
    "PTRAIN_DOC_LONG",                 // 8
    "PTRAIN_DICT_SHORT",               // 9
    "PTRAIN_DICT_MED",                 // 10
    "PTRAIN_DICT_LONG",                // 11
    "PTRAIN_FREQ_SHORT",               // 12
    "PTRAIN_FREQ_MED",                 // 13
    "PTRAIN_FREQ_LONG",                // 14
    "PTRAIN_SHAPE_COST_PER_CHAR",      // 15
    "PTRAIN_NGRAM_COST_PER_CHAR",      // 16
    "PTRAIN_NUM_BAD_PUNC",             // 17
    "PTRAIN_NUM_BAD_CASE",             // 18
    "PTRAIN_XHEIGHT_CONSISTENCY",      // 19
    "PTRAIN_NUM_BAD_CHAR_TYPE",        // 20
    "PTRAIN_NUM_BAD_SPACING",          // 21
    "PTRAIN_NUM_BAD_FONT",             // 22
    "PTRAIN_RATING_PER_CHAR",          // 23
};

// Returns the index of the given feature (by name),
// or -1 meaning the feature is unknown.
int ParamsTrainingFeatureByName(const char *name);


// Entry with features extracted from a single OCR hypothesis for a word.
struct ParamsTrainingHypothesis {
  ParamsTrainingHypothesis() : cost(0.0) {
    memset(features, 0, sizeof(float) * PTRAIN_NUM_FEATURE_TYPES);
  }
  ParamsTrainingHypothesis(const ParamsTrainingHypothesis &other) {
    memcpy(features, other.features,
           sizeof(float) * PTRAIN_NUM_FEATURE_TYPES);
    str = other.str;
    cost = other.cost;
  }
  float features[PTRAIN_NUM_FEATURE_TYPES];
  STRING str;  // string corresponding to word hypothesis (for debugging)
  float cost;  // path cost computed by segsearch
};

// A list of hypotheses explored during one run of segmentation search.
typedef GenericVector<ParamsTrainingHypothesis> ParamsTrainingHypothesisList;

// A bundle that accumulates all of the hypothesis lists explored during all
// of the runs of segmentation search on a word (e.g. a list of hypotheses
// explored on PASS1, PASS2, fix xheight pass, etc).
class ParamsTrainingBundle {
 public:
  ParamsTrainingBundle() {}
  // Starts a new hypothesis list.
  // Should be called at the beginning of a new run of the segmentation search.
  void StartHypothesisList() {
    hyp_list_vec.push_back(ParamsTrainingHypothesisList());
  }
  // Adds a new ParamsTrainingHypothesis to the current hypothesis list
  // and returns the reference to the newly added entry.
  ParamsTrainingHypothesis &AddHypothesis(
      const ParamsTrainingHypothesis &other) {
    if (hyp_list_vec.empty()) StartHypothesisList();
    hyp_list_vec.back().push_back(ParamsTrainingHypothesis(other));
    return hyp_list_vec.back().back();
  }

  GenericVector<ParamsTrainingHypothesisList> hyp_list_vec;
};

}  // namespace tesseract

#endif  // TESSERACT_WORDREC_PARAMS_TRAINING_FEATDEF_H_

 





#if  TESSERACT_CCUTIL_OBJECT_CACHE_H_DEBUG|1




namespace tesseract {

// A simple object cache which maps a string to an object of type T.
// Usually, these are expensive objects that are loaded from disk.
// Reference counting is performed, so every Get() needs to be followed later
// by a Free().  Actual deletion is accomplished by DeleteUnusedObjects().
template<typename T>
class ObjectCache {
 public:
  ObjectCache() {}
  ~ObjectCache() {
    mu_.Lock();
    for (int i = 0; i < cache_.size(); i++) {
      if (cache_[i].count > 0) {
        tprintf("ObjectCache(%p)::~ObjectCache(): WARNING! LEAK! object %p "
                "still has count %d (id %s)\n",
                this, cache_[i].object, cache_[i].count,
                cache_[i].id.string());
      } else {
        delete cache_[i].object;
        cache_[i].object = NULL;
      }
    }
    mu_.Unlock();
  }

  // Return a pointer to the object identified by id.
  // If we haven't yet loaded the object, use loader to load it.
  // If loader fails to load it, record a NULL entry in the cache
  // and return NULL -- further attempts to load will fail (even
  // with a different loader) until DeleteUnusedObjects() is called.
  // We delete the given loader.
  T *Get(STRING id,
         TessResultCallback<T *> *loader) {
    T *retval = NULL;
    mu_.Lock();
    for (int i = 0; i < cache_.size(); i++) {
      if (id == cache_[i].id) {
        retval = cache_[i].object;
        if (cache_[i].object != NULL) {
          cache_[i].count++;
        }
        mu_.Unlock();
        delete loader;
        return retval;
      }
    }
    cache_.push_back(ReferenceCount());
    ReferenceCount &rc = cache_.back();
    rc.id = id;
    retval = rc.object = loader->Run();
    rc.count = (retval != NULL) ? 1 : 0;
    mu_.Unlock();
    return retval;
  }

  // Decrement the count for t.
  // Return whether we knew about the given pointer.
  bool Free(T *t) {
    if (t == NULL) return false;
    mu_.Lock();
    for (int i = 0; i < cache_.size(); i++) {
      if (cache_[i].object == t) {
        --cache_[i].count;
        mu_.Unlock();
        return true;
      }
    }
    mu_.Unlock();
    return false;
  }

  void DeleteUnusedObjects() {
    mu_.Lock();
    for (int i = cache_.size() - 1; i >= 0; i--) {
      if (cache_[i].count <= 0) {
        delete cache_[i].object;
        cache_.remove(i);
      }
    }
    mu_.Unlock();
  }

 private:
  struct ReferenceCount {
    STRING id;  // A unique ID to identify the object (think path on disk)
    T *object;  // A copy of the object in memory.  Can be delete'd.
    int count;  // A count of the number of active users of this object.
  };

  CCUtilMutex mu_;
  GenericVector<ReferenceCount> cache_;
};

}  // namespace tesseract


#endif  // TESSERACT_CCUTIL_OBJECT_CACHE_H_


   



 
#if   TESSERACT_DICT_DAWG_CACHE_H_DEBUG|1


namespace tesseract {

class DawgCache {
 public:
  Dawg *GetSquishedDawg(
      const STRING &lang,
      const char *data_file_name,
      TessdataType tessdata_dawg_type,
      int debug_level);

  // If we manage the given dawg, decrement its count,
  // and possibly delete it if the count reaches zero.
  // If dawg is unknown to us, return false.
  bool FreeDawg(Dawg *dawg) {
    return dawgs_.Free(dawg);
  }

  // Free up any currently unused dawgs.
  void DeleteUnusedDawgs() {
    dawgs_.DeleteUnusedObjects();
  }

 private:
  ObjectCache<Dawg> dawgs_;
};

}  // namespace tesseract

#endif  // TESSERACT_DICT_DAWG_CACHE_H_

 






#if   TESSERACT_DICT_DICT_H_DEBUG|1



#define MAX_WERD_LENGTH        (inT64) 128
#define NO_RATING               -1

/** Struct used to hold temporary information about fragments. */
struct CHAR_FRAGMENT_INFO {
  UNICHAR_ID unichar_id;
  const CHAR_FRAGMENT *fragment;
  int num_fragments;
  float rating;
  float certainty;
};

namespace tesseract {

typedef GenericVector<Dawg *> DawgVector;

//
// Constants
//
static const int kRatingPad = 4;
static const char kDictWildcard[] = "\u2606";   // WHITE STAR
static const int kDictMaxWildcards = 2;  // max wildcards for a word
// TODO(daria): If hyphens are different in different languages and can be
// inferred from training data we should load their values dynamically.
static const char kHyphenSymbol[] = "-";
static const char kSlashSymbol[] = "/";
static const char kQuestionSymbol[] = "?";
static const char kApostropheSymbol[] = "'";
static const float kSimCertaintyScale = -10.0;   // similarity matcher scaling
static const float kSimCertaintyOffset = -10.0;  // similarity matcher offset
static const float kSimilarityFloor = 100.0;  // worst E*L product to stop on
static const int kDocDictMaxRepChars = 4;

// Enum for describing whether the x-height for the word is consistent:
//  0 - everything is good.
//  1 - there are one or two secondary (but consistent) baselines
//      [think subscript and superscript], or there is an oversized
//      first character.
//  2 - the word is inconsistent.
enum XHeightConsistencyEnum {XH_GOOD, XH_SUBNORMAL, XH_INCONSISTENT};

struct DawgArgs {
  DawgArgs(DawgPositionVector *d, DawgPositionVector *up, PermuterType p)
      : active_dawgs(d), updated_dawgs(up), permuter(p), valid_end(false) {}

  DawgPositionVector *active_dawgs;
  DawgPositionVector *updated_dawgs;
  PermuterType permuter;
  // True if the current position is a valid word end.
  bool valid_end;
};

class Dict {
 public:
  Dict(CCUtil* image_ptr);
  ~Dict();
  const CCUtil* getCCUtil() const {
    return ccutil_;
  }
  CCUtil* getCCUtil() {
    return ccutil_;
  }
  const UNICHARSET& getUnicharset() const {
    return getCCUtil()->unicharset;
  }
  UNICHARSET& getUnicharset() {
    return getCCUtil()->unicharset;
  }
  const UnicharAmbigs &getUnicharAmbigs() const {
    return getCCUtil()->unichar_ambigs;
  }

  // Returns true if unichar_id is a word compounding character like - or /.
  inline bool compound_marker(UNICHAR_ID unichar_id) {
    const GenericVector<UNICHAR_ID>& normed_ids =
        getUnicharset().normed_ids(unichar_id);
    return normed_ids.size() == 1 &&
        (normed_ids[0] == hyphen_unichar_id_ ||
         normed_ids[0] == slash_unichar_id_);
  }
  // Returns true if unichar_id is an apostrophe-like character that may
  // separate prefix/suffix words from a main body word.
  inline bool is_apostrophe(UNICHAR_ID unichar_id) {
    const GenericVector<UNICHAR_ID>& normed_ids =
        getUnicharset().normed_ids(unichar_id);
    return normed_ids.size() == 1 && normed_ids[0] == apostrophe_unichar_id_;
  }

  /* hyphen.cpp ************************************************************/

  /// Returns true if we've recorded the beginning of a hyphenated word.
  inline bool hyphenated() const { return
    !last_word_on_line_ && hyphen_word_;
  }
  /// Size of the base word (the part on the line before) of a hyphenated word.
  inline int hyphen_base_size() const {
    return this->hyphenated() ? hyphen_word_->length() : 0;
  }
  /// If this word is hyphenated copy the base word (the part on
  /// the line before) of a hyphenated word into the given word.
  /// This function assumes that word is not NULL.
  inline void copy_hyphen_info(WERD_CHOICE *word) const {
    if (this->hyphenated()) {
      *word = *hyphen_word_;
      if (hyphen_debug_level) word->print("copy_hyphen_info: ");
    }
  }
  /// Check whether the word has a hyphen at the end.
  inline bool has_hyphen_end(UNICHAR_ID unichar_id, bool first_pos) const {
    if (!last_word_on_line_ || first_pos)
      return false;
    const GenericVector<UNICHAR_ID>& normed_ids =
        getUnicharset().normed_ids(unichar_id);
    return normed_ids.size() == 1 && normed_ids[0] == hyphen_unichar_id_;
  }
  /// Same as above, but check the unichar at the end of the word.
  inline bool has_hyphen_end(const WERD_CHOICE &word) const {
    int word_index = word.length() - 1;
    return has_hyphen_end(word.unichar_id(word_index), word_index == 0);
  }
  /// Unless the previous word was the last one on the line, and the current
  /// one is not (thus it is the first one on the line), erase hyphen_word_,
  /// clear hyphen_active_dawgs_, update last_word_on_line_.
  void reset_hyphen_vars(bool last_word_on_line);
  /// Update hyphen_word_, and copy the given DawgPositionVectors into
  /// hyphen_active_dawgs_ .
  void set_hyphen_word(const WERD_CHOICE &word,
                       const DawgPositionVector &active_dawgs);

  /* permdawg.cpp ************************************************************/
  // Note: Functions in permdawg.cpp are only used by NoDangerousAmbig().
  // When this function is refactored, permdawg.cpp can be removed.

  /// Copies word into best_choice if its rating is smaller
  /// than that of best_choice.
  inline void update_best_choice(const WERD_CHOICE &word,
                                 WERD_CHOICE *best_choice) {
    if (word.rating() < best_choice->rating()) {
      *best_choice = word;
    }
  }
  /// Fill the given active_dawgs vector with dawgs that could contain the
  /// beginning of the word. If hyphenated() returns true, copy the entries
  /// from hyphen_active_dawgs_ instead.
  void init_active_dawgs(DawgPositionVector *active_dawgs,
                         bool ambigs_mode) const;
  // Fill the given vector with the default collection of any-length dawgs
  void default_dawgs(DawgPositionVector *anylength_dawgs,
                               bool suppress_patterns) const;


  /// Recursively explore all the possible character combinations in
  /// the given char_choices. Use go_deeper_dawg_fxn() to explore all the
  /// dawgs in the dawgs_ vector in parallel and discard invalid words.
  ///
  /// Allocate and return a WERD_CHOICE with the best valid word found.
  WERD_CHOICE *dawg_permute_and_select(
      const BLOB_CHOICE_LIST_VECTOR &char_choices, float rating_limit);
  /// If the choice being composed so far could be a dictionary word
  /// and we have not reached the end of the word keep exploring the
  /// char_choices further.
  void go_deeper_dawg_fxn(
      const char *debug, const BLOB_CHOICE_LIST_VECTOR &char_choices,
      int char_choice_index, const CHAR_FRAGMENT_INFO *prev_char_frag_info,
      bool word_ending, WERD_CHOICE *word, float certainties[],
      float *limit, WERD_CHOICE *best_choice, int *attempts_left,
      void *void_more_args);

  /// Pointer to go_deeper function.
  void (Dict::*go_deeper_fxn_)(const char *debug,
                               const BLOB_CHOICE_LIST_VECTOR &char_choices,
                               int char_choice_index,
                               const CHAR_FRAGMENT_INFO *prev_char_frag_info,
                               bool word_ending, WERD_CHOICE *word,
                               float certainties[], float *limit,
                               WERD_CHOICE *best_choice, int *attempts_left,
                               void *void_more_args);
  //
  // Helper functions for dawg_permute_and_select().
  //
  void permute_choices(
      const char *debug,
      const BLOB_CHOICE_LIST_VECTOR &char_choices,
      int char_choice_index,
      const CHAR_FRAGMENT_INFO *prev_char_frag_info,
      WERD_CHOICE *word,
      float certainties[],
      float *limit,
      WERD_CHOICE *best_choice,
      int *attempts_left,
      void *more_args);

  void append_choices(
      const char *debug,
      const BLOB_CHOICE_LIST_VECTOR &char_choices,
      const BLOB_CHOICE &blob_choice,
      int char_choice_index,
      const CHAR_FRAGMENT_INFO *prev_char_frag_info,
      WERD_CHOICE *word,
      float certainties[],
      float *limit,
      WERD_CHOICE *best_choice,
      int *attempts_left,
      void *more_args);

    bool fragment_state_okay(UNICHAR_ID curr_unichar_id,
                             float curr_rating, float curr_certainty,
                             const CHAR_FRAGMENT_INFO *prev_char_frag_info,
                             const char *debug, int word_ending,
                             CHAR_FRAGMENT_INFO *char_frag_info);

  /* stopper.cpp *************************************************************/
  bool TESS_API NoDangerousAmbig(WERD_CHOICE *BestChoice,
                        DANGERR *fixpt,
                        bool fix_replaceable,
                        MATRIX* ratings);
  // Replaces the corresponding wrong ngram in werd_choice with the correct
  // one. The whole correct n-gram is inserted into the ratings matrix and
  // the werd_choice: no more fragments!. Rating and certainty of new entries
  // in matrix and werd_choice are the sum and mean of the wrong ngram
  // respectively.
  // E.g. for werd_choice mystring'' and ambiguity ''->": werd_choice becomes
  // mystring", with a new entry in the ratings matrix for ".
  void ReplaceAmbig(int wrong_ngram_begin_index, int wrong_ngram_size,
                    UNICHAR_ID correct_ngram_id, WERD_CHOICE *werd_choice,
                    MATRIX *ratings);

  /// Returns the length of the shortest alpha run in WordChoice.
  int LengthOfShortestAlphaRun(const WERD_CHOICE &WordChoice);
  /// Returns true if the certainty of the BestChoice word is within a
  /// reasonable range of the average certainties for the best choices for
  /// each character in the segmentation.  This test is used to catch words
  /// in which one character is much worse than the other characters in the
  /// word (i.e. false will be returned in that case). The algorithm computes
  /// the mean and std deviation of the certainties in the word with the worst
  /// certainty thrown out.
  int UniformCertainties(const WERD_CHOICE& word);
  /// Returns true if the given best_choice is good enough to stop.
  bool AcceptableChoice(const WERD_CHOICE& best_choice,
                        XHeightConsistencyEnum xheight_consistency);
  /// Returns false if the best choice for the current word is questionable
  /// and should be tried again on the second pass or should be flagged to
  /// the user.
  bool AcceptableResult(WERD_RES* word);
  void EndDangerousAmbigs();
  /// Prints the current choices for this word to stdout.
  void DebugWordChoices();
  /// Sets up stopper variables in preparation for the first pass.
  void SettupStopperPass1();
  /// Sets up stopper variables in preparation for the second pass.
  void SettupStopperPass2();
  /* context.cpp *************************************************************/
  /// Check a string to see if it matches a set of lexical rules.
  int case_ok(const WERD_CHOICE &word, const UNICHARSET &unicharset);
  /// Returns true if the word looks like an absolute garbage
  /// (e.g. image mistakenly recognized as text).
  bool absolute_garbage(const WERD_CHOICE &word, const UNICHARSET &unicharset);

  /* dict.cpp ****************************************************************/

  /// Initialize Dict class - load dawgs from [lang].traineddata and
  /// user-specified wordlist and parttern list.
  static DawgCache *GlobalDawgCache();
  // Sets up ready for a Load.
  void SetupForLoad(DawgCache *dawg_cache);
  // Loads the dawgs needed by Tesseract. Call FinishLoad() after.
  void Load(const char *data_file_name, const STRING &lang);
  // Completes the loading process after Load().
  // Returns false if no dictionaries were loaded.
  bool FinishLoad();
  void End();

  // Resets the document dictionary analogous to ResetAdaptiveClassifier.
  void ResetDocumentDictionary() {
    if (pending_words_ != NULL)
      pending_words_->clear();
    if (document_words_ != NULL)
      document_words_->clear();
  }

  /**
   * Returns the maximal permuter code (from ccstruct/ratngs.h) if in light
   * of the current state the letter at word_index in the given word
   * is allowed according to at least one of the dawgs in dawgs_,
   * otherwise returns NO_PERM.
   *
   * The state is described by void_dawg_args, which are interpreted as
   * DawgArgs and contain relevant active dawg positions.
   * Each entry in the active_dawgs vector contains an index
   * into the dawgs_ vector and an EDGE_REF that indicates the last edge
   * followed in the dawg.  It also may contain a position in the punctuation
   * dawg which describes surrounding punctuation (see struct DawgPosition).
   *
   * Input:
   * At word_index 0 dawg_args->active_dawgs should contain an entry for each
   * dawg that may start at the beginning of a word, with punc_ref and edge_ref
   * initialized to NO_EDGE.  Since the punctuation dawg includes the empty
   * pattern " " (meaning anything without surrounding punctuation), having a
   * single entry for the punctuation dawg will cover all dawgs reachable
   * therefrom -- that includes all number and word dawgs. The only dawg
   * non-reachable from the punctuation_dawg is the pattern dawg.
   * If hyphen state needs to be applied, initial dawg_args->active_dawgs can
   * be copied from the saved hyphen state (maintained by Dict).
   * For word_index > 0 the corresponding state (active_dawgs and punc position)
   * can be obtained from dawg_args->updated_dawgs passed to
   * def_letter_is_okay for word_index-1.
   * Note: the function assumes that active_dawgs, nd updated_dawgs
   * member variables of dawg_args are not NULL.
   *
   * Output:
   * The function fills in dawg_args->updated_dawgs vector with the
   * entries for dawgs that contain the word up to the letter at word_index.
   *
   */

  //
  int def_letter_is_okay(void* void_dawg_args,
                         UNICHAR_ID unichar_id, bool word_end) const;

  int (Dict::*letter_is_okay_)(void* void_dawg_args,
                               UNICHAR_ID unichar_id, bool word_end) const;
  /// Calls letter_is_okay_ member function.
  int LetterIsOkay(void* void_dawg_args,
                   UNICHAR_ID unichar_id, bool word_end) const {
    return (this->*letter_is_okay_)(void_dawg_args, unichar_id, word_end);
  }


  /// Probability in context function used by the ngram permuter.
  double (Dict::*probability_in_context_)(const char* lang,
                                          const char* context,
                                          int context_bytes,
                                          const char* character,
                                          int character_bytes);
  /// Calls probability_in_context_ member function.
  double ProbabilityInContext(const char* context,
                              int context_bytes,
                              const char* character,
                              int character_bytes) {
    return (this->*probability_in_context_)(
        getCCUtil()->lang.string(),
        context, context_bytes,
        character, character_bytes);
  }

  /// Default (no-op) implementation of probability in context function.
  double def_probability_in_context(
      const char* lang, const char* context, int context_bytes,
      const char* character, int character_bytes) {
    (void)lang;
    (void)context;
    (void)context_bytes;
    (void)character;
    (void)character_bytes;
    return 0.0;
  }
  double ngram_probability_in_context(const char* lang,
                                      const char* context,
                                      int context_bytes,
                                      const char* character,
                                      int character_bytes);

  // Interface with params model.
  float (Dict::*params_model_classify_)(const char *lang, void *path);
  float ParamsModelClassify(const char *lang, void *path);
  // Call params_model_classify_ member function.
  float CallParamsModelClassify(void *path) {
    ASSERT_HOST(params_model_classify_ != NULL);  // ASSERT_HOST -> assert
    return (this->*params_model_classify_)(
        getCCUtil()->lang.string(), path);
  }

  inline void SetWildcardID(UNICHAR_ID id) { wildcard_unichar_id_ = id; }
  inline UNICHAR_ID WildcardID() const { return wildcard_unichar_id_; }
  /// Return the number of dawgs in the dawgs_ vector.
  inline int NumDawgs() const { return dawgs_.size(); }
  /// Return i-th dawg pointer recorded in the dawgs_ vector.
  inline const Dawg *GetDawg(int index) const { return dawgs_[index]; }
  /// Return the points to the punctuation dawg.
  inline const Dawg *GetPuncDawg() const { return punc_dawg_; }
  /// Return the points to the unambiguous words dawg.
  inline const Dawg *GetUnambigDawg() const { return unambig_dawg_; }
  /// Returns the appropriate next node given the EDGE_REF.
  static inline NODE_REF GetStartingNode(const Dawg *dawg, EDGE_REF edge_ref) {
    if (edge_ref == NO_EDGE) return 0;  // beginning to explore the dawg
    NODE_REF node = dawg->next_node(edge_ref);
    if (node == 0) node = NO_EDGE;  // end of word
    return node;
  }

  // Given a unichar from a string and a given dawg, return the unichar
  // we should use to match in that dawg type.  (for example, in the number
  // dawg, all numbers are transformed to kPatternUnicharId).
  inline UNICHAR_ID char_for_dawg(UNICHAR_ID ch, const Dawg *dawg) const {
    if (!dawg) return ch;
    switch (dawg->type()) {
      case DAWG_TYPE_NUMBER:
        return getUnicharset().get_isdigit(ch) ? Dawg::kPatternUnicharID : ch;
      default:
        return ch;
    }
  }

  /// For each of the character classes of the given unichar_id (and the
  /// unichar_id itself) finds the corresponding outgoing node or self-loop
  /// in the given dawg and (after checking that it is valid) records it in
  /// dawg_args->updated_ative_dawgs. Updates current_permuter if any valid
  /// edges were found.
  void ProcessPatternEdges(const Dawg *dawg, const DawgPosition &info,
                           UNICHAR_ID unichar_id, bool word_end,
                           DawgArgs *dawg_args,
                           PermuterType *current_permuter) const;

  /// Read/Write/Access special purpose dawgs which contain words
  /// only of a certain length (used for phrase search for
  /// non-space-delimited languages).

  /// Check all the DAWGs to see if this word is in any of them.
  inline static bool valid_word_permuter(uinT8 perm, bool numbers_ok) {
    return (perm == SYSTEM_DAWG_PERM || perm == FREQ_DAWG_PERM ||
            perm == DOC_DAWG_PERM || perm == USER_DAWG_PERM ||
            perm == USER_PATTERN_PERM || perm == COMPOUND_PERM ||
            (numbers_ok && perm == NUMBER_PERM));
  }
  int valid_word(const WERD_CHOICE &word, bool numbers_ok) const;
  int valid_word(const WERD_CHOICE &word) const {
    return valid_word(word, false);  // return NO_PERM for words with digits
  }
  int valid_word_or_number(const WERD_CHOICE &word) const {
    return valid_word(word, true);  // return NUMBER_PERM for valid numbers
  }
  /// This function is used by api/tesseract_cube_combiner.cpp
  int valid_word(const char *string) const {
    WERD_CHOICE word(string, getUnicharset());
    return valid_word(word);
  }
  // Do the two WERD_CHOICEs form a meaningful bigram?
  bool valid_bigram(const WERD_CHOICE &word1, const WERD_CHOICE &word2) const;
  /// Returns true if the word contains a valid punctuation pattern.
  /// Note: Since the domains of punctuation symbols and symblos
  /// used in numbers are not disjoint, a valid number might contain
  /// an invalid punctuation pattern (e.g. .99).
  bool valid_punctuation(const WERD_CHOICE &word);
  /// Returns true if a good answer is found for the unknown blob rating.
  int good_choice(const WERD_CHOICE &choice);
  /// Adds a word found on this document to the document specific dictionary.
  void add_document_word(const WERD_CHOICE &best_choice);
  /// Adjusts the rating of the given word.
  void adjust_word(WERD_CHOICE *word,
                   bool nonword, XHeightConsistencyEnum xheight_consistency,
                   float additional_adjust,
                   bool modify_rating,
                   bool debug);
  /// Set wordseg_rating_adjust_factor_ to the given value.
  inline void SetWordsegRatingAdjustFactor(float f) {
    wordseg_rating_adjust_factor_ = f;
  }
  /// Returns true if the language is space-delimited (not CJ, or T).
  bool IsSpaceDelimitedLang() const;

 private:
  /** Private member variables. */
  CCUtil* ccutil_;
  /**
   * Table that stores ambiguities computed during training
   * (loaded when NoDangerousAmbigs() is called for the first time).
   * Each entry i in the table stores a set of amibiguities whose
   * wrong ngram starts with unichar id i.
   */
  UnicharAmbigs *dang_ambigs_table_;
  /** Same as above, but for ambiguities with replace flag set. */
  UnicharAmbigs *replace_ambigs_table_;
  /** Additional certainty padding allowed before a word is rejected. */
  FLOAT32 reject_offset_;
  // Cached UNICHAR_IDs:
  UNICHAR_ID wildcard_unichar_id_;    // kDictWildcard.
  UNICHAR_ID apostrophe_unichar_id_;  // kApostropheSymbol.
  UNICHAR_ID question_unichar_id_;    // kQuestionSymbol.
  UNICHAR_ID slash_unichar_id_;       // kSlashSymbol.
  UNICHAR_ID hyphen_unichar_id_;      // kHyphenSymbol.
  // Hyphen-related variables.
  WERD_CHOICE *hyphen_word_;
  DawgPositionVector hyphen_active_dawgs_;
  bool last_word_on_line_;
  // List of lists of "equivalent" UNICHAR_IDs for the purposes of dictionary
  // matching.  The first member of each list is taken as canonical.  For
  // example, the first list contains hyphens and dashes with the first symbol
  // being the ASCII hyphen minus.
  GenericVector<GenericVectorEqEq<UNICHAR_ID> > equivalent_symbols_;
  // Dawg Cache reference - this is who we ask to allocate/deallocate dawgs.
  DawgCache *dawg_cache_;
  bool dawg_cache_is_ours_;  // we should delete our own dawg_cache_
  // Dawgs.
  DawgVector dawgs_;
  SuccessorListsVector successors_;
  Trie *pending_words_;
  // bigram_dawg_ points to a dawg of two-word bigrams which always supercede if
  // any of them are present on the best choices list for a word pair.
  // the bigrams are stored as space-separated words where:
  // (1) leading and trailing punctuation has been removed from each word and
  // (2) any digits have been replaced with '?' marks.
  Dawg *bigram_dawg_;
  /// The following pointers are only cached for convenience.
  /// The dawgs will be deleted when dawgs_ vector is destroyed.
  // TODO(daria): need to support multiple languages in the future,
  // so maybe will need to maintain a list of dawgs of each kind.
  Dawg *freq_dawg_;
  Dawg *unambig_dawg_;
  Dawg *punc_dawg_;
  Trie *document_words_;
  /// Current segmentation cost adjust factor for word rating.
  /// See comments in incorporate_segcost.
  float wordseg_rating_adjust_factor_;
  // File for recording ambiguities discovered during dictionary search.
  FILE *output_ambig_words_file_;

 public:
  /// Variable members.
  /// These have to be declared and initialized after image_ptr_, which contains
  /// the pointer to the params vector - the member of its base CCUtil class.
  STRING_VAR_H(user_words_file, "", "A filename of user-provided words.");
  STRING_VAR_H(user_words_suffix, "",
               "A suffix of user-provided words located in tessdata.");
  STRING_VAR_H(user_patterns_file, "",
               "A filename of user-provided patterns.");
  STRING_VAR_H(user_patterns_suffix, "",
               "A suffix of user-provided patterns located in tessdata.");
  BOOL_VAR_H(load_system_dawg, true, "Load system word dawg.");
  BOOL_VAR_H(load_freq_dawg, true, "Load frequent word dawg.");
  BOOL_VAR_H(load_unambig_dawg, true, "Load unambiguous word dawg.");
  BOOL_VAR_H(load_punc_dawg, true,
             "Load dawg with punctuation patterns.");
  BOOL_VAR_H(load_number_dawg, true, "Load dawg with number patterns.");
  BOOL_VAR_H(load_bigram_dawg, true,
             "Load dawg with special word bigrams.");
  double_VAR_H(xheight_penalty_subscripts, 0.125,
               "Score penalty (0.1 = 10%) added if there are subscripts "
               "or superscripts in a word, but it is otherwise OK.");
  double_VAR_H(xheight_penalty_inconsistent, 0.25,
               "Score penalty (0.1 = 10%) added if an xheight is "
               "inconsistent.");
  double_VAR_H(segment_penalty_dict_frequent_word, 1.0,
               "Score multiplier for word matches which have good case and"
               "are frequent in the given language (lower is better).");

  double_VAR_H(segment_penalty_dict_case_ok, 1.1,
               "Score multiplier for word matches that have good case "
               "(lower is better).");

  double_VAR_H(segment_penalty_dict_case_bad, 1.3125,
               "Default score multiplier for word matches, which may have "
               "case issues (lower is better).");

  // TODO(daria): remove this param when ngram permuter is deprecated.
  double_VAR_H(segment_penalty_ngram_best_choice, 1.24,
               "Multipler to for the best choice from the ngram model.");

  double_VAR_H(segment_penalty_dict_nonword, 1.25,
               "Score multiplier for glyph fragment segmentations which "
               "do not match a dictionary word (lower is better).");

  double_VAR_H(segment_penalty_garbage, 1.50,
               "Score multiplier for poorly cased strings that are not in"
               " the dictionary and generally look like garbage (lower is"
               " better).");
  STRING_VAR_H(output_ambig_words_file, "",
               "Output file for ambiguities found in the dictionary");
  INT_VAR_H(dawg_debug_level, 0, "Set to 1 for general debug info"
            ", to 2 for more details, to 3 to see all the debug messages");
  INT_VAR_H(hyphen_debug_level, 0, "Debug level for hyphenated words.");
  INT_VAR_H(max_viterbi_list_size, 10, "Maximum size of viterbi list.");
  BOOL_VAR_H(use_only_first_uft8_step, false,
             "Use only the first UTF8 step of the given string"
             " when computing log probabilities.");
  double_VAR_H(certainty_scale, 20.0, "Certainty scaling factor");
  double_VAR_H(stopper_nondict_certainty_base, -2.50,
               "Certainty threshold for non-dict words");
  double_VAR_H(stopper_phase2_certainty_rejection_offset, 1.0,
               "Reject certainty offset");
  INT_VAR_H(stopper_smallword_size, 2,
            "Size of dict word to be treated as non-dict word");
  double_VAR_H(stopper_certainty_per_char, -0.50,
               "Certainty to add for each dict char above small word size.");
  double_VAR_H(stopper_allowable_character_badness, 3.0,
               "Max certaintly variation allowed in a word (in sigma)");
  INT_VAR_H(stopper_debug_level, 0, "Stopper debug level");
  BOOL_VAR_H(stopper_no_acceptable_choices, false,
             "Make AcceptableChoice() always return false. Useful"
             " when there is a need to explore all segmentations");
  BOOL_VAR_H(save_raw_choices, false,
             "Deprecated- backward compatibility only");
  INT_VAR_H(tessedit_truncate_wordchoice_log, 10, "Max words to keep in list");
  STRING_VAR_H(word_to_debug, "", "Word for which stopper debug information"
               " should be printed to stdout");
  STRING_VAR_H(word_to_debug_lengths, "",
               "Lengths of unichars in word_to_debug");
  INT_VAR_H(fragments_debug, 0, "Debug character fragments");
  BOOL_VAR_H(segment_nonalphabetic_script, false,
             "Don't use any alphabetic-specific tricks."
             "Set to true in the traineddata config file for"
             " scripts that are cursive or inherently fixed-pitch");
  BOOL_VAR_H(save_doc_words, 0, "Save Document Words");
  double_VAR_H(doc_dict_pending_threshold, 0.0,
               "Worst certainty for using pending dictionary");
  double_VAR_H(doc_dict_certainty_threshold, -2.25, "Worst certainty"
               " for words that can be inserted into the document dictionary");
  INT_VAR_H(max_permuter_attempts, 10000, "Maximum number of different"
              " character choices to consider during permutation."
              " This limit is especially useful when user patterns"
              " are specified, since overly generic patterns can result in"
              " dawg search exploring an overly large number of options.");
};
}  // namespace tesseract

#endif  // THIRD_PARTY_TESSERACT_DICT_DICT_H_


 







#if FEATURES_H_DEBUG|1



//class DENORM;
struct INT_FX_RESULT_STRUCT;

#undef Min
#undef Max
#define FEAT_NAME_SIZE    80

// define trap errors which can be caused by this module
#define ILLEGAL_FEATURE_PARAM 1000
#define ILLEGAL_NUM_FEATURES  1001

// A character is described by multiple sets of extracted features.  Each
// set contains a number of features of a particular type, for example, a
// set of bays, or a set of closures, or a set of microfeatures.  Each
// feature consists of a number of parameters.  All features within a
// feature set contain the same number of parameters.  All circular
// parameters are required to be the first parameters in the feature.

struct PARAM_DESC {
  inT8 Circular;                   // TRUE if dimension wraps around
  inT8 NonEssential;               // TRUE if dimension not used in searches
  FLOAT32 Min;                     // low end of range for circular dimensions
  FLOAT32 Max;                     // high end of range for circular dimensions
  FLOAT32 Range;                   // Max - Min
  FLOAT32 HalfRange;               // (Max - Min)/2
  FLOAT32 MidRange;                // (Max + Min)/2
};

struct FEATURE_DESC_STRUCT {
  uinT16 NumParams;                // total # of params
  const char *ShortName;           // short name for feature
  const PARAM_DESC *ParamDesc;     // array - one per param
};
typedef FEATURE_DESC_STRUCT *FEATURE_DESC;

struct FEATURE_STRUCT {
  const FEATURE_DESC_STRUCT *Type;  // points to description of feature type
  FLOAT32 Params[1];                // variable size array - params for feature
};
typedef FEATURE_STRUCT *FEATURE;

struct FEATURE_SET_STRUCT {
  uinT16 NumFeatures;            // number of features in set
  uinT16 MaxNumFeatures;         // maximum size of feature set
  FEATURE Features[1];           // variable size array of features
};
typedef FEATURE_SET_STRUCT *FEATURE_SET;

// A generic character description as a char pointer. In reality, it will be
// a pointer to some data structure. Paired feature extractors/matchers need
// to agree on the data structure to be used, however, the high level
// classifier does not need to know the details of this data structure.
typedef char *CHAR_FEATURES;

/*----------------------------------------------------------------------
    Macros for defining the parameters of a new features
----------------------------------------------------------------------*/
#define StartParamDesc(Name)	\
const PARAM_DESC Name[] = {

#define DefineParam(Circular, NonEssential, Min, Max)	\
	{Circular, NonEssential, Min, Max,			\
	(Max) - (Min), (((Max) - (Min))/2.0), (((Max) + (Min))/2.0)},

#define EndParamDesc  };

/*----------------------------------------------------------------------
Macro for describing a new feature.  The parameters of the macro
are as follows:

DefineFeature (Name, NumLinear, NumCircular, ShortName, ParamName)
----------------------------------------------------------------------*/
#define DefineFeature(Name, NL, NC, SN, PN)		\
const FEATURE_DESC_STRUCT Name = {				\
	((NL) + (NC)), SN, PN};

/*----------------------------------------------------------------------
        Generic routines that work for all feature types
----------------------------------------------------------------------*/
BOOL8 AddFeature(FEATURE_SET FeatureSet, FEATURE Feature);

void FreeFeature(FEATURE Feature);

void TESS_API FreeFeatureSet(FEATURE_SET FeatureSet);

FEATURE NewFeature(const FEATURE_DESC_STRUCT *FeatureDesc);

FEATURE_SET NewFeatureSet(int NumFeatures);

FEATURE ReadFeature(FILE *File, const FEATURE_DESC_STRUCT *FeatureDesc);

FEATURE_SET ReadFeatureSet(FILE *File, const FEATURE_DESC_STRUCT *FeatureDesc);

void WriteFeature(FEATURE Feature, STRING* str);

void WriteFeatureSet(FEATURE_SET FeatureSet, STRING* str);

#endif



  




#if   FEATDEFS_H_DEBUG|1
 


/* Enumerate the different types of features currently defined. */
#define NUM_FEATURE_TYPES 4
extern const char* kMicroFeatureType;
extern const char* kCNFeatureType;
extern const char* kIntFeatureType;
extern const char* kGeoFeatureType;

/* define error traps which can be triggered by this module.*/
#define ILLEGAL_SHORT_NAME  2000

/* A character is described by multiple sets of extracted features.  Each
  set contains a number of features of a particular type, for example, a
  set of bays, or a set of closures, or a set of microfeatures.  Each
  feature consists of a number of parameters.  All features within a
  feature set contain the same number of parameters.*/

struct CHAR_DESC_STRUCT {
  uinT32 NumFeatureSets;
  FEATURE_SET FeatureSets[NUM_FEATURE_TYPES];
};
typedef CHAR_DESC_STRUCT *CHAR_DESC;

struct FEATURE_DEFS_STRUCT {
  inT32 NumFeatureTypes;
  const FEATURE_DESC_STRUCT* FeatureDesc[NUM_FEATURE_TYPES];
  int FeatureEnabled[NUM_FEATURE_TYPES];
};
typedef FEATURE_DEFS_STRUCT *FEATURE_DEFS;

/*----------------------------------------------------------------------
    Generic functions for manipulating character descriptions
----------------------------------------------------------------------*/
void TESS_API InitFeatureDefs(FEATURE_DEFS_STRUCT *featuredefs);

void FreeCharDescription(CHAR_DESC CharDesc);

CHAR_DESC NewCharDescription(const FEATURE_DEFS_STRUCT &FeatureDefs);

bool ValidCharDescription(const FEATURE_DEFS_STRUCT &FeatureDefs,
                          CHAR_DESC CharDesc);

void WriteCharDescription(const FEATURE_DEFS_STRUCT& FeatureDefs,
                          CHAR_DESC CharDesc, STRING* str);

CHAR_DESC TESS_API ReadCharDescription(const FEATURE_DEFS_STRUCT &FeatureDefs,
                              FILE *File);

int TESS_API ShortNameToFeatureType(const FEATURE_DEFS_STRUCT &FeatureDefs,
                           const char *ShortName);

/**----------------------------------------------------------------------------
        Global Data Definitions and Declarations
----------------------------------------------------------------------------**/
extern const FEATURE_DESC_STRUCT MicroFeatureDesc;
extern TESS_API const FEATURE_DESC_STRUCT PicoFeatDesc;
extern const FEATURE_DESC_STRUCT CharNormDesc;
extern const FEATURE_DESC_STRUCT OutlineFeatDesc;
extern const FEATURE_DESC_STRUCT IntFeatDesc;
//extern const FEATURE_DESC_STRUCT GeoFeatDesc;

#endif


 
 




#if    INTFX_H_DEBUG|1


namespace tesseract {
class TrainingSample;
}

struct INT_FX_RESULT_STRUCT {
  inT32 Length;                  // total length of all outlines
  inT16 Xmean, Ymean;            // center of mass of all outlines
  inT16 Rx, Ry;                  // radius of gyration
  inT16 NumBL, NumCN;            // number of features extracted
  inT16 Width;                   // Width of blob in BLN coords.
  uinT8 YBottom;                 // Bottom of blob in BLN coords.
  uinT8 YTop;                    // Top of blob in BLN coords.
};

// The standard feature length
const double kStandardFeatureLength = 64.0 / 5;

/**----------------------------------------------------------------------------
          Public Function Prototypes
----------------------------------------------------------------------------**/
void TESS_API InitIntegerFX();

// Returns a vector representing the direction of a feature with the given
// theta direction in an INT_FEATURE_STRUCT.
FCOORD FeatureDirection(uinT8 theta);

namespace tesseract {
  // Generates a TrainingSample from a TBLOB. Extracts features and sets
  // the bounding box, so classifiers that operate on the image can work.
  // TODO(rays) BlobToTrainingSample must remain a global function until
  // the FlexFx and FeatureDescription code can be removed and LearnBlob
  // made a member of Classify.
  TrainingSample* BlobToTrainingSample(
      const TBLOB& blob, bool nonlinear_norm, INT_FX_RESULT_STRUCT* fx_info,
      GenericVector<INT_FEATURE_STRUCT>* bl_features);
}

// Deprecated! Prefer tesseract::Classify::ExtractFeatures instead.
bool ExtractIntFeat(const TBLOB& blob,
                    bool nonlinear_norm,
                    INT_FEATURE_ARRAY BLFeat,
                    INT_FEATURE_ARRAY CNFeat,
                    INT_FX_RESULT_STRUCT* Results);









#endif

 










#if TESSERACT_CLASSIFY_CLASSIFY_H_DEBUG |1




struct ADAPT_RESULTS;
struct NORM_PROTOS;

static const int kUnknownFontinfoId = -1;
static const int kBlankFontinfoId = -2;

namespace tesseract {

class ShapeClassifier;
struct ShapeRating;
class ShapeTable;
struct UnicharRating;

// How segmented is a blob. In this enum, character refers to a classifiable
// unit, but that is too long and character is usually easier to understand.
enum CharSegmentationType {
  CST_FRAGMENT,  // A partial character.
  CST_WHOLE,     // A correctly segmented character.
  CST_IMPROPER,  // More than one but less than 2 characters.
  CST_NGRAM      // Multiple characters.
};

class Classify : public CCStruct {
 public:
  Classify();
  virtual ~Classify();
  Dict& getDict() {
    return dict_;
  }

  const ShapeTable* shape_table() const {
    return shape_table_;
  }

  // Takes ownership of the given classifier, and uses it for future calls
  // to CharNormClassifier.
  void SetStaticClassifier(ShapeClassifier* static_classifier);

  // Adds a noise classification result that is a bit worse than the worst
  // current result, or the worst possible result if no current results.
  void AddLargeSpeckleTo(int blob_length, BLOB_CHOICE_LIST *choices);

  // Returns true if the blob is small enough to be a large speckle.
  bool LargeSpeckle(const TBLOB &blob);

  /* adaptive.cpp ************************************************************/
  ADAPT_TEMPLATES NewAdaptedTemplates(bool InitFromUnicharset);
  int GetFontinfoId(ADAPT_CLASS Class, uinT8 ConfigId);
  // Runs the class pruner from int_templates on the given features, returning
  // the number of classes output in results.
  //    int_templates          Class pruner tables
  //    num_features           Number of features in blob
  //    features               Array of features
  //    normalization_factors  (input) Array of int_templates->NumClasses fudge
  //                           factors from blob normalization process.
  //                           (Indexed by CLASS_INDEX)
  //    expected_num_features  (input) Array of int_templates->NumClasses
  //                           expected number of features for each class.
  //                           (Indexed by CLASS_INDEX)
  //    results                (output) Sorted Array of pruned classes.
  //                           Array must be sized to take the maximum possible
  //                           number of outputs : int_templates->NumClasses.
  int PruneClasses(const INT_TEMPLATES_STRUCT* int_templates, int num_features,
                   int keep_this, const INT_FEATURE_STRUCT* features,
                   const uinT8* normalization_factors,
                   const uinT16* expected_num_features,
                   GenericVector<CP_RESULT_STRUCT>* results);
  void ReadNewCutoffs(FILE *CutoffFile, bool swap, inT64 end_offset,
                      CLASS_CUTOFF_ARRAY Cutoffs);
  void PrintAdaptedTemplates(FILE *File, ADAPT_TEMPLATES Templates);
  void WriteAdaptedTemplates(FILE *File, ADAPT_TEMPLATES Templates);
  ADAPT_TEMPLATES ReadAdaptedTemplates(FILE *File);
  /* normmatch.cpp ************************************************************/
  FLOAT32 ComputeNormMatch(CLASS_ID ClassId,
                           const FEATURE_STRUCT& feature, BOOL8 DebugMatch);
  void FreeNormProtos();
  NORM_PROTOS *ReadNormProtos(FILE *File, inT64 end_offset);
  /* protos.cpp ***************************************************************/
  void ConvertProto(PROTO Proto, int ProtoId, INT_CLASS Class);
  INT_TEMPLATES CreateIntTemplates(CLASSES FloatProtos,
                                   const UNICHARSET& target_unicharset);
  /* adaptmatch.cpp ***********************************************************/

  // Learns the given word using its chopped_word, seam_array, denorm,
  // box_word, best_state, and correct_text to learn both correctly and
  // incorrectly segmented blobs. If fontname is not NULL, then LearnBlob
  // is called and the data will be saved in an internal buffer.
  // Otherwise AdaptToBlob is called for adaption within a document.
  void LearnWord(const char* fontname, WERD_RES* word);

  // Builds a blob of length fragments, from the word, starting at start,
  // and then learns it, as having the given correct_text.
  // If fontname is not NULL, then LearnBlob is called and the data will be
  // saved in an internal buffer for static training.
  // Otherwise AdaptToBlob is called for adaption within a document.
  // threshold is a magic number required by AdaptToChar and generated by
  // ComputeAdaptionThresholds.
  // Although it can be partly inferred from the string, segmentation is
  // provided to explicitly clarify the character segmentation.
  void LearnPieces(const char* fontname, int start, int length, float threshold,
                   CharSegmentationType segmentation, const char* correct_text,
                   WERD_RES* word);
  void InitAdaptiveClassifier(bool load_pre_trained_templates);
  void InitAdaptedClass(TBLOB *Blob,
                        CLASS_ID ClassId,
                        int FontinfoId,
                        ADAPT_CLASS Class,
                        ADAPT_TEMPLATES Templates);
  void AmbigClassifier(const GenericVector<INT_FEATURE_STRUCT>& int_features,
                       const INT_FX_RESULT_STRUCT& fx_info,
                       const TBLOB *blob,
                       INT_TEMPLATES templates,
                       ADAPT_CLASS *classes,
                       UNICHAR_ID *ambiguities,
                       ADAPT_RESULTS *results);
  void MasterMatcher(INT_TEMPLATES templates,
                     inT16 num_features,
                     const INT_FEATURE_STRUCT* features,
                     const uinT8* norm_factors,
                     ADAPT_CLASS* classes,
                     int debug,
                     int matcher_multiplier,
                     const TBOX& blob_box,
                     const GenericVector<CP_RESULT_STRUCT>& results,
                     ADAPT_RESULTS* final_results);
  // Converts configs to fonts, and if the result is not adapted, and a
  // shape_table_ is present, the shape is expanded to include all
  // unichar_ids represented, before applying a set of corrections to the
  // distance rating in int_result, (see ComputeCorrectedRating.)
  // The results are added to the final_results output.
  void ExpandShapesAndApplyCorrections(ADAPT_CLASS* classes,
                                       bool debug,
                                       int class_id,
                                       int bottom, int top,
                                       float cp_rating,
                                       int blob_length,
                                       int matcher_multiplier,
                                       const uinT8* cn_factors,
                                       UnicharRating* int_result,
                                       ADAPT_RESULTS* final_results);
  // Applies a set of corrections to the distance im_rating,
  // including the cn_correction, miss penalty and additional penalty
  // for non-alnums being vertical misfits. Returns the corrected distance.
  double ComputeCorrectedRating(bool debug, int unichar_id, double cp_rating,
                                double im_rating, int feature_misses,
                                int bottom, int top,
                                int blob_length, int matcher_multiplier,
                                const uinT8* cn_factors);
  void ConvertMatchesToChoices(const DENORM& denorm, const TBOX& box,
                               ADAPT_RESULTS *Results,
                               BLOB_CHOICE_LIST *Choices);
  void AddNewResult(const UnicharRating& new_result, ADAPT_RESULTS *results);
  int GetAdaptiveFeatures(TBLOB *Blob,
                          INT_FEATURE_ARRAY IntFeatures,
                          FEATURE_SET *FloatFeatures);

#ifndef GRAPHICS_DISABLED
  void DebugAdaptiveClassifier(TBLOB *Blob,
                               ADAPT_RESULTS *Results);
#endif
  PROTO_ID MakeNewTempProtos(FEATURE_SET Features,
                             int NumBadFeat,
                             FEATURE_ID BadFeat[],
                             INT_CLASS IClass,
                             ADAPT_CLASS Class,
                             BIT_VECTOR TempProtoMask);
  int MakeNewTemporaryConfig(ADAPT_TEMPLATES Templates,
                             CLASS_ID ClassId,
                             int FontinfoId,
                             int NumFeatures,
                             INT_FEATURE_ARRAY Features,
                             FEATURE_SET FloatFeatures);
  void MakePermanent(ADAPT_TEMPLATES Templates,
                     CLASS_ID ClassId,
                     int ConfigId,
                     TBLOB *Blob);
  void PrintAdaptiveMatchResults(const ADAPT_RESULTS& results);
  void RemoveExtraPuncs(ADAPT_RESULTS *Results);
  void RemoveBadMatches(ADAPT_RESULTS *Results);
  void SetAdaptiveThreshold(FLOAT32 Threshold);
  void ShowBestMatchFor(int shape_id,
                        const INT_FEATURE_STRUCT* features,
                        int num_features);
  // Returns a string for the classifier class_id: either the corresponding
  // unicharset debug_str or the shape_table_ debug str.
  STRING ClassIDToDebugStr(const INT_TEMPLATES_STRUCT* templates,
                           int class_id, int config_id) const;
  // Converts a classifier class_id index with a config ID to:
  // shape_table_ present: a shape_table_ index OR
  // No shape_table_: a font ID.
  // Without shape training, each class_id, config pair represents a single
  // unichar id/font combination, so this function looks up the corresponding
  // font id.
  // With shape training, each class_id, config pair represents a single
  // shape table index, so the fontset_table stores the shape table index,
  // and the shape_table_ must be consulted to obtain the actual unichar_id/
  // font combinations that the shape represents.
  int ClassAndConfigIDToFontOrShapeID(int class_id,
                                      int int_result_config) const;
  // Converts a shape_table_ index to a classifier class_id index (not a
  // unichar-id!). Uses a search, so not fast.
  int ShapeIDToClassID(int shape_id) const;
  UNICHAR_ID *BaselineClassifier(
      TBLOB *Blob, const GenericVector<INT_FEATURE_STRUCT>& int_features,
      const INT_FX_RESULT_STRUCT& fx_info,
      ADAPT_TEMPLATES Templates, ADAPT_RESULTS *Results);
  int CharNormClassifier(TBLOB *blob,
                         const TrainingSample& sample,
                         ADAPT_RESULTS *adapt_results);

  // As CharNormClassifier, but operates on a TrainingSample and outputs to
  // a GenericVector of ShapeRating without conversion to classes.
  int CharNormTrainingSample(bool pruner_only, int keep_this,
                             const TrainingSample& sample,
                             GenericVector<UnicharRating>* results);
  UNICHAR_ID *GetAmbiguities(TBLOB *Blob, CLASS_ID CorrectClass);
  void DoAdaptiveMatch(TBLOB *Blob, ADAPT_RESULTS *Results);
  void AdaptToChar(TBLOB* Blob, CLASS_ID ClassId, int FontinfoId,
                   FLOAT32 Threshold, ADAPT_TEMPLATES adaptive_templates);
  void DisplayAdaptedChar(TBLOB* blob, INT_CLASS_STRUCT* int_class);
  bool AdaptableWord(WERD_RES* word);
  void EndAdaptiveClassifier();
  void SettupPass1();
  void SettupPass2();
  void AdaptiveClassifier(TBLOB *Blob, BLOB_CHOICE_LIST *Choices);
  void ClassifyAsNoise(ADAPT_RESULTS *Results);
  void ResetAdaptiveClassifierInternal();
  void SwitchAdaptiveClassifier();
  void StartBackupAdaptiveClassifier();

  int GetCharNormFeature(const INT_FX_RESULT_STRUCT& fx_info,
                         INT_TEMPLATES templates,
                         uinT8* pruner_norm_array,
                         uinT8* char_norm_array);
  // Computes the char_norm_array for the unicharset and, if not NULL, the
  // pruner_array as appropriate according to the existence of the shape_table.
  // The norm_feature is deleted as it is almost certainly no longer needed.
  void ComputeCharNormArrays(FEATURE_STRUCT* norm_feature,
                             INT_TEMPLATES_STRUCT* templates,
                             uinT8* char_norm_array,
                             uinT8* pruner_array);

  bool TempConfigReliable(CLASS_ID class_id, const TEMP_CONFIG &config);
  void UpdateAmbigsGroup(CLASS_ID class_id, TBLOB *Blob);

  bool AdaptiveClassifierIsFull() const { return NumAdaptationsFailed > 0; }
  bool AdaptiveClassifierIsEmpty() const {
    return AdaptedTemplates->NumPermClasses == 0;
  }
  bool LooksLikeGarbage(TBLOB *blob);
  void RefreshDebugWindow(ScrollView **win, const char *msg,
                          int y_offset, const TBOX &wbox);
  // intfx.cpp
  // Computes the DENORMS for bl(baseline) and cn(character) normalization
  // during feature extraction. The input denorm describes the current state
  // of the blob, which is usually a baseline-normalized word.
  // The Transforms setup are as follows:
  // Baseline Normalized (bl) Output:
  //   We center the grapheme by aligning the x-coordinate of its centroid with
  //   x=128 and leaving the already-baseline-normalized y as-is.
  //
  // Character Normalized (cn) Output:
  //   We align the grapheme's centroid at the origin and scale it
  //   asymmetrically in x and y so that the 2nd moments are a standard value
  //   (51.2) ie the result is vaguely square.
  // If classify_nonlinear_norm is true:
  //   A non-linear normalization is setup that attempts to evenly distribute
  //   edges across x and y.
  //
  // Some of the fields of fx_info are also setup:
  // Length: Total length of outline.
  // Rx:     Rounded y second moment. (Reversed by convention.)
  // Ry:     rounded x second moment.
  // Xmean:  Rounded x center of mass of the blob.
  // Ymean:  Rounded y center of mass of the blob.
  static void SetupBLCNDenorms(const TBLOB& blob, bool nonlinear_norm,
                               DENORM* bl_denorm, DENORM* cn_denorm,
                               INT_FX_RESULT_STRUCT* fx_info);

  // Extracts sets of 3-D features of length kStandardFeatureLength (=12.8), as
  // (x,y) position and angle as measured counterclockwise from the vector
  // <-1, 0>, from blob using two normalizations defined by bl_denorm and
  // cn_denorm. See SetpuBLCNDenorms for definitions.
  // If outline_cn_counts is not NULL, on return it contains the cumulative
  // number of cn features generated for each outline in the blob (in order).
  // Thus after the first outline, there were (*outline_cn_counts)[0] features,
  // after the second outline, there were (*outline_cn_counts)[1] features etc.
  static void ExtractFeatures(const TBLOB& blob,
                              bool nonlinear_norm,
                              GenericVector<INT_FEATURE_STRUCT>* bl_features,
                              GenericVector<INT_FEATURE_STRUCT>* cn_features,
                              INT_FX_RESULT_STRUCT* results,
                              GenericVector<int>* outline_cn_counts);
  /* float2int.cpp ************************************************************/
  void ClearCharNormArray(uinT8* char_norm_array);
  void ComputeIntCharNormArray(const FEATURE_STRUCT& norm_feature,
                               uinT8* char_norm_array);
  void ComputeIntFeatures(FEATURE_SET Features, INT_FEATURE_ARRAY IntFeatures);
  /* intproto.cpp *************************************************************/
  INT_TEMPLATES ReadIntTemplates(FILE *File);
  void WriteIntTemplates(FILE *File, INT_TEMPLATES Templates,
                         const UNICHARSET& target_unicharset);
  CLASS_ID GetClassToDebug(const char *Prompt, bool* adaptive_on,
                           bool* pretrained_on, int* shape_id);
  void ShowMatchDisplay();
  /* font detection ***********************************************************/
  UnicityTable<FontInfo>& get_fontinfo_table() {
    return fontinfo_table_;
  }
  const UnicityTable<FontInfo>& get_fontinfo_table() const {
    return fontinfo_table_;
  }
  UnicityTable<FontSet>& get_fontset_table() {
    return fontset_table_;
  }
  /* mfoutline.cpp ***********************************************************/
  void NormalizeOutlines(LIST Outlines, FLOAT32 *XScale, FLOAT32 *YScale);
  /* outfeat.cpp ***********************************************************/
  FEATURE_SET ExtractOutlineFeatures(TBLOB *Blob);
  /* picofeat.cpp ***********************************************************/
  FEATURE_SET ExtractPicoFeatures(TBLOB *Blob);
  FEATURE_SET ExtractIntCNFeatures(const TBLOB& blob,
                                   const INT_FX_RESULT_STRUCT& fx_info);
  FEATURE_SET ExtractIntGeoFeatures(const TBLOB& blob,
                                    const INT_FX_RESULT_STRUCT& fx_info);
  /* blobclass.cpp ***********************************************************/
  // Extracts features from the given blob and saves them in the tr_file_data_
  // member variable.
  // fontname:  Name of font that this blob was printed in.
  // cn_denorm: Character normalization transformation to apply to the blob.
  // fx_info:   Character normalization parameters computed with cn_denorm.
  // blob_text: Ground truth text for the blob.
  void LearnBlob(const STRING& fontname, TBLOB* Blob, const DENORM& cn_denorm,
                 const INT_FX_RESULT_STRUCT& fx_info, const char* blob_text);
  // Writes stored training data to a .tr file based on the given filename.
  // Returns false on error.
  bool WriteTRFile(const STRING& filename);

  // Member variables.

  // Parameters.
  // Set during training (in lang.config) to indicate whether the divisible
  // blobs chopper should be used (true for latin script.)
  BOOL_VAR_H(allow_blob_division, true, "Use divisible blobs chopping");
  // Set during training (in lang.config) to indicate whether the divisible
  // blobs chopper should be used in preference to chopping. Set to true for
  // southern Indic scripts.
  BOOL_VAR_H(prioritize_division, FALSE,
             "Prioritize blob division over chopping");
  INT_VAR_H(tessedit_single_match, FALSE, "Top choice only from CP");
  BOOL_VAR_H(classify_enable_learning, true, "Enable adaptive classifier");
  INT_VAR_H(classify_debug_level, 0, "Classify debug level");

  /* mfoutline.cpp ***********************************************************/
  /* control knobs used to control normalization of outlines */
  INT_VAR_H(classify_norm_method, character, "Normalization Method   ...");
  double_VAR_H(classify_char_norm_range, 0.2,
             "Character Normalization Range ...");
  double_VAR_H(classify_min_norm_scale_x, 0.0, "Min char x-norm scale ...");
  double_VAR_H(classify_max_norm_scale_x, 0.325, "Max char x-norm scale ...");
  double_VAR_H(classify_min_norm_scale_y, 0.0, "Min char y-norm scale ...");
  double_VAR_H(classify_max_norm_scale_y, 0.325, "Max char y-norm scale ...");
  double_VAR_H(classify_max_rating_ratio, 1.5,
               "Veto ratio between classifier ratings");
  double_VAR_H(classify_max_certainty_margin, 5.5,
               "Veto difference between classifier certainties");

  /* adaptmatch.cpp ***********************************************************/
  BOOL_VAR_H(tess_cn_matching, 0, "Character Normalized Matching");
  BOOL_VAR_H(tess_bn_matching, 0, "Baseline Normalized Matching");
  BOOL_VAR_H(classify_enable_adaptive_matcher, 1, "Enable adaptive classifier");
  BOOL_VAR_H(classify_use_pre_adapted_templates, 0,
             "Use pre-adapted classifier templates");
  BOOL_VAR_H(classify_save_adapted_templates, 0,
             "Save adapted templates to a file");
  BOOL_VAR_H(classify_enable_adaptive_debugger, 0, "Enable match debugger");
  BOOL_VAR_H(classify_nonlinear_norm, 0,
             "Non-linear stroke-density normalization");
  INT_VAR_H(matcher_debug_level, 0, "Matcher Debug Level");
  INT_VAR_H(matcher_debug_flags, 0, "Matcher Debug Flags");
  INT_VAR_H(classify_learning_debug_level, 0, "Learning Debug Level: ");
  double_VAR_H(matcher_good_threshold, 0.125, "Good Match (0-1)");
  double_VAR_H(matcher_reliable_adaptive_result, 0.0, "Great Match (0-1)");
  double_VAR_H(matcher_perfect_threshold, 0.02, "Perfect Match (0-1)");
  double_VAR_H(matcher_bad_match_pad, 0.15, "Bad Match Pad (0-1)");
  double_VAR_H(matcher_rating_margin, 0.1, "New template margin (0-1)");
  double_VAR_H(matcher_avg_noise_size, 12.0, "Avg. noise blob length: ");
  INT_VAR_H(matcher_permanent_classes_min, 1, "Min # of permanent classes");
  INT_VAR_H(matcher_min_examples_for_prototyping, 3,
            "Reliable Config Threshold");
  INT_VAR_H(matcher_sufficient_examples_for_prototyping, 5,
            "Enable adaption even if the ambiguities have not been seen");
  double_VAR_H(matcher_clustering_max_angle_delta, 0.015,
               "Maximum angle delta for prototype clustering");
  double_VAR_H(classify_misfit_junk_penalty, 0.0,
               "Penalty to apply when a non-alnum is vertically out of "
               "its expected textline position");
  double_VAR_H(rating_scale, 1.5, "Rating scaling factor");
  double_VAR_H(certainty_scale, 20.0, "Certainty scaling factor");
  double_VAR_H(tessedit_class_miss_scale, 0.00390625,
               "Scale factor for features not used");
  double_VAR_H(classify_adapted_pruning_factor, 2.5,
               "Prune poor adapted results this much worse than best result");
  double_VAR_H(classify_adapted_pruning_threshold, -1.0,
               "Threshold at which classify_adapted_pruning_factor starts");
  INT_VAR_H(classify_adapt_proto_threshold, 230,
            "Threshold for good protos during adaptive 0-255");
  INT_VAR_H(classify_adapt_feature_threshold, 230,
            "Threshold for good features during adaptive 0-255");
  BOOL_VAR_H(disable_character_fragments, TRUE,
             "Do not include character fragments in the"
             " results of the classifier");
  double_VAR_H(classify_character_fragments_garbage_certainty_threshold, -3.0,
               "Exclude fragments that do not match any whole character"
               " with at least this certainty");
  BOOL_VAR_H(classify_debug_character_fragments, FALSE,
             "Bring up graphical debugging windows for fragments training");
  BOOL_VAR_H(matcher_debug_separate_windows, FALSE,
             "Use two different windows for debugging the matching: "
             "One for the protos and one for the features.");
  STRING_VAR_H(classify_learn_debug_str, "", "Class str to debug learning");

  /* intmatcher.cpp **********************************************************/
  INT_VAR_H(classify_class_pruner_threshold, 229,
            "Class Pruner Threshold 0-255");
  INT_VAR_H(classify_class_pruner_multiplier, 15,
            "Class Pruner Multiplier 0-255:       ");
  INT_VAR_H(classify_cp_cutoff_strength, 7,
            "Class Pruner CutoffStrength:         ");
  INT_VAR_H(classify_integer_matcher_multiplier, 10,
            "Integer Matcher Multiplier  0-255:   ");

  // Use class variables to hold onto built-in templates and adapted templates.
  INT_TEMPLATES PreTrainedTemplates;
  ADAPT_TEMPLATES AdaptedTemplates;
  // The backup adapted templates are created from the previous page (only)
  // so they are always ready and reasonably well trained if the primary
  // adapted templates become full.
  ADAPT_TEMPLATES BackupAdaptedTemplates;

  // Create dummy proto and config masks for use with the built-in templates.
  BIT_VECTOR AllProtosOn;
  BIT_VECTOR AllConfigsOn;
  BIT_VECTOR AllConfigsOff;
  BIT_VECTOR TempProtoMask;
  bool EnableLearning;
  /* normmatch.cpp */
  NORM_PROTOS *NormProtos;
  /* font detection ***********************************************************/
  UnicityTable<FontInfo> fontinfo_table_;
  // Without shape training, each class_id, config pair represents a single
  // unichar id/font combination, so each fontset_table_ entry holds font ids
  // for each config in the class.
  // With shape training, each class_id, config pair represents a single
  // shape_table_ index, so the fontset_table_ stores the shape_table_ index,
  // and the shape_table_ must be consulted to obtain the actual unichar_id/
  // font combinations that the shape represents.
  UnicityTable<FontSet> fontset_table_;

  INT_VAR_H(il1_adaption_test, 0, "Don't adapt to i/I at beginning of word");
  BOOL_VAR_H(classify_bln_numeric_mode, 0,
             "Assume the input is numbers [0-9].");
  double_VAR_H(speckle_large_max_size, 0.30, "Max large speckle size");
  double_VAR_H(speckle_rating_penalty, 10.0,
               "Penalty to add to worst rating for noise");

 protected:

public:


  IntegerMatcher im_;
  FEATURE_DEFS_STRUCT feature_defs_;
  // If a shape_table_ is present, it is used to remap classifier output in
  // ExpandShapesAndApplyCorrections. font_ids referenced by configs actually
  // mean an index to the shape_table_ and the choices returned are *all* the
  // shape_table_ entries at that index.
  ShapeTable* shape_table_;

 private:

public:


  Dict dict_;
  // The currently active static classifier.
  ShapeClassifier* static_classifier_;

  /* variables used to hold performance statistics */
  int NumAdaptationsFailed;

  // Training data gathered here for all the images in a document.
  STRING tr_file_data_;

  // Expected number of features in the class pruner, used to penalize
  // unknowns that have too few features (like a c being classified as e) so
  // it doesn't recognize everything as '@' or '#'.
  // CharNormCutoffs is for the static classifier (with no shapetable).
  // BaselineCutoffs gets a copy of CharNormCutoffs as an estimate of the real
  // value in the adaptive classifier. Both are indexed by unichar_id.
  // shapetable_cutoffs_ provides a similar value for each shape in the
  // shape_table_
  uinT16* CharNormCutoffs;
  uinT16* BaselineCutoffs;
  GenericVector<uinT16> shapetable_cutoffs_;
  ScrollView* learn_debug_win_;
  ScrollView* learn_fragmented_word_debug_win_;
  ScrollView* learn_fragments_debug_win_;
};
}  // namespace tesseract

#endif  // TESSERACT_CLASSIFY_CLASSIFY_H__


 











 
#if  SEAM_H_DEBUG|1

 
/*----------------------------------------------------------------------
              I n c l u d e s
----------------------------------------------------------------------*/
#include "split.h"

/*----------------------------------------------------------------------
              T y p e s
----------------------------------------------------------------------*/
typedef float PRIORITY;          /*  PRIORITY  */

class SEAM {
 public:
  // A seam with no splits
  SEAM(float priority, const TPOINT& location)
      : priority_(priority),
        location_(location),
        widthp_(0),
        widthn_(0),
        num_splits_(0) {}
  // A seam with a single split point.
  SEAM(float priority, const TPOINT& location, const SPLIT& split)
      : priority_(priority),
        location_(location),
        widthp_(0),
        widthn_(0),
        num_splits_(1) {
    splits_[0] = split;
  }
  // Default copy constructor, operator= and destructor are OK!

  // Accessors.
  float priority() const { return priority_; }
  void set_priority(float priority) { priority_ = priority; }
  bool HasAnySplits() const { return num_splits_ > 0; }

  // Returns the bounding box of all the points in the seam.
  TBOX bounding_box() const;

  // Returns true if other can be combined into *this.
  bool CombineableWith(const SEAM& other, int max_x_dist,
                       float max_total_priority) const;
  // Combines other into *this. Only works if CombinableWith returned true.
  void CombineWith(const SEAM& other);

  // Returns true if the given blob contains all splits of *this SEAM.
  bool ContainedByBlob(const TBLOB& blob) const {
    for (int s = 0; s < num_splits_; ++s) {
      if (!splits_[s].ContainedByBlob(blob)) return false;
    }
    return true;
  }

  // Returns true if the given EDGEPT is used by this SEAM, checking only
  // the EDGEPT pointer, not the coordinates.
  bool UsesPoint(const EDGEPT* point) const {
    for (int s = 0; s < num_splits_; ++s) {
      if (splits_[s].UsesPoint(point)) return true;
    }
    return false;
  }
  // Returns true if *this and other share any common point, by coordinates.
  bool SharesPosition(const SEAM& other) const {
    for (int s = 0; s < num_splits_; ++s) {
      for (int t = 0; t < other.num_splits_; ++t)
        if (splits_[s].SharesPosition(other.splits_[t])) return true;
    }
    return false;
  }
  // Returns true if *this and other have any vertically overlapping splits.
  bool OverlappingSplits(const SEAM& other) const {
    for (int s = 0; s < num_splits_; ++s) {
      TBOX split1_box = splits_[s].bounding_box();
      for (int t = 0; t < other.num_splits_; ++t) {
        TBOX split2_box = other.splits_[t].bounding_box();
        if (split1_box.y_overlap(split2_box)) return true;
      }
    }
    return false;
  }

  // Marks the edgepts used by the seam so the segments made by the cut
  // never get split further by another seam in the future.
  void Finalize() {
    for (int s = 0; s < num_splits_; ++s) {
      splits_[s].point1->MarkChop();
      splits_[s].point2->MarkChop();
    }
  }

  // Returns true if the splits in *this SEAM appear OK in the sense that they
  // do not cross any outlines and do not chop off any ridiculously small
  // pieces.
  bool IsHealthy(const TBLOB& blob, int min_points, int min_area) const;

  // Computes the widthp_/widthn_ range for all existing SEAMs and for *this
  // seam, which is about to be inserted at insert_index. Returns false if
  // any of the computations fails, as this indicates an invalid chop.
  // widthn_/widthp_ are only changed if modify is true.
  bool PrepareToInsertSeam(const GenericVector<SEAM*>& seams,
                           const GenericVector<TBLOB*>& blobs, int insert_index,
                           bool modify);
  // Computes the widthp_/widthn_ range. Returns false if not all the splits
  // are accounted for. widthn_/widthp_ are only changed if modify is true.
  bool FindBlobWidth(const GenericVector<TBLOB*>& blobs, int index,
                     bool modify);

  // Splits this blob into two blobs by applying the splits included in
  // *this SEAM
  void ApplySeam(bool italic_blob, TBLOB* blob, TBLOB* other_blob) const;
  // Undoes ApplySeam by removing the seam between these two blobs.
  // Produces one blob as a result, and deletes other_blob.
  void UndoSeam(TBLOB* blob, TBLOB* other_blob) const;

  // Prints everything in *this SEAM.
  void Print(const char* label) const;
  // Prints a collection of SEAMs.
  static void PrintSeams(const char* label, const GenericVector<SEAM*>& seams);
#ifndef GRAPHICS_DISABLED
  // Draws the seam in the given window.
  void Mark(ScrollView* window) const;
#endif

  // Break up the blobs in this chain so that they are all independent.
  // This operation should undo the affect of join_pieces.
  static void BreakPieces(const GenericVector<SEAM*>& seams,
                          const GenericVector<TBLOB*>& blobs, int first,
                          int last);
  // Join a group of base level pieces into a single blob that can then
  // be classified.
  static void JoinPieces(const GenericVector<SEAM*>& seams,
                         const GenericVector<TBLOB*>& blobs, int first,
                         int last);

  // Hides the seam so the outlines appear not to be cut by it.
  void Hide() const;
  // Undoes hide, so the outlines are cut by the seam.
  void Reveal() const;

  // Computes and returns, but does not set, the full priority of *this SEAM.
  // The arguments here are config parameters defined in Wordrec. Add chop_
  // to the beginning of the name.
  float FullPriority(int xmin, int xmax, double overlap_knob,
                     int centered_maxwidth, double center_knob,
                     double width_change_knob) const;

 private:
  // Maximum number of splits that a SEAM can hold.
  static const int kMaxNumSplits = 3;
  // Priority of this split. Lower is better.
  float priority_;
  // Position of the middle of the seam.
  TPOINT location_;
  // A range such that all splits in *this SEAM are contained within blobs in
  // the range [index - widthn_,index + widthp_] where index is the index of
  // this SEAM in the seams vector.
  inT8 widthp_;
  inT8 widthn_;
  // Number of splits_ that are used.
  inT8 num_splits_;
  // Set of pairs of points that are the ends of each split in the SEAM.
  SPLIT splits_[kMaxNumSplits];
};

/*----------------------------------------------------------------------
              F u n c t i o n s
----------------------------------------------------------------------*/

void start_seam_list(TWERD* word, GenericVector<SEAM*>* seam_array);

#endif


 




#if  TESSERACT_CCSTRUCT_BLAMER_H_DEBUG |1



static const inT16 kBlamerBoxTolerance = 5;

// Enum for expressing the source of error.
// Note: Please update kIncorrectResultReasonNames when modifying this enum.
enum IncorrectResultReason {
  // The text recorded in best choice == truth text
  IRR_CORRECT,
  // Either: Top choice is incorrect and is a dictionary word (language model
  // is unlikely to help correct such errors, so blame the classifier).
  // Or: the correct unichar was not included in shortlist produced by the
  // classifier at all.
  IRR_CLASSIFIER,
  // Chopper have not found one or more splits that correspond to the correct
  // character bounding boxes recorded in BlamerBundle::truth_word.
  IRR_CHOPPER,
  // Classifier did include correct unichars for each blob in the correct
  // segmentation, however its rating could have been too bad to allow the
  // language model to pull out the correct choice. On the other hand the
  // strength of the language model might have been too weak to favor the
  // correct answer, this we call this case a classifier-language model
  // tradeoff error.
  IRR_CLASS_LM_TRADEOFF,
  // Page layout failed to produce the correct bounding box. Blame page layout
  // if the truth was not found for the word, which implies that the bounding
  // box of the word was incorrect (no truth word had a similar bounding box).
  IRR_PAGE_LAYOUT,
  // SegSearch heuristic prevented one or more blobs from the correct
  // segmentation state to be classified (e.g. the blob was too wide).
  IRR_SEGSEARCH_HEUR,
  // The correct segmentaiton state was not explored because of poor SegSearch
  // pain point prioritization. We blame SegSearch pain point prioritization
  // if the best rating of a choice constructed from correct segmentation is
  // better than that of the best choice (i.e. if we got to explore the correct
  // segmentation state, language model would have picked the correct choice).
  IRR_SEGSEARCH_PP,
  // Same as IRR_CLASS_LM_TRADEOFF, but used when we only run chopper on a word,
  // and thus use the old language model (permuters).
  // TODO(antonova): integrate the new language mode with chopper
  IRR_CLASS_OLD_LM_TRADEOFF,
  // If there is an incorrect adaptive template match with a better score than
  // a correct one (either pre-trained or adapted), mark this as adaption error.
  IRR_ADAPTION,
  // split_and_recog_word() failed to find a suitable split in truth.
  IRR_NO_TRUTH_SPLIT,
  // Truth is not available for this word (e.g. when words in corrected content
  // file are turned into ~~~~ because an appropriate alignment was not found.
  IRR_NO_TRUTH,
  // The text recorded in best choice != truth text, but none of the above
  // reasons are set.
  IRR_UNKNOWN,

  IRR_NUM_REASONS
};

// Blamer-related information to determine the source of errors.
struct BlamerBundle {
  static const char *IncorrectReasonName(IncorrectResultReason irr);
  BlamerBundle() : truth_has_char_boxes_(false),
      incorrect_result_reason_(IRR_CORRECT),
      lattice_data_(NULL) { ClearResults(); }
  BlamerBundle(const BlamerBundle &other) {
    this->CopyTruth(other);
    this->CopyResults(other);
  }
  ~BlamerBundle() { delete[] lattice_data_; }

  // Accessors.
  STRING TruthString() const {
    STRING truth_str;
    for (int i = 0; i < truth_text_.length(); ++i)
      truth_str += truth_text_[i];
    return truth_str;
  }
  IncorrectResultReason incorrect_result_reason() const {
    return incorrect_result_reason_;
  }
  bool NoTruth() const {
    return incorrect_result_reason_ == IRR_NO_TRUTH ||
           incorrect_result_reason_ == IRR_PAGE_LAYOUT;
  }
  bool HasDebugInfo() const {
    return debug_.length() > 0 || misadaption_debug_.length() > 0;
  }
  const STRING& debug() const {
    return debug_;
  }
  const STRING& misadaption_debug() const {
    return misadaption_debug_;
  }
  void UpdateBestRating(float rating) {
    if (rating < best_correctly_segmented_rating_)
      best_correctly_segmented_rating_ = rating;
  }
  int correct_segmentation_length() const {
    return correct_segmentation_cols_.length();
  }
  // Returns true if the given ratings matrix col,row position is included
  // in the correct segmentation path at the given index.
  bool MatrixPositionCorrect(int index, const MATRIX_COORD& coord) {
    return correct_segmentation_cols_[index] == coord.col &&
        correct_segmentation_rows_[index] == coord.row;
  }
  void set_best_choice_is_dict_and_top_choice(bool value) {
    best_choice_is_dict_and_top_choice_ = value;
  }
  const char* lattice_data() const {
    return lattice_data_;
  }
  int lattice_size() const {
    return lattice_size_;  // size of lattice_data in bytes
  }
  void set_lattice_data(const char* data, int size) {
    lattice_size_ = size;
    delete [] lattice_data_;
    lattice_data_ = new char[lattice_size_];
    memcpy(lattice_data_, data, lattice_size_);
  }
  const tesseract::ParamsTrainingBundle& params_training_bundle() const {
    return params_training_bundle_;
  }
  // Adds a new ParamsTrainingHypothesis to the current hypothesis list.
  void AddHypothesis(const tesseract::ParamsTrainingHypothesis& hypo) {
    params_training_bundle_.AddHypothesis(hypo);
  }

  // Functions to setup the blamer.
  // Whole word string, whole word bounding box.
  void SetWordTruth(const UNICHARSET& unicharset,
                    const char* truth_str, const TBOX& word_box);
  // Single "character" string, "character" bounding box.
  // May be called multiple times to indicate the characters in a word.
  void SetSymbolTruth(const UNICHARSET& unicharset,
                      const char* char_str, const TBOX& char_box);
  // Marks that there is something wrong with the truth text, like it contains
  // reject characters.
  void SetRejectedTruth();

  // Returns true if the provided word_choice is correct.
  bool ChoiceIsCorrect(const WERD_CHOICE* word_choice) const;

  void ClearResults() {
    norm_truth_word_.DeleteAllBoxes();
    norm_box_tolerance_ = 0;
    if (!NoTruth()) incorrect_result_reason_ = IRR_CORRECT;
    debug_ = "";
    segsearch_is_looking_for_blame_ = false;
    best_correctly_segmented_rating_ = WERD_CHOICE::kBadRating;
    correct_segmentation_cols_.clear();
    correct_segmentation_rows_.clear();
    best_choice_is_dict_and_top_choice_ = false;
    delete[] lattice_data_;
    lattice_data_ = NULL;
    lattice_size_ = 0;
  }
  void CopyTruth(const BlamerBundle &other) {
    truth_has_char_boxes_ = other.truth_has_char_boxes_;
    truth_word_ = other.truth_word_;
    truth_text_ = other.truth_text_;
    incorrect_result_reason_ =
        (other.NoTruth() ? other.incorrect_result_reason_ : IRR_CORRECT);
  }
  void CopyResults(const BlamerBundle &other) {
    norm_truth_word_ = other.norm_truth_word_;
    norm_box_tolerance_ = other.norm_box_tolerance_;
    incorrect_result_reason_ = other.incorrect_result_reason_;
    segsearch_is_looking_for_blame_ = other.segsearch_is_looking_for_blame_;
    best_correctly_segmented_rating_ = other.best_correctly_segmented_rating_;
    correct_segmentation_cols_ = other.correct_segmentation_cols_;
    correct_segmentation_rows_ = other.correct_segmentation_rows_;
    best_choice_is_dict_and_top_choice_ =
        other.best_choice_is_dict_and_top_choice_;
    if (other.lattice_data_ != NULL) {
      lattice_data_ = new char[other.lattice_size_];
      memcpy(lattice_data_, other.lattice_data_, other.lattice_size_);
      lattice_size_ = other.lattice_size_;
    } else {
      lattice_data_ = NULL;
    }
  }
  const char *IncorrectReason() const;

  // Appends choice and truth details to the given debug string.
  void FillDebugString(const STRING &msg, const WERD_CHOICE *choice,
                       STRING *debug);

  // Sets up the norm_truth_word from truth_word using the given DENORM.
  void SetupNormTruthWord(const DENORM& denorm);

  // Splits *this into two pieces in bundle1 and bundle2 (preallocated, empty
  // bundles) where the right edge/ of the left-hand word is word1_right,
  // and the left edge of the right-hand word is word2_left.
  void SplitBundle(int word1_right, int word2_left, bool debug,
                   BlamerBundle* bundle1, BlamerBundle* bundle2) const;
  // "Joins" the blames from bundle1 and bundle2 into *this.
  void JoinBlames(const BlamerBundle& bundle1, const BlamerBundle& bundle2,
                  bool debug);

  // If a blob with the same bounding box as one of the truth character
  // bounding boxes is not classified as the corresponding truth character
  // blames character classifier for incorrect answer.
  void BlameClassifier(const UNICHARSET& unicharset,
                       const TBOX& blob_box,
                       const BLOB_CHOICE_LIST& choices,
                       bool debug);


  // Checks whether chops were made at all the character bounding box
  // boundaries in word->truth_word. If not - blames the chopper for an
  // incorrect answer.
  void SetChopperBlame(const WERD_RES* word, bool debug);
  // Blames the classifier or the language model if, after running only the
  // chopper, best_choice is incorrect and no blame has been yet set.
  // Blames the classifier if best_choice is classifier's top choice and is a
  // dictionary word (i.e. language model could not have helped).
  // Otherwise, blames the language model (formerly permuter word adjustment).
  void BlameClassifierOrLangModel(
      const WERD_RES* word,
      const UNICHARSET& unicharset, bool valid_permuter, bool debug);
  // Sets up the correct_segmentation_* to mark the correct bounding boxes.
  void SetupCorrectSegmentation(const TWERD* word, bool debug);

  // Returns true if a guided segmentation search is needed.
  bool GuidedSegsearchNeeded(const WERD_CHOICE *best_choice) const;
  // Setup ready to guide the segmentation search to the correct segmentation.
  // The callback pp_cb is used to avoid a cyclic dependency.
  // It calls into LMPainPoints::GenerateForBlamer by pre-binding the
  // WERD_RES, and the LMPainPoints itself.
  // pp_cb must be a permanent callback, and should be deleted by the caller.
  void InitForSegSearch(const WERD_CHOICE *best_choice,
                        MATRIX* ratings, UNICHAR_ID wildcard_id,
                        bool debug, STRING *debug_str,
                        TessResultCallback2<bool, int, int>* pp_cb);
  // Returns true if the guided segsearch is in progress.
  bool GuidedSegsearchStillGoing() const;
  // The segmentation search has ended. Sets the blame appropriately.
  void FinishSegSearch(const WERD_CHOICE *best_choice,
                       bool debug, STRING *debug_str);

  // If the bundle is null or still does not indicate the correct result,
  // fix it and use some backup reason for the blame.
  static void LastChanceBlame(bool debug, WERD_RES* word);

  // Sets the misadaption debug if this word is incorrect, as this word is
  // being adapted to.
  void SetMisAdaptionDebug(const WERD_CHOICE *best_choice, bool debug);

 private:
  void SetBlame(IncorrectResultReason irr, const STRING &msg,
                const WERD_CHOICE *choice, bool debug) {
    incorrect_result_reason_ = irr;
    debug_ = IncorrectReason();
    debug_ += " to blame: ";
    FillDebugString(msg, choice, &debug_);
    if (debug) tprintf("SetBlame(): %s", debug_.string());
  }

 private:
  // Set to true when bounding boxes for individual unichars are recorded.
  bool truth_has_char_boxes_;
  // The true_word (in the original image coordinate space) contains ground
  // truth bounding boxes for this WERD_RES.
  tesseract::BoxWord truth_word_;
  // Same as above, but in normalized coordinates
  // (filled in by WERD_RES::SetupForRecognition()).
  tesseract::BoxWord norm_truth_word_;
  // Tolerance for bounding box comparisons in normalized space.
  int norm_box_tolerance_;
  // Contains ground truth unichar for each of the bounding boxes in truth_word.
  GenericVector<STRING> truth_text_;
  // The reason for incorrect OCR result.
  IncorrectResultReason incorrect_result_reason_;
  // Debug text associated with the blame.
  STRING debug_;
  // Misadaption debug information (filled in if this word was misadapted to).
  STRING misadaption_debug_;
  // Variables used by the segmentation search when looking for the blame.
  // Set to true while segmentation search is continued after the usual
  // termination condition in order to look for the blame.
  bool segsearch_is_looking_for_blame_;
  // Best rating for correctly segmented path
  // (set and used by SegSearch when looking for blame).
  float best_correctly_segmented_rating_;
  // Vectors populated by SegSearch to indicate column and row indices that
  // correspond to blobs with correct bounding boxes.
  GenericVector<int> correct_segmentation_cols_;
  GenericVector<int> correct_segmentation_rows_;
  // Set to true if best choice is a dictionary word and
  // classifier's top choice.
  bool best_choice_is_dict_and_top_choice_;
  // Serialized segmentation search lattice.
  char *lattice_data_;
  int lattice_size_;  // size of lattice_data in bytes
  // Information about hypotheses (paths) explored by the segmentation search.
  tesseract::ParamsTrainingBundle params_training_bundle_;
};






#endif  // TESSERACT_CCSTRUCT_BLAMER_H_


 







#if  REJCTMAP_DEBUG|1




enum REJ_FLAGS {
  /* Reject modes which are NEVER overridden */
  R_TESS_FAILURE,    // PERM Tess didn't classify
  R_SMALL_XHT,       // PERM Xht too small
  R_EDGE_CHAR,       // PERM Too close to edge of image
  R_1IL_CONFLICT,    // PERM 1Il confusion
  R_POSTNN_1IL,      // PERM 1Il unrejected by NN
  R_REJ_CBLOB,       // PERM Odd blob
  R_MM_REJECT,       // PERM Matrix match rejection (m's)
  R_BAD_REPETITION,  // TEMP Repeated char which doesn't match trend

  /* Initial reject modes (pre NN_ACCEPT) */
  R_POOR_MATCH,         // TEMP Ray's original heuristic (Not used)
  R_NOT_TESS_ACCEPTED,  // TEMP Tess didn't accept WERD
  R_CONTAINS_BLANKS,    // TEMP Tess failed on other chs in WERD
  R_BAD_PERMUTER,       // POTENTIAL Bad permuter for WERD

  /* Reject modes generated after NN_ACCEPT but before MM_ACCEPT */
  R_HYPHEN,        // TEMP Post NN dodgy hyphen or full stop
  R_DUBIOUS,       // TEMP Post NN dodgy chars
  R_NO_ALPHANUMS,  // TEMP No alphanumerics in word after NN
  R_MOSTLY_REJ,    // TEMP Most of word rejected so rej the rest
  R_XHT_FIXUP,     // TEMP Xht tests unsure

  /* Reject modes generated after MM_ACCEPT but before QUALITY_ACCEPT */
  R_BAD_QUALITY,  // TEMP Quality metrics bad for WERD

  /* Reject modes generated after QUALITY_ACCEPT but before MINIMAL_REJ accep*/
  R_DOC_REJ,    // TEMP Document rejection
  R_BLOCK_REJ,  // TEMP Block rejection
  R_ROW_REJ,    // TEMP Row rejection
  R_UNLV_REJ,   // TEMP ~ turned to - or ^ turned to space

  /* Accept modes which occur between the above rejection groups */
  R_NN_ACCEPT,          // NN acceptance
  R_HYPHEN_ACCEPT,      // Hyphen acceptance
  R_MM_ACCEPT,          // Matrix match acceptance
  R_QUALITY_ACCEPT,     // Accept word in good quality doc
  R_MINIMAL_REJ_ACCEPT  // Accept EVERYTHING except tess failures
};

/* REJECT MAP VALUES */

#define           MAP_ACCEPT '1'
#define           MAP_REJECT_PERM '0'
#define           MAP_REJECT_TEMP '2'
#define           MAP_REJECT_POTENTIAL '3'

class REJ
{
  BITS16 flags1;
  BITS16 flags2;

  void set_flag(REJ_FLAGS rej_flag) {
    if (rej_flag < 16)
      flags1.turn_on_bit (rej_flag);
    else
      flags2.turn_on_bit (rej_flag - 16);
  }

  BOOL8 rej_before_nn_accept();
  BOOL8 rej_between_nn_and_mm();
  BOOL8 rej_between_mm_and_quality_accept();
  BOOL8 rej_between_quality_and_minimal_rej_accept();
  BOOL8 rej_before_mm_accept();
  BOOL8 rej_before_quality_accept();

  public:
    REJ() {  //constructor
    }

    REJ(  //classwise copy
        const REJ &source) {
      flags1 = source.flags1;
      flags2 = source.flags2;
    }

    REJ & operator= (            //assign REJ
    const REJ & source) {        //from this
      flags1 = source.flags1;
      flags2 = source.flags2;
      return *this;
    }

    BOOL8 flag(REJ_FLAGS rej_flag) {
      if (rej_flag < 16)
        return flags1.bit (rej_flag);
      else
        return flags2.bit (rej_flag - 16);
    }

    char display_char() {
      if (perm_rejected ())
        return MAP_REJECT_PERM;
      else if (accept_if_good_quality ())
        return MAP_REJECT_POTENTIAL;
      else if (rejected ())
        return MAP_REJECT_TEMP;
      else
        return MAP_ACCEPT;
    }

    BOOL8 perm_rejected();  //Is char perm reject?

    BOOL8 rejected();  //Is char rejected?

    BOOL8 accepted() {  //Is char accepted?
      return !rejected ();
    }

                                 //potential rej?
    BOOL8 accept_if_good_quality();

    BOOL8 recoverable() {
      return (rejected () && !perm_rejected ());
    }

    void setrej_tess_failure();  //Tess generated blank
    void setrej_small_xht();  //Small xht char/wd
    void setrej_edge_char();  //Close to image edge
    void setrej_1Il_conflict();  //Initial reject map
    void setrej_postNN_1Il();  //1Il after NN
    void setrej_rej_cblob();  //Insert duff blob
    void setrej_mm_reject();  //Matrix matcher
                                 //Odd repeated char
    void setrej_bad_repetition();
    void setrej_poor_match();  //Failed Rays heuristic
                                 //TEMP reject_word
    void setrej_not_tess_accepted();
                                 //TEMP reject_word
    void setrej_contains_blanks();
    void setrej_bad_permuter();  //POTENTIAL reject_word
    void setrej_hyphen();  //PostNN dubious hyph or .
    void setrej_dubious();  //PostNN dubious limit
    void setrej_no_alphanums();  //TEMP reject_word
    void setrej_mostly_rej();  //TEMP reject_word
    void setrej_xht_fixup();  //xht fixup
    void setrej_bad_quality();  //TEMP reject_word
    void setrej_doc_rej();  //TEMP reject_word
    void setrej_block_rej();  //TEMP reject_word
    void setrej_row_rej();  //TEMP reject_word
    void setrej_unlv_rej();  //TEMP reject_word
    void setrej_nn_accept();  //NN Flipped a char
    void setrej_hyphen_accept();  //Good aspect ratio
    void setrej_mm_accept();  //Matrix matcher
                                 //Quality flip a char
    void setrej_quality_accept();
                                 //Accept all except blank
    void setrej_minimal_rej_accept();

    void full_print(FILE *fp);
};

class REJMAP
{
  REJ *ptr;                      //ptr to the chars
  inT16 len;                     //Number of chars

  public:
    REJMAP() {  //constructor
      ptr = NULL;
      len = 0;
    }

    REJMAP(  //classwise copy
           const REJMAP &rejmap);

    REJMAP & operator= (         //assign REJMAP
      const REJMAP & source);    //from this

    ~REJMAP () {                 //destructor
      if (ptr != NULL)
        free_struct (ptr, len * sizeof (REJ), "REJ");
    }

    void initialise(  //Redefine map
                    inT16 length);

    REJ & operator[](            //access function
      inT16 index) const         //map index
    {
      ASSERT_HOST (index < len);
      return ptr[index];         //no bounds checks
    }

    inT32 length() const {  //map length
      return len;
    }

    inT16 accept_count();  //How many accepted?

    inT16 reject_count() {  //How many rejects?
      return len - accept_count ();
    }

    void remove_pos(             //Cut out an element
                    inT16 pos);  //element to remove

    void print(FILE *fp);

    void full_print(FILE *fp);

    BOOL8 recoverable_rejects();  //Any non perm rejs?

    BOOL8 quality_recoverable_rejects();
    //Any potential rejs?

    void rej_word_small_xht();  //Reject whole word
                                 //Reject whole word
    void rej_word_tess_failure();
    void rej_word_not_tess_accepted();
    //Reject whole word
                                 //Reject whole word
    void rej_word_contains_blanks();
                                 //Reject whole word
    void rej_word_bad_permuter();
    void rej_word_xht_fixup();  //Reject whole word
                                 //Reject whole word
    void rej_word_no_alphanums();
    void rej_word_mostly_rej();  //Reject whole word
    void rej_word_bad_quality();  //Reject whole word
    void rej_word_doc_rej();  //Reject whole word
    void rej_word_block_rej();  //Reject whole word
    void rej_word_row_rej();  //Reject whole word
};




#endif


 
 









#if PAGERES_H_DBG |1


namespace tesseract {
struct FontInfo;
class Tesseract;
}
using tesseract::FontInfo;

/* Forward declarations */

class BLOCK_RES;

ELISTIZEH (BLOCK_RES) CLISTIZEH (BLOCK_RES)
class
ROW_RES;

ELISTIZEH (ROW_RES)
class WERD_RES;

ELISTIZEH (WERD_RES)

/*************************************************************************
 * PAGE_RES - Page results
 *************************************************************************/
class PAGE_RES {                 // page result
 public:
  inT32 char_count;
  inT32 rej_count;
  BLOCK_RES_LIST block_res_list;
  BOOL8 rejected;
  // Updated every time PAGE_RES_IT iterating on this PAGE_RES moves to
  // the next word. This pointer is not owned by PAGE_RES class.
  WERD_CHOICE **prev_word_best_choice;
  // Sums of blame reasons computed by the blamer.
  GenericVector<int> blame_reasons;
  // Debug information about all the misadaptions on this page.
  // Each BlamerBundle contains an index into this vector, so that words that
  // caused misadaption could be marked. However, since words could be
  // deleted/split/merged, the log is stored on the PAGE_RES level.
  GenericVector<STRING> misadaption_log;

  inline void Init() {
    char_count = 0;
    rej_count = 0;
    rejected = FALSE;
    prev_word_best_choice = NULL;
    blame_reasons.init_to_size(IRR_NUM_REASONS, 0);
  }

  PAGE_RES() { Init(); }  // empty constructor

  PAGE_RES(bool merge_similar_words,
           BLOCK_LIST *block_list,   // real blocks
           WERD_CHOICE **prev_word_best_choice_ptr);

  ~PAGE_RES () {               // destructor
  }
};

/*************************************************************************
 * BLOCK_RES - Block results
 *************************************************************************/

class BLOCK_RES:public ELIST_LINK {
 public:
  BLOCK * block;               // real block
  inT32 char_count;            // chars in block
  inT32 rej_count;             // rejected chars
  inT16 font_class;            //
  inT16 row_count;
  float x_height;
  BOOL8 font_assigned;         // block already
  //      processed
  BOOL8 bold;                  // all bold
  BOOL8 italic;                // all italic

  ROW_RES_LIST row_res_list;

  BLOCK_RES() {
  }                            // empty constructor

  BLOCK_RES(bool merge_similar_words, BLOCK *the_block);  // real block

  ~BLOCK_RES () {              // destructor
  }
};

/*************************************************************************
 * ROW_RES - Row results
 *************************************************************************/

class ROW_RES:public ELIST_LINK {
 public:
  ROW * row;                   // real row
  inT32 char_count;            // chars in block
  inT32 rej_count;             // rejected chars
  inT32 whole_word_rej_count;  // rejs in total rej wds
  WERD_RES_LIST word_res_list;

  ROW_RES() {
  }                            // empty constructor

  ROW_RES(bool merge_similar_words, ROW *the_row);  // real row

  ~ROW_RES() {                // destructor
  }
};

/*************************************************************************
 * WERD_RES - Word results
 *************************************************************************/
enum CRUNCH_MODE
{
  CR_NONE,
  CR_KEEP_SPACE,
  CR_LOOSE_SPACE,
  CR_DELETE
};

// WERD_RES is a collection of publicly accessible members that gathers
// information about a word result.
class WERD_RES : public ELIST_LINK {
 public:
  // Which word is which?
  // There are 3 coordinate spaces in use here: a possibly rotated pixel space,
  // the original image coordinate space, and the BLN space in which the
  // baseline of a word is at kBlnBaselineOffset, the xheight is kBlnXHeight,
  // and the x-middle of the word is at 0.
  // In the rotated pixel space, coordinates correspond to the input image,
  // but may be rotated about the origin by a multiple of 90 degrees,
  // and may therefore be negative.
  // In any case a rotation by denorm.block()->re_rotation() will take them
  // back to the original image.
  // The other differences between words all represent different stages of
  // processing during recognition.

  // ---------------------------INPUT-------------------------------------

  // The word is the input C_BLOBs in the rotated pixel space.
  // word is NOT owned by the WERD_RES unless combination is true.
  // All the other word pointers ARE owned by the WERD_RES.
  WERD* word;                     // Input C_BLOB word.

  // -------------SETUP BY SetupFor*Recognition---READONLY-INPUT------------

  // The bln_boxes contains the bounding boxes (only) of the input word, in the
  // BLN space. The lengths of word and bln_boxes
  // match as they are both before any chopping.
  // TODO(rays) determine if docqual does anything useful and delete bln_boxes
  // if it doesn't.
  tesseract::BoxWord* bln_boxes;  // BLN input bounding boxes.
  // The ROW that this word sits in. NOT owned by the WERD_RES.
  ROW* blob_row;
  // The denorm provides the transformation to get back to the rotated image
  // coords from the chopped_word/rebuild_word BLN coords, but each blob also
  // has its own denorm.
  DENORM denorm;                  // For use on chopped_word.
  // Unicharset used by the classifier output in best_choice and raw_choice.
  const UNICHARSET* uch_set;  // For converting back to utf8.

  // ----Initialized by SetupFor*Recognition---BUT OUTPUT FROM RECOGNITION----
  // ----Setup to a (different!) state expected by the various classifiers----
  // TODO(rays) Tidy and make more consistent.

  // The chopped_word is also in BLN space, and represents the fully chopped
  // character fragments that make up the word.
  // The length of chopped_word matches length of seam_array + 1 (if set).
  TWERD* chopped_word;            // BLN chopped fragments output.
  // Vector of SEAM* holding chopping points matching chopped_word.
  GenericVector<SEAM*> seam_array;
  // Widths of blobs in chopped_word.
  GenericVector<int> blob_widths;
  // Gaps between blobs in chopped_word. blob_gaps[i] is the gap between
  // blob i and blob i+1.
  GenericVector<int> blob_gaps;
  // Ratings matrix contains classifier choices for each classified combination
  // of blobs. The dimension is the same as the number of blobs in chopped_word
  // and the leading diagonal corresponds to classifier results of the blobs
  // in chopped_word. The state_ members of best_choice, raw_choice and
  // best_choices all correspond to this ratings matrix and allow extraction
  // of the blob choices for any given WERD_CHOICE.
  MATRIX* ratings;                // Owned pointer.
  // Pointer to the first WERD_CHOICE in best_choices. This is the result that
  // will be output from Tesseract. Note that this is now a borrowed pointer
  // and should NOT be deleted.
  WERD_CHOICE* best_choice;       // Borrowed pointer.
  // The best raw_choice found during segmentation search. Differs from the
  // best_choice by being the best result according to just the character
  // classifier, not taking any language model information into account.
  // Unlike best_choice, the pointer IS owned by this WERD_RES.
  WERD_CHOICE* raw_choice;        // Owned pointer.
  // Alternative results found during chopping/segmentation search stages.
  // Note that being an ELIST, best_choices owns the WERD_CHOICEs.
  WERD_CHOICE_LIST best_choices;

  // Truth bounding boxes, text and incorrect choice reason.
  BlamerBundle *blamer_bundle;

  // --------------OUTPUT FROM RECOGNITION-------------------------------
  // --------------Not all fields are necessarily set.-------------------
  // ---best_choice, raw_choice *must* end up set, with a box_word-------
  // ---In complete output, the number of blobs in rebuild_word matches---
  // ---the number of boxes in box_word, the number of unichar_ids in---
  // ---best_choice, the number of ints in best_state, and the number---
  // ---of strings in correct_text--------------------------------------
  // ---SetupFake Sets everything to appropriate values if the word is---
  // ---known to be bad before recognition.------------------------------

  // The rebuild_word is also in BLN space, but represents the final best
  // segmentation of the word. Its length is therefore the same as box_word.
  TWERD* rebuild_word;            // BLN best segmented word.
  // The box_word is in the original image coordinate space. It is the
  // bounding boxes of the rebuild_word, after denormalization.
  // The length of box_word matches rebuild_word, best_state (if set) and
  // correct_text (if set), as well as best_choice and represents the
  // number of classified units in the output.
  tesseract::BoxWord* box_word;   // Denormalized output boxes.
  // The best_state stores the relationship between chopped_word and
  // rebuild_word. Each blob[i] in rebuild_word is composed of best_state[i]
  // adjacent blobs in chopped_word. The seams in seam_array are hidden
  // within a rebuild_word blob and revealed between them.
  GenericVector<int> best_state;  // Number of blobs in each best blob.
  // The correct_text is used during training and adaption to carry the
  // text to the training system without the need for a unicharset. There
  // is one entry in the vector for each blob in rebuild_word and box_word.
  GenericVector<STRING> correct_text;
  // The Tesseract that was used to recognize this word. Just a borrowed
  // pointer. Note: Tesseract's class definition is in a higher-level library.
  // We avoid introducing a cyclic dependency by not using the Tesseract
  // within WERD_RES. We are just storing it to provide access to it
  // for the top-level multi-language controller, and maybe for output of
  // the recognized language.
  tesseract::Tesseract* tesseract;

  // Less-well documented members.
  // TODO(rays) Add more documentation here.
  WERD_CHOICE *ep_choice;      // ep text TODO(rays) delete this.
  REJMAP reject_map;           // best_choice rejects
  BOOL8 tess_failed;
  /*
    If tess_failed is TRUE, one of the following tests failed when Tess
    returned:
    - The outword blob list was not the same length as the best_choice string;
    - The best_choice string contained ALL blanks;
    - The best_choice string was zero length
  */
  BOOL8 tess_accepted;          // Tess thinks its ok?
  BOOL8 tess_would_adapt;       // Tess would adapt?
  BOOL8 done;                   // ready for output?
  bool small_caps;              // word appears to be small caps
  bool odd_size;                // word is bigger than line or leader dots.
  inT8 italic;
  inT8 bold;
  // The fontinfos are pointers to data owned by the classifier.
  const FontInfo* fontinfo;
  const FontInfo* fontinfo2;
  inT8 fontinfo_id_count;       // number of votes
  inT8 fontinfo_id2_count;      // number of votes
  BOOL8 guessed_x_ht;
  BOOL8 guessed_caps_ht;
  CRUNCH_MODE unlv_crunch_mode;
  float x_height;              // post match estimate
  float caps_height;           // post match estimate
  float baseline_shift;        // post match estimate.
  // Certainty score for the spaces either side of this word (LSTM mode).
  // MIN this value with the actual word certainty.
  float space_certainty;

  /*
    To deal with fuzzy spaces we need to be able to combine "words" to form
    combinations when we suspect that the gap is a non-space. The (new) text
    ord code generates separate words for EVERY fuzzy gap - flags in the word
    indicate whether the gap is below the threshold (fuzzy kern) and is thus
    NOT a real word break by default, or above the threshold (fuzzy space) and
    this is a real word break by default.

    The WERD_RES list contains all these words PLUS "combination" words built
    out of (copies of) the words split by fuzzy kerns. The separate parts have
    their "part_of_combo" flag set true and should be IGNORED on a default
    reading of the list.

    Combination words are FOLLOWED by the sequence of part_of_combo words
    which they combine.
  */
  BOOL8 combination;           //of two fuzzy gap wds
  BOOL8 part_of_combo;         //part of a combo
  BOOL8 reject_spaces;         //Reject spacing?

  WERD_RES() {
    InitNonPointers();
    InitPointers();
  }
  WERD_RES(WERD *the_word) {
    InitNonPointers();
    InitPointers();
    word = the_word;
  }
  // Deep copies everything except the ratings MATRIX.
  // To get that use deep_copy below.
  WERD_RES(const WERD_RES& source) : ELIST_LINK(source) {
    InitPointers();
    *this = source;            // see operator=
  }

  ~WERD_RES();

  // Returns the UTF-8 string for the given blob index in the best_choice word,
  // given that we know whether we are in a right-to-left reading context.
  // This matters for mirrorable characters such as parentheses.  We recognize
  // characters purely based on their shape on the page, and by default produce
  // the corresponding unicode for a left-to-right context.
  const char* BestUTF8(int blob_index, bool in_rtl_context) const {
    if (blob_index < 0 || best_choice == NULL ||
        blob_index >= best_choice->length())
      return NULL;
    UNICHAR_ID id = best_choice->unichar_id(blob_index);
    if (id < 0 || id >= uch_set->size() || id == INVALID_UNICHAR_ID)
      return NULL;
    UNICHAR_ID mirrored = uch_set->get_mirror(id);
    if (in_rtl_context && mirrored > 0 && mirrored != INVALID_UNICHAR_ID)
      id = mirrored;
    return uch_set->id_to_unichar_ext(id);
  }






  // Returns the UTF-8 string for the given blob index in the raw_choice word.
  const char* RawUTF8(int blob_index) const {
    if (blob_index < 0 || blob_index >= raw_choice->length())
      return NULL;
    UNICHAR_ID id = raw_choice->unichar_id(blob_index);
    if (id < 0 || id >= uch_set->size() || id == INVALID_UNICHAR_ID)
      return NULL;
    return uch_set->id_to_unichar(id);
  }

  UNICHARSET::Direction SymbolDirection(int blob_index) const {
    if (best_choice == NULL ||
        blob_index >= best_choice->length() ||
        blob_index < 0)
      return UNICHARSET::U_OTHER_NEUTRAL;
    return uch_set->get_direction(best_choice->unichar_id(blob_index));
  }

  bool AnyRtlCharsInWord() const {
    if (uch_set == NULL || best_choice == NULL || best_choice->length() < 1)
      return false;
    for (int id = 0; id < best_choice->length(); id++) {
      int unichar_id = best_choice->unichar_id(id);
      if (unichar_id < 0 || unichar_id >= uch_set->size())
        continue;  // Ignore illegal chars.
      UNICHARSET::Direction dir =
          uch_set->get_direction(unichar_id);
      if (dir == UNICHARSET::U_RIGHT_TO_LEFT ||
          dir == UNICHARSET::U_RIGHT_TO_LEFT_ARABIC ||
          dir == UNICHARSET::U_ARABIC_NUMBER)
        return true;
    }
    return false;
  }

  bool AnyLtrCharsInWord() const {
    if (uch_set == NULL || best_choice == NULL || best_choice->length() < 1)
      return false;
    for (int id = 0; id < best_choice->length(); id++) {
      int unichar_id = best_choice->unichar_id(id);
      if (unichar_id < 0 || unichar_id >= uch_set->size())
        continue;  // Ignore illegal chars.
      UNICHARSET::Direction dir = uch_set->get_direction(unichar_id);
      if (dir == UNICHARSET::U_LEFT_TO_RIGHT)
        return true;
    }
    return false;
  }

  // Return whether the blobs in this WERD_RES 0, 1,... come from an engine
  // that gave us the unichars in reading order (as opposed to strict left
  // to right).
  bool UnicharsInReadingOrder() const {
    return best_choice->unichars_in_script_order();
  }

  void InitNonPointers();
  void InitPointers();
  void Clear();
  void ClearResults();
  void ClearWordChoices();
  void ClearRatings();

  // Deep copies everything except the ratings MATRIX.
  // To get that use deep_copy below.
  WERD_RES& operator=(const WERD_RES& source);  //from this

  void CopySimpleFields(const WERD_RES& source);

  // Initializes a blank (default constructed) WERD_RES from one that has
  // already been recognized.
  // Use SetupFor*Recognition afterwards to complete the setup and make
  // it ready for a retry recognition.
  void InitForRetryRecognition(const WERD_RES& source);

  // Sets up the members used in recognition: bln_boxes, chopped_word,
  // seam_array, denorm.  Returns false if
  // the word is empty and sets up fake results.  If use_body_size is
  // true and row->body_size is set, then body_size will be used for
  // blob normalization instead of xheight + ascrise. This flag is for
  // those languages that are using CJK pitch model and thus it has to
  // be true if and only if tesseract->textord_use_cjk_fp_model is
  // true.
  // If allow_detailed_fx is true, the feature extractor will receive fine
  // precision outline information, allowing smoother features and better
  // features on low resolution images.
  // The norm_mode sets the default mode for normalization in absence
  // of any of the above flags. It should really be a tesseract::OcrEngineMode
  // but is declared as int for ease of use with tessedit_ocr_engine_mode.
  // Returns false if the word is empty and sets up fake results.
  bool SetupForRecognition(const UNICHARSET& unicharset_in,
                           tesseract::Tesseract* tesseract, Pix* pix,
                           int norm_mode,
                           const TBOX* norm_box, bool numeric_mode,
                           bool use_body_size, bool allow_detailed_fx,
                           ROW *row, const BLOCK* block);

  // Set up the seam array, bln_boxes, best_choice, and raw_choice to empty
  // accumulators from a made chopped word.  We presume the fields are already
  // empty.
  void SetupBasicsFromChoppedWord(const UNICHARSET &unicharset_in);

  // Sets up the members used in recognition for an empty recognition result:
  // bln_boxes, chopped_word, seam_array, denorm, best_choice, raw_choice.
  void SetupFake(const UNICHARSET& uch);

  // Set the word as having the script of the input unicharset.
  void SetupWordScript(const UNICHARSET& unicharset_in);

  // Sets up the blamer_bundle if it is not null, using the initialized denorm.
  void SetupBlamerBundle();

  // Computes the blob_widths and blob_gaps from the chopped_word.
  void SetupBlobWidthsAndGaps();

  // Updates internal data to account for a new SEAM (chop) at the given
  // blob_number. Fixes the ratings matrix and states in the choices, as well
  // as the blob widths and gaps.
  void InsertSeam(int blob_number, SEAM* seam);

  // Returns true if all the word choices except the first have adjust_factors
  // worse than the given threshold.
  bool AlternativeChoiceAdjustmentsWorseThan(float threshold) const;

  // Returns true if the current word is ambiguous (by number of answers or
  // by dangerous ambigs.)
  bool IsAmbiguous();

  // Returns true if the ratings matrix size matches the sum of each of the
  // segmentation states.
  bool StatesAllValid();

  // Prints a list of words found if debug is true or the word result matches
  // the word_to_debug.
  void DebugWordChoices(bool debug, const char* word_to_debug);

  // Prints the top choice along with the accepted/done flags.
  void DebugTopChoice(const char* msg) const;

  // Removes from best_choices all choices which are not within a reasonable
  // range of the best choice.
  void FilterWordChoices(int debug_level);

  // Computes a set of distance thresholds used to control adaption.
  // Compares the best choice for the current word to the best raw choice
  // to determine which characters were classified incorrectly by the
  // classifier. Then places a separate threshold into thresholds for each
  // character in the word. If the classifier was correct, max_rating is placed
  // into thresholds. If the classifier was incorrect, the mean match rating
  // (error percentage) of the classifier's incorrect choice minus some margin
  // is placed into thresholds. This can then be used by the caller to try to
  // create a new template for the desired class that will classify the
  // character with a rating better than the threshold value. The match rating
  // placed into thresholds is never allowed to be below min_rating in order to
  // prevent trying to make overly tight templates.
  // min_rating limits how tight to make a template.
  // max_rating limits how loose to make a template.
  // rating_margin denotes the amount of margin to put in template.
  void ComputeAdaptionThresholds(float certainty_scale,
                                 float min_rating,
                                 float max_rating,
                                 float rating_margin,
                                 float* thresholds);

  // Saves a copy of the word_choice if it has the best unadjusted rating.
  // Returns true if the word_choice was the new best.
  bool LogNewRawChoice(WERD_CHOICE* word_choice);
  // Consumes word_choice by adding it to best_choices, (taking ownership) if
  // the certainty for word_choice is some distance of the best choice in
  // best_choices, or by deleting the word_choice and returning false.
  // The best_choices list is kept in sorted order by rating. Duplicates are
  // removed, and the list is kept no longer than max_num_choices in length.
  // Returns true if the word_choice is still a valid pointer.
  bool LogNewCookedChoice(int max_num_choices, bool debug,
                          WERD_CHOICE* word_choice);

  // Prints a brief list of all the best choices.
  void PrintBestChoices() const;

  // Returns the sum of the widths of the blob between start_blob and last_blob
  // inclusive.
  int GetBlobsWidth(int start_blob, int last_blob);
  // Returns the width of a gap between the specified blob and the next one.
  int GetBlobsGap(int blob_index);

  // Returns the BLOB_CHOICE corresponding to the given index in the
  // best choice word taken from the appropriate cell in the ratings MATRIX.
  // Borrowed pointer, so do not delete. May return NULL if there is no
  // BLOB_CHOICE matching the unichar_id at the given index.
  BLOB_CHOICE* GetBlobChoice(int index) const;

  // Returns the BLOB_CHOICE_LIST corresponding to the given index in the
  // best choice word taken from the appropriate cell in the ratings MATRIX.
  // Borrowed pointer, so do not delete.
  BLOB_CHOICE_LIST* GetBlobChoices(int index) const;

  // Moves the results fields from word to this. This takes ownership of all
  // the data, so src can be destructed.
  // word1.ConsumeWordResult(word);
  // delete word;
  // is simpler and faster than:
  // word1 = *word;
  // delete word;
  // as it doesn't need to copy and reallocate anything.
  void ConsumeWordResults(WERD_RES* word);

  // Replace the best choice and rebuild box word.
  // choice must be from the current best_choices list.
  void ReplaceBestChoice(WERD_CHOICE* choice);

  // Builds the rebuild_word and sets the best_state from the chopped_word and
  // the best_choice->state.
  void RebuildBestState();

  // Copies the chopped_word to the rebuild_word, faking a best_state as well.
  // Also sets up the output box_word.
  void CloneChoppedToRebuild();

  // Sets/replaces the box_word with one made from the rebuild_word.
  void SetupBoxWord();

  // Sets up the script positions in the best_choice using the best_choice
  // to get the unichars, and the unicharset to get the target positions.
  void SetScriptPositions();
  // Sets all the blobs in all the words (best choice and alternates) to be
  // the given position. (When a sub/superscript is recognized as a separate
  // word, it falls victim to the rule that a whole word cannot be sub or
  // superscript, so this function overrides that problem.)
  void SetAllScriptPositions(tesseract::ScriptPos position);

  // Classifies the word with some already-calculated BLOB_CHOICEs.
  // The choices are an array of blob_count pointers to BLOB_CHOICE,
  // providing a single classifier result for each blob.
  // The BLOB_CHOICEs are consumed and the word takes ownership.
  // The number of blobs in the box_word must match blob_count.
  void FakeClassifyWord(int blob_count, BLOB_CHOICE** choices);

  // Creates a WERD_CHOICE for the word using the top choices from the leading
  // diagonal of the ratings matrix.
  void FakeWordFromRatings(PermuterType permuter);

  // Copies the best_choice strings to the correct_text for adaption/training.
  void BestChoiceToCorrectText();

  // Merges 2 adjacent blobs in the result if the permanent callback
  // class_cb returns other than INVALID_UNICHAR_ID, AND the permanent
  // callback box_cb is NULL or returns true, setting the merged blob
  // result to the class returned from class_cb.
  // Returns true if anything was merged.
  bool ConditionalBlobMerge(
      TessResultCallback2<UNICHAR_ID, UNICHAR_ID, UNICHAR_ID>* class_cb,
      TessResultCallback2<bool, const TBOX&, const TBOX&>* box_cb);

  // Merges 2 adjacent blobs in the result (index and index+1) and corrects
  // all the data to account for the change.
  void MergeAdjacentBlobs(int index);

  // Callback helper for fix_quotes returns a double quote if both
  // arguments are quote, otherwise INVALID_UNICHAR_ID.
  UNICHAR_ID BothQuotes(UNICHAR_ID id1, UNICHAR_ID id2);
  void fix_quotes();

  // Callback helper for fix_hyphens returns UNICHAR_ID of - if both
  // arguments are hyphen, otherwise INVALID_UNICHAR_ID.
  UNICHAR_ID BothHyphens(UNICHAR_ID id1, UNICHAR_ID id2);
  // Callback helper for fix_hyphens returns true if box1 and box2 overlap
  // (assuming both on the same textline, are in order and a chopped em dash.)
  bool HyphenBoxesOverlap(const TBOX& box1, const TBOX& box2);
  void fix_hyphens();

  // Callback helper for merge_tess_fails returns a space if both
  // arguments are space, otherwise INVALID_UNICHAR_ID.
  UNICHAR_ID BothSpaces(UNICHAR_ID id1, UNICHAR_ID id2);
  void merge_tess_fails();

  // Returns a really deep copy of *src, including the ratings MATRIX.
  static WERD_RES* deep_copy(const WERD_RES* src) {
    WERD_RES* result = new WERD_RES(*src);
    // That didn't copy the ratings, but we want a copy if there is one to
    // begin with.
    if (src->ratings != NULL)
      result->ratings = src->ratings->DeepCopy();
    return result;
  }

  // Copy blobs from word_res onto this word (eliminating spaces between).
  // Since this may be called bidirectionally OR both the BOL and EOL flags.
  void copy_on(WERD_RES *word_res) {  //from this word
    word->set_flag(W_BOL, word->flag(W_BOL) || word_res->word->flag(W_BOL));
    word->set_flag(W_EOL, word->flag(W_EOL) || word_res->word->flag(W_EOL));
    word->copy_on(word_res->word);
  }

  // Returns true if the collection of count pieces, starting at start, are all
  // natural connected components, ie there are no real chops involved.
  bool PiecesAllNatural(int start, int count) const;
};

/*************************************************************************
 * PAGE_RES_IT - Page results iterator
 *************************************************************************/

class PAGE_RES_IT {
 public:
  PAGE_RES * page_res;         // page being iterated

PAGE_RES_IT() {}                              // empty contructor

PAGE_RES_IT(PAGE_RES *the_page_res) {    // page result
page_res = the_page_res;  
//\\restart_page();  // ready to scan
}

  // Do two PAGE_RES_ITs point at the same word?
  // This is much cheaper than cmp().
  bool operator ==(const PAGE_RES_IT &other) const;

  bool operator !=(const PAGE_RES_IT &other) const {return !(*this == other); }






  // Given another PAGE_RES_IT to the same page,
  //  this before other:     -1
  //  this equal to other:    0
  //  this later than other:  1
  int cmp(const PAGE_RES_IT &other) const;

  WERD_RES *restart_page() {
    return start_page(false);  // Skip empty blocks.
  }
  WERD_RES *restart_page_with_empties() {
    return start_page(true);  // Allow empty blocks.
  }
  WERD_RES *start_page(bool empty_ok);

  WERD_RES *restart_row();

  // ============ Methods that mutate the underling structures ===========
  // Note that these methods will potentially invalidate other PAGE_RES_ITs
  // and are intended to be used only while a single PAGE_RES_IT is  active.
  // This problem needs to be taken into account if these mutation operators
  // are ever provided to PageIterator or its subclasses.

  // Inserts the new_word and a corresponding WERD_RES before the current
  // position. The simple fields of the WERD_RES are copied from clone_res and
  // the resulting WERD_RES is returned for further setup with best_choice etc.
  WERD_RES* InsertSimpleCloneWord(const WERD_RES& clone_res, WERD* new_word);

  // Replaces the current WERD/WERD_RES with the given words. The given words
  // contain fake blobs that indicate the position of the characters. These are
  // replaced with real blobs from the current word as much as possible.
  void ReplaceCurrentWord(tesseract::PointerVector<WERD_RES>* words);

  // Deletes the current WERD_RES and its underlying WERD.
  void DeleteCurrentWord();

  // Makes the current word a fuzzy space if not already fuzzy. Updates
  // corresponding part of combo if required.
  void MakeCurrentWordFuzzy();

  WERD_RES *forward() {  // Get next word.
    return internal_forward(false, false);
  }
  // Move forward, but allow empty blocks to show as single NULL words.
  WERD_RES *forward_with_empties() {
    return internal_forward(false, true);
  }

  WERD_RES *forward_paragraph();  // get first word in next non-empty paragraph
  WERD_RES *forward_block();  // get first word in next non-empty block

  WERD_RES *prev_word() const {  // previous word
    return prev_word_res;
  }
  ROW_RES *prev_row() const {  // row of prev word
    return prev_row_res;
  }
  BLOCK_RES *prev_block() const {  // block of prev word
    return prev_block_res;
  }
  WERD_RES *word() const {  // current word
    return word_res;
  }
  ROW_RES *row() const {  // row of current word
    return row_res;
  }
  BLOCK_RES *block() const {  // block of cur. word
    return block_res;
  }
  WERD_RES *next_word() const {  // next word
    return next_word_res;
  }
  ROW_RES *next_row() const {  // row of next word
    return next_row_res;
  }
  BLOCK_RES *next_block() const {  // block of next word
    return next_block_res;
  }
  void rej_stat_word();  // for page/block/row
  void ResetWordIterator();

 private:

public:

  WERD_RES *internal_forward(bool new_block, bool empty_ok);

  WERD_RES * prev_word_res;    // previous word
  ROW_RES *prev_row_res;       // row of prev word
  BLOCK_RES *prev_block_res;   // block of prev word

  WERD_RES *word_res;          // current word
  ROW_RES *row_res;            // row of current word
  BLOCK_RES *block_res;        // block of cur. word

  WERD_RES *next_word_res;     // next word
  ROW_RES *next_row_res;       // row of next word
  BLOCK_RES *next_block_res;   // block of next word

  BLOCK_RES_IT block_res_it;   // iterators
  ROW_RES_IT row_res_it;
  WERD_RES_IT word_res_it;
};



#endif    // PAGERES_H_DBG 













 

#if TESSERACT_CCUTIL_GENERICHEAP_H_|1
 




namespace tesseract {

// GenericHeap requires 1 template argument:
// Pair will normally be either KDPairInc<Key, Data> or KDPairDec<Key, Data>
// for some arbitrary Key and scalar, smart pointer, or non-ownership pointer
// Data type, according to whether a MIN heap or a MAX heap is desired,
// respectively. Using KDPtrPairInc<Key, Data> or KDPtrPairDec<Key, Data>,
// GenericHeap can also handle simple Data pointers and own them.
// If no additional data is required, Pair can also be a scalar, since
// GenericHeap doesn't look inside it except for operator<.
//
// The heap is stored as a packed binary tree in an array hosted by a
// GenericVector<Pair>, with the invariant that the children of each node are
// both NOT Pair::operator< the parent node. KDPairInc defines Pair::operator<
// to use Key::operator< to generate a MIN heap and KDPairDec defines
// Pair::operator< to use Key::operator> to generate a MAX heap by reversing
// all the comparisons.
// See http://en.wikipedia.org/wiki/Heap_(data_structure) for more detail on
// the basic heap implementation.
//
// Insertion and removal are both O(log n) and, unlike the STL heap, an
// explicit Reshuffle function allows a node to be repositioned in time O(log n)
// after changing its value.
//
// Accessing the element for revaluation is a more complex matter, since the
// index and pointer can be changed arbitrarily by heap operations.
// Revaluation can be done by making the Data type in the Pair derived from or
// contain a DoublePtr as its first data element, making it possible to convert
// the pointer to a Pair using KDPairInc::RecastDataPointer.
template <typename Pair>
class GenericHeap {
 public:
  GenericHeap() {}
  // The initial size is only a GenericVector::reserve. It is not enforced as
  // the size limit of the heap. Caller must implement their own enforcement.
  explicit GenericHeap(int initial_size) {
    heap_.reserve(initial_size);
  }

  // Simple accessors.
  bool empty() const {
    return heap_.empty();
  }
  int size() const {
    return heap_.size();
  }
  int size_reserved() const {
    return heap_.size_reserved();
  }
  void clear() {
    // Clear truncates to 0 to keep the number reserved in tact.
    heap_.truncate(0);
  }
  // Provides access to the underlying vector.
  // Caution! any changes that modify the keys will invalidate the heap!
  GenericVector<Pair>* heap() {
    return &heap_;
  }
  // Provides read-only access to an element of the underlying vector.
  const Pair& get(int index) const {
    return heap_[index];
  }

  // Add entry to the heap, keeping the smallest item at the top, by operator<.
  // Note that *entry is used as the source of operator=, but it is non-const
  // to allow for a smart pointer to be contained within.
  // Time = O(log n).
  void Push(Pair* entry) {
    int hole_index = heap_.size();
    // Make a hole in the end of heap_ and sift it up to be the correct
    // location for the new *entry. To avoid needing a default constructor
    // for primitive types, and to allow for use of DoublePtr in the Pair
    // somewhere, we have to incur a double copy here.
    heap_.push_back(*entry);
    *entry = heap_.back();
    hole_index = SiftUp(hole_index, *entry);
    heap_[hole_index] = *entry;
  }

  // Get the value of the top (smallest, defined by operator< ) element.
  const Pair& PeekTop() const {
    return heap_[0];
  }
  // Get the value of the worst (largest, defined by operator< ) element.
  const Pair& PeekWorst() const { return heap_[IndexOfWorst()]; }

  // Removes the top element of the heap. If entry is not NULL, the element
  // is copied into *entry, otherwise it is discarded.
  // Returns false if the heap was already empty.
  // Time = O(log n).
  bool Pop(Pair* entry) {
    int new_size = heap_.size() - 1;
    if (new_size < 0)
      return false;  // Already empty.
    if (entry != NULL)
      *entry = heap_[0];
    if (new_size > 0) {
      // Sift the hole at the start of the heap_ downwards to match the last
      // element.
      Pair hole_pair = heap_[new_size];
      heap_.truncate(new_size);
      int hole_index = SiftDown(0, hole_pair);
      heap_[hole_index] = hole_pair;
    } else {
      heap_.truncate(new_size);
    }
    return true;
  }

  // Removes the MAXIMUM element of the heap. (MIN from a MAX heap.) If entry is
  // not NULL, the element is copied into *entry, otherwise it is discarded.
  // Time = O(n). Returns false if the heap was already empty.
  bool PopWorst(Pair* entry) {
    int worst_index = IndexOfWorst();
    if (worst_index < 0) return false;  // It cannot be empty!
    // Extract the worst element from the heap, leaving a hole at worst_index.
    if (entry != NULL)
      *entry = heap_[worst_index];
    int heap_size = heap_.size() - 1;
    if (heap_size > 0) {
      // Sift the hole upwards to match the last element of the heap_
      Pair hole_pair = heap_[heap_size];
      int hole_index = SiftUp(worst_index, hole_pair);
      heap_[hole_index] = hole_pair;
    }
    heap_.truncate(heap_size);
    return true;
  }

  // Returns the index of the worst element. Time = O(n/2).
  int IndexOfWorst() const {
    int heap_size = heap_.size();
    if (heap_size == 0) return -1;  // It cannot be empty!

    // Find the maximum element. Its index is guaranteed to be greater than
    // the index of the parent of the last element, since by the heap invariant
    // the parent must be less than or equal to the children.
    int worst_index = heap_size - 1;
    int end_parent = ParentNode(worst_index);
    for (int i = worst_index - 1; i > end_parent; --i) {
      if (heap_[worst_index] < heap_[i]) worst_index = i;
    }
    return worst_index;
  }

  // The pointed-to Pair has changed its key value, so the location of pair
  // is reshuffled to maintain the heap invariant.
  // Must be a valid pointer to an element of the heap_!
  // Caution! Since GenericHeap is based on GenericVector, reallocs may occur
  // whenever the vector is extended and elements may get shuffled by any
  // Push or Pop operation. Therefore use this function only if Data in Pair is
  // of type DoublePtr, derived (first) from DoublePtr, or has a DoublePtr as
  // its first element. Reshuffles the heap to maintain the invariant.
  // Time = O(log n).
  void Reshuffle(Pair* pair) {
    int index = pair - &heap_[0];
    Pair hole_pair = heap_[index];
    index = SiftDown(index, hole_pair);
    index = SiftUp(index, hole_pair);
    heap_[index] = hole_pair;
  }

 private:
  // A hole in the heap exists at hole_index, and we want to fill it with the
  // given pair. SiftUp sifts the hole upward to the correct position and
  // returns the destination index without actually putting pair there.
  int SiftUp(int hole_index, const Pair& pair) {
    int parent;
    while (hole_index > 0 && pair < heap_[parent = ParentNode(hole_index)]) {
      heap_[hole_index] = heap_[parent];
      hole_index = parent;
    }
    return hole_index;
  }

  // A hole in the heap exists at hole_index, and we want to fill it with the
  // given pair. SiftDown sifts the hole downward to the correct position and
  // returns the destination index without actually putting pair there.
  int SiftDown(int hole_index, const Pair& pair) {
    int heap_size = heap_.size();
    int child;
    while ((child = LeftChild(hole_index)) < heap_size) {
      if (child + 1 < heap_size && heap_[child + 1] < heap_[child])
        ++child;
      if (heap_[child] < pair) {
        heap_[hole_index] = heap_[child];
        hole_index = child;
      } else {
        break;
      }
    }
    return hole_index;
  }

  // Functions to navigate the tree. Unlike the original implementation, we
  // store the root at index 0.
  int ParentNode(int index) const {
    return (index + 1) / 2 - 1;
  }
  int LeftChild(int index) const {
    return index * 2 + 1;
  }

 private:
  GenericVector<Pair> heap_;
};

}  // namespace tesseract



#endif  // TESSERACT_CCUTIL_GENERICHEAP_H_




#if ASSOCIATE_H|1


//class WERD_RES;

namespace tesseract {

// Statisitcs about character widths, gaps and seams.
struct AssociateStats {
  AssociateStats() { Clear(); }

  void Clear() {
    shape_cost = 0.0f;
    bad_shape = false;
    full_wh_ratio = 0.0f;
    full_wh_ratio_total = 0.0f;
    full_wh_ratio_var = 0.0f;
    bad_fixed_pitch_right_gap = false;
    bad_fixed_pitch_wh_ratio = false;
    gap_sum = 0;
  }

  void Print() { tprintf("AssociateStats: s(%g %d)\n", shape_cost, bad_shape); }

  float shape_cost;           // cost of blob shape
  bool bad_shape;             // true if the shape of the blob is unacceptable
  float full_wh_ratio;        // width-to-hight ratio + gap on the right
  float full_wh_ratio_total;  // sum of width-to-hight ratios
                              // on the path terminating at this blob
  float full_wh_ratio_var;    // variance of full_wh_ratios on the path
  bool bad_fixed_pitch_right_gap;  // true if there is no gap before
                                   // the blob on the right
  bool bad_fixed_pitch_wh_ratio;   // true if the blobs has width-to-hight
                                   // ratio > kMaxFixedPitchCharAspectRatio
  int gap_sum;  // sum of gaps within the blob
};

// Utility functions for scoring segmentation paths according to their
// character widths, gap widths, seam characteristics.
class AssociateUtils {
 public:
  static const float kMaxFixedPitchCharAspectRatio;
  static const float kMinGap;

  // Returns outline length of the given blob is computed as:
  // rating_cert_scale * rating / certainty
  // Since from Wordrec::SegSearch() in segsearch.cpp
  // rating_cert_scale = -1.0 * getDict().certainty_scale / rating_scale
  // And from Classify::ConvertMatchesToChoices() in adaptmatch.cpp
  // Rating = Certainty = next.rating
  // Rating *= rating_scale * Results->BlobLength
  // Certainty *= -(getDict().certainty_scale)
  static inline float ComputeOutlineLength(float rating_cert_scale,
                                           const BLOB_CHOICE &b) {
    return rating_cert_scale * b.rating() / b.certainty();
  }
  static inline float ComputeRating(float rating_cert_scale,
                                    float cert, int width) {
    return static_cast<float>(width) * cert / rating_cert_scale;
  }

  // Computes character widths, gaps and seams stats given the
  // AssociateStats of the path so far, col, row of the blob that
  // is being added to the path, and WERD_RES containing information
  // about character widths, gaps and seams.
  // Fills associate_cost with the combined shape, gap and seam cost
  // of adding a unichar from (col, row) to the path (note that since
  // this function could be used to compute the prioritization for
  // pain points, (col, row) entry might not be classified yet; thus
  // information in the (col, row) entry of the ratings matrix is not used).
  //
  // Note: the function assumes that word_res, stats and
  // associate_cost pointers are not NULL.
  static void ComputeStats(int col, int row,
                           const AssociateStats *parent_stats,
                           int parent_path_length,
                           bool fixed_pitch,
                           float max_char_wh_ratio,
                           WERD_RES *word_res,
                           bool debug,
                           AssociateStats *stats);

  // Returns the width cost for fixed-pitch text.
  static float FixedPitchWidthCost(float norm_width, float right_gap,
                                   bool end_pos, float max_char_wh_ratio);

  // Returns the gap cost for fixed-pitch text (penalizes vertically
  // overlapping components).
  static inline float FixedPitchGapCost(float norm_gap, bool end_pos) {
    return (norm_gap < 0.05 && !end_pos) ? 5.0f : 0.0f;
  }
};

}  // namespace tesseract

#endif

 






 

#if TESSERACT_WORDREC_CONSISTENCY_H_|1




#include "dawg.h"
#include "dict.h"
#include "host.h"
#include "ratngs.h"








namespace tesseract {

static const char * const XHeightConsistencyEnumName[] = {
    "XH_GOOD",
    "XH_SUBNORMAL",
    "XH_INCONSISTENT",
};

// Struct for keeping track of the consistency of the path.
struct LMConsistencyInfo {
  enum ChartypeEnum { CT_NONE, CT_ALPHA, CT_DIGIT, CT_OTHER};

  // How much do characters have to be shifted away from normal parameters
  // before we say they're not normal?
  static const int kShiftThresh = 1;

  // How much shifting from subscript to superscript and back
  // before we declare shenanigans?
  static const int kMaxEntropy = 1;

  // Script positions - order important for entropy calculation.
  static const int kSUB = 0, kNORM = 1, kSUP = 2;
  static const int kNumPos = 3;


LMConsistencyInfo(){}; 


  explicit LMConsistencyInfo(const LMConsistencyInfo* parent_info) {
    if (parent_info == NULL) {
      // Initialize from scratch.
      num_alphas = 0;
      num_digits = 0;
      num_punc = 0;
      num_other = 0;
      chartype = CT_NONE;
      punc_ref = NO_EDGE;
      invalid_punc = false;
      num_non_first_upper = 0;
      num_lower = 0;
      script_id = 0;
      inconsistent_script = false;
      num_inconsistent_spaces = 0;
      inconsistent_font = false;
      // Initialize XHeight stats.
      for (int i = 0; i < kNumPos; i++) {
        xht_count[i] = 0;
        xht_count_punc[i] = 0;
        xht_lo[i] = 0;
        xht_hi[i] = 256;  // kBlnCellHeight
      }
      xht_sp = -1;  // This invalid value indicates that there was no parent.
      xpos_entropy = 0;
      xht_decision = XH_GOOD;
    } else {
      // Copy parent info
      *this = *parent_info;
    }
  }




  inline int NumInconsistentPunc() const {
    return invalid_punc ? num_punc : 0;
  }
  inline int NumInconsistentCase() const {
    return (num_non_first_upper > num_lower) ? num_lower : num_non_first_upper;
  }
  inline int NumInconsistentChartype() const {
    return (NumInconsistentPunc() + num_other +
        ((num_alphas > num_digits) ? num_digits : num_alphas));
  }
  inline bool Consistent() const {
    return (NumInconsistentPunc() == 0 && NumInconsistentCase() == 0 &&
            NumInconsistentChartype() == 0 && !inconsistent_script &&
            !inconsistent_font && !InconsistentXHeight());
  }
  inline int  NumInconsistentSpaces() const {
    return num_inconsistent_spaces;
  }
  inline int InconsistentXHeight() const {
    return xht_decision == XH_INCONSISTENT;
  }
  void ComputeXheightConsistency(const BLOB_CHOICE *b, bool is_punc);
  float BodyMinXHeight() const {
    if (InconsistentXHeight())
      return 0.0f;
    return xht_lo[kNORM];
  }
  float BodyMaxXHeight() const {
    if (InconsistentXHeight())
      return static_cast<float>(MAX_INT16);
    return xht_hi[kNORM];
  }

  int num_alphas;
  int num_digits;
  int num_punc;
  int num_other;
  ChartypeEnum chartype;
  EDGE_REF punc_ref;
  bool invalid_punc;
  int num_non_first_upper;
  int num_lower;
  int script_id;
  bool inconsistent_script;
  int num_inconsistent_spaces;
  bool inconsistent_font;
  // Metrics clumped by position.
  float xht_lo[kNumPos];
  float xht_hi[kNumPos];
  inT16 xht_count[kNumPos];
  inT16 xht_count_punc[kNumPos];
  inT16 xht_sp;
  inT16 xpos_entropy;
  XHeightConsistencyEnum xht_decision;
};


}  // namespace tesseract



#endif  // TESSERACT_WORDREC_CONSISTENCY_H_

















#if TESSERACT_WORDREC_LANGUAGE_MODEL_DEFS_H_|1






namespace tesseract {

/// Used for expressing various language model flags.
typedef unsigned char LanguageModelFlagsType;

/// The following structs are used for storing the state of the language model
/// in the segmentation search graph. In this graph the nodes are BLOB_CHOICEs
/// and the links are the relationships between the underlying blobs (see
/// segsearch.h for a more detailed description).
///
/// Each of the BLOB_CHOICEs contains LanguageModelState struct, which has
/// a list of N best paths (list of ViterbiStateEntry) explored by the Viterbi
/// search leading up to and including this BLOB_CHOICE.
///
/// Each ViterbiStateEntry contains information from various components of the
/// language model: dawgs in which the path is found, character ngram model
/// probability of the path, script/chartype/font consistency info, state for
/// language-specific heuristics (e.g. hyphenated and compound words,
/// lower/upper case preferences, etc).
///
/// Each ViterbiStateEntry also contains the parent pointer, so that the path
/// that it represents (WERD_CHOICE) can be constructed by following these
/// parent pointers.

/// Struct for storing additional information used by Dawg language model
/// component. It stores the set of active dawgs in which the sequence of
/// letters on a path can be found.
struct LanguageModelDawgInfo {
  LanguageModelDawgInfo(const DawgPositionVector *a, PermuterType pt)
    : active_dawgs(*a), permuter(pt) {}
  DawgPositionVector active_dawgs;
  PermuterType permuter;
};

/// Struct for storing additional information used by Ngram language model
/// component.
struct LanguageModelNgramInfo {
  LanguageModelNgramInfo(const char *c, int l, bool p, float nc, float ncc)
    : context(c), context_unichar_step_len(l), pruned(p), ngram_cost(nc),
      ngram_and_classifier_cost(ncc) {}
  STRING context;  //< context string
  /// Length of the context measured by advancing using UNICHAR::utf8_step()
  /// (should be at most the order of the character ngram model used).
  int context_unichar_step_len;
  /// The paths with pruned set are pruned out from the perspective of the
  /// character ngram model. They are explored further because they represent
  /// a dictionary match or a top choice. Thus ngram_info is still computed
  /// for them in order to calculate the combined cost.
  bool pruned;
  /// -ln(P_ngram_model(path))
  float ngram_cost;
  /// -[ ln(P_classifier(path)) + scale_factor * ln(P_ngram_model(path)) ]
  float ngram_and_classifier_cost;
};

/// Struct for storing the information about a path in the segmentation graph
/// explored by Viterbi search.
struct ViterbiStateEntry : public ELIST_LINK {





  ViterbiStateEntry(ViterbiStateEntry *pe,
                    BLOB_CHOICE *b, float c, float ol,
                    const LMConsistencyInfo &ci,
                    const AssociateStats &as,
                    LanguageModelFlagsType tcf,
                    LanguageModelDawgInfo *d,
                    LanguageModelNgramInfo *n,
                    const char *debug_uch)



    : cost(c), curr_b(b), parent_vse(pe), competing_vse(NULL),
      ratings_sum(b->rating()),
      min_certainty(b->certainty()), adapted(b->IsAdapted()), length(1),
      outline_length(ol), consistency_info(ci), associate_stats(as),
      top_choice_flags(tcf), dawg_info(d), ngram_info(n),
      updated(true) 



{
    debug_str = (debug_uch == NULL) ? NULL : new STRING();
    if (pe != NULL) {
      ratings_sum += pe->ratings_sum;
      if (pe->min_certainty < min_certainty) {
        min_certainty = pe->min_certainty;
      }
      adapted += pe->adapted;
      length += pe->length;
      outline_length += pe->outline_length;
      if (debug_uch != NULL) *debug_str += *(pe->debug_str);
    }
    if (debug_str != NULL && debug_uch != NULL) *debug_str += debug_uch;
  }






  ~ViterbiStateEntry() {
    delete dawg_info;
    delete ngram_info;
    delete debug_str;
  }
  /// Comparator function for sorting ViterbiStateEntry_LISTs in
  /// non-increasing order of costs.
  static int Compare(const void *e1, const void *e2) {
    const ViterbiStateEntry *ve1 =
      *reinterpret_cast<const ViterbiStateEntry * const *>(e1);
    const ViterbiStateEntry *ve2 =
      *reinterpret_cast<const ViterbiStateEntry * const *>(e2);
    return (ve1->cost < ve2->cost) ? -1 : 1;
  }
  inline bool Consistent() const {
    if (dawg_info != NULL && consistency_info.NumInconsistentCase() == 0) {
      return true;
    }
    return consistency_info.Consistent();
  }
  /// Returns true if this VSE has an alphanumeric character as its classifier
  /// result.
  bool HasAlnumChoice(const UNICHARSET& unicharset) {
    if (curr_b == NULL) return false;
    UNICHAR_ID unichar_id =  curr_b->unichar_id();
    if (unicharset.get_isalpha(unichar_id) ||
        unicharset.get_isdigit(unichar_id))
      return true;
    return false;
  }
  void Print(const char *msg) const;

  /// The cost is an adjusted ratings sum, that is adjusted by all the language
  /// model components that use Viterbi search.
  float cost;

  /// Pointers to BLOB_CHOICE and parent ViterbiStateEntry (not owned by this).
  BLOB_CHOICE *curr_b;
  ViterbiStateEntry *parent_vse;
  /// Pointer to a case-competing ViterbiStateEntry in the same list that
  /// represents a path ending in the same letter of the opposite case.
  ViterbiStateEntry *competing_vse;

  /// Various information about the characters on the path represented
  /// by this ViterbiStateEntry.
  float ratings_sum;     //< sum of ratings of character on the path
  float min_certainty;   //< minimum certainty on the path
  int adapted;           //< number of BLOB_CHOICES from adapted templates
  int length;            //< number of characters on the path
  float outline_length;  //< length of the outline so far
  LMConsistencyInfo consistency_info;  //< path consistency info
  AssociateStats associate_stats;      //< character widths/gaps/seams

  /// Flags for marking the entry as a top choice path with
  /// the smallest rating or lower/upper case letters).
  LanguageModelFlagsType top_choice_flags;

  /// Extra information maintained by Dawg language model component
  /// (owned by ViterbiStateEntry).
  LanguageModelDawgInfo *dawg_info;

  /// Extra information maintained by Ngram language model component
  /// (owned by ViterbiStateEntry).
  LanguageModelNgramInfo *ngram_info;

  bool updated;  //< set to true if the entry has just been created/updated
  /// UTF8 string representing the path corresponding to this vse.
  /// Populated only in when language_model_debug_level > 0.
  STRING *debug_str;
};

ELISTIZEH(ViterbiStateEntry);

/// Struct to store information maintained by various language model components.
struct LanguageModelState {
  LanguageModelState() :
     viterbi_state_entries_prunable_length(0),
    viterbi_state_entries_prunable_max_cost(MAX_FLOAT32),
    viterbi_state_entries_length(0) {}
  ~LanguageModelState() {}

  /// Clears the viterbi search state back to its initial conditions.
  void Clear();

  void Print(const char *msg);

  /// Storage for the Viterbi state.
  ViterbiStateEntry_LIST viterbi_state_entries;
  /// Number and max cost of prunable paths in viterbi_state_entries.
  int viterbi_state_entries_prunable_length;
  float viterbi_state_entries_prunable_max_cost;
  /// Total number of entries in viterbi_state_entries.
  int viterbi_state_entries_length;
};

/// Bundle together all the things pertaining to the best choice/state.
struct BestChoiceBundle {
  explicit BestChoiceBundle(int matrix_dimension)
    : updated(false), best_vse(NULL) {
    beam.reserve(matrix_dimension);
    for (int i = 0; i < matrix_dimension; ++i)
      beam.push_back(new LanguageModelState);
  }
  ~BestChoiceBundle() {}

  /// Flag to indicate whether anything was changed.
  bool updated;
  /// Places to try to fix the word suggested by ambiguity checking.
  DANGERR fixpt;
  /// The beam. One LanguageModelState containing a list of ViterbiStateEntry
  /// per row in the ratings matrix containing all VSEs whose BLOB_CHOICE is
  /// somewhere in the corresponding row.
  PointerVector<LanguageModelState> beam;
  /// Best ViterbiStateEntry and BLOB_CHOICE.
  ViterbiStateEntry *best_vse;
};

}  // namespace tesseract



 

#endif  // TESSERACT_WORDREC_LANGUAGE_MODEL_DEFS_H_



#if DEBUG_MODE|1





namespace tesseract {

// Heap of pain points used for determining where to chop/join.
typedef GenericHeap<MatrixCoordPair> PainPointHeap;

// Types of pain points (ordered in the decreasing level of importance).
enum LMPainPointsType {
  LM_PPTYPE_BLAMER,
  LM_PPTYPE_AMBIG,
  LM_PPTYPE_PATH,
  LM_PPTYPE_SHAPE,

  LM_PPTYPE_NUM
};

static const char * const LMPainPointsTypeName[] = {
    "LM_PPTYPE_BLAMER",
    "LM_PPTYPE_AMBIGS",
    "LM_PPTYPE_PATH",
    "LM_PPTYPE_SHAPE",
};

class LMPainPoints {
 public:




  static const float kDefaultPainPointPriorityAdjustment;
  // If there is a significant drop in character ngram probability or a
  // dangerous ambiguity make the thresholds on what blob combinations
  // can be classified looser.
  static const float kLooseMaxCharWhRatio;
  // Returns a description of the type of a pain point.
  static const char* PainPointDescription(LMPainPointsType type) {
    return LMPainPointsTypeName[type];
  }

  LMPainPoints(int max, float rat, bool fp, const Dict *d, int deb) :
    max_heap_size_(max), max_char_wh_ratio_(rat), fixed_pitch_(fp),
    dict_(d), debug_level_(deb) {}
  ~LMPainPoints() {}



LMPainPoints(){}  //\\ 



  // Returns true if the heap of pain points of pp_type is not empty().
  inline bool HasPainPoints(LMPainPointsType pp_type) const {
    return !pain_points_heaps_[pp_type].empty();
  }

  // Dequeues the next pain point from the pain points queue and copies
  // its contents and priority to *pp and *priority.
  // Returns LM_PPTYPE_NUM if pain points queue is empty, otherwise the type.
  LMPainPointsType Deque(MATRIX_COORD *pp, float *priority);

  // Clears pain points heap.
  void Clear() {
    for (int h = 0; h < LM_PPTYPE_NUM; ++h) pain_points_heaps_[h].clear();
  }

  // For each cell, generate a "pain point" if the cell is not classified
  // and has a left or right neighbor that was classified.
  void GenerateInitial(WERD_RES *word_res);

  // Generate pain points from the given path.
  void GenerateFromPath(float rating_cert_scale, ViterbiStateEntry *vse,
                        WERD_RES *word_res);

  // Generate pain points from dangerous ambiguities in best choice.
  void GenerateFromAmbigs(const DANGERR &fixpt, ViterbiStateEntry *vse,
                          WERD_RES *word_res);

  // Generate a pain point for the blamer.
  bool GenerateForBlamer(double max_char_wh_ratio, WERD_RES *word_res,
                         int col, int row) {
    return GeneratePainPoint(col, row, LM_PPTYPE_BLAMER, 0.0, false,
                             max_char_wh_ratio, word_res);
  }

  // Adds a pain point to classify chunks_record->ratings(col, row).
  // Returns true if a new pain point was added to an appropriate heap.
  // Pain point priority is set to special_priority for pain points of
  // LM_PPTYPE_AMBIG or LM_PPTYPE_PATH, for other pain points
  // AssociateStats::gap_sum is used.
  bool GeneratePainPoint(int col, int row, LMPainPointsType pp_type,
                         float special_priority, bool ok_to_extend,
                         float max_char_wh_ratio,
                         WERD_RES *word_res);

  // Adjusts the pain point coordinates to cope with expansion of the ratings
  // matrix due to a split of the blob with the given index.
  void RemapForSplit(int index);

 


private:

public:
  // Priority queues containing pain points generated by the language model
  // The priority is set by the language model components, adjustments like
  // seam cost and width priority are factored into the priority.
  PainPointHeap pain_points_heaps_[LM_PPTYPE_NUM];
  // Maximum number of points to keep in the heap.
  int max_heap_size_;
  // Maximum character width/height ratio.
  float max_char_wh_ratio_;
  // Set to true if fixed pitch should be assumed.
  bool fixed_pitch_;
  // Cached pointer to dictionary.
  const Dict *dict_;
  // Debug level for print statements.
  int debug_level_;
};

}  // namespace tesseract






#endif    //  DEBUG_MODE 







#if TESSERACT_WORDREC_LANGUAGE_MODEL_H_|1







#if DEBUG_MODE|1

#include "params_training_featdef.h"
#include "ratngs.h"
#include "strngs.h"

namespace tesseract {

// Represents the learned weights for a given language.
class ParamsModel {
 public:
  // Enum for expressing OCR pass.
  enum PassEnum {
    PTRAIN_PASS1,
    PTRAIN_PASS2,

    PTRAIN_NUM_PASSES
  };

  ParamsModel() : pass_(PTRAIN_PASS1) {}
  ParamsModel(const char *lang, const GenericVector<float> &weights) :
    lang_(lang), pass_(PTRAIN_PASS1) { weights_vec_[pass_] = weights; }
  inline bool Initialized() {
    return weights_vec_[pass_].size() == PTRAIN_NUM_FEATURE_TYPES;
  }
  // Prints out feature weights.
  void Print();
  // Clears weights for all passes.
  void Clear() {
    for (int p = 0; p < PTRAIN_NUM_PASSES; ++p) weights_vec_[p].clear();
  }
  // Copies the weights of the given params model.
  void Copy(const ParamsModel &other_model);
  // Applies params model weights to the given features.
  // Assumes that features is an array of size PTRAIN_NUM_FEATURE_TYPES.
  float ComputeCost(const float features[]) const;
  bool Equivalent(const ParamsModel &that) const;

  // Returns true on success.
  bool SaveToFile(const char *full_path) const;

  // Returns true on success.
  bool LoadFromFile(const char *lang, const char *full_path);
  bool LoadFromFp(const char *lang, FILE *fp, inT64 end_offset);

  const GenericVector<float>& weights() const {
    return weights_vec_[pass_];
  }
  const GenericVector<float>& weights_for_pass(PassEnum pass) const {
    return weights_vec_[pass];
  }
  void SetPass(PassEnum pass) { pass_ = pass; }

 private:
  bool ParseLine(char *line, char **key, float *val);

  STRING lang_;
  // Set to the current pass type and used to determine which set of weights
  // should be used for ComputeCost() and other functions.
  PassEnum pass_;
  // Several sets of weights for various OCR passes (e.g. pass1 with adaption,
  // pass2 without adaption, etc).
  GenericVector<float> weights_vec_[PTRAIN_NUM_PASSES];
};

}  // namespace tesseract



#endif  // DEBUG_MODE 














namespace tesseract {
 

void ScanParentsForCaseMix(const UNICHARSET& unicharset,LanguageModelState* parent_node);

bool HasBetterCaseVariant(const UNICHARSET& unicharset,
                                 const BLOB_CHOICE* choice,
                                 BLOB_CHOICE_LIST* choices);




// This class that contains the data structures and functions necessary
// to represent and use the knowledge about the language.
class LanguageModel {
 public:
  // Masks for keeping track of top choices that should not be pruned out.
  static const LanguageModelFlagsType kSmallestRatingFlag = 0x1;
  static const LanguageModelFlagsType kLowerCaseFlag = 0x2;
  static const LanguageModelFlagsType kUpperCaseFlag = 0x4;
  static const LanguageModelFlagsType kDigitFlag = 0x8;
  static const LanguageModelFlagsType kXhtConsistentFlag = 0x10;

  // Denominator for normalizing per-letter ngram cost when deriving
  // penalty adjustments.
  static const float kMaxAvgNgramCost;

  LanguageModel(const UnicityTable<FontInfo> *fontinfo_table, Dict *dict);
  ~LanguageModel();

  // Fills the given floats array with features extracted from path represented
  // by the given ViterbiStateEntry. See ccstruct/params_training_featdef.h
  // for feature information.
  // Note: the function assumes that features points to an array of size
  // PTRAIN_NUM_FEATURE_TYPES.
  static void ExtractFeaturesFromPath(const ViterbiStateEntry &vse,
                                      float features[]);

  // Updates data structures that are used for the duration of the segmentation
  // search on the current word;
  void InitForWord(const WERD_CHOICE *prev_word,
                   bool fixed_pitch, float max_char_wh_ratio,
                   float rating_cert_scale);

  // Updates language model state of the given BLOB_CHOICE_LIST (from
  // the ratings matrix) a its parent. Updates pain_points if new
  // problematic points are found in the segmentation graph.
  //
  // At most language_model_viterbi_list_size are kept in each
  // LanguageModelState.viterbi_state_entries list.
  // At most language_model_viterbi_list_max_num_prunable of those are prunable
  // (non-dictionary) paths.
  // The entries that represent dictionary word paths are kept at the front
  // of the list.
  // The list ordered by cost that is computed collectively by several
  // language model components (currently dawg and ngram components).
  bool UpdateState(
      bool just_classified,
      int curr_col, int curr_row,
      BLOB_CHOICE_LIST *curr_list,
      LanguageModelState *parent_node,
      LMPainPoints *pain_points,
      WERD_RES *word_res,
      BestChoiceBundle *best_choice_bundle,
      BlamerBundle *blamer_bundle);

  // Returns true if an acceptable best choice was discovered.
  inline bool AcceptableChoiceFound() { return acceptable_choice_found_; }
  inline void SetAcceptableChoiceFound(bool val) {
    acceptable_choice_found_ = val;
  }
  // Returns the reference to ParamsModel.
  inline ParamsModel &getParamsModel() { return params_model_; }

 protected:


public:


  inline float CertaintyScore(float cert) {
    if (language_model_use_sigmoidal_certainty) {
      // cert is assumed to be between 0 and -dict_->certainty_scale.
      // If you enable language_model_use_sigmoidal_certainty, you
      // need to adjust language_model_ngram_nonmatch_score as well.
      cert = -cert / dict_->certainty_scale;
      return 1.0f / (1.0f + exp(10.0f * cert));
    } else {
      return (-1.0f / cert);
    }
  }

  inline float ComputeAdjustment(int num_problems, float penalty) {
    if (num_problems == 0) return 0.0f;
    if (num_problems == 1) return penalty;
    return (penalty + (language_model_penalty_increment *
                       static_cast<float>(num_problems-1)));
  }

  // Computes the adjustment to the ratings sum based on the given
  // consistency_info. The paths with invalid punctuation, inconsistent
  // case and character type are penalized proportionally to the number
  // of inconsistencies on the path.
  inline float ComputeConsistencyAdjustment(
      const LanguageModelDawgInfo *dawg_info,
      const LMConsistencyInfo &consistency_info) {
    if (dawg_info != NULL) {
      return ComputeAdjustment(consistency_info.NumInconsistentCase(),
                               language_model_penalty_case) +
          (consistency_info.inconsistent_script ?
             language_model_penalty_script : 0.0f);
    }




    return (ComputeAdjustment(consistency_info.NumInconsistentPunc(),
                              language_model_penalty_punc) +
            ComputeAdjustment(consistency_info.NumInconsistentCase(),
                              language_model_penalty_case) +
            ComputeAdjustment(consistency_info.NumInconsistentChartype(),
                              language_model_penalty_chartype) +
            ComputeAdjustment(consistency_info.NumInconsistentSpaces(),
                              language_model_penalty_spacing) +
            (consistency_info.inconsistent_script ?
             language_model_penalty_script : 0.0f) +
            (consistency_info.inconsistent_font ?
             language_model_penalty_font : 0.0f));



  }

  // Returns an adjusted ratings sum that includes inconsistency penalties,
  // penalties for non-dictionary paths and paths with dips in ngram
  // probability.
  float ComputeAdjustedPathCost(ViterbiStateEntry *vse);

  // Finds the first lower and upper case letter and first digit in curr_list.
  // Uses the first character in the list in place of empty results.
  // Returns true if both alpha and digits are found.
  bool GetTopLowerUpperDigit(BLOB_CHOICE_LIST *curr_list,
                             BLOB_CHOICE **first_lower,
                             BLOB_CHOICE **first_upper,
                             BLOB_CHOICE **first_digit) const;
  // Forces there to be at least one entry in the overall set of the
  // viterbi_state_entries of each element of parent_node that has the
  // top_choice_flag set for lower, upper and digit using the same rules as
  // GetTopLowerUpperDigit, setting the flag on the first found suitable
  // candidate, whether or not the flag is set on some other parent.
  // Returns 1 if both alpha and digits are found among the parents, -1 if no
  // parents are found at all (a legitimate case), and 0 otherwise.
  int SetTopParentLowerUpperDigit(LanguageModelState *parent_node) const;

  // Finds the next ViterbiStateEntry with which the given unichar_id can
  // combine sensibly, taking into account any mixed alnum/mixed case
  // situation, and whether this combination has been inspected before.
  ViterbiStateEntry* GetNextParentVSE(
      bool just_classified, bool mixed_alnum,
      const BLOB_CHOICE* bc, LanguageModelFlagsType blob_choice_flags,
      const UNICHARSET& unicharset, WERD_RES* word_res,
      ViterbiStateEntry_IT* vse_it,
      LanguageModelFlagsType* top_choice_flags) const;
  // Helper function that computes the cost of the path composed of the
  // path in the given parent ViterbiStateEntry and the given BLOB_CHOICE.
  // If the new path looks good enough, adds a new ViterbiStateEntry to the
  // list of viterbi entries in the given BLOB_CHOICE and returns true.

  bool AddViterbiStateEntry(
      LanguageModelFlagsType top_choice_flags, float denom, bool word_end,
      int curr_col, int curr_row, BLOB_CHOICE *b,
      LanguageModelState *curr_state, ViterbiStateEntry *parent_vse,
      LMPainPoints *pain_points, WERD_RES *word_res,
      BestChoiceBundle *best_choice_bundle, BlamerBundle *blamer_bundle);



  bool m_AddViterbiStateEntry(
      LanguageModelFlagsType top_choice_flags,          bool word_end,
      int curr_col, int curr_row, BLOB_CHOICE *b,
      LanguageModelState *curr_state, ViterbiStateEntry *parent_vse,
      LMPainPoints *pain_points, WERD_RES *word_res,
      BestChoiceBundle *best_choice_bundle, BlamerBundle *blamer_bundle);








  // Determines whether a potential entry is a true top choice and
  // updates changed accordingly.
  //
  // Note: The function assumes that b, top_choice_flags and changed
  // are not NULL.
  void GenerateTopChoiceInfo(ViterbiStateEntry *new_vse,
                             const ViterbiStateEntry *parent_vse,
                             LanguageModelState *lms);

  // Calls dict_->LetterIsOk() with DawgArgs initialized from parent_vse and
  // unichar from b.unichar_id(). Constructs and returns LanguageModelDawgInfo
  // with updated active dawgs, constraints and permuter.
  //
  // Note: the caller is responsible for deleting the returned pointer.
  LanguageModelDawgInfo *GenerateDawgInfo(bool word_end,
                                          int curr_col, int curr_row,
                                          const BLOB_CHOICE &b,
                                          const ViterbiStateEntry *parent_vse);

  // Computes p(unichar | parent context) and records it in ngram_cost.
  // If b.unichar_id() is an unlikely continuation of the parent context
  // sets found_small_prob to true and returns NULL.
  // Otherwise creates a new LanguageModelNgramInfo entry containing the
  // updated context (that includes b.unichar_id() at the end) and returns it.
  //
  // Note: the caller is responsible for deleting the returned pointer.
  LanguageModelNgramInfo *GenerateNgramInfo(
      const char *unichar, float certainty, float denom,
      int curr_col, int curr_row, float outline_length,
      const ViterbiStateEntry *parent_vse);

  // Computes -(log(prob(classifier)) + log(prob(ngram model)))
  // for the given unichar in the given context. If there are multiple
  // unichars at one position - takes the average of their probabilities.
  // UNICHAR::utf8_step() is used to separate out individual UTF8 characters,
  // since probability_in_context() can only handle one at a time (while
  // unicharset might contain ngrams and glyphs composed from multiple UTF8
  // characters).
  float ComputeNgramCost(const char *unichar, float certainty, float denom,
                         const char *context, int *unichar_step_len,
                         bool *found_small_prob, float *ngram_prob);

  // Computes the normalization factors for the classifier confidences
  // (used by ComputeNgramCost()).
  float ComputeDenom(BLOB_CHOICE_LIST *curr_list);

  // Fills the given consistenty_info based on parent_vse.consistency_info
  // and on the consistency of the given unichar_id with parent_vse.
  void FillConsistencyInfo(
      int curr_col, bool word_end, BLOB_CHOICE *b,
      ViterbiStateEntry *parent_vse,
      WERD_RES *word_res,
      LMConsistencyInfo *consistency_info);

  // Constructs WERD_CHOICE by recording unichar_ids of the BLOB_CHOICEs
  // on the path represented by the given BLOB_CHOICE and language model
  // state entries (lmse, dse). The path is re-constructed by following
  // the parent pointers in the the lang model state entries). If the
  // constructed WERD_CHOICE is better than the best/raw choice recorded
  // in the best_choice_bundle, this function updates the corresponding
  // fields and sets best_choice_bunldle->updated to true.
  void UpdateBestChoice(ViterbiStateEntry *vse,
                        LMPainPoints *pain_points,
                        WERD_RES *word_res,
                        BestChoiceBundle *best_choice_bundle,
                        BlamerBundle *blamer_bundle);

  // Constructs a WERD_CHOICE by tracing parent pointers starting with
  // the given LanguageModelStateEntry. Returns the constructed word.
  // Updates best_char_choices, certainties and state if they are not
  // NULL (best_char_choices and certainties are assumed to have the
  // length equal to lmse->length).
  // The caller is responsible for freeing memory associated with the
  // returned WERD_CHOICE.
  WERD_CHOICE *ConstructWord(ViterbiStateEntry *vse,
                             WERD_RES *word_res,
                             DANGERR *fixpt,
                             BlamerBundle *blamer_bundle,
                             bool *truth_path);

  // Wrapper around AssociateUtils::ComputeStats().
  inline void ComputeAssociateStats(int col, int row,
                                    float max_char_wh_ratio,
                                    ViterbiStateEntry *parent_vse,
                                    WERD_RES *word_res,
                                    AssociateStats *associate_stats) {
    AssociateUtils::ComputeStats(
        col, row,
        (parent_vse != NULL) ? &(parent_vse->associate_stats) : NULL,
        (parent_vse != NULL) ? parent_vse->length : 0,
        fixed_pitch_, max_char_wh_ratio,
        word_res, language_model_debug_level > 2, associate_stats);
  }

  // Returns true if the path with such top_choice_flags and dawg_info
  // could be pruned out (i.e. is neither a system/user/frequent dictionary
  // nor a top choice path).
  // In non-space delimited languages all paths can be "somewhat" dictionary
  // words. In such languages we can not do dictionary-driven path pruning,
  // so paths with non-empty dawg_info are considered prunable.
  inline bool PrunablePath(const ViterbiStateEntry &vse) {
    if (vse.top_choice_flags) return false;
    if (vse.dawg_info != NULL &&
        (vse.dawg_info->permuter == SYSTEM_DAWG_PERM ||
         vse.dawg_info->permuter == USER_DAWG_PERM ||
         vse.dawg_info->permuter == FREQ_DAWG_PERM)) return false;
    return true;
  }

  // Returns true if the given ViterbiStateEntry represents an acceptable path.
  inline bool AcceptablePath(const ViterbiStateEntry &vse) {
    return (vse.dawg_info != NULL || vse.Consistent() ||
            (vse.ngram_info != NULL && !vse.ngram_info->pruned));
  }

 public:
  // Parameters.
  INT_VAR_H(language_model_debug_level, 0, "Language model debug level");
  BOOL_VAR_H(language_model_ngram_on, false,
             "Turn on/off the use of character ngram model");
  INT_VAR_H(language_model_ngram_order, 8,
            "Maximum order of the character ngram model");
  INT_VAR_H(language_model_viterbi_list_max_num_prunable, 10,
            "Maximum number of prunable (those for which PrunablePath() is"
            " true) entries in each viterbi list recorded in BLOB_CHOICEs");
  INT_VAR_H(language_model_viterbi_list_max_size, 500,
            "Maximum size of viterbi lists recorded in BLOB_CHOICEs");
  double_VAR_H(language_model_ngram_small_prob, 0.000001,
               "To avoid overly small denominators use this as the floor"
               " of the probability returned by the ngram model");
  double_VAR_H(language_model_ngram_nonmatch_score, -40.0,
               "Average classifier score of a non-matching unichar");
  BOOL_VAR_H(language_model_ngram_use_only_first_uft8_step, false,
             "Use only the first UTF8 step of the given string"
             " when computing log probabilities");
  double_VAR_H(language_model_ngram_scale_factor, 0.03,
               "Strength of the character ngram model relative to the"
               " character classifier ");
  double_VAR_H(language_model_ngram_rating_factor, 16.0,
               "Factor to bring log-probs into the same range as ratings"
               " when multiplied by outline length ");
  BOOL_VAR_H(language_model_ngram_space_delimited_language, true,
             "Words are delimited by space");
  INT_VAR_H(language_model_min_compound_length, 3,
            "Minimum length of compound words");
  // Penalties used for adjusting path costs and final word rating.
  double_VAR_H(language_model_penalty_non_freq_dict_word, 0.1,
               "Penalty for words not in the frequent word dictionary");
  double_VAR_H(language_model_penalty_non_dict_word, 0.15,
               "Penalty for non-dictionary words");
  double_VAR_H(language_model_penalty_punc, 0.2,
               "Penalty for inconsistent punctuation");
  double_VAR_H(language_model_penalty_case, 0.1,
               "Penalty for inconsistent case");
  double_VAR_H(language_model_penalty_script, 0.5,
               "Penalty for inconsistent script");
  double_VAR_H(language_model_penalty_chartype, 0.3,
               "Penalty for inconsistent character type");
  double_VAR_H(language_model_penalty_font, 0.00,
               "Penalty for inconsistent font");
  double_VAR_H(language_model_penalty_spacing, 0.05,
               "Penalty for inconsistent spacing");
  double_VAR_H(language_model_penalty_increment, 0.01, "Penalty increment");
  INT_VAR_H(wordrec_display_segmentations, 0, "Display Segmentations");
  BOOL_VAR_H(language_model_use_sigmoidal_certainty, false,
             "Use sigmoidal score for certainty");


 protected:


public:

  // Member Variables.

  // Temporary DawgArgs struct that is re-used across different words to
  // avoid dynamic memory re-allocation (should be cleared before each use).
  DawgArgs dawg_args_;
  // Scaling for recovering blob outline length from rating and certainty.
  float rating_cert_scale_;

  // The following variables are set at construction time.

  // Pointer to fontinfo table (not owned by LanguageModel).
  const UnicityTable<FontInfo> *fontinfo_table_;

  // Pointer to Dict class, that is used for querying the dictionaries
  // (the pointer is not owned by LanguageModel).
  Dict *dict_;

  // TODO(daria): the following variables should become LanguageModel params
  // when the old code in bestfirst.cpp and heuristic.cpp is deprecated.
  //
  // Set to true if we are dealing with fixed pitch text
  // (set to assume_fixed_pitch_char_segment).
  bool fixed_pitch_;
  // Max char width-to-height ratio allowed
  // (set to segsearch_max_char_wh_ratio).
  float max_char_wh_ratio_;

  // The following variables are initialized with InitForWord().

  // String representation of the classification of the previous word
  // (since this is only used by the character ngram model component,
  // only the last language_model_ngram_order of the word are stored).
  STRING prev_word_str_;
  int prev_word_unichar_step_len_;
  // Active dawg vector.
  DawgPositionVector very_beginning_active_dawgs_;  // includes continuation
  DawgPositionVector beginning_active_dawgs_;
  // Set to true if acceptable choice was discovered.
  // Note: it would be nice to use this to terminate the search once an
  // acceptable choices is found. However we do not do that and once an
  // acceptable choice is found we finish looking for alternative choices
  // in the current segmentation graph and then exit the search (no more
  // classifications are done after an acceptable choice is found).
  // This is needed in order to let the search find the words very close to
  // the best choice in rating (e.g. what/What, Cat/cat, etc) and log these
  // choices. This way the stopper will know that the best choice is not
  // ambiguous (i.e. there are best choices in the best choice list that have
  // ratings close to the very best one) and will be less likely to mis-adapt.
  bool acceptable_choice_found_;
  // Set to true if a choice representing correct segmentation was explored.
  bool correct_segmentation_explored_;

  // Params models containing weights for for computing ViterbiStateEntry costs.
  ParamsModel params_model_;
};

}  // namespace tesseract



#endif  // TESSERACT_WORDREC_LANGUAGE_MODEL_H_

 
 



#define MAX_NUM_POINTS 50
typedef tesseract::KDPairInc<float, EDGEPT*> PointPair;
typedef tesseract::GenericHeap<PointPair> PointHeap;
typedef tesseract::KDPtrPairInc<float, SEAM> SeamPair;
typedef tesseract::GenericHeap<SeamPair> SeamQueue;
typedef tesseract::KDPtrPairDec<float, SEAM> SeamDecPair;
typedef tesseract::GenericHeap<SeamDecPair> SeamPile;






typedef enum {
  Black,
  White,
  Red,
  Yellow,
  Green,
  Cyan,
  Blue,
  Magenta,
  Aquamarine,
  Dark_SLATE_BLUE,
  Light_BLUE,
  Medium_BLUE,
  Midnight_BLUE,
  Navy_BLUE,
  Sky_BLUE,
  Slate_BLUE,
  Steel_BLUE,
  Coral,
  Brown,
  Sandy_BROWN,
  Gold,
  GoldENROD,
  Dark_GREEN,
  Dark_OLIVE_GREEN,
  Forest_GREEN,
  Lime_GREEN,
  Pale_GREEN,
  Yellow_GREEN,
  Light_GREY,
  Dark_SLATE_GREY,
  Dim_GREY,
  Grey,
  Khaki,
  Maroon,
  Orange,
  Orchid,
  Pink,
  Plum,
  Indian_RED,
  Orange_RED,
  Violet_RED,
  Salmon,
  Tan,
  Turqoise,
  Dark_TURQUOISE,
  Violet,
  Wheat,
  Green_YELLOW
} C_COL;                         









#if WORD_REC|1



namespace tesseract {

// A class for storing which nodes are to be processed by the segmentation
// search. There is a single SegSearchPending for each column in the ratings
// matrix, and it indicates whether the segsearch should combine all
// BLOB_CHOICES in the column, or just the given row with the parents
// corresponding to *this SegSearchPending, and whether only updated parent
// ViterbiStateEntries should be combined, or all, with the BLOB_CHOICEs.
class SegSearchPending {
 public:
  SegSearchPending()
    : classified_row_(-1),
      revisit_whole_column_(false),
      column_classified_(false) {}

  // Marks the whole column as just classified. Used to start a search on
  // a newly initialized ratings matrix.
  void SetColumnClassified() {
    column_classified_ = true;
  }
  // Marks the matrix entry at the given row as just classified.
  // Used after classifying a new matrix cell.
  // Additional to, not overriding a previous RevisitWholeColumn.
  void SetBlobClassified(int row) {
    classified_row_ = row;
  }
  // Marks the whole column as needing work, but not just classified.
  // Used when the parent vse list is updated.
  // Additional to, not overriding a previous SetBlobClassified.
  void RevisitWholeColumn() {
    revisit_whole_column_ = true;
  }

  // Clears *this to indicate no work to do.
  void Clear() {
    classified_row_ = -1;
    revisit_whole_column_ = false;
    column_classified_ = false;
  }

  // Returns true if there are updates to do in the column that *this
  // represents.
  bool WorkToDo() const {
    return revisit_whole_column_ || column_classified_ || classified_row_ >= 0;
  }
  // Returns true if the given row was just classified.
  bool IsRowJustClassified(int row) const {
    return row == classified_row_ || column_classified_;
  }
  // Returns the single row to process if there is only one, otherwise -1.
  int SingleRow() const {
    return revisit_whole_column_ || column_classified_ ? -1 : classified_row_;
  }

 


private:

public:
  // If non-negative, indicates the single row in the ratings matrix that has
  // just been classified, and so should be combined with all the parents in the
  // column that this SegSearchPending represents.
  // Operates independently of revisit_whole_column.
  int classified_row_;
  // If revisit_whole_column is true, then all BLOB_CHOICEs in this column will
  // be processed, but classified_row can indicate a row that is newly
  // classified. Overridden if column_classified is true.
  bool revisit_whole_column_;
  // If column_classified is true, parent vses are processed with all rows
  // regardless of whether they are just updated, overriding
  // revisit_whole_column and classified_row.
  bool column_classified_;
};


/* ccmain/tstruct.cpp *********************************************************/
class FRAGMENT:public ELIST_LINK
{
  public:
    FRAGMENT() {  //constructor
    }
    FRAGMENT(EDGEPT *head_pt,   //start
             EDGEPT *tail_pt);  //end

    ICOORD head;                 //coords of start
    ICOORD tail;                 //coords of end
    EDGEPT *headpt;              //start point
    EDGEPT *tailpt;              //end point
};
ELISTIZEH(FRAGMENT)


class Wordrec : public Classify {
 public:
  // config parameters *******************************************************
  BOOL_VAR_H(merge_fragments_in_matrix, TRUE,
             "Merge the fragments in the ratings matrix and delete them "
             "after merging");
  BOOL_VAR_H(wordrec_no_block, FALSE, "Don't output block information");
  BOOL_VAR_H(wordrec_enable_assoc, TRUE, "Associator Enable");
  BOOL_VAR_H(force_word_assoc, FALSE,
             "force associator to run regardless of what enable_assoc is."
             "This is used for CJK where component grouping is necessary.");
  double_VAR_H(wordrec_worst_state, 1, "Worst segmentation state");
  BOOL_VAR_H(fragments_guide_chopper, FALSE,
             "Use information from fragments to guide chopping process");
  INT_VAR_H(repair_unchopped_blobs, 1, "Fix blobs that aren't chopped");
  double_VAR_H(tessedit_certainty_threshold, -2.25, "Good blob limit");
  INT_VAR_H(chop_debug, 0, "Chop debug");
  BOOL_VAR_H(chop_enable, 1, "Chop enable");
  BOOL_VAR_H(chop_vertical_creep, 0, "Vertical creep");
  INT_VAR_H(chop_split_length, 10000, "Split Length");
  INT_VAR_H(chop_same_distance, 2, "Same distance");
  INT_VAR_H(chop_min_outline_points, 6, "Min Number of Points on Outline");
  INT_VAR_H(chop_seam_pile_size, 150, "Max number of seams in seam_pile");
  BOOL_VAR_H(chop_new_seam_pile, 1, "Use new seam_pile");
  INT_VAR_H(chop_inside_angle, -50, "Min Inside Angle Bend");
  INT_VAR_H(chop_min_outline_area, 2000, "Min Outline Area");
  double_VAR_H(chop_split_dist_knob, 0.5, "Split length adjustment");
  double_VAR_H(chop_overlap_knob, 0.9, "Split overlap adjustment");
  double_VAR_H(chop_center_knob, 0.15, "Split center adjustment");
  INT_VAR_H(chop_centered_maxwidth, 90, "Width of (smaller) chopped blobs "
            "above which we don't care that a chop is not near the center.");
  double_VAR_H(chop_sharpness_knob, 0.06, "Split sharpness adjustment");
  double_VAR_H(chop_width_change_knob, 5.0, "Width change adjustment");
  double_VAR_H(chop_ok_split, 100.0, "OK split limit");
  double_VAR_H(chop_good_split, 50.0, "Good split limit");
  INT_VAR_H(chop_x_y_weight, 3, "X / Y  length weight");
  INT_VAR_H(segment_adjust_debug, 0, "Segmentation adjustment debug");
  BOOL_VAR_H(assume_fixed_pitch_char_segment, FALSE,
             "include fixed-pitch heuristics in char segmentation");
  INT_VAR_H(wordrec_debug_level, 0, "Debug level for wordrec");
  INT_VAR_H(wordrec_max_join_chunks, 4,
            "Max number of broken pieces to associate");
  BOOL_VAR_H(wordrec_skip_no_truth_words, false,
             "Only run OCR for words that had truth recorded in BlamerBundle");
  BOOL_VAR_H(wordrec_debug_blamer, false, "Print blamer debug messages");
  BOOL_VAR_H(wordrec_run_blamer, false, "Try to set the blame for errors");
  INT_VAR_H(segsearch_debug_level, 0, "SegSearch debug level");
  INT_VAR_H(segsearch_max_pain_points, 2000,
            "Maximum number of pain points stored in the queue");
  INT_VAR_H(segsearch_max_futile_classifications, 10,
            "Maximum number of pain point classifications per word.");
  double_VAR_H(segsearch_max_char_wh_ratio, 2.0,
               "Maximum character width-to-height ratio");
  BOOL_VAR_H(save_alt_choices, true,
             "Save alternative paths found during chopping "
             "and segmentation search");

  // methods from wordrec/*.cpp ***********************************************
  Wordrec();
  virtual ~Wordrec();

  // Fills word->alt_choices with alternative paths found during
  // chopping/segmentation search that are kept in best_choices.
  void SaveAltChoices(const LIST &best_choices, WERD_RES *word);

  // Fills character choice lattice in the given BlamerBundle
  // using the given ratings matrix and best choice list.
  void FillLattice(const MATRIX &ratings, const WERD_CHOICE_LIST &best_choices,
                   const UNICHARSET &unicharset, BlamerBundle *blamer_bundle);

  // Calls fill_lattice_ member function
  // (assumes that fill_lattice_ is not NULL).
  void CallFillLattice(const MATRIX &ratings,
                       const WERD_CHOICE_LIST &best_choices,
                       const UNICHARSET &unicharset,
                       BlamerBundle *blamer_bundle) {
    (this->*fill_lattice_)(ratings, best_choices, unicharset, blamer_bundle);
  }





  // tface.cpp

  // void program_editup(const char *textbase,    bool init_classifier,  bool init_permute);


#if  MOVED_OTHERWHERE|1



  /**
   * @name program_editup
   *
   * Initialize all the things in the program that need to be initialized.
   * init_permute determines whether to initialize the permute functions
   * and Dawg models.
   */

  void Wordrec::program_editup(const char* textbase,
      bool init_classifier,
      bool init_dict) {
//\\if (textbase != NULL) imagefile = textbase;
      InitFeatureDefs(&feature_defs_);
      InitAdaptiveClassifier(init_classifier);




      if(1)if (init_dict) {
          getDict().SetupForLoad(Dict::GlobalDawgCache());
          getDict().Load(tessdata_manager.GetDataFileName().string(), lang);
          getDict().FinishLoad();
      }

      //\\pass2_ok_split = chop_ok_split;
  }



#endif  // MOVED_OTHERWHERE






  void cc_recog(WERD_RES *word);
  void program_editdown(inT32 elasped_time);
  void set_pass1();
  void set_pass2();
  int end_recog();
  BLOB_CHOICE_LIST *call_matcher(TBLOB* blob);
  int dict_word(const WERD_CHOICE &word);
  // wordclass.cpp
  BLOB_CHOICE_LIST *classify_blob(TBLOB *blob,
                                  const char *string,
                                  C_COL color,
                                  BlamerBundle *blamer_bundle);

  // segsearch.cpp
  // SegSearch works on the lower diagonal matrix of BLOB_CHOICE_LISTs.
  // Each entry in the matrix represents the classification choice
  // for a chunk, i.e. an entry in row 2, column 1 represents the list
  // of ratings for the chunks 1 and 2 classified as a single blob.
  // The entries on the diagonal of the matrix are classifier choice lists
  // for a single chunk from the maximal segmentation.
  //
  // The ratings matrix given to SegSearch represents the segmentation
  // graph / trellis for the current word. The nodes in the graph are the
  // individual BLOB_CHOICEs in each of the BLOB_CHOICE_LISTs in the ratings
  // matrix. The children of each node (nodes connected by outgoing links)
  // are the entries in the column that is equal to node's row+1. The parents
  // (nodes connected by the incoming links) are the entries in the row that
  // is equal to the node's column-1. Here is an example ratings matrix:
  //
  //    0    1    2   3   4
  //  -------------------------
  // 0| c,(                   |
  // 1| d    l,1              |
  // 2|           o           |
  // 3|              c,(      |
  // 4|              g,y  l,1 |
  //  -------------------------
  //
  // In the example above node "o" has children (outgoing connection to nodes)
  // "c","(","g","y" and parents (incoming connections from nodes) "l","1","d".
  //
  // The objective of the search is to find the least cost path, where the cost
  // is determined by the language model components and the properties of the
  // cut between the blobs on the path. SegSearch starts by populating the
  // matrix with the all the entries that were classified by the chopper and
  // finding the initial best path. Based on the classifier ratings, language
  // model scores and the properties of each cut, a list of "pain points" is
  // constructed - those are the points on the path where the choices do not
  // look consistent with the neighboring choices, the cuts look particularly
  // problematic, or the certainties of the blobs are low. The most troublesome
  // "pain point" is picked from the list and the new entry in the ratings
  // matrix corresponding to this "pain point" is filled in. Then the language
  // model state is updated to reflect the new classification and the new
  // "pain points" are added to the list and the next most troublesome
  // "pain point" is determined. This continues until either the word choice
  // composed from the best paths in the segmentation graph is "good enough"
  // (e.g. above a certain certainty threshold, is an unambiguous dictionary
  // word, etc) or there are no more "pain points" to explore.
  //
  // If associate_blobs is set to false no new classifications will be done
  // to combine blobs. Segmentation search will run only one "iteration"
  // on the classifications already recorded in chunks_record.ratings.
  //
  // Note: this function assumes that word_res, best_choice_bundle arguments
  // are not NULL.
  void SegSearch(WERD_RES* word_res,
                 BestChoiceBundle* best_choice_bundle,
                 BlamerBundle* blamer_bundle);
  // Setup and run just the initial segsearch on an established matrix,
  // without doing any additional chopping or joining.
  void WordSearch(WERD_RES* word_res);

  // Setup and run just the initial segsearch on an established matrix,
  // without doing any additional chopping or joining.
  // (Internal factored version that can be used as part of the main SegSearch.)
  void InitialSegSearch(WERD_RES* word_res, LMPainPoints* pain_points,
                        GenericVector<SegSearchPending>* pending,
                        BestChoiceBundle* best_choice_bundle,
                        BlamerBundle* blamer_bundle);

  // Runs SegSearch() function (above) without needing a best_choice_bundle
  // or blamer_bundle. Used for testing.
  void DoSegSearch(WERD_RES* word_res);

  // chop.cpp
  PRIORITY point_priority(EDGEPT *point);
  void add_point_to_list(PointHeap* point_heap, EDGEPT *point);
  // Returns true if the edgept supplied as input is an inside angle.  This
  // is determined by the angular change of the vectors from point to point.
  bool is_inside_angle(EDGEPT *pt);
  int angle_change(EDGEPT *point1, EDGEPT *point2, EDGEPT *point3);
  EDGEPT *pick_close_point(EDGEPT *critical_point,
                           EDGEPT *vertical_point,
                           int *best_dist);
  void prioritize_points(TESSLINE *outline, PointHeap* points);
  void new_min_point(EDGEPT *local_min, PointHeap* points);
  void new_max_point(EDGEPT *local_max, PointHeap* points);
  void vertical_projection_point(EDGEPT *split_point, EDGEPT *target_point,
                                 EDGEPT** best_point,
                                 EDGEPT_CLIST *new_points);

  // chopper.cpp
  SEAM *attempt_blob_chop(TWERD *word, TBLOB *blob, inT32 blob_number,
                          bool italic_blob, const GenericVector<SEAM*>& seams);
  SEAM *chop_numbered_blob(TWERD *word, inT32 blob_number,
                           bool italic_blob, const GenericVector<SEAM*>& seams);
  SEAM *chop_overlapping_blob(const GenericVector<TBOX>& boxes,
                              bool italic_blob,
                              WERD_RES *word_res, int *blob_number);
  SEAM *improve_one_blob(const GenericVector<BLOB_CHOICE*> &blob_choices,
                         DANGERR *fixpt,
                         bool split_next_to_fragment,
                         bool italic_blob,
                         WERD_RES *word,
                         int *blob_number);
  SEAM *chop_one_blob(const GenericVector<TBOX> &boxes,
                      const GenericVector<BLOB_CHOICE*> &blob_choices,
                      WERD_RES *word_res,
                      int *blob_number);
  void chop_word_main(WERD_RES *word);
  void improve_by_chopping(float rating_cert_scale,
                           WERD_RES *word,
                           BestChoiceBundle *best_choice_bundle,
                           BlamerBundle *blamer_bundle,
                           LMPainPoints *pain_points,
                           GenericVector<SegSearchPending>* pending);
  int select_blob_to_split(const GenericVector<BLOB_CHOICE*> &blob_choices,
                           float rating_ceiling,
                           bool split_next_to_fragment);
  int select_blob_to_split_from_fixpt(DANGERR *fixpt);



 

  // findseam.cpp
  void add_seam_to_queue(float new_priority, SEAM *new_seam, SeamQueue* seams);
  void choose_best_seam(SeamQueue *seam_queue, const SPLIT *split,
                        PRIORITY priority, SEAM **seam_result, TBLOB *blob,
                        SeamPile *seam_pile);
  void combine_seam(const SeamPile& seam_pile,
                    const SEAM* seam, SeamQueue* seam_queue);
  SEAM *pick_good_seam(TBLOB *blob);
  void try_point_pairs (EDGEPT * points[MAX_NUM_POINTS],
                        inT16 num_points,
                        SeamQueue* seam_queue,
                        SeamPile* seam_pile,
                        SEAM ** seam, TBLOB * blob);
  void try_vertical_splits(EDGEPT * points[MAX_NUM_POINTS],
                           inT16 num_points,
                           EDGEPT_CLIST *new_points,
                           SeamQueue* seam_queue,
                           SeamPile* seam_pile,
                           SEAM ** seam, TBLOB * blob);

  
 




// gradechop.cpp
  PRIORITY grade_split_length(register SPLIT *split);
  PRIORITY grade_sharpness(register SPLIT *split);

  // outlines.cpp
  bool near_point(EDGEPT *point, EDGEPT *line_pt_0, EDGEPT *line_pt_1,
                  EDGEPT **near_pt);

  // pieces.cpp
  virtual BLOB_CHOICE_LIST *classify_piece(const GenericVector<SEAM*>& seams,
                                           inT16 start,
                                           inT16 end,
                                           const char* description,
                                           TWERD *word,
                                           BlamerBundle *blamer_bundle);
  // Try to merge fragments in the ratings matrix and put the result in
  // the corresponding row and column
  void merge_fragments(MATRIX *ratings,
                       inT16 num_blobs);
  // Recursively go through the ratings matrix to find lists of fragments
  // to be merged in the function merge_and_put_fragment_lists.
  // current_frag is the position of the piece we are looking for.
  // current_row is the row in the rating matrix we are currently at.
  // start is the row we started initially, so that we can know where
  // to append the results to the matrix. num_frag_parts is the total
  // number of pieces we are looking for and num_blobs is the size of the
  // ratings matrix.
  void get_fragment_lists(inT16 current_frag,
                          inT16 current_row,
                          inT16 start,
                          inT16 num_frag_parts,
                          inT16 num_blobs,
                          MATRIX *ratings,
                          BLOB_CHOICE_LIST *choice_lists);
  // Merge the fragment lists in choice_lists and append it to the
  // ratings matrix
  void merge_and_put_fragment_lists(inT16 row,
                                    inT16 column,
                                    inT16 num_frag_parts,
                                    BLOB_CHOICE_LIST *choice_lists,
                                    MATRIX *ratings);
  // Filter the fragment list so that the filtered_choices only contain
  // fragments that are in the correct position. choices is the list
  // that we are going to filter. fragment_pos is the position in the
  // fragment that we are looking for and num_frag_parts is the the
  // total number of pieces. The result will be appended to
  // filtered_choices.
  void fill_filtered_fragment_list(BLOB_CHOICE_LIST *choices,
                                   int fragment_pos,
                                   int num_frag_parts,
                                   BLOB_CHOICE_LIST *filtered_choices);

  // Member variables.

  LanguageModel *language_model_;
  PRIORITY pass2_ok_split;
  // Stores the best choice for the previous word in the paragraph.
  // This variable is modified by PAGE_RES_IT when iterating over
  // words to OCR on the page.
  WERD_CHOICE *prev_word_best_choice_;
  // Sums of blame reasons computed by the blamer.
  GenericVector<int> blame_reasons_;
  // Function used to fill char choice lattices.
  void (Wordrec::*fill_lattice_)(const MATRIX &ratings,
                                 const WERD_CHOICE_LIST &best_choices,
                                 const UNICHARSET &unicharset,
                                 BlamerBundle *blamer_bundle);

 protected:
public:


  inline bool SegSearchDone(int num_futile_classifications) {
    return (language_model_->AcceptableChoiceFound() ||
            num_futile_classifications >=
            segsearch_max_futile_classifications);
  }

  // Updates the language model state recorded for the child entries specified
  // in pending[starting_col]. Enqueues the children of the updated entries
  // into pending and proceeds to update (and remove from pending) all the
  // remaining entries in pending[col] (col >= starting_col). Upon termination
  // of this function all the pending[col] lists will be empty.
  //
  // The arguments:
  //
  // starting_col: index of the column in chunks_record->ratings from
  // which the update should be started
  //
  // pending: list of entries listing chunks_record->ratings entries
  // that should be updated
  //
  // pain_points: priority heap listing the pain points generated by
  // the language model
  //
  // temp_pain_points: temporary storage for tentative pain points generated
  // by the language model after a single call to LanguageModel::UpdateState()
  // (the argument is passed in rather than created before each
  // LanguageModel::UpdateState() call to avoid dynamic memory re-allocation)
  //
  // best_choice_bundle: a collection of variables that should be updated
  // if a new best choice is found
  //
  void UpdateSegSearchNodes(
      float rating_cert_scale,
      int starting_col,
      GenericVector<SegSearchPending>* pending,
      WERD_RES *word_res,
      LMPainPoints *pain_points,
      BestChoiceBundle *best_choice_bundle,
      BlamerBundle *blamer_bundle);

  // Process the given pain point: classify the corresponding blob, enqueue
  // new pain points to join the newly classified blob with its neighbors.
  void ProcessSegSearchPainPoint(float pain_point_priority,
                                 const MATRIX_COORD &pain_point,
                                 const char* pain_point_type,
                                 GenericVector<SegSearchPending>* pending,
                                 WERD_RES *word_res,
                                 LMPainPoints *pain_points,
                                 BlamerBundle *blamer_bundle);
  // Resets enough of the results so that the Viterbi search is re-run.
  // Needed when the n-gram model is enabled, as the multi-length comparison
  // implementation will re-value existing paths to worse values.
  void ResetNGramSearch(WERD_RES* word_res,
                        BestChoiceBundle* best_choice_bundle,
                        GenericVector<SegSearchPending>* pending);

  // Add pain points for classifying blobs on the correct segmentation path
  // (so that we can evaluate correct segmentation path and discover the reason
  // for incorrect result).
  void InitBlamerForSegSearch(WERD_RES *word_res,
                              LMPainPoints *pain_points,
                              BlamerBundle *blamer_bundle,
                              STRING *blamer_debug);
};


}  // namespace tesseract





#endif  // WORD_REC  










enum ACCEPTABLE_WERD_TYPE
{
  AC_UNACCEPTABLE,               ///< Unacceptable word
  AC_LOWER_CASE,                 ///< ALL lower case
  AC_UPPER_CASE,                 ///< ALL upper case
  AC_INITIAL_CAP,                ///< ALL but initial lc
  AC_LC_ABBREV,                  ///< a.b.c.
  AC_UC_ABBREV                   ///< A.B.C.
};




enum GARBAGE_LEVEL
{
  G_NEVER_CRUNCH,
  G_OK,
  G_DODGY,
  G_TERRIBLE
};



void reject_whole_page(PAGE_RES_IT &page_res_it);





#if  DEBUG_MODE|1 


#if OCR_CLASS|1


 




#ifndef __GNUC__
#ifdef _WIN32

#include          "gettimeofday.h"         // gettimeofday  


#endif
#else
#include          <sys/time.h>
#endif
#include          <time.h>
#include          "host.h"

/*Maximum lengths of various strings*/
#define MAX_FONT_NAME   34       /*name of font */
#define MAX_OCR_NAME    32       /*name of engine */
#define MAX_OCR_VERSION   17     /*version code of engine */

/*pitch set definitions are identical to RTF*/
#define PITCH_DEF     0          /*default */
#define PITCH_FIXED     1        /*fixed pitch */
#define PITCH_VAR     2          /*variable pitch */

/**********************************************************************
 * EANYCODE_CHAR
 * Description of a single character. The character code is defined by
 * the character set of the current font.
 * Output text is sent as an array of these structures.
 * Spaces and line endings in the output are represented in the
 * structures of the surrounding characters. They are not directly
 * represented as characters.
 * The first character in a word has a positive value of blanks.
 * Missing information should be set to the defaults in the comments.
 * If word bounds are known, but not character bounds, then the top and
 * bottom of each character should be those of the word. The left of the
 * first and right of the last char in each word should be set. All other
 * lefts and rights should be set to -1.
 * If set, the values of right and bottom are left+width and top+height.
 * Most of the members come directly from the parameters to ocr_append_char.
 * The formatting member uses the enhancement parameter and combines the
 * line direction stuff into the top 3 bits.
 * The coding is 0=RL char, 1=LR char, 2=DR NL, 3=UL NL, 4=DR Para,
 * 5=UL Para, 6=TB char, 7=BT char. API users do not need to know what
 * the coding is, only that it is backwards compatible with the previous
 * version.
 **********************************************************************/

typedef struct {                  /*single character */
// It should be noted that the format for char_code for version 2.0 and beyond
// is UTF8 which means that ASCII characters will come out as one structure but
// other characters will be returned in two or more instances of this structure
// with a single byte of the  UTF8 code in each, but each will have the same
// bounding box. Programs which want to handle languagues with different
// characters sets will need to handle extended characters appropriately, but
// *all* code needs to be prepared to receive UTF8 coded characters for
// characters such as bullet and fancy quotes.
  uinT16 char_code;              /*character itself */
  inT16 left;                    /*of char (-1) */
  inT16 right;                   /*of char (-1) */
  inT16 top;                     /*of char (-1) */
  inT16 bottom;                  /*of char (-1) */
  inT16 font_index;              /*what font (0) */
  uinT8 confidence;              /*0=perfect, 100=reject (0/100) */
  uinT8 point_size;              /*of char, 72=i inch, (10) */
  inT8 blanks;                   /*no of spaces before this char (1) */
  uinT8 formatting;              /*char formatting (0) */
} EANYCODE_CHAR;                 /*single character */

/**********************************************************************
 * ETEXT_DESC
 * Description of the output of the OCR engine.
 * This structure is used as both a progress monitor and the final
 * output header, since it needs to be a valid progress monitor while
 * the OCR engine is storing its output to shared memory.
 * During progress, all the buffer info is -1.
 * Progress starts at 0 and increases to 100 during OCR. No other constraint.
 * Additionally the progress callback contains the bounding box of the word that
 * is currently being processed.
 * Every progress callback, the OCR engine must set ocr_alive to 1.
 * The HP side will set ocr_alive to 0. Repeated failure to reset
 * to 1 indicates that the OCR engine is dead.
 * If the cancel function is not null then it is called with the number of
 * user words found. If it returns true then operation is cancelled.
 **********************************************************************/
typedef bool (*CANCEL_FUNC)(void* cancel_this, int words);
typedef bool (*PROGRESS_FUNC)(int progress, int left, int right, int top,
                              int bottom);

class ETEXT_DESC {             // output header
 public:
  inT16 count;     /// chars in this buffer(0)
  inT16 progress;  /// percent complete increasing (0-100)
  /** Progress monitor covers word recognition and it does not cover layout
  * analysis.
  * See Ray comment in https://github.com/tesseract-ocr/tesseract/pull/27 */
  inT8 more_to_come;                /// true if not last
  volatile inT8 ocr_alive;          /// ocr sets to 1, HP 0
  inT8 err_code;                    /// for errcode use
  CANCEL_FUNC cancel;               /// returns true to cancel
  PROGRESS_FUNC progress_callback;  /// called whenever progress increases
  void* cancel_this;                /// this or other data for cancel
  struct timeval end_time;          /// Time to stop. Expected to be set only
                                    /// by call to set_deadline_msecs().
  EANYCODE_CHAR text[1];            /// character data

  ETEXT_DESC()
      : count(0),
        progress(0),
        more_to_come(0),
        ocr_alive(0),
        err_code(0),
        cancel(NULL),
        progress_callback(NULL),
        cancel_this(NULL) {
    end_time.tv_sec = 0;
    end_time.tv_usec = 0;
  }

  // Sets the end time to be deadline_msecs milliseconds from now.
  void set_deadline_msecs(inT32 deadline_msecs) {
    gettimeofday(&end_time, NULL);
    inT32 deadline_secs = deadline_msecs / 1000;
    end_time.tv_sec += deadline_secs;
    end_time.tv_usec += (deadline_msecs -  deadline_secs * 1000) * 1000;
    if (end_time.tv_usec > 1000000) {
      end_time.tv_usec -= 1000000;
      ++end_time.tv_sec;
    }
  }

  // Returns false if we've not passed the end_time, or have not set a deadline.
  bool deadline_exceeded() const {
    if (end_time.tv_sec == 0 && end_time.tv_usec == 0) return false;
    struct timeval now;
    gettimeofday(&now, NULL);
    return (now.tv_sec > end_time.tv_sec || (now.tv_sec == end_time.tv_sec &&
                                             now.tv_usec > end_time.tv_usec));
  }
};






 

#endif   // OCR_CLASS
 


 



#if DEVANAGARI_PROCESS|1



extern    INT_VAR_H(devanagari_split_debuglevel, 0,      "Debug level for split shiro-rekha process.");

extern    BOOL_VAR_H(devanagari_split_debugimage, 0,     "Whether to create a debug image for split shiro-rekha process.");


namespace tesseract {

class PixelHistogram {
 public:
  PixelHistogram() {
    hist_ = NULL;
    length_ = 0;
  }

  ~PixelHistogram() {
    Clear();
  }

  void Clear() {
    if (hist_) {
      delete[] hist_;
    }
    length_ = 0;
  }

  int* hist() const { return hist_; }

  int length() const {
    return length_;
  }

  // Methods to construct histograms from images. These clear any existing data.
  void ConstructVerticalCountHist(Pix* pix);
  void ConstructHorizontalCountHist(Pix* pix);

  // This method returns the global-maxima for the histogram. The frequency of
  // the global maxima is returned in count, if specified.
  int GetHistogramMaximum(int* count) const;

 private:
  int* hist_;
  int length_;
};

class ShiroRekhaSplitter {
 public:
  enum SplitStrategy {
    NO_SPLIT = 0,   // No splitting is performed for the phase.
    MINIMAL_SPLIT,  // Blobs are split minimally.
    MAXIMAL_SPLIT   // Blobs are split maximally.
  };

  ShiroRekhaSplitter();
  virtual ~ShiroRekhaSplitter();

  // Top-level method to perform splitting based on current settings.
  // Returns true if a split was actually performed.
  // If split_for_pageseg is true, the pageseg_split_strategy_ is used for
  // splitting. If false, the ocr_split_strategy_ is used.
  bool Split(bool split_for_pageseg);

  // Clears the memory held by this object.
  void Clear();

  // Refreshes the words in the segmentation block list by using blobs in the
  // input blob list.
  // The segmentation block list must be set.
  void RefreshSegmentationWithNewBlobs(C_BLOB_LIST* new_blobs);

  // Returns true if the split strategies for pageseg and ocr are different.
  bool HasDifferentSplitStrategies() const {
    return pageseg_split_strategy_ != ocr_split_strategy_;
  }

  // This only keeps a copy of the block list pointer. At split call, the list
  // object should still be alive. This block list is used as a golden
  // segmentation when performing splitting.
  void set_segmentation_block_list(BLOCK_LIST* block_list) {
    segmentation_block_list_ = block_list;
  }

  static const int kUnspecifiedXheight = -1;

  void set_global_xheight(int xheight) {
    global_xheight_ = xheight;
  }

  void set_perform_close(bool perform) {
    perform_close_ = perform;
  }

  // Returns the image obtained from shiro-rekha splitting. The returned object
  // is owned by this class. Callers may want to clone the returned pix to keep
  // it alive beyond the life of ShiroRekhaSplitter object.
  Pix* splitted_image() {
    return splitted_image_;
  }

  // On setting the input image, a clone of it is owned by this class.
  void set_orig_pix(Pix* pix);

  // Returns the input image provided to the object. This object is owned by
  // this class. Callers may want to clone the returned pix to work with it.
  Pix* orig_pix() {
    return orig_pix_;
  }

  SplitStrategy ocr_split_strategy() const {
    return ocr_split_strategy_;
  }

  void set_ocr_split_strategy(SplitStrategy strategy) {
    ocr_split_strategy_ = strategy;
  }

  SplitStrategy pageseg_split_strategy() const {
    return pageseg_split_strategy_;
  }

  void set_pageseg_split_strategy(SplitStrategy strategy) {
    pageseg_split_strategy_ = strategy;
  }

  BLOCK_LIST* segmentation_block_list() {
    return segmentation_block_list_;
  }

  // This method dumps a debug image to the specified location.
  void DumpDebugImage(const char* filename) const;

  // This method returns the computed mode-height of blobs in the pix.
  // It also prunes very small blobs from calculation. Could be used to provide
  // a global xheight estimate for images which have the same point-size text.
  static int GetModeHeight(Pix* pix);

 private:
  // Method to perform a close operation on the input image. The xheight
  // estimate decides the size of sel used.
  static void PerformClose(Pix* pix, int xheight_estimate);

  // This method resolves the cc bbox to a particular row and returns the row's
  // xheight. This uses block_list_ if available, else just returns the
  // global_xheight_ estimate currently set in the object.
  int GetXheightForCC(Box* cc_bbox);

  // Returns a list of regions (boxes) which should be cleared in the original
  // image so as to perform shiro-rekha splitting. Pix is assumed to carry one
  // (or less) word only. Xheight measure could be the global estimate, the row
  // estimate, or unspecified. If unspecified, over splitting may occur, since a
  // conservative estimate of stroke width along with an associated multiplier
  // is used in its place. It is advisable to have a specified xheight when
  // splitting for classification/training.
  void SplitWordShiroRekha(SplitStrategy split_strategy,
                           Pix* pix,
                           int xheight,
                           int word_left,
                           int word_top,
                           Boxa* regions_to_clear);

  // Returns a new box object for the corresponding TBOX, based on the original
  // image's coordinate system.
  Box* GetBoxForTBOX(const TBOX& tbox) const;

  // This method returns y-extents of the shiro-rekha computed from the input
  // word image.
  static void GetShiroRekhaYExtents(Pix* word_pix,
                                    int* shirorekha_top,
                                    int* shirorekha_bottom,
                                    int* shirorekha_ylevel);

  Pix* orig_pix_;         // Just a clone of the input image passed.
  Pix* splitted_image_;   // Image produced after the last splitting round. The
                          // object is owned by this class.
  SplitStrategy pageseg_split_strategy_;
  SplitStrategy ocr_split_strategy_;
  Pix* debug_image_;
  // This block list is used as a golden segmentation when performing splitting.
  BLOCK_LIST* segmentation_block_list_;
  int global_xheight_;
  bool perform_close_;  // Whether a morphological close operation should be
                        // performed before CCs are run through splitting.
};

}  // namespace tesseract.



#endif    //  DEVANAGARI_PROCESS






struct OSResults;


class SVMenuNode;
class TBOX;
class TO_BLOCK_LIST;
class WERD;
class WERD_CHOICE;
class WERD_RES;


// Top-level class for all tesseract global instance data.
// This class either holds or points to all data used by an instance
// of Tesseract, including the memory allocator. When this is
// complete, Tesseract will be thread-safe. UNTIL THEN, IT IS NOT!
//
// NOTE to developers: Do not create cyclic dependencies through this class!
// The directory dependency tree must remain a tree! The keep this clean,
// lower-level code (eg in ccutil, the bottom level) must never need to
// know about the content of a higher-level directory.
// The following scheme will grant the easiest access to lower-level
// global members without creating a cyclic dependency:
//
// Class Hierarchy (^ = inheritance):
//
//             CCUtil (ccutil/ccutil.h)
//                         ^      Members include: UNICHARSET
//            CUtil (cutil/cutil_class.h)
//                         ^       Members include: TBLOB*, TEXTBLOCK*
//           CCStruct (ccstruct/ccstruct.h)
//                         ^       Members include: Image
//           Classify (classify/classify.h)
//                         ^       Members include: Dict
//             WordRec (wordrec/wordrec.h)
//                         ^       Members include: WERD*, DENORM*
//        Tesseract (ccmain/tesseractclass.h)
//                                 Members include: Pix*, CubeRecoContext*,
//                                 TesseractCubeCombiner*
//
// Other important classes:
//
//  TessBaseAPI (api/baseapi.h)
//                                 Members include: BLOCK_LIST*, PAGE_RES*,
//                                 Tesseract*, ImageThresholder*
//  Dict (dict/dict.h)
//                                 Members include: Image* (private)
//
// NOTE: that each level contains members that correspond to global
// data that is defined (and used) at that level, not necessarily where
// the type is defined so for instance:
// BOOL_VAR_H(textord_show_blobs, false, "Display unsorted blobs");
// goes inside the Textord class, not the cc_util class.

namespace tesseract {

class ColumnFinder;
#ifndef NO_CUBE_BUILD
class CharSamp;
class CubeLineObject;
class CubeObject;
class CubeRecoContext;
#endif
class EquationDetect;
class Tesseract;
#ifndef NO_CUBE_BUILD
class TesseractCubeCombiner;
#endif

// A collection of various variables for statistics and debugging.
struct TesseractStats {
  TesseractStats()
    : adaption_word_number(0),
      doc_blob_quality(0),
      doc_outline_errs(0),
      doc_char_quality(0),
      good_char_count(0),
      doc_good_char_quality(0),
      word_count(0),
      dict_words(0),
      tilde_crunch_written(false),
      last_char_was_newline(true),
      last_char_was_tilde(false),
      write_results_empty_block(true) {}

  inT32 adaption_word_number;
  inT16 doc_blob_quality;
  inT16 doc_outline_errs;
  inT16 doc_char_quality;
  inT16 good_char_count;
  inT16 doc_good_char_quality;
  inT32 word_count;  // count of word in the document
  inT32 dict_words;  // number of dicitionary words in the document
  STRING dump_words_str;  // accumulator used by dump_words()
  // Flags used by write_results()
  bool tilde_crunch_written;
  bool last_char_was_newline;
  bool last_char_was_tilde;
  bool write_results_empty_block;
};






// Struct to hold all the pointers to relevant data for processing a word.




struct WordData {
  WordData() : word(NULL), row(NULL), block(NULL), prev_word(NULL) {}
  explicit WordData(const PAGE_RES_IT& page_res_it)
    : word(page_res_it.word()), row(page_res_it.row()->row),
      block(page_res_it.block()->block), prev_word(NULL) {}
  WordData(BLOCK* block_in, ROW* row_in, WERD_RES* word_res)
    : word(word_res), row(row_in), block(block_in), prev_word(NULL) {}

  WERD_RES* word;
  ROW* row;
  BLOCK* block;
  WordData* prev_word;
  PointerVector<WERD_RES> lang_words;
};














// Definition of a Tesseract WordRecognizer. The WordData provides the context
// of row/block, in_word holds an initialized, possibly pre-classified word,
// that the recognizer may or may not consume (but if so it sets *in_word=NULL)
// and produces one or more output words in out_words, which may be the
// consumed in_word, or may be generated independently.
// This api allows both a conventional tesseract classifier to work, or a
// line-level classifier that generates multiple words from a merged input.
typedef void (Tesseract::*WordRecognizer)(const WordData& word_data,
                                          WERD_RES** in_word,
                                          PointerVector<WERD_RES>* out_words);

class Tesseract : public Wordrec {
 public:
  Tesseract();
  ~Tesseract();

  // Clear as much used memory as possible without resetting the adaptive
  // classifier or losing any other classifier data.
  void Clear();
  // Clear all memory of adaption for this and all subclassifiers.
  void ResetAdaptiveClassifier();
  // Clear the document dictionary for this and all subclassifiers.
  void ResetDocumentDictionary();

  // Set the equation detector.
  void SetEquationDetect(EquationDetect* detector);

  // Simple accessors.
  const FCOORD& reskew() const {
    return reskew_;
  }
  // Destroy any existing pix and return a pointer to the pointer.
  Pix** mutable_pix_binary() {
    pixDestroy(&pix_binary_);
    return &pix_binary_;
  }
  Pix* pix_binary() const {
    return pix_binary_;
  }
  Pix* pix_grey() const {
    return pix_grey_;
  }
  void set_pix_grey(Pix* grey_pix) {
    pixDestroy(&pix_grey_);
    pix_grey_ = grey_pix;
  }
  Pix* pix_original() const { return pix_original_; }
  // Takes ownership of the given original_pix.
  void set_pix_original(Pix* original_pix) {
    pixDestroy(&pix_original_);
    pix_original_ = original_pix;
  }
  // Returns a pointer to a Pix representing the best available (original) image
  // of the page. Can be of any bit depth, but never color-mapped, as that has
  // always been dealt with. Note that in grey and color, 0 is black and 255 is
  // white. If the input was binary, then black is 1 and white is 0.
  // To tell the difference pixGetDepth() will return 32, 8 or 1.
  // In any case, the return value is a borrowed Pix, and should not be
  // deleted or pixDestroyed.
  Pix* BestPix() const { return pix_original_; }
  void set_pix_thresholds(Pix* thresholds) {
    pixDestroy(&pix_thresholds_);
    pix_thresholds_ = thresholds;
  }
  int source_resolution() const {
    return source_resolution_;
  }
  void set_source_resolution(int ppi) {
    source_resolution_ = ppi;
  }
  int ImageWidth() const {
    return pixGetWidth(pix_binary_);
  }
  int ImageHeight() const {
    return pixGetHeight(pix_binary_);
  }
  Pix* scaled_color() const {
    return scaled_color_;
  }
  int scaled_factor() const {
    return scaled_factor_;
  }
  void SetScaledColor(int factor, Pix* color) {
    scaled_factor_ = factor;
    scaled_color_ = color;
  }
  const Textord& textord() const {
    return textord_;
  }
  Textord* mutable_textord() {
    return &textord_;
  }

  bool right_to_left() const {
    return right_to_left_;
  }
  int num_sub_langs() const {
    return sub_langs_.size();
  }
  Tesseract* get_sub_lang(int index) const {
    return sub_langs_[index];
  }
  // Returns true if any language uses Tesseract (as opposed to cube).
  bool AnyTessLang() const {
    if (tessedit_ocr_engine_mode != OEM_CUBE_ONLY) return true;
    for (int i = 0; i < sub_langs_.size(); ++i) {
      if (sub_langs_[i]->tessedit_ocr_engine_mode != OEM_CUBE_ONLY)
        return true;
    }
    return false;
  }

  void SetBlackAndWhitelist();

  // Perform steps to prepare underlying binary image/other data structures for
  // page segmentation. Uses the strategy specified in the global variable
  // pageseg_devanagari_split_strategy for perform splitting while preparing for
  // page segmentation.
  void PrepareForPageseg();

  // Perform steps to prepare underlying binary image/other data structures for
  // Tesseract OCR. The current segmentation is required by this method.
  // Uses the strategy specified in the global variable
  // ocr_devanagari_split_strategy for performing splitting while preparing for
  // Tesseract ocr.
  void PrepareForTessOCR(BLOCK_LIST* block_list,
                         Tesseract* osd_tess, OSResults* osr);

  int SegmentPage(const STRING* input_file, BLOCK_LIST* blocks,
                  Tesseract* osd_tess, OSResults* osr);
  void SetupWordScripts(BLOCK_LIST* blocks);
  int AutoPageSeg(PageSegMode pageseg_mode, BLOCK_LIST* blocks,
                  TO_BLOCK_LIST* to_blocks, BLOBNBOX_LIST* diacritic_blobs,
                  Tesseract* osd_tess, OSResults* osr);
  ColumnFinder* SetupPageSegAndDetectOrientation(
      PageSegMode pageseg_mode, BLOCK_LIST* blocks, Tesseract* osd_tess,
      OSResults* osr, TO_BLOCK_LIST* to_blocks, Pix** photo_mask_pix,
      Pix** music_mask_pix);
  // par_control.cpp
  void PrerecAllWordsPar(const GenericVector<WordData>& words);

  //// control.h /////////////////////////////////////////////////////////
  bool ProcessTargetWord(const TBOX& word_box, const TBOX& target_word_box,
                         const char* word_config, int pass);
  




// Sets up the words ready for whichever engine is to be run
  void SetupAllWordsPassN(int pass_n,
                          const TBOX* target_word_box,
                          const char* word_config,
                          PAGE_RES* page_res,
                          GenericVector<WordData>* words);




  void Tesseract::m_SetupAllWordsPassN(int pass_n, PAGE_RES* page_res, GenericVector<WordData>* words);





  // Sets up the single word ready for whichever engine is to be run.
  void SetupWordPassN(int pass_n, WordData* word);
  // Runs word recognition on all the words.



  bool RecogAllWordsPassN(int pass_n, ETEXT_DESC* monitor,
                          PAGE_RES_IT* pr_it,
                          GenericVector<WordData>* words);




  bool m_RecogAllWordsPassN(int pass_n,  PAGE_RES_IT* pr_it,  GenericVector<WordData>* words);





  bool recog_all_words(PAGE_RES* page_res,
                       ETEXT_DESC* monitor,
                       const TBOX* target_word_box,
                       const char* word_config,
                       int dopasses);





  bool Tesseract::m_recog_all_words(PAGE_RES* page_res);









  void rejection_passes(PAGE_RES* page_res,
                        ETEXT_DESC* monitor,
                        const TBOX* target_word_box,
                        const char* word_config);
  void bigram_correction_pass(PAGE_RES *page_res);
  void blamer_pass(PAGE_RES* page_res);
  // Sets script positions and detects smallcaps on all output words.
  void script_pos_pass(PAGE_RES* page_res);
  // Helper to recognize the word using the given (language-specific) tesseract.
  // Returns positive if this recognizer found more new best words than the
  // number kept from best_words.
  int RetryWithLanguage(const WordData& word_data,
                        WordRecognizer recognizer,
                        WERD_RES** in_word,
                        PointerVector<WERD_RES>* best_words);
  // Moves good-looking "noise"/diacritics from the reject list to the main
  // blob list on the current word. Returns true if anything was done, and
  // sets make_next_word_fuzzy if blob(s) were added to the end of the word.
  bool ReassignDiacritics(int pass, PAGE_RES_IT* pr_it,
                          bool* make_next_word_fuzzy);
  // Attempts to put noise/diacritic outlines into the blobs that they overlap.
  // Input: a set of noisy outlines that probably belong to the real_word.
  // Output: outlines that overlapped blobs are set to NULL and put back into
  // the word, either in the blobs or in the reject list.
  void AssignDiacriticsToOverlappingBlobs(
      const GenericVector<C_OUTLINE*>& outlines, int pass, WERD* real_word,
      PAGE_RES_IT* pr_it, GenericVector<bool>* word_wanted,
      GenericVector<bool>* overlapped_any_blob,
      GenericVector<C_BLOB*>* target_blobs);
  // Attempts to assign non-overlapping outlines to their nearest blobs or
  // make new blobs out of them.
  void AssignDiacriticsToNewBlobs(const GenericVector<C_OUTLINE*>& outlines,
                                  int pass, WERD* real_word, PAGE_RES_IT* pr_it,
                                  GenericVector<bool>* word_wanted,
                                  GenericVector<C_BLOB*>* target_blobs);
  // Starting with ok_outlines set to indicate which outlines overlap the blob,
  // chooses the optimal set (approximately) and returns true if any outlines
  // are desired, in which case ok_outlines indicates which ones.
  bool SelectGoodDiacriticOutlines(int pass, float certainty_threshold,
                                   PAGE_RES_IT* pr_it, C_BLOB* blob,
                                   const GenericVector<C_OUTLINE*>& outlines,
                                   int num_outlines,
                                   GenericVector<bool>* ok_outlines);
  // Classifies the given blob plus the outlines flagged by ok_outlines, undoes
  // the inclusion of the outlines, and returns the certainty of the raw choice.
  float ClassifyBlobPlusOutlines(const GenericVector<bool>& ok_outlines,
                                 const GenericVector<C_OUTLINE*>& outlines,
                                 int pass_n, PAGE_RES_IT* pr_it, C_BLOB* blob,
                                 STRING* best_str);
  // Classifies the given blob (part of word_data->word->word) as an individual
  // word, using languages, chopper etc, returning only the certainty of the
  // best raw choice, and undoing all the work done to fake out the word.
  float ClassifyBlobAsWord(int pass_n, PAGE_RES_IT* pr_it, C_BLOB* blob,
                           STRING* best_str, float* c2);
  void classify_word_and_language(int pass_n, PAGE_RES_IT* pr_it,
                                  WordData* word_data);
  void classify_word_pass1(const WordData& word_data,
                           WERD_RES** in_word,
                           PointerVector<WERD_RES>* out_words);
  void recog_pseudo_word(PAGE_RES* page_res,  // blocks to check
                         TBOX &selection_box);

  void fix_rep_char(PAGE_RES_IT* page_res_it);

  ACCEPTABLE_WERD_TYPE acceptable_word_string(const UNICHARSET& char_set,
                                              const char *s,
                                              const char *lengths);
  void match_word_pass_n(int pass_n, WERD_RES *word, ROW *row, BLOCK* block);
  void classify_word_pass2(const WordData& word_data,
                           WERD_RES** in_word,
                           PointerVector<WERD_RES>* out_words);
  void ReportXhtFixResult(bool accept_new_word, float new_x_ht,
                          WERD_RES* word, WERD_RES* new_word);
  bool RunOldFixXht(WERD_RES *word, BLOCK* block, ROW *row);
  bool TrainedXheightFix(WERD_RES *word, BLOCK* block, ROW *row);
  // Runs recognition with the test baseline shift and x-height and returns true
  // if there was an improvement in recognition result.
  bool TestNewNormalization(int original_misfits, float baseline_shift,
                            float new_x_ht, WERD_RES *word, BLOCK* block,
                            ROW *row);
  BOOL8 recog_interactive(PAGE_RES_IT* pr_it);

  // Set fonts of this word.
  void set_word_fonts(WERD_RES *word);
  void font_recognition_pass(PAGE_RES* page_res);
  void dictionary_correction_pass(PAGE_RES* page_res);
  BOOL8 check_debug_pt(WERD_RES *word, int location);

  //// superscript.cpp ////////////////////////////////////////////////////
  bool SubAndSuperscriptFix(WERD_RES *word_res);
  void GetSubAndSuperscriptCandidates(const WERD_RES *word,
                                      int *num_rebuilt_leading,
                                      ScriptPos *leading_pos,
                                      float *leading_certainty,
                                      int *num_rebuilt_trailing,
                                      ScriptPos *trailing_pos,
                                      float *trailing_certainty,
                                      float *avg_certainty,
                                      float *unlikely_threshold);
  WERD_RES *TrySuperscriptSplits(int num_chopped_leading,
                                 float leading_certainty,
                                 ScriptPos leading_pos,
                                 int num_chopped_trailing,
                                 float trailing_certainty,
                                 ScriptPos trailing_pos,
                                 WERD_RES *word,
                                 bool *is_good,
                                 int *retry_leading,
                                 int *retry_trailing);
  bool BelievableSuperscript(bool debug,
                             const WERD_RES &word,
                             float certainty_threshold,
                             int *left_ok,
                             int *right_ok) const;

  //// cube_control.cpp ///////////////////////////////////////////////////
#ifndef NO_CUBE_BUILD
  bool init_cube_objects(bool load_combiner,
                         TessdataManager *tessdata_manager);
  // Iterates through tesseract's results and calls cube on each word,
  // combining the results with the existing tesseract result.
  void run_cube_combiner(PAGE_RES *page_res);
  // Recognizes a single word using (only) cube. Compatible with
  // Tesseract's classify_word_pass1/classify_word_pass2.
  void cube_word_pass1(BLOCK* block, ROW *row, WERD_RES *word);
  // Cube recognizer to recognize a single word as with classify_word_pass1
  // but also returns the cube object in case the combiner is needed.
  CubeObject* cube_recognize_word(BLOCK* block, WERD_RES* word);
  // Combines the cube and tesseract results for a single word, leaving the
  // result in tess_word.
  void cube_combine_word(CubeObject* cube_obj, WERD_RES* cube_word,
                        WERD_RES* tess_word);
  // Call cube on the current word, and write the result to word.
  // Sets up a fake result  and returns false if something goes wrong.
  bool cube_recognize(CubeObject *cube_obj, BLOCK* block, WERD_RES *word);
  void fill_werd_res(const BoxWord& cube_box_word,
                     const char* cube_best_str,
                     WERD_RES* tess_werd_res);
  bool extract_cube_state(CubeObject* cube_obj, int* num_chars,
                          Boxa** char_boxes, CharSamp*** char_samples);
  bool create_cube_box_word(Boxa *char_boxes, int num_chars,
                            TBOX word_box, BoxWord* box_word);
#endif
  //// output.h //////////////////////////////////////////////////////////

  void output_pass(PAGE_RES_IT &page_res_it, const TBOX *target_word_box);
  void write_results(PAGE_RES_IT &page_res_it,  // full info
                     char newline_type,         // type of newline
                     BOOL8 force_eol            // override tilde crunch?
                    );
  void set_unlv_suspects(WERD_RES *word);
  UNICHAR_ID get_rep_char(WERD_RES *word);  // what char is repeated?
  BOOL8 acceptable_number_string(const char *s,
                                 const char *lengths);
  inT16 count_alphanums(const WERD_CHOICE &word);
  inT16 count_alphas(const WERD_CHOICE &word);
  //// tessedit.h ////////////////////////////////////////////////////////
  void read_config_file(const char *filename, SetParamConstraint constraint);
  


// Initialize for potentially a set of languages defined by the language
  // string and recursively any additional languages required by any language
  // traineddata file (via tessedit_load_sublangs in its config) that is loaded.
  // See init_tesseract_internal for args.
  

int m_init_tesseract(const char *arg0,
                      
                     const char *language,
                     OcrEngineMode oem,
                      
                     const GenericVector<STRING> *vars_vec,
                     const GenericVector<STRING> *vars_values );





  int Tesseract::init_tesseract(
      const char *arg0, const char *textbase, const char *language,
      OcrEngineMode oem, char **configs, int configs_size,
      const GenericVector<STRING> *vars_vec,
      const GenericVector<STRING> *vars_values,
      bool set_only_non_debug_params); 








  int init_tesseract(const char *datapath,
                     const char *language,
                     OcrEngineMode oem) {
    return init_tesseract(datapath, NULL, language, oem,
                          NULL, 0, NULL, NULL, false);
  }
  // Common initialization for a single language.
  // arg0 is the datapath for the tessdata directory, which could be the
  // path of the tessdata directory with no trailing /, or (if tessdata
  // lives in the same directory as the executable, the path of the executable,
  // hence the name arg0.
  // textbase is an optional output file basename (used only for training)
  // language is the language code to load.
  // oem controls which engine(s) will operate on the image
  // configs (argv) is an array of config filenames to load variables from.
  // May be NULL.
  // configs_size (argc) is the number of elements in configs.
  // vars_vec is an optional vector of variables to set.
  // vars_values is an optional corresponding vector of values for the variables
  // in vars_vec.
  // If set_only_init_params is true, then only the initialization variables
  // will be set.
  int init_tesseract_internal(const char *arg0,
                              const char *textbase,
                              const char *language,
                              OcrEngineMode oem,
                              char **configs,
                              int configs_size,
                              const GenericVector<STRING> *vars_vec,
                              const GenericVector<STRING> *vars_values,
                              bool set_only_init_params);














  // Set the universal_id member of each font to be unique among all
  // instances of the same font loaded.
  void SetupUniversalFontIds();

  int init_tesseract_lm(const char *arg0,
                        const char *textbase,
                        const char *language);

  void recognize_page(STRING& image_name);
  void end_tesseract();

  bool init_tesseract_lang_data(const char *arg0,
                                const char *textbase,
                                const char *language,
                                OcrEngineMode oem,
                                char **configs,
                                int configs_size,
                                const GenericVector<STRING> *vars_vec,
                                const GenericVector<STRING> *vars_values,
                                bool set_only_init_params);



 // bool Tesseract::m_init_tesseract_lang_data( const char *arg0, const char *language,  OcrEngineMode oem,   const GenericVector<STRING> *vars_vec,  const GenericVector<STRING> *vars_values);






// int Tesseract::m_init_tesseract_internal(const char *arg0, const char *language, OcrEngineMode oem, const GenericVector<STRING> *vars_vec, const GenericVector<STRING> *vars_values);

int Tesseract::m_init_tesseract_internal(   const char *arg0,   const char *language,  OcrEngineMode oem,   const GenericVector<STRING> *vars_vec, const GenericVector<STRING> *vars_values)
{

if (!m_init_tesseract_lang_data(arg0, language, oem,  vars_vec, vars_values ) )    return -1;
    
     
// If only Cube will be used, skip loading Tesseract classifier's  pre-trained templates.

    bool init_tesseract_classifier =   (tessedit_ocr_engine_mode == OEM_TESSERACT_ONLY ||  tessedit_ocr_engine_mode == OEM_TESSERACT_CUBE_COMBINED);




// If only Cube will be used and if it has its own Unicharset, skip initializing permuter and loading Tesseract Dawgs.

    bool init_dict =  !(tessedit_ocr_engine_mode == OEM_CUBE_ONLY && tessdata_manager.SeekToStart(TESSDATA_CUBE_UNICHARSET));

alert("init_tesseract_classifier=%d, init_dict=%d",  init_tesseract_classifier, init_dict); 

program_editup(0, init_tesseract_classifier, init_dict);


 
tessdata_manager.End();


return 0;                      //Normal exit
}




bool Tesseract::m_init_tesseract_lang_data(const char *arg0, const char *language, OcrEngineMode oem, const GenericVector<STRING> *vars_vec, const GenericVector<STRING> *vars_values)
{
    // Set the basename, compute the data directory.
    main_setup(arg0, 0);



    // Set the language data path prefix
    lang = language != NULL ? language : "eng";
    language_data_path_prefix = datadir;
    language_data_path_prefix += lang;
    language_data_path_prefix += ".";




    // Initialize TessdataManager.
    STRING tessdata_path = language_data_path_prefix + kTrainedDataSuffix;


   // qTrace("tessdata_path=%s", tessdata_path.c_str());

    //qTrace("tessdata_manager.Init:%s",tessdata_path.string());

    if (!tessdata_manager.Init(tessdata_path.string(), tessdata_manager_debug_level))   return false;



    // If a language specific config file (lang.config) exists, load it in.

   if (tessdata_manager.SeekToStart(TESSDATA_LANG_CONFIG)) {

        ParamUtils::ReadParamsFromFp(tessdata_manager.GetDataFilePtr(), tessdata_manager.GetEndOffset(TESSDATA_LANG_CONFIG),  // 
            SET_PARAM_CONSTRAINT_NONE, this->params());



 

    }

 


    SetParamConstraint set_params_constraint = false ?
        SET_PARAM_CONSTRAINT_NON_DEBUG_ONLY : SET_PARAM_CONSTRAINT_NONE;

    // Load tesseract variables from config files. This is done after loading
      // language-specific variables from [lang].traineddata file, so that custom
      // config files can override values in [lang].traineddata file.
   

    // Set params specified in vars_vec (done after setting params from config
    // files, so that params in vars_vec can override those from files).
    if (vars_vec != NULL && vars_values != NULL) {
        for (int i = 0; i < vars_vec->size(); ++i) {
            if (!ParamUtils::SetParam((*vars_vec)[i].string(),
                (*vars_values)[i].string(),
                set_params_constraint, this->params())) {
                tprintf("Error setting param %s\n", (*vars_vec)[i].string());
                exit(1);
            }
        }
    }




    if (((STRING &)tessedit_write_params_to_file).length() > 0) {
        qTrace(tessedit_write_params_to_file.string());
        FILE *params_file = fopen(tessedit_write_params_to_file.string(), "wb");
        if (params_file != NULL) {
            ParamUtils::PrintParams(params_file, this->params());
            fclose(params_file);
            if (tessdata_manager_debug_level > 0) {
                tprintf("Wrote parameters to %s\n",
                    tessedit_write_params_to_file.string());
            }
        }
        else {
            tprintf("Failed to open %s for writing params.\n",
                tessedit_write_params_to_file.string());
        }
    }




    // Determine which ocr engine(s) should be loaded and used for recognition.
    
//if (oem != OEM_DEFAULT) tessedit_ocr_engine_mode.set_value(oem);
    if (oem != OEM_DEFAULT) tessedit_ocr_engine_mode=oem;


    if (tessdata_manager_debug_level) {
        tprintf("Loading Tesseract/Cube with tessedit_ocr_engine_mode %d\n",
            static_cast<int>(tessedit_ocr_engine_mode));
    }

    // If we are only loading the config file (and so not planning on doing any
    // recognition) then there's nothing else do here.
    if (tessedit_init_config_only) {
        if (tessdata_manager_debug_level) {
            tprintf("Returning after loading config file\n");
        }
        return true;
    }




    // Load the unicharset
   //\\ if (!tessdata_manager.SeekToStart(TESSDATA_UNICHARSET) ||   !unicharset.load_from_file(tessdata_manager.GetDataFilePtr())) {return false;}

    if (!unicharset.load_from_file(tessdata_manager.GetDataFilePtr())) { qTrace("load_from_file failed"); return false; }

    if (!tessdata_manager.SeekToStart(TESSDATA_UNICHARSET)) { qTrace("No Data!"); return false; }


    return true;
}







  void ParseLanguageString(const char* lang_str,
                           GenericVector<STRING>* to_load,
                           GenericVector<STRING>* not_to_load);

  //// pgedit.h //////////////////////////////////////////////////////////
  SVMenuNode *build_menu_new();
  #ifndef GRAPHICS_DISABLED
  void pgeditor_main(int width, int height, PAGE_RES* page_res);
  #endif  // GRAPHICS_DISABLED
  void process_image_event( // action in image win
                           const SVEvent &event);
  BOOL8 process_cmd_win_event(                 // UI command semantics
                              inT32 cmd_event,  // which menu item?
                              char *new_value   // any prompt data
                             );
  void debug_word(PAGE_RES* page_res, const TBOX &selection_box);
  void do_re_display(
      BOOL8 (tesseract::Tesseract::*word_painter)(PAGE_RES_IT* pr_it));
  BOOL8 word_display(PAGE_RES_IT* pr_it);
  BOOL8 word_bln_display(PAGE_RES_IT* pr_it);
  BOOL8 word_blank_and_set_display(PAGE_RES_IT* pr_its);
  BOOL8 word_set_display(PAGE_RES_IT* pr_it);
  // #ifndef GRAPHICS_DISABLED
  BOOL8 word_dumper(PAGE_RES_IT* pr_it);
  // #endif  // GRAPHICS_DISABLED
  void blob_feature_display(PAGE_RES* page_res, const TBOX& selection_box);
  //// reject.h //////////////////////////////////////////////////////////
  // make rej map for word
  void make_reject_map(WERD_RES *word, ROW *row, inT16 pass);
  BOOL8 one_ell_conflict(WERD_RES *word_res, BOOL8 update_map);
  inT16 first_alphanum_index(const char *word,
                             const char *word_lengths);
  inT16 first_alphanum_offset(const char *word,
                              const char *word_lengths);
  inT16 alpha_count(const char *word,
                    const char *word_lengths);
  BOOL8 word_contains_non_1_digit(const char *word,
                                  const char *word_lengths);
  void dont_allow_1Il(WERD_RES *word);
  inT16 count_alphanums(  //how many alphanums
                        WERD_RES *word);
  void flip_0O(WERD_RES *word);
  BOOL8 non_0_digit(const UNICHARSET& ch_set, UNICHAR_ID unichar_id);
  BOOL8 non_O_upper(const UNICHARSET& ch_set, UNICHAR_ID unichar_id);
  BOOL8 repeated_nonalphanum_wd(WERD_RES *word, ROW *row);
  void nn_match_word(  //Match a word
                     WERD_RES *word,
                     ROW *row);
  void nn_recover_rejects(WERD_RES *word, ROW *row);
  void set_done(  //set done flag
                WERD_RES *word,
                inT16 pass);
  inT16 safe_dict_word(const WERD_RES *werd_res);  // is best_choice in dict?
  void flip_hyphens(WERD_RES *word);
  void reject_I_1_L(WERD_RES *word);
  void reject_edge_blobs(WERD_RES *word);
  void reject_mostly_rejects(WERD_RES *word);
  //// adaptions.h ///////////////////////////////////////////////////////
  BOOL8 word_adaptable(  //should we adapt?
                       WERD_RES *word,
                       uinT16 mode);

  //// tfacepp.cpp ///////////////////////////////////////////////////////
  void recog_word_recursive(WERD_RES* word);
  void recog_word(WERD_RES *word);
  void split_and_recog_word(WERD_RES* word);
  void split_word(WERD_RES *word,
                  int split_pt,
                  WERD_RES **right_piece,
                  BlamerBundle **orig_blamer_bundle) const;
  void join_words(WERD_RES *word,
                  WERD_RES *word2,
                  BlamerBundle *orig_bb) const;
  //// fixspace.cpp ///////////////////////////////////////////////////////
  BOOL8 digit_or_numeric_punct(WERD_RES *word, int char_position);
  inT16 eval_word_spacing(WERD_RES_LIST &word_res_list);
  void match_current_words(WERD_RES_LIST &words, ROW *row, BLOCK* block);
  inT16 fp_eval_word_spacing(WERD_RES_LIST &word_res_list);
  void fix_noisy_space_list(WERD_RES_LIST &best_perm, ROW *row, BLOCK* block);
  void fix_fuzzy_space_list(WERD_RES_LIST &best_perm, ROW *row, BLOCK* block);
  void fix_sp_fp_word(WERD_RES_IT &word_res_it, ROW *row, BLOCK* block);
  void fix_fuzzy_spaces(                      //find fuzzy words
                        ETEXT_DESC *monitor,  //progress monitor
                        inT32 word_count,     //count of words in doc
                        PAGE_RES *page_res);
  void dump_words(WERD_RES_LIST &perm, inT16 score,
                  inT16 mode, BOOL8 improved);
  BOOL8 fixspace_thinks_word_done(WERD_RES *word);
  inT16 worst_noise_blob(WERD_RES *word_res, float *worst_noise_score);
  float blob_noise_score(TBLOB *blob);
  void break_noisiest_blob_word(WERD_RES_LIST &words);
  //// docqual.cpp ////////////////////////////////////////////////////////
  GARBAGE_LEVEL garbage_word(WERD_RES *word, BOOL8 ok_dict_word);
  BOOL8 potential_word_crunch(WERD_RES *word,
                              GARBAGE_LEVEL garbage_level,
                              BOOL8 ok_dict_word);
  void tilde_crunch(PAGE_RES_IT &page_res_it);
  void unrej_good_quality_words(  //unreject potential
                                PAGE_RES_IT &page_res_it);
  void doc_and_block_rejection(  //reject big chunks
                               PAGE_RES_IT &page_res_it,
                               BOOL8 good_quality_doc);
  void quality_based_rejection(PAGE_RES_IT &page_res_it,
                               BOOL8 good_quality_doc);
  void convert_bad_unlv_chs(WERD_RES *word_res);
  void tilde_delete(PAGE_RES_IT &page_res_it);
  inT16 word_blob_quality(WERD_RES *word, ROW *row);
  void word_char_quality(WERD_RES *word, ROW *row, inT16 *match_count,
                         inT16 *accepted_match_count);
  void unrej_good_chs(WERD_RES *word, ROW *row);
  inT16 count_outline_errs(char c, inT16 outline_count);
  inT16 word_outline_errs(WERD_RES *word);
  BOOL8 terrible_word_crunch(WERD_RES *word, GARBAGE_LEVEL garbage_level);
  CRUNCH_MODE word_deletable(WERD_RES *word, inT16 &delete_mode);
  inT16 failure_count(WERD_RES *word);
  BOOL8 noise_outlines(TWERD *word);
  //// pagewalk.cpp ///////////////////////////////////////////////////////
  void
  process_selected_words (
      PAGE_RES* page_res, // blocks to check
      //function to call
      TBOX & selection_box,
      BOOL8 (tesseract::Tesseract::*word_processor)(PAGE_RES_IT* pr_it));
  //// tessbox.cpp ///////////////////////////////////////////////////////
  void tess_add_doc_word(                          //test acceptability
                         WERD_CHOICE *word_choice  //after context
                        );
  void tess_segment_pass_n(int pass_n, WERD_RES *word);
  bool tess_acceptable_word(WERD_RES *word);

  //// applybox.cpp //////////////////////////////////////////////////////
  // Applies the box file based on the image name fname, and resegments
  // the words in the block_list (page), with:
  // blob-mode: one blob per line in the box file, words as input.
  // word/line-mode: one blob per space-delimited unit after the #, and one word
  // per line in the box file. (See comment above for box file format.)
  // If find_segmentation is true, (word/line mode) then the classifier is used
  // to re-segment words/lines to match the space-delimited truth string for
  // each box. In this case, the input box may be for a word or even a whole
  // text line, and the output words will contain multiple blobs corresponding
  // to the space-delimited input string.
  // With find_segmentation false, no classifier is needed, but the chopper
  // can still be used to correctly segment touching characters with the help
  // of the input boxes.
  // In the returned PAGE_RES, the WERD_RES are setup as they would be returned
  // from normal classification, ie. with a word, chopped_word, rebuild_word,
  // seam_array, denorm, box_word, and best_state, but NO best_choice or
  // raw_choice, as they would require a UNICHARSET, which we aim to avoid.
  // Instead, the correct_text member of WERD_RES is set, and this may be later
  // converted to a best_choice using CorrectClassifyWords. CorrectClassifyWords
  // is not required before calling ApplyBoxTraining.
  PAGE_RES* ApplyBoxes(const STRING& fname, bool find_segmentation,
                       BLOCK_LIST *block_list);

  // Any row xheight that is significantly different from the median is set
  // to the median.
  void PreenXHeights(BLOCK_LIST *block_list);

  // Builds a PAGE_RES from the block_list in the way required for ApplyBoxes:
  // All fuzzy spaces are removed, and all the words are maximally chopped.
  PAGE_RES* SetupApplyBoxes(const GenericVector<TBOX>& boxes,
                            BLOCK_LIST *block_list);
  // Tests the chopper by exhaustively running chop_one_blob.
  // The word_res will contain filled chopped_word, seam_array, denorm,
  // box_word and best_state for the maximally chopped word.
  void MaximallyChopWord(const GenericVector<TBOX>& boxes,
                         BLOCK* block, ROW* row, WERD_RES* word_res);
  // Gather consecutive blobs that match the given box into the best_state
  // and corresponding correct_text.
  // Fights over which box owns which blobs are settled by pre-chopping and
  // applying the blobs to box or next_box with the least non-overlap.
  // Returns false if the box was in error, which can only be caused by
  // failing to find an appropriate blob for a box.
  // This means that occasionally, blobs may be incorrectly segmented if the
  // chopper fails to find a suitable chop point.
  bool ResegmentCharBox(PAGE_RES* page_res, const TBOX *prev_box,
                        const TBOX& box, const TBOX& next_box,
                        const char* correct_text);
  // Consume all source blobs that strongly overlap the given box,
  // putting them into a new word, with the correct_text label.
  // Fights over which box owns which blobs are settled by
  // applying the blobs to box or next_box with the least non-overlap.
  // Returns false if the box was in error, which can only be caused by
  // failing to find an overlapping blob for a box.
  bool ResegmentWordBox(BLOCK_LIST *block_list,
                        const TBOX& box, const TBOX& next_box,
                        const char* correct_text);
  // Resegments the words by running the classifier in an attempt to find the
  // correct segmentation that produces the required string.
  void ReSegmentByClassification(PAGE_RES* page_res);
  // Converts the space-delimited string of utf8 text to a vector of UNICHAR_ID.
  // Returns false if an invalid UNICHAR_ID is encountered.
  bool ConvertStringToUnichars(const char* utf8,
                               GenericVector<UNICHAR_ID>* class_ids);
  // Resegments the word to achieve the target_text from the classifier.
  // Returns false if the re-segmentation fails.
  // Uses brute-force combination of up to kMaxGroupSize adjacent blobs, and
  // applies a full search on the classifier results to find the best classified
  // segmentation. As a compromise to obtain better recall, 1-1 ambigiguity
  // substitutions ARE used.
  bool FindSegmentation(const GenericVector<UNICHAR_ID>& target_text,
                        WERD_RES* word_res);
  // Recursive helper to find a match to the target_text (from text_index
  // position) in the choices (from choices_pos position).
  // Choices is an array of GenericVectors, of length choices_length, with each
  // element representing a starting position in the word, and the
  // GenericVector holding classification results for a sequence of consecutive
  // blobs, with index 0 being a single blob, index 1 being 2 blobs etc.
  void SearchForText(const GenericVector<BLOB_CHOICE_LIST*>* choices,
                     int choices_pos, int choices_length,
                     const GenericVector<UNICHAR_ID>& target_text,
                     int text_index,
                     float rating, GenericVector<int>* segmentation,
                     float* best_rating, GenericVector<int>* best_segmentation);
  // Counts up the labelled words and the blobs within.
  // Deletes all unused or emptied words, counting the unused ones.
  // Resets W_BOL and W_EOL flags correctly.
  // Builds the rebuild_word and rebuilds the box_word.
  void TidyUp(PAGE_RES* page_res);
  // Logs a bad box by line in the box file and box coords.
  void ReportFailedBox(int boxfile_lineno, TBOX box, const char *box_ch,
                       const char *err_msg);
  // Creates a fake best_choice entry in each WERD_RES with the correct text.
  void CorrectClassifyWords(PAGE_RES* page_res);
  // Call LearnWord to extract features for labelled blobs within each word.
  // Features are stored in an internal buffer.
  void ApplyBoxTraining(const STRING& fontname, PAGE_RES* page_res);

  //// fixxht.cpp ///////////////////////////////////////////////////////
  // Returns the number of misfit blob tops in this word.
  int CountMisfitTops(WERD_RES *word_res);
  // Returns a new x-height in pixels (original image coords) that is
  // maximally compatible with the result in word_res.
  // Returns 0.0f if no x-height is found that is better than the current
  // estimate.
  float ComputeCompatibleXheight(WERD_RES *word_res, float* baseline_shift);
  //// Data members ///////////////////////////////////////////////////////
  // TODO(ocr-team): Find and remove obsolete parameters.
  BOOL_VAR_H(tessedit_resegment_from_boxes, false,
             "Take segmentation and labeling from box file");
  BOOL_VAR_H(tessedit_resegment_from_line_boxes, false,
              "Conversion of word/line box file to char box file");
  BOOL_VAR_H(tessedit_train_from_boxes, false,
             "Generate training data from boxed chars");
  BOOL_VAR_H(tessedit_make_boxes_from_boxes, false,
             "Generate more boxes from boxed chars");
  BOOL_VAR_H(tessedit_dump_pageseg_images, false,
             "Dump intermediate images made during page segmentation");
  INT_VAR_H(tessedit_pageseg_mode, PSM_SINGLE_BLOCK,
            "Page seg mode: 0=osd only, 1=auto+osd, 2=auto, 3=col, 4=block,"
            " 5=line, 6=word, 7=char"
            " (Values from PageSegMode enum in publictypes.h)");
  


// INT_VAR_H(tessedit_ocr_engine_mode, tesseract::OEM_TESSERACT_ONLY,  \
            "Which OCR engine(s) to run (Tesseract, Cube, both). Defaults"  \
            " to loading and running only Tesseract (no Cube, no combiner)."  \
            " (Values from OcrEngineMode enum in tesseractclass.h)");

int  tessedit_ocr_engine_mode   = tesseract::OEM_TESSERACT_ONLY;


  STRING_VAR_H(tessedit_char_blacklist, "",
               "Blacklist of chars not to recognize");
  STRING_VAR_H(tessedit_char_whitelist, "",
               "Whitelist of chars to recognize");
  STRING_VAR_H(tessedit_char_unblacklist, "",
               "List of chars to override tessedit_char_blacklist");
  BOOL_VAR_H(tessedit_ambigs_training, false,
             "Perform training for ambiguities");
  INT_VAR_H(pageseg_devanagari_split_strategy,
            tesseract::ShiroRekhaSplitter::NO_SPLIT,
            "Whether to use the top-line splitting process for Devanagari "
            "documents while performing page-segmentation.");
  INT_VAR_H(ocr_devanagari_split_strategy,
            tesseract::ShiroRekhaSplitter::NO_SPLIT,
            "Whether to use the top-line splitting process for Devanagari "
            "documents while performing ocr.");
  STRING_VAR_H(tessedit_write_params_to_file, "",
               "Write all parameters to the given file.");
  BOOL_VAR_H(tessedit_adaption_debug, false,
             "Generate and print debug information for adaption");
  INT_VAR_H(bidi_debug, 0, "Debug level for BiDi");
  INT_VAR_H(applybox_debug, 1, "Debug level");
  INT_VAR_H(applybox_page, 0, "Page number to apply boxes from");
  STRING_VAR_H(applybox_exposure_pattern, ".exp",
               "Exposure value follows this pattern in the image"
               " filename. The name of the image files are expected"
               " to be in the form [lang].[fontname].exp[num].tif");
  BOOL_VAR_H(applybox_learn_chars_and_char_frags_mode, false,
             "Learn both character fragments (as is done in the"
             " special low exposure mode) as well as unfragmented"
             " characters.");
  BOOL_VAR_H(applybox_learn_ngrams_mode, false,
             "Each bounding box is assumed to contain ngrams. Only"
             " learn the ngrams whose outlines overlap horizontally.");
  BOOL_VAR_H(tessedit_display_outwords, false, "Draw output words");
  BOOL_VAR_H(tessedit_dump_choices, false, "Dump char choices");
  BOOL_VAR_H(tessedit_timing_debug, false, "Print timing stats");
  BOOL_VAR_H(tessedit_fix_fuzzy_spaces, true,
             "Try to improve fuzzy spaces");
  BOOL_VAR_H(tessedit_unrej_any_wd, false,
             "Don't bother with word plausibility");
  BOOL_VAR_H(tessedit_fix_hyphens, true, "Crunch double hyphens?");
  BOOL_VAR_H(tessedit_redo_xheight, true, "Check/Correct x-height");
  BOOL_VAR_H(tessedit_enable_doc_dict, true,
             "Add words to the document dictionary");
  BOOL_VAR_H(tessedit_debug_fonts, false, "Output font info per char");
  BOOL_VAR_H(tessedit_debug_block_rejection, false, "Block and Row stats");
  BOOL_VAR_H(tessedit_enable_bigram_correction, true,
             "Enable correction based on the word bigram dictionary.");
  BOOL_VAR_H(tessedit_enable_dict_correction, false,
             "Enable single word correction based on the dictionary.");
  INT_VAR_H(tessedit_bigram_debug, 0, "Amount of debug output for bigram "
            "correction.");
  BOOL_VAR_H(enable_noise_removal, true,
             "Remove and conditionally reassign small outlines when they"
             " confuse layout analysis, determining diacritics vs noise");
  INT_VAR_H(debug_noise_removal, 0, "Debug reassignment of small outlines");
  // Worst (min) certainty, for which a diacritic is allowed to make the base
  // character worse and still be included.
  double_VAR_H(noise_cert_basechar, -8.0, "Hingepoint for base char certainty");
  // Worst (min) certainty, for which a non-overlapping diacritic is allowed to
  // make the base character worse and still be included.
  double_VAR_H(noise_cert_disjoint, -2.5, "Hingepoint for disjoint certainty");
  // Worst (min) certainty, for which a diacritic is allowed to make a new
  // stand-alone blob.
  double_VAR_H(noise_cert_punc, -2.5, "Threshold for new punc char certainty");
  // Factor of certainty margin for adding diacritics to not count as worse.
  double_VAR_H(noise_cert_factor, 0.375,
               "Scaling on certainty diff from Hingepoint");
  INT_VAR_H(noise_maxperblob, 8, "Max diacritics to apply to a blob");
  INT_VAR_H(noise_maxperword, 16, "Max diacritics to apply to a word");
  INT_VAR_H(debug_x_ht_level, 0, "Reestimate debug");
  BOOL_VAR_H(debug_acceptable_wds, false, "Dump word pass/fail chk");
  STRING_VAR_H(chs_leading_punct, "('`\"", "Leading punctuation");
  STRING_VAR_H(chs_trailing_punct1, ").,;:?!", "1st Trailing punctuation");
  STRING_VAR_H(chs_trailing_punct2, ")'`\"", "2nd Trailing punctuation");
  double_VAR_H(quality_rej_pc, 0.08, "good_quality_doc lte rejection limit");
  double_VAR_H(quality_blob_pc, 0.0, "good_quality_doc gte good blobs limit");
  double_VAR_H(quality_outline_pc, 1.0,
               "good_quality_doc lte outline error limit");
  double_VAR_H(quality_char_pc, 0.95, "good_quality_doc gte good char limit");
  INT_VAR_H(quality_min_initial_alphas_reqd, 2, "alphas in a good word");
  INT_VAR_H(tessedit_tess_adaption_mode, 0x27,
            "Adaptation decision algorithm for tess");
  BOOL_VAR_H(tessedit_minimal_rej_pass1, false,
             "Do minimal rejection on pass 1 output");
  BOOL_VAR_H(tessedit_test_adaption, false, "Test adaption criteria");
  BOOL_VAR_H(tessedit_matcher_log, false, "Log matcher activity");
  INT_VAR_H(tessedit_test_adaption_mode, 3,
            "Adaptation decision algorithm for tess");
  BOOL_VAR_H(test_pt, false, "Test for point");
  double_VAR_H(test_pt_x, 99999.99, "xcoord");
  double_VAR_H(test_pt_y, 99999.99, "ycoord");
  INT_VAR_H(paragraph_debug_level, 0, "Print paragraph debug info.");
  BOOL_VAR_H(paragraph_text_based, true,
             "Run paragraph detection on the post-text-recognition "
             "(more accurate)");
  INT_VAR_H(cube_debug_level, 1, "Print cube debug info.");
  STRING_VAR_H(outlines_odd, "%| ", "Non standard number of outlines");
  STRING_VAR_H(outlines_2, "ij!?%\":;", "Non standard number of outlines");
  BOOL_VAR_H(docqual_excuse_outline_errs, false,
             "Allow outline errs in unrejection?");
  BOOL_VAR_H(tessedit_good_quality_unrej, true,
             "Reduce rejection on good docs");
  BOOL_VAR_H(tessedit_use_reject_spaces, true, "Reject spaces?");
  double_VAR_H(tessedit_reject_doc_percent, 65.00,
               "%rej allowed before rej whole doc");
  double_VAR_H(tessedit_reject_block_percent, 45.00,
               "%rej allowed before rej whole block");
  double_VAR_H(tessedit_reject_row_percent, 40.00,
               "%rej allowed before rej whole row");
  double_VAR_H(tessedit_whole_wd_rej_row_percent, 70.00,
               "Number of row rejects in whole word rejects"
               "which prevents whole row rejection");
  BOOL_VAR_H(tessedit_preserve_blk_rej_perfect_wds, true,
             "Only rej partially rejected words in block rejection");
  BOOL_VAR_H(tessedit_preserve_row_rej_perfect_wds, true,
             "Only rej partially rejected words in row rejection");
  BOOL_VAR_H(tessedit_dont_blkrej_good_wds, false,
             "Use word segmentation quality metric");
  BOOL_VAR_H(tessedit_dont_rowrej_good_wds, false,
             "Use word segmentation quality metric");
  INT_VAR_H(tessedit_preserve_min_wd_len, 2,
            "Only preserve wds longer than this");
  BOOL_VAR_H(tessedit_row_rej_good_docs, true,
             "Apply row rejection to good docs");
  double_VAR_H(tessedit_good_doc_still_rowrej_wd, 1.1,
               "rej good doc wd if more than this fraction rejected");
  BOOL_VAR_H(tessedit_reject_bad_qual_wds, true,
             "Reject all bad quality wds");
  BOOL_VAR_H(tessedit_debug_doc_rejection, false, "Page stats");
  BOOL_VAR_H(tessedit_debug_quality_metrics, false,
             "Output data to debug file");
  BOOL_VAR_H(bland_unrej, false, "unrej potential with no chekcs");
  double_VAR_H(quality_rowrej_pc, 1.1,
               "good_quality_doc gte good char limit");
  BOOL_VAR_H(unlv_tilde_crunching, true,
             "Mark v.bad words for tilde crunch");
  BOOL_VAR_H(hocr_font_info, false,
             "Add font info to hocr output");
  BOOL_VAR_H(crunch_early_merge_tess_fails, true, "Before word crunch?");
  BOOL_VAR_H(crunch_early_convert_bad_unlv_chs, false, "Take out ~^ early?");
  double_VAR_H(crunch_terrible_rating, 80.0, "crunch rating lt this");
  BOOL_VAR_H(crunch_terrible_garbage, true, "As it says");
  double_VAR_H(crunch_poor_garbage_cert, -9.0,
               "crunch garbage cert lt this");
  double_VAR_H(crunch_poor_garbage_rate, 60, "crunch garbage rating lt this");
  double_VAR_H(crunch_pot_poor_rate, 40, "POTENTIAL crunch rating lt this");
  double_VAR_H(crunch_pot_poor_cert, -8.0, "POTENTIAL crunch cert lt this");
  BOOL_VAR_H(crunch_pot_garbage, true, "POTENTIAL crunch garbage");
  double_VAR_H(crunch_del_rating, 60, "POTENTIAL crunch rating lt this");
  double_VAR_H(crunch_del_cert, -10.0, "POTENTIAL crunch cert lt this");
  double_VAR_H(crunch_del_min_ht, 0.7, "Del if word ht lt xht x this");
  double_VAR_H(crunch_del_max_ht, 3.0, "Del if word ht gt xht x this");
  double_VAR_H(crunch_del_min_width, 3.0, "Del if word width lt xht x this");
  double_VAR_H(crunch_del_high_word, 1.5,
               "Del if word gt xht x this above bl");
  double_VAR_H(crunch_del_low_word, 0.5, "Del if word gt xht x this below bl");
  double_VAR_H(crunch_small_outlines_size, 0.6, "Small if lt xht x this");
  INT_VAR_H(crunch_rating_max, 10, "For adj length in rating per ch");
  INT_VAR_H(crunch_pot_indicators, 1, "How many potential indicators needed");
  BOOL_VAR_H(crunch_leave_ok_strings, true, "Don't touch sensible strings");
  BOOL_VAR_H(crunch_accept_ok, true, "Use acceptability in okstring");
  BOOL_VAR_H(crunch_leave_accept_strings, false,
             "Don't pot crunch sensible strings");
  BOOL_VAR_H(crunch_include_numerals, false, "Fiddle alpha figures");
  INT_VAR_H(crunch_leave_lc_strings, 4,
            "Don't crunch words with long lower case strings");
  INT_VAR_H(crunch_leave_uc_strings, 4,
            "Don't crunch words with long lower case strings");
  INT_VAR_H(crunch_long_repetitions, 3, "Crunch words with long repetitions");
  INT_VAR_H(crunch_debug, 0, "As it says");
  INT_VAR_H(fixsp_non_noise_limit, 1,
            "How many non-noise blbs either side?");
  double_VAR_H(fixsp_small_outlines_size, 0.28, "Small if lt xht x this");
  BOOL_VAR_H(tessedit_prefer_joined_punct, false, "Reward punctation joins");
  INT_VAR_H(fixsp_done_mode, 1, "What constitues done for spacing");
  INT_VAR_H(debug_fix_space_level, 0, "Contextual fixspace debug");
  STRING_VAR_H(numeric_punctuation, ".,",
               "Punct. chs expected WITHIN numbers");
  INT_VAR_H(x_ht_acceptance_tolerance, 8,
            "Max allowed deviation of blob top outside of font data");
  INT_VAR_H(x_ht_min_change, 8, "Min change in xht before actually trying it");
  INT_VAR_H(superscript_debug, 0, "Debug level for sub & superscript fixer");
  double_VAR_H(superscript_worse_certainty, 2.0, "How many times worse "
               "certainty does a superscript position glyph need to be for us "
               "to try classifying it as a char with a different baseline?");
  double_VAR_H(superscript_bettered_certainty, 0.97, "What reduction in "
               "badness do we think sufficient to choose a superscript over "
               "what we'd thought.  For example, a value of 0.6 means we want "
               "to reduce badness of certainty by 40%");
  double_VAR_H(superscript_scaledown_ratio, 0.4,
               "A superscript scaled down more than this is unbelievably "
               "small.  For example, 0.3 means we expect the font size to "
               "be no smaller than 30% of the text line font size.");
  double_VAR_H(subscript_max_y_top, 0.5,
               "Maximum top of a character measured as a multiple of x-height "
               "above the baseline for us to reconsider whether it's a "
               "subscript.");
  double_VAR_H(superscript_min_y_bottom, 0.3,
              "Minimum bottom of a character measured as a multiple of "
              "x-height above the baseline for us to reconsider whether it's "
              "a superscript.");
  BOOL_VAR_H(tessedit_write_block_separators, false,
             "Write block separators in output");
  BOOL_VAR_H(tessedit_write_rep_codes, false,
             "Write repetition char code");
  BOOL_VAR_H(tessedit_write_unlv, false, "Write .unlv output file");
  BOOL_VAR_H(tessedit_create_txt, false, "Write .txt output file");
  BOOL_VAR_H(tessedit_create_hocr, false, "Write .html hOCR output file");
  BOOL_VAR_H(tessedit_create_tsv, false, "Write .tsv output file");
  BOOL_VAR_H(tessedit_create_pdf, false, "Write .pdf output file");
  BOOL_VAR_H(textonly_pdf, false, "Create PDF with only one invisible text layer");
  STRING_VAR_H(unrecognised_char, "|",
               "Output char for unidentified blobs");
  INT_VAR_H(suspect_level, 99, "Suspect marker level");
  INT_VAR_H(suspect_space_level, 100,
            "Min suspect level for rejecting spaces");
  INT_VAR_H(suspect_short_words, 2, "Don't Suspect dict wds longer than this");
  BOOL_VAR_H(suspect_constrain_1Il, false, "UNLV keep 1Il chars rejected");
  double_VAR_H(suspect_rating_per_ch, 999.9, "Don't touch bad rating limit");
  double_VAR_H(suspect_accept_rating, -999.9, "Accept good rating limit");
  BOOL_VAR_H(tessedit_minimal_rejection, false, "Only reject tess failures");
  BOOL_VAR_H(tessedit_zero_rejection, false, "Don't reject ANYTHING");
  BOOL_VAR_H(tessedit_word_for_word, false,
             "Make output have exactly one word per WERD");
  BOOL_VAR_H(tessedit_zero_kelvin_rejection, false,
             "Don't reject ANYTHING AT ALL");
  BOOL_VAR_H(tessedit_consistent_reps, true, "Force all rep chars the same");
  INT_VAR_H(tessedit_reject_mode, 0, "Rejection algorithm");
  BOOL_VAR_H(tessedit_rejection_debug, false, "Adaption debug");
  BOOL_VAR_H(tessedit_flip_0O, true, "Contextual 0O O0 flips");
  double_VAR_H(tessedit_lower_flip_hyphen, 1.5,
               "Aspect ratio dot/hyphen test");
  double_VAR_H(tessedit_upper_flip_hyphen, 1.8,
               "Aspect ratio dot/hyphen test");
  BOOL_VAR_H(rej_trust_doc_dawg, false, "Use DOC dawg in 11l conf. detector");
  BOOL_VAR_H(rej_1Il_use_dict_word, false, "Use dictword test");
  BOOL_VAR_H(rej_1Il_trust_permuter_type, true, "Don't double check");
  BOOL_VAR_H(rej_use_tess_accepted, true, "Individual rejection control");
  BOOL_VAR_H(rej_use_tess_blanks, true, "Individual rejection control");
  BOOL_VAR_H(rej_use_good_perm, true, "Individual rejection control");
  BOOL_VAR_H(rej_use_sensible_wd, false, "Extend permuter check");
  BOOL_VAR_H(rej_alphas_in_number_perm, false, "Extend permuter check");
  double_VAR_H(rej_whole_of_mostly_reject_word_fract, 0.85, "if >this fract");
  INT_VAR_H(tessedit_image_border, 2, "Rej blbs near image edge limit");
  STRING_VAR_H(ok_repeated_ch_non_alphanum_wds, "-?*\075",
               "Allow NN to unrej");
  STRING_VAR_H(conflict_set_I_l_1, "Il1[]", "Il1 conflict set");
  INT_VAR_H(min_sane_x_ht_pixels, 8, "Reject any x-ht lt or eq than this");
  BOOL_VAR_H(tessedit_create_boxfile, false, "Output text with boxes");
  INT_VAR_H(tessedit_page_number, -1,
            "-1 -> All pages, else specifc page to process");
  BOOL_VAR_H(tessedit_write_images, false, "Capture the image from the IPE");
  BOOL_VAR_H(interactive_display_mode, false, "Run interactively?");
  STRING_VAR_H(file_type, ".tif", "Filename extension");
  BOOL_VAR_H(tessedit_override_permuter, true, "According to dict_word");
  INT_VAR_H(tessdata_manager_debug_level, 0,
            "Debug level for TessdataManager functions.");
  STRING_VAR_H(tessedit_load_sublangs, "",
               "List of languages to load with this one");
  BOOL_VAR_H(tessedit_use_primary_params_model, false,
             "In multilingual mode use params model of the primary language");
  // Min acceptable orientation margin (difference in scores between top and 2nd
  // choice in OSResults::orientations) to believe the page orientation.
  double_VAR_H(min_orientation_margin, 7.0,
               "Min acceptable orientation margin");
  BOOL_VAR_H(textord_tabfind_show_vlines, false, "Debug line finding");
  BOOL_VAR_H(textord_use_cjk_fp_model, FALSE, "Use CJK fixed pitch model");
  BOOL_VAR_H(poly_allow_detailed_fx, false,
             "Allow feature extractors to see the original outline");
  BOOL_VAR_H(tessedit_init_config_only, false,
             "Only initialize with the config file. Useful if the instance is "
             "not going to be used for OCR but say only for layout analysis.");
  BOOL_VAR_H(textord_equation_detect, false, "Turn on equation detector");
  BOOL_VAR_H(textord_tabfind_vertical_text, true, "Enable vertical detection");
  BOOL_VAR_H(textord_tabfind_force_vertical_text, false,
             "Force using vertical text page mode");
  double_VAR_H(textord_tabfind_vertical_text_ratio, 0.5,
               "Fraction of textlines deemed vertical to use vertical page "
               "mode");
  double_VAR_H(textord_tabfind_aligned_gap_fraction, 0.75,
               "Fraction of height used as a minimum gap for aligned blobs.");
  INT_VAR_H(tessedit_parallelize, 0, "Run in parallel where possible");
  BOOL_VAR_H(preserve_interword_spaces, false,
             "Preserve multiple interword spaces");
  BOOL_VAR_H(include_page_breaks, false,
             "Include page separator string in output text after each "
             "image/page.");
  STRING_VAR_H(page_separator, "\f",
               "Page separator (default is form feed control character)");

  // The following parameters were deprecated and removed from their original
  // locations. The parameters are temporarily kept here to give Tesseract
  // users a chance to updated their [lang].traineddata and config files
  // without introducing failures during Tesseract initialization.
  // TODO(ocr-team): remove these parameters from the code once we are
  // reasonably sure that Tesseract users have updated their data files.
  //
  // BEGIN DEPRECATED PARAMETERS
  BOOL_VAR_H(textord_tabfind_vertical_horizontal_mix, true,
             "find horizontal lines such as headers in vertical page mode");
  INT_VAR_H(tessedit_ok_mode, 5, "Acceptance decision algorithm");
  BOOL_VAR_H(load_fixed_length_dawgs, true,  "Load fixed length"
             " dawgs (e.g. for non-space delimited languages)");
  INT_VAR_H(segment_debug, 0, "Debug the whole segmentation process");
  BOOL_VAR_H(permute_debug, 0, "char permutation debug");
  double_VAR_H(bestrate_pruning_factor, 2.0, "Multiplying factor of"
               " current best rate to prune other hypotheses");
  BOOL_VAR_H(permute_script_word, 0,
             "Turn on word script consistency permuter");
  BOOL_VAR_H(segment_segcost_rating, 0,
             "incorporate segmentation cost in word rating?");
  double_VAR_H(segment_reward_script, 0.95,
               "Score multipler for script consistency within a word. "
               "Being a 'reward' factor, it should be <= 1. "
               "Smaller value implies bigger reward.");
  BOOL_VAR_H(permute_fixed_length_dawg, 0,
             "Turn on fixed-length phrasebook search permuter");
  BOOL_VAR_H(permute_chartype_word, 0,
             "Turn on character type (property) consistency permuter");
  double_VAR_H(segment_reward_chartype, 0.97,
               "Score multipler for char type consistency within a word. ");
  double_VAR_H(segment_reward_ngram_best_choice, 0.99,
               "Score multipler for ngram permuter's best choice"
               " (only used in the Han script path).");
  BOOL_VAR_H(ngram_permuter_activated, false,
             "Activate character-level n-gram-based permuter");
  BOOL_VAR_H(permute_only_top, false, "Run only the top choice permuter");
  INT_VAR_H(language_model_fixed_length_choices_depth, 3,
            "Depth of blob choice lists to explore"
            " when fixed length dawgs are on");
  BOOL_VAR_H(use_new_state_cost, FALSE,
             "use new state cost heuristics for segmentation state evaluation");
  double_VAR_H(heuristic_segcost_rating_base, 1.25,
               "base factor for adding segmentation cost into word rating."
               "It's a multiplying factor, the larger the value above 1, "
               "the bigger the effect of segmentation cost.");
  double_VAR_H(heuristic_weight_rating, 1,
               "weight associated with char rating in combined cost of state");
  double_VAR_H(heuristic_weight_width, 1000.0,
               "weight associated with width evidence in combined cost of"
               " state");
  double_VAR_H(heuristic_weight_seamcut, 0,
               "weight associated with seam cut in combined cost of state");
  double_VAR_H(heuristic_max_char_wh_ratio, 2.0,
               "max char width-to-height ratio allowed in segmentation");
  BOOL_VAR_H(enable_new_segsearch, false,
             "Enable new segmentation search path.");
  double_VAR_H(segsearch_max_fixed_pitch_char_wh_ratio, 2.0,
               "Maximum character width-to-height ratio for"
               "fixed pitch fonts");
  // END DEPRECATED PARAMETERS

  //// ambigsrecog.cpp /////////////////////////////////////////////////////////
  FILE *init_recog_training(const STRING &fname);
  void recog_training_segmented(const STRING &fname,
                                PAGE_RES *page_res,
                                volatile ETEXT_DESC *monitor,
                                FILE *output_file);
  void ambigs_classify_and_output(const char *label,
                                  PAGE_RES_IT* pr_it,
                                  FILE *output_file);

#ifndef NO_CUBE_BUILD
  inline CubeRecoContext *GetCubeRecoContext() { return cube_cntxt_; }
#endif

 



private:

public:


  // The filename of a backup config file. If not null, then we currently
  // have a temporary debug config file loaded, and backup_config_file_
  // will be loaded, and set to null when debug is complete.
  const char* backup_config_file_;
  // The filename of a config file to read when processing a debug word.
  STRING word_config_;
  // Image used for input to layout analysis and tesseract recognition.
  // May be modified by the ShiroRekhaSplitter to eliminate the top-line.
  Pix* pix_binary_;
  // Unmodified image used for input to cube. Always valid.
  Pix* cube_binary_;
  // Grey-level input image if the input was not binary, otherwise NULL.
  Pix* pix_grey_;
  // Original input image. Color if the input was color.
  Pix* pix_original_;
  // Thresholds that were used to generate the thresholded image from grey.
  Pix* pix_thresholds_;
  // Input image resolution after any scaling. The resolution is not well
  // transmitted by operations on Pix, so we keep an independent record here.
  int source_resolution_;
  // The shiro-rekha splitter object which is used to split top-lines in
  // Devanagari words to provide a better word and grapheme segmentation.
  ShiroRekhaSplitter splitter_;
  // Page segmentation/layout
  Textord textord_;
  // True if the primary language uses right_to_left reading order.
  bool right_to_left_;
  Pix* scaled_color_;
  int scaled_factor_;
  FCOORD deskew_;
  FCOORD reskew_;
  TesseractStats stats_;
  // Sub-languages to be tried in addition to this.
  GenericVector<Tesseract*> sub_langs_;
  // Most recently used Tesseract out of this and sub_langs_. The default
  // language for the next word.
  Tesseract* most_recently_used_;
  // The size of the font table, ie max possible font id + 1.
  int font_table_size_;
#ifndef NO_CUBE_BUILD
  // Cube objects.
  CubeRecoContext* cube_cntxt_;
  TesseractCubeCombiner *tess_cube_combiner_;
#endif
  // Equation detector. Note: this pointer is NOT owned by the class.
  EquationDetect* equ_detect_;
};

}  // namespace tesseract








#endif  // DEBUG_MODE



#endif  // TESSERACT_CCMAIN_TESSERACTCLASS_H__
