





///////////////////////////////////////////////////////////////////////
// File:        ccutil.h
// Description: ccutil class.
// Author:      Samuel Charron
//
// (C) Copyright 2006, Google Inc.
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// http://www.apache.org/licenses/LICENSE-2.0
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
///////////////////////////////////////////////////////////////////////




#ifndef TESSERACT_CCUTIL_CCUTIL_H__
#define TESSERACT_CCUTIL_CCUTIL_H__

#include "ambigs.h"
#include "errcode.h"
#include "strngs.h"
#include "tessdatamanager.h"
#include "params.h"
#include "unicharset.h"

#ifndef _WIN32
#include <pthread.h>
#include <semaphore.h>
#endif




// #include <string>   // m_data_sub_dir  
#include <io.h>    // access 






namespace tesseract {

class CCUtilMutex {
 public:
  CCUtilMutex();

  void Lock();

  void Unlock();
 private:
#ifdef _WIN32
  HANDLE mutex_;
#else
  pthread_mutex_t mutex_;
#endif
};


class TESS_API CCUtil {
 public:
  CCUtil(){};
  virtual ~CCUtil(){};

 public:
  


// Read the arguments and set up the data path.
 // void main_setup( const char *argv0,  const char *basename );      // program name, name of image
                





  void CCUtil::main_setup(const char* argv0, const char* basename) {

      imagebasename = basename;      /**< name of image */


      char* tessdata_prefix = "../../tessdata3.02";  // getenv("TESSDATA_PREFIX");
      //qTrace("argv0=%s\r\ntessdata_prefix=%s", argv0, tessdata_prefix); 



      if (argv0 != NULL) {

          /* Use tessdata prefix from the command line. */
          datadir = argv0;

      }
      else if (tessdata_prefix) {

          /* Use tessdata prefix from the environment. */
          datadir = tessdata_prefix;




#if defined(_WIN32)
      }
      else if (datadir == NULL || access(datadir.string(), 0) != 0) {


          /* Look for tessdata in directory of executable. */
          static char dir[128];
          static char exe[128];
          DWORD length = GetModuleFileName(NULL, exe, sizeof(exe));

          if (length > 0 && length < sizeof(exe)) {

              _splitpath(exe, NULL, dir, NULL, NULL);
              datadir = dir;

          }
#endif /* _WIN32 */





#if defined(TESSDATA_PREFIX)
      }
      else {
          /* Use tessdata prefix which was compiled in. */
#define _STR(a) #a
#define _XSTR(a) _STR(a)
          datadir = _XSTR(TESSDATA_PREFIX);
#undef _XSTR
#undef _STR
#endif



      }






      // datadir may still be empty:
      if (datadir.length() == 0) {
          datadir = "./";
      }
      else {
          // Remove tessdata from the end if present, as we will add it back!
          int length = datadir.length();
          if (length >= 8 && strcmp(&datadir[length - 8], "tessdata") == 0)
              datadir.truncate_at(length - 8);
          else if (length >= 9 && strcmp(&datadir[length - 9], "tessdata/") == 0)
              datadir.truncate_at(length - 9);
      }



      // check for missing directory separator
      const char* lastchar = datadir.string();
      lastchar += datadir.length() - 1;
      if ((strcmp(lastchar, "/") != 0) && (strcmp(lastchar, "\\") != 0))  datadir += "/";

      datadir += m_data_sub_dir;     /**< data directory */

      // qTrace("datadir=%s", datadir.c_str());

  }  // main_setup 


 




 






ParamsVectors *params() { return &params_; }

  // STRING datadir;        // dir for data files
STRING datadir=""; 


  STRING imagebasename;  // name of image
  STRING lang;
  STRING language_data_path_prefix;
  TessdataManager tessdata_manager;
  UNICHARSET unicharset;
  UnicharAmbigs unichar_ambigs;
  STRING imagefile;  // image file name
  STRING directory;  // main directory

 private:
  ParamsVectors params_;

 public:
  // Member parameters.
  // These have to be declared and initialized after params_ member, since
  // params_ should be initialized before parameters are added to it.
  
//// STRING_VAR_H(m_data_sub_dir, "tessdata/", "Directory for data files");
STRING m_data_sub_dir="tessdata/";

  
#ifdef _WIN32

// STRING_VAR_H(tessedit_module_name, WINDLLNAME, "Module colocated with tessdata dir");
STRING tessedit_module_name= "libtesseract305.dll";  
  
#endif


// INT_VAR_H(ambigs_debug_level, 0, "Debug level for unichar ambiguities");
int ambigs_debug_level=0; 


// BOOL_VAR_H(use_definite_ambigs_for_classifier, 0, "Use definite ambiguities when running character classifier");

bool use_definite_ambigs_for_classifier=0;

// BOOL_VAR_H(use_ambigs_for_adaption, 0, "Use ambigs for deciding whether to adapt to a character");
bool  use_ambigs_for_adaption =0; 
 



};
// class CCUtil




extern CCUtilMutex tprintfMutex;  // should remain global
}  // namespace tesseract

#endif  // TESSERACT_CCUTIL_CCUTIL_H__
