



#ifndef _MAIN_H_

#define _MAIN_H_


int main(int argc=0, char** argv=0);

int main32c(char*cmd);

int main32s(char*pic, char*outputbase, char*lang="eng");

int main32q(char*image, char*outputbase, char* lang = "eng");   

#endif  //  _MAIN_H_ 