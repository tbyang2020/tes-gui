




#pragma warning(disable:4996)  // error C4996: 'fopen' ...  



#include <Windows.h>
#include <stdio.h>
#include <io.h>

#include "../InterfaceMDI/InterfaceMDI.h"  // CCW_DATA 
#include "../InterfaceMDI/qTrace.h"

#include <math.h>   // pow 

#define _DIB_CPP_

#include "Dib.h"

#include "vmath.h"



#if SHELL_PROCS |1 


// ִ�� eProc(pDIB, rc, lParam Param ���������� ���� eProc. 
// eProc �ķ���ֵӰ�� dib_Exec ��ִ�еĲ���:  enum RECV_OP 

BYTE*  dib_Exec( HWND hWnd, DIB_PROC eProc, WPARAM wParam, LPARAM lParam){  // =0  = 0

CCW_DATA*pcd = (CCW_DATA*)GetWindowLong(hWnd,GWL_USERDATA);
if (!pcd){ MessageBox(0,"No User Data!",0,0); return 0; }
if (!pcd->pData){ MessageBox(0,"No DIB!",0,0); return 0; }

#if CLIP_RECT|1

int B=12; 	

RECT gc; GetClientRect(hWnd,&gc); 
gc.left+=B, gc.top+=B; gc.right-=B, gc.bottom-=B; 

RECT rc=gc; 
matx(pcd->xf,&rc);

intr(&rc, &pcd->sel);

XFORM xm=pcd->xf;   

int w=BIWIDTH((BYTE*)pcd->pData), h=BIHEIGHT((BYTE*)pcd->pData); 
RECT rs = {0,0, w, h, };  

if (rc.right == rc.left || rc.bottom == rc.top){
//rc=gc;
rc = rs;
}else{ 

matinv(&xm);  matx(xm,&rc); 
mkTransform( gc, rs, xm); 
matx(xm, &rc); 

}   // if..else 

int t=rc.top;  rc.top= h-rc.bottom;  rc.bottom=h-t; 

#endif  // CLIP_RECT


BYTE* ir= eProc((LPBYTE)pcd->pData, &rc, wParam, lParam); 


#if PASS_BOUND|1

if(rc.left<rc.right && rc.top<rc.bottom)pcd->bound=rc; 
mapPoints((POINT*)&pcd->bound , 2, hWnd, true); 

#endif  // PASS_BOUND


if (ir){  // wParam Ϊ��λͼָ�� BYTE**  

#if NEW_WND|0  

BYTE* pp = (BYTE*)ir; 
if (pp){

MDICREATESTRUCTW mdics; ZeroMemory(&mdics,sizeof(mdics));
mdics.szClass=WNDCLS_CLIENT;  
mdics.szTitle=L"dib_Exec.bmp";  
CCW_DATA* ccd=new CCW_DATA; 
mdics.lParam=(long)ccd;   

ccd->pData = pp; 

HWND hClient= GetParent(hWnd); 
SendMessageW( hClient ,WM_MDICREATE,0,(LPARAM)&mdics);
SendMessage(hClient,WM_MDITILE,MDITILE_VERTICAL,0);

}  


#endif   // NEW_WND

}



return ir;
}




// ִ�� eProc(pDIB, rc, wParam, lParam) , wParam, lParam ���������� ���� eProc .  �� bDup=true, ���� DIB, ����

int  dipr_Exec( HWND hWnd,  DIPR_PROC eProc, WPARAM wParam, LPARAM lParam){  // =0  = 0 = false 

CCW_DATA*pcd = (CCW_DATA*)GetWindowLong(hWnd,GWL_USERDATA);
if (!pcd){ MessageBox(0,"No User Data!",0,0); return 0; }
if (!pcd->pData){ MessageBox(0,"No DIB!",0,0); return 0; }


BYTE* pDIB=(BYTE*)pcd->pData;  // ���ԭ���� 
BYTE* pSrc=(BYTE*)pcd->pSrc; 


if (!pSrc){

//int iR = MessageBox(0, "�Ƿ񴴽��´���?", "dipr_Exec",MB_YESNO); 
//if (iR == IDYES){

MDICREATESTRUCTW mdics; ZeroMemory(&mdics,sizeof(mdics));
mdics.szClass=WNDCLS_CLIENT;  
mdics.szTitle=L"dib_Exec.bmp";  
CCW_DATA* ccd=new CCW_DATA; 
mdics.lParam=(long)ccd;   

ccd->pSrc = pcd->pData;
ccd->pData =  dib_dup((BYTE*)pcd->pData); 

HWND hClient= GetParent(hWnd); 
SendMessageW( hClient ,WM_MDICREATE,0,(LPARAM)&mdics);
SendMessage(hClient,WM_MDITILE,MDITILE_VERTICAL,0);

pSrc= (BYTE*)pcd->pData;  // ����´���
pDIB= (BYTE*)ccd->pData; 

// }  // IDYES 


}  // if(!pSrc) 


#if CLIP_RECT|1

int B=12; 	

RECT gc; GetClientRect(hWnd,&gc); 
gc.left+=B, gc.top+=B; gc.right-=B, gc.bottom-=B; 

RECT rc=gc; 
matx(pcd->xf,&rc);

intr(&rc, &pcd->sel);

XFORM xm=pcd->xf;   

int w=BIWIDTH((BYTE*)pcd->pData), h=BIHEIGHT((BYTE*)pcd->pData); 
RECT rs = {0,0, w, h, };  

if (rc.right == rc.left || rc.bottom == rc.top){
//rc=gc;
rc = rs;
}else{ 

matinv(&xm);  matx(xm,&rc); 
mkTransform( gc, rs, xm); 
matx(xm, &rc); 

}   // if..else 

int t=rc.top;  rc.top= h-rc.bottom;  rc.bottom=h-t; 

#endif  // CLIP_RECT



return eProc(pDIB, &rc, pSrc,  wParam, lParam);   

}




int anim_Exec(HWND hWnd,  ANIM_PROC eProc, WPARAM wParam, LPARAM lParam){ 


CCW_DATA*pcd = (CCW_DATA*)GetWindowLong(hWnd,GWL_USERDATA);
if (!pcd){ MessageBox(0,"No User Data!",0,0); return 0; }
if (!pcd->pData){ MessageBox(0,"No DIB!",0,0); return 0; }


BYTE* pDIB=(BYTE*)pcd->pData;  // ���ԭ���� 
BYTE* pSrc=(BYTE*)pcd->pSrc; 


if (!pSrc){

//int iR = MessageBox(0, "�Ƿ񴴽��´���?", "dipr_Exec",MB_YESNO); 
//if (iR == IDYES){

MDICREATESTRUCTW mdics; ZeroMemory(&mdics,sizeof(mdics));
mdics.szClass=WNDCLS_CLIENT;  
mdics.szTitle=L"anim_Exec.bmp";  
CCW_DATA* ccd=new CCW_DATA; 
mdics.lParam=(long)ccd;   

ccd->pSrc = pcd->pData;
ccd->pData =  dib_dup((BYTE*)pcd->pData, -1); 

HWND hClient= GetParent(hWnd); 
SendMessageW( hClient ,WM_MDICREATE,0,(LPARAM)&mdics);
SendMessage(hClient,WM_MDITILE,MDITILE_VERTICAL,0);

pSrc= (BYTE*)pcd->pData;  // ����´���
pDIB= (BYTE*)ccd->pData; 

// }  // IDYES 


}  // if(!pSrc) 


#if CLIP_RECT|1

int B=12; 	

RECT gc; GetClientRect(hWnd,&gc); 
gc.left+=B, gc.top+=B; gc.right-=B, gc.bottom-=B; 

static RECT  rc;  // static,  ��ΪҪ���������߳�
rc=gc; 
matx(pcd->xf,&rc);

intr(&rc, &pcd->sel);

XFORM xm=pcd->xf;   

int w=BIWIDTH((BYTE*)pcd->pData), h=BIHEIGHT((BYTE*)pcd->pData); 
RECT rs = {0,0, w, h, };  

if (rc.right == rc.left || rc.bottom == rc.top){
//rc=gc;
rc = rs;
}else{ 

matinv(&xm);  matx(xm,&rc); 
mkTransform( gc, rs, xm); 
matx(xm, &rc); 

}   // if..else 

int t=rc.top;  rc.top= h-rc.bottom;  rc.bottom=h-t; 


// qTrace("[%d,%d,  %d,%d]", rc.left,rc.top,rc.right,rc.bottom);



#endif  // CLIP_RECT


// �������߳�, ���� eProc  // dipr_grow(hOpen, hEdit);

static  // ����! 
struct PARAM{ LPBYTE pDIB; RECT* rc; LPBYTE pSrc; WPARAM wParam; LPARAM lParam;} pa;  // ��������һ��!  
pa ={pDIB, &rc, pSrc, wParam, lParam};   

// qTrace("[%d, %d,  %d,%d]", rc.left, rc.top, rc.right, rc.bottom);


DWORD thID;   // DWORD (WINAPI*)(LPVOID);   
return (int)CreateThread(0, 0, eProc, &pa,  0,    &thID);   // (LPTHREAD_START_ROUTINE) 

}


#endif   // SHELL_PROCS











// for anim_Exec 
// pt.x-�����б�, pt.y-�����б�. hWnd, ���� pbi �Ĵ���. 


DWORD WINAPI anim_grow(LPVOID Param){

int er=1; 

struct PARAM{ BYTE*pbi; RECT*rc; BYTE*pSrc; POINT*pt; HWND hWnd; } *pa = (PARAM*)Param; 

if (!pa) return 0;  

// qTrace("[%d,%d,  %d,%d] ", pa->rc->left,pa->rc->top,pa->rc->right,pa->rc->bottom );




LPBITMAPINFOHEADER bi= (LPBITMAPINFOHEADER)pa->pbi;  // if (bi->biBitCount != 24) { MessageBox(0,"Ŀǰ��֧��24λ���ͼ",0,0); return 0L; }
 
int x=pa->pt->x, y=pa->pt->y; 

y=bi->biHeight-y;
if ( x < 0 || x >=bi->biWidth || y < 0 || y >=bi->biHeight)  { qTrace("pt (%d, %d) / [%d,%d]", x,  y, bi->biWidth, bi->biHeight); return 0; }

RECT re={ 0,0,bi->biWidth, bi->biHeight }; 
if (pa->rc!=0) re=*pa->rc; 
if (re.left<0) re.left = 0;  if (re.top<0)  re.top = 0;
if (re.right>bi->biWidth) re.right=bi->biWidth;  if (re.bottom>bi->biHeight) re.bottom=bi->biHeight; 

//qTrace("[%d, %d,  %d,%d]/[%d, %d]", re.left, re.top, re.right, re.bottom,bi->biWidth, bi->biHeight);

int wb = ((bi->biWidth*bi->biBitCount/8+3)/4)*4;  // WIDTHBYTES(bi->biWidth*bi->biBitCount); // 4-bytes aligning  
int bc = bi->biHeight*wb;  
int hc = sizeof(BITMAPINFOHEADER);   // +sizeof(BITMAPFILEHEADER);
int pc = bi->biClrUsed *sizeof(RGBQUAD);   // assert( bi->biClrUsed==0);
int mc = hc+pc+bc; 


BYTE* pi=pa->pbi+hc+pc, b,g,r;   // LocBits(pbi); 
const BYTE* cpi=pa->pSrc+hc+pc;  



#if GROW_COLOR|1

b  = *(cpi + y*wb + x*bi->biBitCount/8),
g  = *(cpi + y*wb + x*bi->biBitCount/8 +1 ),
r  = *(cpi + y*wb + x*bi->biBitCount/8 +2 );    // getPixel  

if (bi->biBitCount<24) r=b; 
if (bi->biBitCount<16){ r=b, g=b; }


DWORD c=0, co = r| (g << 8) | (b << 16) ; 




*( pi + y*wb + x*bi->biBitCount/8 ) = b; 
if(bi->biBitCount>8)  *( pi + y*wb + x*bi->biBitCount/8 + 1 ) = g; 
if(bi->biBitCount>16) *( pi + y*wb + x*bi->biBitCount/8 + 2 ) = r;     // ��һ������ 

//qTrace("[%d,%d,  %d,%d]/ [%d,%d]", re.left,re.top,re.right,re.bottom, bi->biWidth, bi->biHeight);


int iC=1, ic=0;  

int iLoop=0;  


// re={0,0, bi->biWidth, bi->biHeight};  // ע�� static 



do{

InvalidateRect(pa->hWnd,0,1);   // ���� pbi �ǵ�ǰ��ʾ�� DIB ʱ������ 

ic=0;   //  ic ����Ϊ0, ��ζ����Ҳû�п������ӵ��� 

 

for( int i=re.top; i<re.bottom; i++ ){            // �����ڽ����� i--iy, j--ix

//BYTE* dp=pi+ i*wb;   // ָ��� i �� 
//const BYTE* sp=cpi+i*wb; 
 
for(int j=re.left; j<re.right; j++ ){


b  = *(cpi + i*wb + j*bi->biBitCount/8),
g  = *(cpi + i*wb + j*bi->biBitCount/8 +1 ),
r  = *(cpi + i*wb + j*bi->biBitCount/8 +2 );   

if (bi->biBitCount<24) r=b; 
if (bi->biBitCount<16){ r=b, g=b; }


c = r| (g << 8) | (b << 16) ; 

// if(j==x && i==y) qTrace("b=%X, g=%X, r=%X,  c=%X, co=%X, i=%d, j=%d", b,g,r, c,co, i,j)


//if (c!=co)  continue; 
if (!dipr_Equ(c,co,er)) continue; 
 

b  = *(pi + i*wb + j*bi->biBitCount/8);
g  = *(pi + i*wb + j*bi->biBitCount/8 +1 );
r  = *(pi + i*wb + j*bi->biBitCount/8 +2 );   

if (bi->biBitCount<24) r=b; 
if (bi->biBitCount<16){ r=b, g=b; }

c = r| (g << 8) | (b << 16) ; 

//if (c==co) continue; 
if (dipr_Equ(c,co,er)) continue; 






#if READ_PIXELS |1  // ��ȡ�ڽ��� 9 ������  

int jc=0; 

for (int v=-1; v<2; v++){

jc=0; 

for (int u=-1; u<2; u++){

if (i+v<re.top || i+v>re.bottom) continue; 
if (j+u<re.left || j+u>re.right) continue; 

b  = *(pi + (i+v)*wb + (j+u)*bi->biBitCount/8),
g  = *(pi + (i+v)*wb + (j+u)*bi->biBitCount/8 +1),
r  = *(pi + (i+v)*wb + (j+u)*bi->biBitCount/8 +2);    // getPixel  

if (bi->biBitCount<24) r=b; 
if (bi->biBitCount<16){ r=b, g=b; }


c = r| (g << 8) | (b << 16) ; 

//if (c == co) {
if (dipr_Equ(c,co,er)) {   

*(pi + i*wb + j*bi->biBitCount/8) = b;
if (bi->biBitCount>8) *(pi + i*wb + j*bi->biBitCount/8 +1) = g;
if (bi->biBitCount>16) *(pi + i*wb + j*bi->biBitCount/8 +2) = r;    

iC++;  ic++; jc++; 
break; 
}  // if c==co   

}  // for u  

if (jc>0) break; 
}  // for v

#endif  // READ_PIXELS



// sp+=3; dp+=3; 
}  // for j  
 
}  // for i 




HDC hdc = GetDC(pa->hWnd);  \
RECT rc; GetClientRect(pa->hWnd, &rc);   \
char sz[128];    \
int it = sprintf(sz, "%X (%d,%d), ic=%d, iC=%d, iLoop=%d", co,   x, bi->biHeight-y, ic, iC, iLoop++);   \
TextOut(hdc, 0,rc.bottom-32,sz,it);  \
ReleaseDC(pa->hWnd, hdc); 

Sleep(10); 


} while (ic>0); 


#endif  // GROW_COLOR


return 1; 
}





// ͼ��ɫ -- Ŀǰ����� 8��16��24λλͼ. 


BYTE* dib_8s(LPBYTE pbi){   
if (pbi == NULL) return 0;

LPBITMAPINFOHEADER bi= (LPBITMAPINFOHEADER)pbi;  
if (bi->biBitCount < 8) { MessageBox(0,"Ŀǰ��֧��8λ����λͼ",0,0); return 0L; }

// 4-bytes aligning  
int wb  = ((bi->biWidth*bi->biBitCount/8+3)/4)*4;  //  WIDTHBYTES(bi->biWidth*bi->biBitCount);  //  int rwb =  ((bi->biWidth + 31) / 32 * 4);   

int clrUsed=bi->biClrUsed;  
if (clrUsed == 0) clrUsed = (1<<bi->biBitCount);  // pow(2, bi->biBitCount);  // math.h 
if (bi->biBitCount>8) clrUsed=0;  

int bc = bi->biHeight*wb;  
int hc = sizeof(BITMAPINFOHEADER);      // sizeof(BITMAPFILEHEADER) + 
int pc = clrUsed *sizeof(RGBQUAD);     // assert( bi->biClrUsed==256);  //RGBQUAD* pal = (RGBQUAD*)(pbi+hc);     // ������λ���� ...... 
int mc = hc+pc+bc; 



BITMAPINFOHEADER rbi= *(LPBITMAPINFOHEADER)pbi;  
rbi.biBitCount = 8; 
rbi.biClrUsed= 1<<8 ;  // ��Ҫ��ɫ��, �ǲ��е�  

// 4-bytes aligning  
int rwb  = ((rbi.biWidth*rbi.biBitCount/8+3)/4)*4;  //  WIDTHBYTES(bi->biWidth*bi->biBitCount);  //  int rwb =  ((bi->biWidth + 31) / 32 * 4);   
int rbc = rbi.biHeight*rwb;  
// int rhc = sizeof(BITMAPINFOHEADER);      // sizeof(BITMAPFILEHEADER) + 
int rpc = rbi.biClrUsed *sizeof(RGBQUAD);     // assert( bi->biClrUsed==256);  //RGBQUAD* pal = (RGBQUAD*)(pbi+hc);     // ������λ���� ...... 
int rmc = hc+rpc+rbc; 

rbi.biSizeImage=rbc; 

BYTE*pn = (BYTE*)malloc(rmc); 
memcpy(pn, &rbi, hc); 

RGBQUAD*qd = (RGBQUAD*)(pn+hc); 
for (int i = 0; i<rbi.biClrUsed; i++){ qd[i].rgbBlue = qd[i].rgbGreen = qd[i].rgbRed = i; qd[i].rgbReserved=0; }

BYTE c,  *p, *q,  *pi=pbi+hc+pc, *rpi=pn+hc+rpc;   // LocBits(pbi); 


for( int i=0; i<bi->biHeight; i++ ){  

p=pi+i*wb;  // �� i �� j ��  
q=rpi+i*rwb; 

for( int j=0; j<bi->biWidth; j++ ){

// pi[ i*bi->biWidth+j ] = cm- pi[ i*bi->biWidth+j ] ;    // ��Ӧ��ʹ��  bi->biWidth 
 
c=*p++; 
if ( bi->biBitCount > 8 ){ c=*p++;  }
if ( bi->biBitCount > 16 ){ c=*p++;  }  // �����Ժ�ɫ����Ϊ׼ 
if (bi->biBitCount>24) assert(0);

*q++=c; 

}  // for j  
}  // for i 



#if SHOW_FILE|0

FILE*fp = fopen("dib_8s.bmp", "wb");
BITMAPFILEHEADER fh = {0x4D42, 0,  0,0,  0, };  // bfSize,  bfOffBits 

fh.bfOffBits=sizeof(fh)+sizeof(BITMAPINFOHEADER)+sizeof(RGBQUAD)*rbi.biClrUsed;  // 0 
fh.bfSize = fh.bfOffBits + rbc;  
int ir=fwrite(&fh, sizeof(fh),1, fp); 
ir=fwrite(pn, fh.bfSize-sizeof(fh),1, fp);    // qTrace("ir=%d, %d",ir, (fh.bfSize-sizeof(fh))/1024); 
fclose(fp);
ShellExecute(0,"open","mspaint.exe","dib_8s.bmp",0,SW_SHOW);

#endif  // SHOW_FILE



return pn;  // wParam ������ BYTE** 
}



//  ת��Ϊ 24 λ�Ҷ�ͼ 

BYTE* dib_24s(LPBYTE pbi){   
if (pbi == NULL) return 0;

LPBITMAPINFOHEADER bi= (LPBITMAPINFOHEADER)pbi;  
if (bi->biBitCount < 8) { MessageBox(0,"Ŀǰ��֧��8λ����λͼ",0,0); return 0L; }

// 4-bytes aligning  
int wb  = ((bi->biWidth*bi->biBitCount/8+3)/4)*4;  //  WIDTHBYTES(bi->biWidth*bi->biBitCount);  //  int rwb =  ((bi->biWidth + 31) / 32 * 4);   

int clrUsed=bi->biClrUsed;  
if (clrUsed == 0) clrUsed = (1<<bi->biBitCount);  // pow(2, bi->biBitCount);  // math.h 
if (bi->biBitCount>8) clrUsed=0;  

int bc = bi->biHeight*wb;  
int hc = sizeof(BITMAPINFOHEADER);      // sizeof(BITMAPFILEHEADER) + 
int pc = clrUsed *sizeof(RGBQUAD);     // assert( bi->biClrUsed==256);  //RGBQUAD* pal = (RGBQUAD*)(pbi+hc);     // ������λ���� ...... 
int mc = hc+pc+bc; 



BITMAPINFOHEADER rbi= *(LPBITMAPINFOHEADER)pbi;  
rbi.biBitCount = 24; 
rbi.biClrUsed= 0;  // ��Ҫ��ɫ��  

// 4-bytes aligning  
int rwb  = ((rbi.biWidth*rbi.biBitCount/8+3)/4)*4;  //  WIDTHBYTES(bi->biWidth*bi->biBitCount);  //  int rwb =  ((bi->biWidth + 31) / 32 * 4);   
int rbc = rbi.biHeight*rwb;  
// int rhc = sizeof(BITMAPINFOHEADER);      // sizeof(BITMAPFILEHEADER) + 
int rpc = rbi.biClrUsed *sizeof(RGBQUAD);     // assert( bi->biClrUsed==256);  //RGBQUAD* pal = (RGBQUAD*)(pbi+hc);     // ������λ���� ...... 
int rmc = hc+rpc+rbc; 

rbi.biSizeImage=rbc; 

BYTE*pn = (BYTE*)malloc(rmc); 
memcpy(pn, &rbi, hc); 

// RGBQUAD*qd = (RGBQUAD*)(pn+hc);  for (int i = 0; i<rbi.biClrUsed; i++){ qd[i].rgbBlue = qd[i].rgbGreen = qd[i].rgbRed = i; qd[i].rgbReserved=0; }

BYTE c,  *p, *q,  *pi=pbi+hc+pc, *rpi=pn+hc+rpc;   // LocBits(pbi); 

for( int i=0; i<bi->biHeight; i++ ){  

p=pi+i*wb;  // �� i �� j ��  
q=rpi+i*rwb; 

for( int j=0; j<bi->biWidth; j++ ){

// pi[ i*bi->biWidth+j ] = cm- pi[ i*bi->biWidth+j ] ;    // ��Ӧ��ʹ��  bi->biWidth 
 
c=*p++; 
if ( bi->biBitCount > 8 ){ c=*p++;  }
if ( bi->biBitCount > 16 ){ c=*p++;  }  // �����Ժ�ɫ����Ϊ׼ 
if (bi->biBitCount>24) assert(0);

*q++=c;  *q++=c;  *q++=c;  

}  // for j  
}  // for i 



#if SHOW_FILE|0

FILE*fp = fopen("dib_8s.bmp", "wb");
BITMAPFILEHEADER fh = {0x4D42, 0,  0,0,  0, };  // bfSize,  bfOffBits 

fh.bfOffBits=sizeof(fh)+sizeof(BITMAPINFOHEADER)+sizeof(RGBQUAD)*rbi.biClrUsed;  // 0 
fh.bfSize = fh.bfOffBits + rbc;  
int ir=fwrite(&fh, sizeof(fh),1, fp); 
ir=fwrite(pn, fh.bfSize-sizeof(fh),1, fp);    // qTrace("ir=%d, %d",ir, (fh.bfSize-sizeof(fh))/1024); 
fclose(fp);
ShellExecute(0,"open","mspaint.exe","dib_8s.bmp",0,SW_SHOW);

#endif  // SHOW_FILE



return pn;  // wParam ������ BYTE** 
}








// dib_bgr, ֱ��ת��Ϊ��ɫ��Ҷ�ͼ.   iMethod=GRAY_BLUE ... �ֱ��Ӧ�� b��g��r��   gray...

int dib_gray(LPBYTE pbi, RECT* rc, int iMethod){  // =8   = 0

if (pbi == NULL) return 0;
LPBITMAPINFOHEADER bi= (LPBITMAPINFOHEADER)pbi;  
if (bi->biBitCount != 24) { MessageBox(0,"��֧��24λ���ͼ",0,0); return 0L; }
 

FILE*fp =0;  

const char*szFile = 0; 
if (szFile != 0) fp = fopen(szFile,"wb");   


int wb  =  ((bi->biWidth*bi->biBitCount/8+3)/4)*4;  // WIDTHBYTES(bi->biWidth*bi->biBitCount); // 4-bytes aligning  
int bc = bi->biHeight*wb;  
int hc= sizeof(BITMAPINFOHEADER);   // +sizeof(BITMAPFILEHEADER);
int pc = bi->biClrUsed *sizeof(RGBQUAD);    assert( bi->biClrUsed==0);

BYTE* pi=pbi+hc+pc, b,g,r;   // LocBits(pbi); 


RECT re={0,0,bi->biWidth, bi->biHeight}; 
if (rc!=0) re=*rc; 

for( int i=0; i<bi->biHeight; i++ ){

BYTE*sp=pi+ i*wb;   // ָ��� i �� 


for( int j=0; j<bi->biWidth; j++ ){
 
if (i>=re.top && i<re.bottom  && j>=re.left && j< re.right)  {

b=*sp, g=*(sp+1), r=*(sp+2); 
//c = r | (g<<8) | (b<<16); 

switch (iMethod){
case GRAY_BLUE:  g=r=b;  break; 
case GRAY_GREEN: b=r=g;  break; 
case GRAY_RED:   b=g=r;  break; 


case GRAY_WEIGHT:  // WEIGHT_GRAY 
b=g=r=  ( (306*r+601*g+117*b)>>10 ); 
break; 

case GRAY_MEAN:  // MEAN_GRAY 
b=g=r= (r+g+b)/3 ; 
break; 

case GRAY_MAXI:  // MAXIMUM_GRAY 
b=g=r=  maxi( r,g,b ); 
break; 

case GRAY_MINI:
b=g=r=  mini( r,g,b ); 
break; 


default: 
assert(false);  // Ҳ�����������㷨    
break; 
}  // switch  iMethod  


*sp=b, *(sp+1)=g,  *(sp+2)=r; 

} // if in rect    


sp+=bi->biBitCount/8; 
}  // for j  

}  // for i 


if (fp){


BITMAPFILEHEADER fh = {0x4D42, 0,  0,0,  0, };  // bfSize,  bfOffBits 
BITMAPINFOHEADER* fi= (BITMAPINFOHEADER*)pbi; 

fh.bfOffBits=sizeof(fh)+sizeof(BITMAPINFOHEADER)+sizeof(RGBQUAD)*fi->biClrUsed; 
fh.bfSize = fh.bfOffBits + fi->biSizeImage;  
int ir=fwrite(&fh, sizeof(fh),1, fp); 
ir=fwrite(pbi, fh.bfSize-sizeof(fh),1, fp);    // qTrace("ir=%d, %d",ir, (fh.bfSize-sizeof(fh))/1024); 

fclose(fp);
ShellExecute(0,"open","mspaint.exe","gray.bmp",0,SW_SHOW);
}  // if(fp) 

  
return 1;
}










// ReadDIB. ��BITMAPFILEHEADER ������ݶ����������ڴ�.  free �ͷ��ڴ�. 

BYTE* dib_read(const wchar_t* szFile){  

FILE*fp = _wfopen(szFile, L"rb");  if (!fp) { MessageBoxW(0,szFile,L"δ�ܴ�",0); return 0L; }

BITMAPFILEHEADER bfh;
fread(&bfh, sizeof(bfh),1,fp); 

if(bfh.bfType!=DIB_MARKER){ MessageBoxW(0,szFile,L"����Bitmap�ļ�",0);return 0L; }  // �ж��Ƿ���DIB���󣬼��ͷ�����ֽ��Ƿ���"BM"

int ic = filelength(fileno(fp)); 

LPBYTE pDIB=(LPBYTE)malloc(ic);  // ΪDIB�����ڴ�
if (!pDIB){ qTrace("malloc"); return 0L;}

// HDIB hDIB;
int ir=fread(pDIB, ic - sizeof(bfh),1,fp); 

if (ir != 1){ qTrace("fread=%d", ir); free(pDIB); return 0L; }

fclose(fp);
return pDIB;// ����DIB���
}



// ReadDIB. ��BITMAPFILEHEADER ������ݶ����������ڴ�.  free �ͷ��ڴ�. 

BYTE* dib_read(const char* szFile){  

FILE*fp = fopen(szFile, "rb");  if (!fp) { MessageBox(0,szFile,"δ�ܴ�",0); return 0L; }

BITMAPFILEHEADER bfh;
fread(&bfh, sizeof(bfh),1,fp); 

if(bfh.bfType!=DIB_MARKER){ MessageBox(0,szFile,"����Bitmap�ļ�",0);return 0L; }  // �ж��Ƿ���DIB���󣬼��ͷ�����ֽ��Ƿ���"BM"

int ic = filelength(fileno(fp)); 

LPBYTE pDIB=(LPBYTE)malloc(ic);  // ΪDIB�����ڴ�
if (!pDIB){ qTrace("malloc"); return 0L;}

// HDIB hDIB;
int ir=fread(pDIB, ic - sizeof(bfh),1,fp); 

if (ir != 1){ qTrace("fread=%d", ir); free(pDIB); return 0L; }

fclose(fp);
return pDIB;// ����DIB���
}






bool saveDib(BYTE*pDib, const wchar_t* szFile){

if (!pDib) return false;
if (!szFile) return false; 

FILE*fp = _wfopen(szFile, L"wb");  if (!fp) { MessageBoxW(0,szFile,L"δ�ܴ�",0); return false; }

BITMAPFILEHEADER fh = {0x4D42, 0,  0,0,  0, };  // bfSize,  bfOffBits 
BITMAPINFOHEADER* fi= (BITMAPINFOHEADER*)pDib; 

fh.bfOffBits=sizeof(fh)+sizeof(BITMAPINFOHEADER)+sizeof(RGBQUAD)*fi->biClrUsed; 
fh.bfSize = fh.bfOffBits + fi->biSizeImage;  
int ir=fwrite(&fh, sizeof(fh),1, fp); 
ir=fwrite(pDib, fh.bfSize-sizeof(fh),1, fp);    // qTrace("ir=%d, %d",ir, (fh.bfSize-sizeof(fh))/1024); 

fclose(fp); 
return true; 
}


BYTE* dib_dup(BYTE*pSrc, int clr_Color){  // = 0 

BITMAPINFOHEADER*bi = (BITMAPINFOHEADER*)pSrc;
int wb  =  ((bi->biWidth*bi->biBitCount/8+3)/4)*4;  // WIDTHBYTES(bi->biWidth*bi->biBitCount); // 4-bytes aligning  
int bc = bi->biHeight*wb;  
int hc = sizeof(BITMAPINFOHEADER);         // +sizeof(BITMAPFILEHEADER);
int pc = bi->biClrUsed *sizeof(RGBQUAD);   // assert( bi->biClrUsed==0);

int mc=hc+pc+bc; 

LPBYTE pDib = (LPBYTE)malloc(mc); 
memcpy(pDib,pSrc, mc); 

if(clr_Color<0) memset(pDib+hc+pc, 0, bc);  // ��յ�ǰ��ʾ��ͼ�� 
else  memset(pDib+hc+pc, clr_Color, bc); 

BYTE*p=pSrc+hc+pc; 
BYTE*q=pDib+hc+pc;  

if (clr_Color==-1)
for (int i=0; i<bi->biHeight; i++)
for (int j=0; j<bi->biWidth; j++){

	q[i*wb + j*bi->biBitCount/8] = 0xFF-p[i*wb+j*bi->biBitCount/8]; 
	if (bi->biBitCount>8) q[i*wb + j*bi->biBitCount/8 +1] = 0xFF-p[i*wb+j*bi->biBitCount/8 +1]; 
	if (bi->biBitCount>16) q[i*wb + j*bi->biBitCount/8 +2] = 0xFF-p[i*wb+j*bi->biBitCount/8 +2]; 


}



return pDib; 
}


// PaintDIB ����StretchDIBits ��  SetDIBitsToDevice  ���� DIB ���� 

// rs��rd ָ��ԭ��Ŀ�ľ�������. 0L ��ʾĬ�����, ԭͼ���Ƶ������û�����   

// pBits = LocBits(pDIB)  


void dib_draw(HDC hdc, BYTE*pDib, RECT*rd,  RECT*rs){  // rd=0L��ʾ�����û�����,  rs=0L ��ʾͼ�����  
if(pDib==NULL)return; 

RECT rc[2]={{0,0,0,0},{0,0,0,0,}};

if (rd == 0){ GetClientRect(WindowFromDC(hdc), rc);  rd =&rc[0]; }
if (!rs){   rc[1]= { 0,0, (long)BiWidth(pDib), (long)BiHeight(pDib) };  rs =&rc[1]; }

CONST BITMAPINFO * pih = (CONST BITMAPINFO *)pDib; 

BYTE* p = LocBits(pDib); 

SetStretchBltMode(hdc,COLORONCOLOR);  // ������ʾģʽ  deletes all eliminated���� lines of pixels  


int w=rd->right - rd->left,  h= rd->bottom - rd->top;  
int ws=rs->right - rs->left,  hs= rs->bottom - rs->top;  


// ����, ��������任 
// StretchDIBits(hdc,  rd->left,rd->top, w,h,   \
rs->left,rs->top, ws, hs,      \
p,(LPBITMAPINFO)pDib,DIB_RGB_COLORS,SRCCOPY); // lpBits/ lpBitsInfo/ wUsage/ dwROP 

// ������, ��������任 
StretchDIBits(hdc,  rd->left,rd->top, ws,hs,   \
rs->left,rs->top, ws, hs,      \
p,(LPBITMAPINFO)pDib,DIB_RGB_COLORS,SRCCOPY); // lpBits/ lpBitsInfo/ wUsage/ dwROP 


// ������, ����������任 
// SetDIBitsToDevice(hdc,rd->left, rd->top,  \
ws,hs, rs->left,rs->top,     \
0,   BiHeight(pDib),  p, (CONST BITMAPINFO *)pDib, DIB_RGB_COLORS);



return;
}

















// ��ȡ threshhold 

int dib_cri(BYTE*pbi, RECT*rc){   

if (pbi == NULL) return 0;

LPBITMAPINFOHEADER bi= (LPBITMAPINFOHEADER)pbi;  

int wb  = ((bi->biWidth*bi->biBitCount/8+3)/4)*4;  //  WIDTHBYTES(bi->biWidth*bi->biBitCount);  //  int rwb =  ((bi->biWidth + 31) / 32 * 4);   
int bc = bi->biHeight*wb;  
int hc= sizeof(BITMAPINFOHEADER);      // sizeof(BITMAPFILEHEADER) + 
int clrUsed=bi->biClrUsed;  if (clrUsed == 0) clrUsed = (1<<bi->biBitCount);  // pow(2, bi->biBitCount);  // math.h 
if (bi->biBitCount>8) clrUsed=0;  
int pc = clrUsed *sizeof(RGBQUAD);     // assert( bi->biClrUsed==256);  //RGBQUAD* pal = (RGBQUAD*)(pbi+hc);     // ������λ���� ...... 

BYTE* p, *pi=pbi+hc+pc;   // LocBits(pbi); 

RECT re={ 0,0,bi->biWidth, bi->biHeight }; 
if (rc!=0) re=*rc; 
if (re.left<0) re.left = 0;  if (re.top<0)  re.top = 0;
if (re.right>bi->biWidth) re.right=bi->biWidth;  if (re.bottom>bi->biHeight) re.bottom=bi->biHeight; 


BYTE c, t;  BYTE v = 0xFF, V = 0;  BYTE H[256]; memset(H,0,256);  // 256 = 0xFF+1 

for( int i=re.top; i<re.bottom; i++ ){  

p=pi+i*wb + re.left*bi->biBitCount/8;  // �� i �� j ��  

for( int j=re.left; j<re.right; j++ ){

c = *p++;  H[c]++; 

if (v>c) v=c;
if (V<c) V=c; 

if ( bi->biBitCount > 8 ){ p++; } // t=*p++; assert(t==c); 
if ( bi->biBitCount > 16 ){ p++; }  // t=*p++;  assert(t==c); }

}  // for j  
}  // for i 


int cri=0; 

qTrace("v=%d, V=%d",v,V);

#if HIST_CENTER|1

BYTE  m1,m2;  //��ֵ�����Ҷ�ֵ����С�Ҷ�ֵ�����������ƽ���Ҷ�ֵ
long lP1,lS1, lP2,lS2;		// ���ڼ�������Ҷ�ƽ��ֵ���м����	

BYTE iThr = 0,  iNThr = (v + V)/2;   

for(int Iter = 0; iThr != iNThr &&Iter < 100; Iter ++){   // �����������ֵ 	

iThr = iNThr;

lP1 =lP2 =lS1 = lS2 = 0;

for (int i = v;i < iThr;i++){ lP1 += H[i]*i;  lS1 += H[i]; }  // ����������ĻҶ�ƽ��ֵ
m1 = (unsigned char)(lP1 / lS1);

for (int i = iThr+1;i < V;i++) { lP2 += H[i]*i;  lS2 += H[i]; }
m2 = (unsigned char)(lP2 / lS2);

iNThr =  (m1 + m2)/2;

}

cri= iThr; 


#else


int SHG=0, SH=0; 

for (int g=0; g<=0xFF; g++){
	SHG += H[g]*g;
	SH += H[g]; 
}  // for g 

if(SH>0) cri = (float)SHG/SH;  

#endif  // HISTO_CENTER

qTrace("cri=%d", cri);
return cri;
}





int dipr_sp(BYTE*pbi, RECT*rc, BYTE*pSrc, int g){


if (!pbi) return 0;  

LPBITMAPINFOHEADER bi= (LPBITMAPINFOHEADER)pbi;  

int wb  = ((bi->biWidth*bi->biBitCount/8+3)/4)*4;  //  WIDTHBYTES(bi->biWidth*bi->biBitCount);  //  int rwb =  ((bi->biWidth + 31) / 32 * 4);   
int bc = bi->biHeight*wb;  
int hc= sizeof(BITMAPINFOHEADER);      // sizeof(BITMAPFILEHEADER) + 
int clrUsed=bi->biClrUsed;  if (clrUsed == 0) clrUsed = (1<<bi->biBitCount);  // pow(2, bi->biBitCount);  // math.h 
if (bi->biBitCount>8) clrUsed=0;  
int pc = clrUsed *sizeof(RGBQUAD);     // assert( bi->biClrUsed==256);  //RGBQUAD* pal = (RGBQUAD*)(pbi+hc);     // ������λ���� ...... 

BYTE* p, *q, *pi=pbi+hc+pc;   // LocBits(pbi); 
BYTE* cpi=pSrc+hc+pc;  
if (!pSrc)  cpi=pbi+hc+pc; 

RECT re={ 0,0,bi->biWidth, bi->biHeight }; 
if (rc!=0) re=*rc; 
if (re.left<0) re.left = 0;  if (re.top<0)  re.top = 0;
if (re.right>bi->biWidth) re.right=bi->biWidth;  if (re.bottom>bi->biHeight) re.bottom=bi->biHeight; 

if (g == -1) g = dib_cri(pbi,rc); 
if (g<0) g = 0;  if (g>0xFF) g=0xFF; 


BYTE c;   // qTrace("g=%d", g);

for( int i=re.top; i<re.bottom; i++ ){  

p=cpi+i*wb + re.left*bi->biBitCount/8;  
q=pi+i*wb + re.left*bi->biBitCount/8;  // �� i �� j ��  

for( int j=re.left; j<re.right; j++ ){

c = *p++;   
 
if ( bi->biBitCount > 8 ){ p++; } // t=*p++; assert(t==c); 
if ( bi->biBitCount > 16 ){ p++; }  // t=*p++;  assert(t==c); }

if (c<g) c=0; 
if (c>g) c=0xFF;



*q++=c; 
if ( bi->biBitCount > 8 ){ *q++=c; } // t=*p++; assert(t==c); 
if ( bi->biBitCount > 16 ){ *q++=c; }  // t=*p++;  assert(t==c); }

}  // for j  
}  // for i 


return 1; 
}



// ���Ź���
bool dipr_Equ(DWORD c, DWORD co, int er){  // =0
if (c==co) return true;

BYTE r=c&0xFF , ro= co&0xFF; 
BYTE g=(c>>8)&0xFF , go= (co>>8)&0xFF; 
BYTE b=(c>>16)&0xFF , bo= (co>>16)&0xFF; 

//int er=1; 

if (
(r>=ro-er && r<= ro+er) &&
(g>=go-er && g<= go+er) &&
(b>=bo-er && b<= bo+er)
) return true; 


return false; 
}


// x-�����б�, y-�����б�
int dipr_expand(BYTE*pbi, RECT*rc, BYTE*pSrc, int x, int y){

if (!pbi) return 0;  

LPBITMAPINFOHEADER bi= (LPBITMAPINFOHEADER)pbi;  // if (bi->biBitCount != 24) { MessageBox(0,"Ŀǰ��֧��24λ���ͼ",0,0); return 0L; }
 
y=bi->biHeight-y;
if ( x < 0 || x >=bi->biWidth || y < 0 || y >=bi->biHeight)  { qTrace("pt (%d, %d) / [%d,%d]", x,  y, bi->biWidth, bi->biHeight); return 0; }

RECT re={ 0,0,bi->biWidth, bi->biHeight }; 
if (rc!=0) re=*rc; 
if (re.left<0) re.left = 0;  if (re.top<0)  re.top = 0;
if (re.right>bi->biWidth) re.right=bi->biWidth;  if (re.bottom>bi->biHeight) re.bottom=bi->biHeight; 

//qTrace("[%d, %d,  %d,%d]/[%d, %d]", re.left, re.top, re.right, re.bottom,bi->biWidth, bi->biHeight);

int wb  =  ((bi->biWidth*bi->biBitCount/8+3)/4)*4;  // WIDTHBYTES(bi->biWidth*bi->biBitCount); // 4-bytes aligning  
int bc = bi->biHeight*wb;  
int hc = sizeof(BITMAPINFOHEADER);   // +sizeof(BITMAPFILEHEADER);
int pc = bi->biClrUsed *sizeof(RGBQUAD);   // assert( bi->biClrUsed==0);
int mc = hc+pc+bc; 


BYTE* pi=pbi+hc+pc, b,g,r;   // LocBits(pbi); 
const BYTE* cpi=pSrc+hc+pc;  



#if GROW_COLOR|1

b  = *(cpi + y*wb + x*bi->biBitCount/8),
g  = *(cpi + y*wb + x*bi->biBitCount/8 +1 ),
r  = *(cpi + y*wb + x*bi->biBitCount/8 +2 );    // getPixel  

if (bi->biBitCount<24) r=b; 
if (bi->biBitCount<16){ r=b, g=b; }


DWORD c=0, co = r| (g << 8) | (b << 16) ; 

*( pi + y*wb + x*bi->biBitCount/8 ) = b; 
if(bi->biBitCount>8)  *( pi + y*wb + x*bi->biBitCount/8 + 1 ) = g; 
if(bi->biBitCount>16) *( pi + y*wb + x*bi->biBitCount/8 + 2 ) = r;     // ��һ������ 


int iC=1, ic=0;  

int iLoop=0;  

do{

// InvalidateRect(pa->hWnd_TR,0,1);   // ���� pbi �ǵ�ǰ��ʾ�� DIB ʱ������ 

ic=0;   //  ic ����Ϊ0, ��ζ����Ҳû�п������ӵ��� 

 

for( int i=re.top; i<re.bottom; i++ ){            // �����ڽ����� i--iy, j--ix

//BYTE* dp=pi+ i*wb;   // ָ��� i �� 
//const BYTE* sp=cpi+i*wb; 
 
for(int j=re.left; j<re.right; j++ ){


b  = *(cpi + i*wb + j*bi->biBitCount/8),
g  = *(cpi + i*wb + j*bi->biBitCount/8 +1 ),
r  = *(cpi + i*wb + j*bi->biBitCount/8 +2 );   

if (bi->biBitCount<24) r=b; 
if (bi->biBitCount<16){ r=b, g=b; }


c = r| (g << 8) | (b << 16) ; 

// if(j==x && i==y) qTrace("b=%X, g=%X, r=%X,  c=%X, co=%X, i=%d, j=%d", b,g,r, c,co, i,j)


//if (c!=co)  continue; 
if (!dipr_Equ(c,co)) continue; 
 

b  = *(pi + i*wb + j*bi->biBitCount/8);
g  = *(pi + i*wb + j*bi->biBitCount/8 +1 );
r  = *(pi + i*wb + j*bi->biBitCount/8 +2 );   

if (bi->biBitCount<24) r=b; 
if (bi->biBitCount<16){ r=b, g=b; }

c = r| (g << 8) | (b << 16) ; 

//if (c==co) continue; 
if (dipr_Equ(c,co)) continue; 






#if READ_PIXELS |1  // ��ȡ�ڽ��� 9 ������  

int jc=0; 

for (int v=-1; v<2; v++){

jc=0; 

for (int u=-1; u<2; u++){

if (i+v<re.top || i+v>re.bottom) continue; 
if (j+u<re.left || j+u>re.right) continue; 

b  = *(pi + (i+v)*wb + (j+u)*bi->biBitCount/8),
g  = *(pi + (i+v)*wb + (j+u)*bi->biBitCount/8 +1),
r  = *(pi + (i+v)*wb + (j+u)*bi->biBitCount/8 +2);    // getPixel  

if (bi->biBitCount<24) r=b; 
if (bi->biBitCount<16){ r=b, g=b; }


c = r| (g << 8) | (b << 16) ; 

//if (c == co) {
if (dipr_Equ(c,co)) {   

*(pi + i*wb + j*bi->biBitCount/8) = b;
if (bi->biBitCount>8) *(pi + i*wb + j*bi->biBitCount/8 +1) = g;
if (bi->biBitCount>16) *(pi + i*wb + j*bi->biBitCount/8 +2) = r;    

iC++;  ic++; jc++; 
break; 
}  // if c==co   

}  // for u  

if (jc>0) break; 
}  // for v

#endif  // READ_PIXELS



// sp+=3; dp+=3; 
}  // for j  
 
}  // for i 




// HDC hdc = GetDC(pa->hWnd_TR);  \
RECT rc; GetClientRect(pa->hWnd_TR, &rc);   \
char sz[128];    \
int it = sprintf(sz, "%X (%d,%d), ic=%d, iC=%d, iLoop=%d", co,   x, bi->biHeight-y, ic, iC, iLoop++);   \
TextOut(hdc, 0,rc.bottom-32,sz,it);  \
ReleaseDC(pa->hWnd_TR, hdc); 

// Sleep(10); 


} while (ic>0); 


#endif  // GROW_COLOR


return 1; 
}

















// PaintDIB ����StretchDIBits ��  SetDIBitsToDevice  ���� DIB ���� 

// rs��rd ָ��ԭ��Ŀ�ľ�������. 0L ��ʾĬ�����, ԭͼ���Ƶ������û�����   

// pBits = LocBits(pDIB)  

void drawPixels(HDC hdc, BYTE*pDib, RECT*rd,  RECT*rs){  // =0 =0  
if(pDib==NULL)return; 

int w=BiWidth(pDib), h=BiHeight(pDib); 
int wb= (w*8 +31)/32*4;   


RECT rc[2];

if (rd == 0){ GetClientRect(WindowFromDC(hdc), rc);  rd =&rc[0];} 
if (!rs) { rc[1]= { 0,0, w, h };  rs=&rc[1]; }



if (rs->left<0) rs->right-=rs->left,  rs->left=0;   
if (rs->right>w) rs->left-=(rs->right-w),  rs->right=w;   

if (rs->top<0) rs->bottom-=rs->top,  rs->top=0;   
if (rs->bottom>h) rs->top-=(rs->bottom-h),  rs->bottom=h;   
 
//if(rs->left==0 && rs->bottom==h) qTrace("rs->top=%d, rs->bottom =%d",rs->top, rs->bottom);

HPEN hPenO=0, hPen = (HPEN)GetStockObject(DC_PEN);  
HPEN hPenDot = CreatePen(PS_DOT, 0, 0); 

hPenO = (HPEN)SelectObject(hdc,hPenDot); 

float cws=rs->right-rs->left ;
float chs=rs->bottom-rs->top ; 
//if (cws<=0 || chs<=0) return; 

//if (cws<1)  cws=1;   if (chs<1)  chs=1;  

float cwd=rd->right-rd->left, chd=rd->bottom-rd->top; 

float dx= cwd / cws, dy= chd / chs;  // ��ʱ�� rd ��ʾλͼѡ������ rs  

float xo=rd->left, x=rd->right;   // ������ float, ���������! 
float yo=rd->top,  y=rd->bottom; 

y=yo; 

//while(yo<rd->bottom){
for (int i=rs->top; i<=rs->bottom; i++){ 
MoveToEx(hdc, xo, yo, 0L); LineTo(hdc,x,y);   // �С����� 
yo += dy, y = yo;   // if (i == rs->bottom) qTrace("yo=%d, rd->bottom=%d", yo, rd->bottom); 
}

yo=rd->top,  y=rd->bottom; 
xo=rd->left,  x=xo;

for (int j=rs->left; j<=rs->right; j++){
MoveToEx(hdc, xo, yo, 0L); LineTo(hdc,x,y);   // �С����� 
xo+=dx,  x=xo;
}  // for j   


//SelectObject(hdc,hPenO);  return; 


HBRUSH hBrush = (HBRUSH)GetStockObject(DC_BRUSH);  


BYTE c, * pBits = LocBits(pDib); 
RECT rcb; 

//   //  (i=h-1; i>0; i--) λͼ���µߵ�  

for (int i=rs->top; i<rs->bottom; i++){ 
//for (int i=rs->bottom-1; i>=0; i--){ 

rcb.top=rd->top +  (i-rs->top) *dy+1;  rcb.bottom=rcb.top+dy-1; 
//rcb.top=rd->top + ( rs->bottom-1  -  ( i-rs->top) )*dy+1;  rcb.bottom=rcb.top+dy-1; 
//rcb.bottom=rd->top + ( rs->bottom-1  -  ( i-rs->top) )*dy-1;  rcb.top=rcb.bottom-dy+1; 

for (int j=rs->left; j<rs->right; j++){
c = *(pBits + (h-1-i)*wb + j);  
SetDCBrushColor(hdc,c|(c<<8)|(c<<16)); 

rcb.left=rd->left+ (j-rs->left)*dx+1;  rcb.right=rcb.left+dx -1; 

FillRect(hdc,&rcb,hBrush); 
// SetPixel(hdc, (rcb.left + rcb.right)/2, (rcb.top+rcb.bottom)/2, c); 

}  // for j   

}  // for i  





#if SHOW_RECT|1


SelectObject(hdc,hPen);

dx= cwd / w,  dy= chd / h;  // ��ʱ�� rd ��ʾ����λͼ��С, ��ʾѡ������ rs  
xo=rd->left, x=rd->right;
yo=rd->top,  y=rd->bottom; 

SetDCPenColor(hdc,0xFF0000); 
//Rectangle(hdc, xo-2,yo-2, x+2, y+2); 
MoveToEx(hdc, xo - 2, yo - 2, 0);  LineTo(hdc, xo-2,y+2); 
LineTo(hdc, x+2,y+2);  LineTo(hdc, x+2,yo-2); LineTo(hdc, xo-2,yo-2);

xo = rd->left + rs->left*dx;   x= rd->left + rs->right*dx; 

yo=rd->top+ rs->top*dy ;  y= rd->top+ rs->bottom*dy ; 
// yo=rd->top+ (h-rs->top)*dy;  y = rd->top+ (h-rs->bottom)*dy; 


SetDCPenColor(hdc,0x0000FF); 
//Rectangle(hdc, xo-1,yo-1, x+1, y+1); 
MoveToEx(hdc, xo - 1, yo - 1, 0);  LineTo(hdc, xo-1,y+1);  
LineTo(hdc, x+1,y+1);  LineTo(hdc, x+1,yo-1); LineTo(hdc, xo-1,yo-1);

// SelectObject(hdc,hPenO);  return; 

#endif  // SHOW_RECT 


if(hPenO) SelectObject(hdc,hPenO); 
return;
}














// https://www.cnblogs.com/wd1001/p/4571163.html



// ��ͨ... ColorProcess,  Change DIB color table from color to grayscale
// nMethod=0 WEIGHT_GRAY,  1 MEAN_GRAY,  2 MAXIMUM_GRAY


// ���� 256 �Ҷ�ͼ�洢��ַ 

BYTE* mk256(LPBYTE pbi, int nMethod, double* w_rgb){  // =0=0
if (pbi == NULL) return false;

// ׼�� 256�Ҷ�ͼ���  

LPBITMAPINFOHEADER bi= (LPBITMAPINFOHEADER)pbi;  

if (bi->biBitCount != 24) {MessageBox(0,"Ŀǰ��֧��24λ���ͼ",0,0); return 0L;}


// 4-bytes aligning  

int wb  =  ((bi->biWidth*bi->biBitCount/8+3)/4)*4;  // WIDTHBYTES(bi->biWidth*bi->biBitCount);  //  bi->biBitCount = 24   
int rwb =  ((bi->biWidth*1+3)/4) *4;  // WIDTHBYTES(bi->biWidth*8);  //               // Bytes -- 8 λ�Ҷ�ͼ, ÿһ������ 1 Byte  

int bc = bi->biHeight*wb;  
int rbc= bi->biHeight*rwb;  
int hc= sizeof(BITMAPINFOHEADER);  // +sizeof(BITMAPFILEHEADER);
int pc = bi->biClrUsed *sizeof(RGBQUAD);   assert( bi->biClrUsed==0);
int rpc=256*sizeof(RGBQUAD); 

BYTE*pr = (BYTE*)malloc(hc+rpc+rbc); 

LPBITMAPINFOHEADER rbi=(LPBITMAPINFOHEADER)pr; 


// qTrace("bi->biClrUsed=%d, bi->biWidth=%d, bc=%d, 3*rbc=%d", bi->biClrUsed, bi->biWidth, bc/1024, 3*rbc/1024 );  // rbc = 3* bc
// qTrace("wb=%d, 3*rwb=%d", wb, 3*rwb );  // ÿ�ж�� 4 �ֽ�


// �޸�ͷ��Ϣ

//fi->biBitCount=8;
//fi->biSizeImage=( (fi->biWidth*3+3)/4 ) * 4*fi->biHeight;
//fi->biClrUsed=256;
     
//fh->bfOffBits = sizeof(fileHeader)+sizeof(fileInfo)+256*sizeof(rgbq);
//fh->bfSize = fh->bfOffBits + fi->biSizeImage;

*rbi = *bi;  
rbi->biBitCount=8; 
rbi->biClrUsed=256;  
rbi->biSizeImage=rbc;  

RGBQUAD* rgbv = (RGBQUAD*)(pr+sizeof(BITMAPINFOHEADER));
for (int i = 0; i<256; i++) { rgbv[i].rgbRed=rgbv[i].rgbGreen=rgbv[i].rgbBlue=i;  rgbv[i].rgbReserved=0; }

BYTE*rpi=pr+hc+rpc; 
BYTE* pi=pbi+hc+pc;   // LocBits(pbi); 
    
 


//for( int i=0; i<bc/3; i++ ){   // ÿ���ֽ���δ����ͬ ! 
for( int i=0; i<bi->biHeight; i++ ){

BYTE*sp=pi+ i*wb;   // ָ��� i �� 
BYTE*rp=rpi+ i*rwb;

for( int j=0; j<bi->biWidth; j++ ){

BYTE r=*sp++, g=*sp++, b=*sp++;  


switch (nMethod){

case 0:  // WEIGHT_GRAY 
*rp++=  ( (306*r+601*g+117*b)>>10 ); 
break; 

case 1:  // MEAN_GRAY 
*rp++=  (r+g+b)/3 ; 
break; 

case 2:  // MAXIMUM_GRAY 
*rp++=  maxi( r,g,b ); 
break; 


default:
*rpi++=  ( (306*r+601*g+117*b)>>10 ); 
break;
}


}  // for j  
 
}  // for i 

return pr;
}



 


// ����˫ɫ8λλͼ�洢��ַ 

BYTE* c256_01(LPBYTE pbi, int cri ){  // cri = threshold = 128
if (pbi == NULL) return false;

// ׼����ɫλͼ���  

LPBITMAPINFOHEADER bi= (LPBITMAPINFOHEADER)pbi;  
if (bi->biBitCount != 8) {MessageBox(0,"Ŀǰ��֧��8λ�Ҷ�ͼ",0,0); return 0L;}

//bi->biClrUsed=2;  // 0��0xFF


// 4-bytes aligning  

int wb  =  ((bi->biWidth*bi->biBitCount/8+3)/4)*4;  // WIDTHBYTES(bi->biWidth*bi->biBitCount);  //  bi->biBitCount = 8  
// int rwb =  ((bi->biWidth + 31) / 32 * 4);  // ((bi->biWidth*1+3)/4) *4;  // WIDTHBYTES(bits);   //  Bytes -- 1 λͼ, ÿ������ 1 bit  

int bc = bi->biHeight*wb;  
int rbc= bc;  
int hc= sizeof(BITMAPINFOHEADER);  // +sizeof(BITMAPFILEHEADER);
int pc = 256 *sizeof(RGBQUAD);     // assert( bi->biClrUsed==256);
int rpc= 2*sizeof(RGBQUAD); 

BYTE*pr = (BYTE*)malloc(hc+rpc+rbc); 

LPBITMAPINFOHEADER rbi=(LPBITMAPINFOHEADER)pr; 

// qTrace("bi->biClrUsed=%d, bi->biWidth=%d, bc=%d, 3*rbc=%d", bi->biClrUsed, bi->biWidth, bc/1024, 3*rbc/1024 );  // rbc = 3* bc
// qTrace("wb=%d, 3*rwb=%d", wb, 3*rwb );  // ÿ�ж�� 4 �ֽ�


// �޸�ͷ��Ϣ
      
*rbi = *bi;  
//rbi->biBitCount=1; 
rbi->biClrUsed=2;  
rbi->biSizeImage=rbc;  

// fh->bfOffBits = sizeof(fileHeader)+sizeof(fileInfo)+256*sizeof(rgbq);
// fh->bfSize = fh->bfOffBits + fi->biSizeImage;

RGBQUAD* rgbv = (RGBQUAD*)(pr+hc);
//for (int i = 0; i<rbi->biClrUsed; i++) { rgbv[i].rgbRed=rgbv[i].rgbGreen=rgbv[i].rgbBlue=i;  rgbv[i].rgbReserved=0; }
rgbv[0].rgbRed=rgbv[0].rgbGreen=rgbv[0].rgbBlue=0;      rgbv[0].rgbReserved=0; 
rgbv[1].rgbRed=rgbv[1].rgbGreen=rgbv[1].rgbBlue=0xFF;   rgbv[1].rgbReserved=0; 

BYTE* pi=pbi+hc+pc;   // LocBits(pbi); 
BYTE*rpi=pr+hc+rpc; 
    
//for( int i=0; i<bc/3; i++ ){   // ÿ���ֽ���δ����ͬ ! 
for( int i=0; i<bi->biHeight; i++ ){

BYTE*sp=pi +  i*wb;      // ָ��� i �� 
BYTE*rp=rpi + i*wb; 

for( int j=0; j<bi->biWidth; j++ ){

BYTE r=*sp++;  // =g=b   

//if(r>cri)  rp[j/8] |= (1<<(j%8));        
*rp++=(r>cri)? 0xFF:0;             

}  // for j  
 
}  // for i 

return pr;
}









// ���ص�ɫͼ�洢��ַ 

BYTE* mk01(LPBYTE pbi, int cri ){  // cri = threshold = 128
if (pbi == NULL) return false;

// ׼����ɫλͼ���  

LPBITMAPINFOHEADER bi= (LPBITMAPINFOHEADER)pbi;  
if (bi->biBitCount != 8) {MessageBox(0,"Ŀǰ��֧��8λ�Ҷ�ͼ",0,0); return 0L;}


bi->biClrUsed=256; 


// 4-bytes aligning  

int wb  =  ((bi->biWidth*bi->biBitCount/8+3)/4)*4;  // WIDTHBYTES(bi->biWidth*bi->biBitCount);  //  bi->biBitCount = 8  
int rwb =  ((bi->biWidth + 31) / 32 * 4);  // ((bi->biWidth*1+3)/4) *4;  // WIDTHBYTES(bits);   //  Bytes -- 1 λͼ, ÿ������ 1 bit  

int bc = bi->biHeight*wb;  
int rbc= bi->biHeight*rwb;  
int hc= sizeof(BITMAPINFOHEADER);  // +sizeof(BITMAPFILEHEADER);
int pc = bi->biClrUsed *sizeof(RGBQUAD);   assert( bi->biClrUsed==256);
int rpc=2*sizeof(RGBQUAD); 

BYTE*pr = (BYTE*)malloc(hc+rpc+rbc); 

LPBITMAPINFOHEADER rbi=(LPBITMAPINFOHEADER)pr; 


// qTrace("bi->biClrUsed=%d, bi->biWidth=%d, bc=%d, 3*rbc=%d", bi->biClrUsed, bi->biWidth, bc/1024, 3*rbc/1024 );  // rbc = 3* bc
// qTrace("wb=%d, 3*rwb=%d", wb, 3*rwb );  // ÿ�ж�� 4 �ֽ�


// �޸�ͷ��Ϣ
      
*rbi = *bi;  
rbi->biBitCount=1; 
rbi->biClrUsed=2;  
rbi->biSizeImage=rbc;  

// fh->bfOffBits = sizeof(fileHeader)+sizeof(fileInfo)+256*sizeof(rgbq);
// fh->bfSize = fh->bfOffBits + fi->biSizeImage;

RGBQUAD* rgbv = (RGBQUAD*)(pr+sizeof(BITMAPINFOHEADER));
//for (int i = 0; i<rbi->biClrUsed; i++) { rgbv[i].rgbRed=rgbv[i].rgbGreen=rgbv[i].rgbBlue=i;  rgbv[i].rgbReserved=0; }
rgbv[0].rgbRed=rgbv[0].rgbGreen=rgbv[0].rgbBlue=0;      rgbv[0].rgbReserved=0; 
rgbv[1].rgbRed=rgbv[1].rgbGreen=rgbv[1].rgbBlue=0xFF;   rgbv[1].rgbReserved=0; 

BYTE*rpi=pr+hc+rpc; 
BYTE* pi=pbi+hc+pc;   // LocBits(pbi); 
    
//for( int i=0; i<bc/3; i++ ){   // ÿ���ֽ���δ����ͬ ! 
for( int i=0; i<bi->biHeight; i++ ){

BYTE*sp=pi+ i*wb;      // ָ��� i �� 
BYTE*rp=rpi+ i*rwb;
for( int j=0; j<rwb; j++ ){  // ע�� 1. д���ֽ���������ȷ  

BYTE c =0xFF;  // 0; //   // Ĭ�ϰ�/��ɫ


for (int k = 0; k < 8; k++){
//int x=j*8+k; 
//if (i < ch - 4 && i>4){   if ( x<cw-20 && x>20 ) c |=  (1<<(7-k));  }
BYTE r=*sp++;  // =g=b   
//if(r>cri)  rp[j/8] |= (1<<(j%8));      // ע�� 2. �洢�ֽ�ֵ��λ�ں�!  �� j �� bit �� 1 
if(r<cri)  c &= ~(1<<((7-k)%8));       // �� j �� bit �� 0
}  // for k 

rp[j]= c; 

}  // for j  
 
}  // for i 

return pr;
}








// ����8λ��ɫͼ�洢��ַ 

BYTE* cv801(LPBYTE pbi, int cri ){  // cri = threshold = 128
if (pbi == NULL) return false;

// ׼����ɫλͼ���  

LPBITMAPINFOHEADER bi= (LPBITMAPINFOHEADER)pbi;  
if (bi->biBitCount != 8) {MessageBox(0,"Ŀǰ��֧��8λ�Ҷ�ͼ",0,0); return 0L;}

int clrUsed=bi->biClrUsed;
if (clrUsed==0) clrUsed=256; 


// 4-bytes aligning  

int wb  =  ((bi->biWidth*bi->biBitCount/8+3)/4)*4;  // WIDTHBYTES(bi->biWidth*bi->biBitCount);  //  bi->biBitCount = 8  

int bc = bi->biHeight*wb;  
int hc= sizeof(BITMAPINFOHEADER);  // +sizeof(BITMAPFILEHEADER);
int pc = clrUsed *sizeof(RGBQUAD);    

RGBQUAD* pal = (RGBQUAD*)(pbi+sizeof(BITMAPINFOHEADER));

BYTE* pi=pbi+hc+pc;   // LocBits(pbi); 
int v=0; 
    
for( int i=0; i<bi->biHeight; i++ ){

for( int j=0; j<wb; j++ ){  // ע�� 1. д���ֽ���������ȷ  
v = pi[i*bi->biWidth+j];
v = pal[v%clrUsed].rgbBlue;
if (v>cri) pi[i*bi->biWidth+j]=clrUsed-1; 
else       pi[i*bi->biWidth+j]=0; 
}  // for j  
 
}  // for i 

return pbi;
}















// ���� 101��20 ��8-λͼ, ��ɫΪ  0x8E �� 0xA  

bool t_mk8(const wchar_t*szFile, int cw, int ch, int px0, int px1){  // =101  =20  =0xA  =0x8E


if (!szFile) return false; 

FILE*fp = _wfopen(szFile, L"wb");  if (!fp) { MessageBoxW(0,szFile,L"δ�ܴ�",0); return false; }

BITMAPFILEHEADER fh = {0x4D42, 0,  0,0,  0, };  // bfSize,  bfOffBits 
BITMAPINFOHEADER fi = { sizeof(fi), cw,ch,1,  8, BI_RGB,  
0,     0, 0,      // biSizeImage 
2,     0,         // biClrUsed, biClrImportant
};  


qTrace("sizeof(fh)=%d, fi.biClrUsed=%d, fi.biBitCount=%d", sizeof(fh), fi.biClrUsed, fi.biBitCount); 

int wb= (cw*fi.biBitCount+31)/32 *4; 
fi.biSizeImage=ch*wb;   

fh.bfOffBits=sizeof(fh)+sizeof(fi)+sizeof(RGBQUAD)*fi.biClrUsed; 
fh.bfSize = fh.bfOffBits + fi.biSizeImage;  

int ir = fwrite(&fh, sizeof(fh), 1, fp);  assert(ir==1); 
ir=fwrite(&fi, sizeof(fi),1, fp); assert(ir==1); 

RGBQUAD bgrv = {px0,px0,px0,0};  // {0,0,0,0};
ir=fwrite(&bgrv, sizeof(RGBQUAD),1, fp);  assert(ir==1);    

bgrv = {(BYTE)px1,(BYTE)px1,(BYTE)px1,0};  // {0xFF,0xFF,0xFF,0};
ir=fwrite(&bgrv, sizeof(RGBQUAD),1, fp);  assert(ir==1);    

BYTE c=0; 
for (int i = 0; i<ch; i++){
for (int j = 0; j<wb; j++){

c=  0; 
if (i < ch - 4 && i>4){ 
c=  0; 
if ( (j<cw - 20 && j>20) ) c= 1;
}

ir=fwrite(&c, 1,1, fp);   

}} 


fclose(fp); 
return true; 
}



// ���� 101��20 �� 1-λͼ, ��ɫΪ  0x8E �� 0xA  

bool t_mk01(const wchar_t*szFile, int cw, int ch, int px0, int px1){  // =101  =20  =0xA  =0x8E


if (!szFile) return false; 

FILE*fp = _wfopen(szFile, L"wb");  if (!fp) { MessageBoxW(0,szFile,L"δ�ܴ�",0); return false; }

BITMAPFILEHEADER fh = {0x4D42, 0,  0,0,  0, };  // bfSize,  bfOffBits 
BITMAPINFOHEADER fi = { sizeof(fi), cw,ch,1,  1, BI_RGB,  
0,     0, 0,      // biSizeImage 
2,     0,         // biClrUsed, biClrImportant
};  


//qTrace("sizeof(fh)=%d, fi.biClrUsed=%d, fi.biBitCount=%d", sizeof(fh), fi.biClrUsed, fi.biBitCount); 


int wb= (cw*fi.biBitCount+31)/32 *4; 
fi.biSizeImage=ch*wb;  
 
qTrace("cw=%d, wb=%d ", cw, wb); 


fh.bfOffBits=sizeof(fh)+sizeof(fi)+sizeof(RGBQUAD)*fi.biClrUsed; 
fh.bfSize = fh.bfOffBits + fi.biSizeImage;  

int ir = fwrite(&fh, sizeof(fh), 1, fp);  assert(ir==1); 
ir=fwrite(&fi, sizeof(fi),1, fp); assert(ir==1); 

RGBQUAD bgrv = {0,0,0,0};
ir=fwrite(&bgrv, sizeof(RGBQUAD),1, fp);  assert(ir==1);    

bgrv = {0xFF,0xFF,0xFF,0};
ir=fwrite(&bgrv, sizeof(RGBQUAD),1, fp);  assert(ir==1);    

BYTE c=0; 
for (int i = 0; i<ch; i++){


for (int j = 0; j<wb ; j++){
c=  0; 
	
for (int k = 0; k < 8; k++){
int x=j*8+k; 
if (i < ch - 4 && i>4){   if ( x<cw-20 && x>20 ) c |=  (1<<(7-k));  }
}  // for k 
 
ir=fwrite(&c, 1,1, fp);  

}  // for i 

}  // for j 


fclose(fp); 
return true; 
}




// ��ȡ 0-based y �� x �е�����ֵ.  
inline 
RGBQUAD getPixel(BYTE*pDib, int x, int y){
RGBQUAD bgr = {0,0,0,  0}; 
if (!pDib) return bgr; 
if (x<0 || y<0) return bgr; 

BYTE*pi = pDib+*(DWORD*)pDib;   // LocBits(pDib);  // ֧�����ָ�ʽ 
pi += PalSize(pDib); 


LPBITMAPINFOHEADER pbi = (LPBITMAPINFOHEADER)pDib;  // ������ WIN 3.0 �ĸ�ʽ

if (y>=pbi->biHeight) return bgr; 

y=pbi->biHeight-1-y;  // ԭ�� y=pbi->biHeight-y Ӧ���Ǵ���  

int wb =  (pbi->biWidth* pbi->biBitCount +31)/32*4;   


RGBQUAD* pal=0; 
BYTE* px=0; 

switch (pbi->biBitCount){

case 1:{  // ����ɫ�� 
int clrUsed=pbi->biClrUsed; 
if (clrUsed == 0) clrUsed = 2;  
pal = (RGBQUAD*)(pDib + *(DWORD*)pDib);  // qTrace("0x%X, 0x%X", *(DWORD*)pal, *( (DWORD*)pal+1) );


px= pi+y*wb+x/8;    // ÿ8������ 1 �ֽڵ���ɫ����
int id = ( (*px)&(1 << (7 - x % 8)) ) >> (7 - x % 8) ;  
// if (id>0) id=1; 
bgr=pal[ id %2 ]; 

}break; 


case 4:{  // To be continued. 


}break; 


case 8:{  // ����ɫ�� 
int clrUsed = pbi->biClrUsed;  // qTrace("clrUsed=%d", clrUsed); 
if (clrUsed==0) clrUsed=256; 
pal=(RGBQUAD*)(pDib + *(DWORD*)pDib); 

px= pi+y*wb+x;    // ÿ������ 1 �ֽڵ���ɫ����
int id=*px;  

bgr=pal[id%clrUsed]; 

}break;


case 24:{  // ����ɫ�� 
px= pi+y*wb+x*3;    // ÿ������ 3 �ֽ�

bgr.rgbBlue=*px++; 
bgr.rgbGreen=*px++; 
bgr.rgbRed=*px++; 
}break; 


default: MessageBox(0,"Ŀǰ��֧�� 1��4��8��24 λ��ʽ",0,0); break; 
}


return bgr; 
}


// ��ȡ 0-based y �� x �е�����ֵ. ������ 8-bit λͼ   
inline 
BYTE getPixel8(BYTE*pDib, int x, int y){

if (!pDib) return 0; 
if (x<0 || y<0) return 0; 

BYTE*pi = pDib+*(DWORD*)pDib;   // LocBits(pDib);  // ֧�����ָ�ʽ 
pi += PalSize(pDib); 


LPBITMAPINFOHEADER pbi = (LPBITMAPINFOHEADER)pDib;  // ������ WIN 3.0 �ĸ�ʽ

if (y>=pbi->biHeight) return 0; 

y=pbi->biHeight-1-y;  


int wb =  (pbi->biWidth* pbi->biBitCount +31)/32*4;   


RGBQUAD* pal=0; 
BYTE *px=0; 
 
//int clrUsed = pbi->biClrUsed;  \
if (clrUsed==0) clrUsed=256;     \
pal=(RGBQUAD*)(pDib + *(DWORD*)pDib); 

px= pi+y*wb+x;    // ÿ������ 1 �ֽڵ���ɫ���� --  ������ɫ��, ��ʹ������ֵ, ��Ϊ�Ҷ�ֵ  

// bgr=pal[id%clrUsed]; 

return *px; 
}



// ��ʾ���������ֵ -- �� drawDib �й� 
// 
void vBit24(HDC hdc, BYTE*pDib, RECT*rd,  RECT*rs){  //, HPALETTE hPal =0L  =0L  =0L 

RECT rc[2];
HWND hWnd=WindowFromDC(hdc); 

if (rd == 0){ GetClientRect(hWnd, rc);  rd =&rc[0];} 

POINT pt;            // ��Ļ����. GDI �����Ĳ�������������.   
GetCursorPos(&pt);   // �������� po �� g_XFO = pt     
ScreenToClient(hWnd,&pt);

// SetGraphicsMode(hdc,GM_ADVANCED);  
static XFORM g_E={1,0,  0,1,  0,0, };  
static XFORM g_XFO;  GetWorldTransform(hdc,&g_XFO);   // ��Ҫʱ�ָ���ǰ������� 

XFORM xf = matinv(g_XFO); 
POINT po = matx(pt,xf);   // po = pt �� (g_XFO^-1)



COLORREF co=GetPixel(hdc, po.x, po.y);  // 0x00bbggrr // ��Ȼ�� Rectangle Ӱ�� ! LineTo(hdc,po.x,po.y) ��Ӱ��. Ellipse(hdc,po.x-5,po.y-5,po.x+5,po.y+5) ��Ӱ�� 

//SetDCPenColor(hdc,0x0000FF);  // red -- �����ڵ�ǰ����任 -- Ӧ���������غ�      
SetPixel(hdc,po.x,po.y,0x0000FF);  // Rectangle(hdc, po.x-1,po.y-1,po.x+1,po.y+1);   // Rectangle Ӱ�� GetPixel ! 
// SetPixel(hdc,po.x,po.y-1,0x0000FF);  \
SetPixel(hdc,po.x+1,po.y+1,0x0000FF); \
SetPixel(hdc,po.x-1,po.y+1,0x0000FF); 

SetWorldTransform(hdc,&g_E);   // �������任�����Ӱ��  
SetBkMode(hdc,TRANSPARENT);  SetTextColor(hdc, 0xFF0000); 

//SetDCPenColor(hdc,0xFF0000);  // blue -- ������������Ӱ�� -- Ӧ���������غ�     

int s=2; 

// MoveToEx(hdc, pt.x - 2, pt.y - 2, 0L); LineTo(hdc,pt.x-2,pt.y+2);   \
LineTo(hdc,pt.x+2,pt.y+2); LineTo(hdc,pt.x+2,pt.y-2); LineTo(hdc,pt.x-2,pt.y-2);  // ������  

//MoveToEx(hdc, pt.x - 2, pt.y, 0L); LineTo(hdc,pt.x+2,pt.y);   \
MoveToEx(hdc,pt.x,pt.y-4, 0);  LineTo(hdc,pt.x, pt.y+4);   // ��ʮ��  

MoveToEx(hdc, pt.x, pt.y-s, 0L); LineTo(hdc,pt.x-s,pt.y);   \
LineTo(hdc,pt.x,pt.y+s); LineTo(hdc,pt.x+s,pt.y); LineTo(hdc,pt.x,pt.y-s);  // ������  


// Ellipse(hdc, pt.x-2,pt.y-2,pt.x+2,pt.y+2);   // Ellipse �����Ӱ��. ��Ҳ����ʹ�� NULL_BRUSH ʹ֮͸��.
   

int x=20,  y=20, dy=24; 
char szt[128]; 
int
ic=sprintf(szt, "pt(%d,%d) --> po(%d,%d) ", pt.x, pt.y,  po.x,po.y );

TextOut(hdc,x,y, szt,ic); y+=dy;

ic=sprintf(szt, "bgr(%02X, %02X, %02X) ", 0xFF&(co>>16),  0xFF&(co>>8) ,  0xFF&co);


COLORREF c = GetPixel(hdc,x,y);  
c=0xFFFFFF-c; 
SetTextColor(hdc,c); 

TextOut(hdc,x,y, szt,ic);



if(pDib==NULL){ SetWorldTransform(hdc,&g_XFO); return; }


HPEN hPen = (HPEN)GetStockObject(DC_PEN); 
HPEN  hPenO=(HPEN)SelectObject(hdc,hPen); 
HBRUSH hBrush = (HBRUSH)GetStockObject(NULL_BRUSH);
HBRUSH hBrushO=(HBRUSH)SelectObject(hdc, hBrush);  // ��Բ����  




if (!rs) { rc[1]= { 0,0, (long)BiWidth(pDib), (long)BiHeight(pDib) };  rs=&rc[1]; }

XFORM xsd = {1,0,0,1,0,0}; //// mkTransform(*rd,*rs,xsd);  // ������������
POINT pm=matx(po,xsd);

RGBQUAD bgr[9];  // getPixel �� GetPixel ��λ����, �л��п��ܴ� 1 ���� 2  

for (int i = 0; i<9; i++){
bgr[i]= getPixel(pDib,pm.x + i/3,   pm.y + i%3 );   
//bgr[i]=   getPixel(pDib,pm.x + i/3-1,   pm.y + i%3 -1  ); 
}






#if DRAW_PIXEL|1

SetWorldTransform(hdc,&g_E);   SetBkMode(hdc,TRANSPARENT);  SetTextColor(hdc, 0x808080); 

SetDCPenColor(hdc,0xFF0000);  // blue -- ������������Ӱ�� -- Ӧ���������غ�     
Ellipse(hdc, pt.x-3,pt.y-3,pt.x+3,pt.y+3);   // Ellipse 

   

y+=dy;
ic=sprintf(szt, "λͼ���� ");
TextOut(hdc,x,y, szt,ic);

for (int i = 0; i<3; i++){
y+=dy; ic=0; 
for (int j=0; j<3; j++){

c = bgr[i * 3 + j].rgbRed | (bgr[i * 3 + j].rgbGreen << 8) | (bgr[i*3+j].rgbBlue<<16); 

// ic+=sprintf(szt+ic, "(%02X, %02X, %02X)   ",  bgr[i*3+j].rgbBlue,  bgr[i*3+j].rgbGreen, bgr[i*3+j].rgbRed); 
ic+=sprintf(szt+ic, "%06X    ",c); 
}
TextOut(hdc,x,y, szt,ic);
}  // for i 



#endif  // DRAW_PIXEL

 
SetWorldTransform(hdc,&g_XFO);  

SelectObject(hdc, hBrushO); 
SelectObject(hdc,hPenO);

return;
}



// ��ʾ���������ֵ -- ���������� drawDib һ�� 
// 
void vBit8 (HDC hdc, BYTE*pDib, RECT*rd,  RECT*rs){   //, HPALETTE hPal =0L  =0L  =0L 

RECT rc[2];
HWND hWnd=WindowFromDC(hdc); 

if (rd == 0){ GetClientRect(hWnd, rc);  rd =&rc[0];} 
// if (!rs) { rc[1]= { 0,0, BiWidth(pDib), BiHeight(pDib) };  rs=&rc[1]; }

POINT pt; GetCursorPos(&pt);   // GDI ��Ϊ--����Ҳ��Ϊ--���������� -- ��������ֱ����Ϊ GetPixel �Ĳ���   po �� g_XFO = pt, �����Ϊ po     
ScreenToClient(hWnd,&pt);

//SetGraphicsMode(hdc,GM_ADVANCED);  
static XFORM g_E={1,0,  0,1,  0,0, };  
static XFORM g_XFO;  GetWorldTransform(hdc,&g_XFO);   // ��Ҫʱ�ָ���ǰ������� 

XFORM xf = matinv(g_XFO); 
POINT po = matx(pt,xf);   // �ޱ任ʱ��λ��. DC ����. ����ʩ���������任:  po = matx(pt,g_XFO); 

COLORREF co=GetPixel(hdc, po.x, po.y);  // 0x00bbggrr // ��Ȼ�� Rectangle Ӱ�� ! LineTo(hdc,po.x,po.y) ��Ӱ��. Ellipse(hdc,po.x-5,po.y-5,po.x+5,po.y+5) ��Ӱ�� 

//SetDCPenColor(hdc,0x0000FF);  // red -- �����ڵ�ǰ����任 -- Ӧ���������غ�      
SetPixel(hdc,po.x,po.y,0xFF0000);  // Rectangle(hdc, po.x-1,po.y-1,po.x+1,po.y+1);   // Rectangle Ӱ�� GetPixel ! 
// SetPixel(hdc,po.x,po.y-1,0x0000FF);  \
SetPixel(hdc,po.x+1,po.y+1,0x0000FF); \
SetPixel(hdc,po.x-1,po.y+1,0x0000FF); 

SetWorldTransform(hdc,&g_E);  
SetBkMode(hdc,TRANSPARENT);  SetTextColor(hdc, 0xFF0000); 

SetDCPenColor(hdc,0xFF0000);  // blue -- ������������Ӱ�� -- Ӧ���������غ�     
MoveToEx(hdc, pt.x - 2, pt.y - 2, 0L); LineTo(hdc,pt.x-2,pt.y+2); 
LineTo(hdc,pt.x+2,pt.y+2); LineTo(hdc,pt.x+2,pt.y-2); LineTo(hdc,pt.x-2,pt.y-2);
//Ellipse(hdc, pt.x-2,pt.y-2,pt.x+2,pt.y+2);   // Ellipse �����Ӱ��. ��Ҳ����ʹ�� NULL_BRUSH ʹ֮͸��.
   

int x=20,  y=20, dy=24; 
char szt[128]; 
int
ic=sprintf(szt, "pt(%d,%d) --> po(%d,%d) ", pt.x, pt.y,  po.x,po.y );
TextOut(hdc,x,y, szt,ic);

y+=dy;
ic=sprintf(szt, "c(%02X, %02X, %02X) ",  0xFF&co,  0xFF&(co>>8), 0xFF&(co>>16) );
TextOut(hdc,x,y, szt,ic);

if(pDib==NULL)return; 
if(BitCount(pDib)!=8)return; 

if (!rs) { rc[1]= { 0,0, (long)BiWidth(pDib), (long)BiHeight(pDib) };  rs=&rc[1]; }


XFORM xsd = {1,0,0,1,0,0};  mkTransform(*rd,*rs,xsd);
POINT pm=matx(po,xsd);  // ������������

BYTE c[9];  // getPixel �� GetPixel ��λ����, �л��п��ܴ� 1 ���� 2  

for (int i = 0; i<9; i++){
//c[i]= getPixel8(pDib,pm.x + i/3,   pm.y + i%3 );   
c[i]= getPixel8(pDib,pm.x + i/3-1,   pm.y + i%3 -1  ); 
}


#if DRAW_PIXEL|1

//HPEN hPen = (HPEN)GetStockObject(DC_PEN);    \
SelectObject(hdc,hPen);   \
HBRUSH hBrush = (HBRUSH)GetStockObject(NULL_BRUSH);  \
SelectObject(hdc, hBrush);  // ��Բ����  

// SetWorldTransform(hdc,&g_E);  SetBkMode(hdc,TRANSPARENT);  
SetTextColor(hdc, 0x808080); 


y+=dy;
ic=sprintf(szt, "λͼ���� ");
TextOut(hdc,x,y, szt,ic);

for (int i = 0; i<3; i++){
y+=dy; ic=0; 
for (int j=0; j<3; j++){
ic+=sprintf(szt+ic, "%02X  ", c[i*3+j]); 
}
TextOut(hdc,x,y, szt,ic);
}  // for i 


SetWorldTransform(hdc,&g_XFO);  

#endif  // DRAW_PIXEL
 
return;
}








// ͼƬ���� rs ���Ż��Ƶ��ӱ��û����� rd ʱ, ���� (x,y) ��Ӧ���ļ�����λ�� (��i, ��j)  

//  rd һ��ָ�ӱ��û���, rs һ��ָͼƬ�������� (0,0, BIWIDTH(bi), BIHEIGHT(bi)) 
 
// �÷�����Ҫ��¼���Ĵ�������, �ڴ�������. 
 
// ע��, ����ֵ pt.y û�����µߵ�.  

POINT* LocPixel(HWND hWnd, RECT*rd,  RECT*rs){   

CCW_DATA* pcd = (CCW_DATA*)GetWindowLong(hWnd,GWL_USERDATA); 
if (!pcd) { MessageBox(0,"�÷�����Ҫ��������!",0,0);  return 0L;}

LPBYTE pDib=(LPBYTE) pcd->pData; 


RECT rc[2];
if (rd == 0){ GetClientRect(hWnd, rc);  int B=12; rc[0].left+=B; rc[0].top+=B; rc[0].right-=B; rc[0].bottom-=B;      rd =&rc[0]; } 
if (!rs) { rc[1]= { 0,0, (long)BiWidth(pDib), (long)BiHeight(pDib) };  rs=&rc[1]; }

POINT pt=pcd->pt;           // GetCursorPos(&pt);  ScreenToClient(hWnd,&pt); // ��Ļ����. ��ͼƬʵ����ʾ������.   

XFORM xf = matinv(pcd->xf);  POINT po = matx(pt,xf);   // po = pt �� (g_XFO^-1)  // һ����˵, po �ڼӱ��û��� 

HDC hdc=GetDC(hWnd); 
COLORREF co=GetPixel(hdc, po.x, po.y);  // 0x00bbggrr // ��Ȼ�� Rectangle Ӱ�� ! LineTo(hdc,po.x,po.y) ��Ӱ��. Ellipse(hdc,po.x-5,po.y-5,po.x+5,po.y+5) ��Ӱ�� 
ReleaseDC(hWnd,hdc); 

mkTransform(*rd,*rs,xf);  // ������������, ӳ�䵽�ļ������ص� 
POINT pm=matx(po,xf);


RGBQUAD bgr;  // getPixel �� GetPixel ��λ����, �л��п��ܴ� 1 ���� 2  
RGBQUAD q= getPixel(pDib, pm.x,   pm.y);
DWORD c=0;    // COLORREF,  0x00bbggrr   

int io=pm.y, jo=pm.x; 


for(int i = 4; i<9+4; i++){  // ���ȼ�����ĵ� 
bgr = getPixel(pDib, pm.x + i/3-1,   pm.y + i%3 -1  );    

c = (bgr.rgbBlue << 16) | (bgr.rgbGreen<<8) | bgr.rgbRed ; 
if (c==co) { io += i/3-1; jo += i%3-1; break; }
}  // for i 

POINT*pix=new POINT;   pix->x=jo; pix->y=io;  

return pix;
}





// ��ʾ���������ֵ -- �� drawDib �й� 
// rd һ��ָ�ӱ��û���, rs һ��ָͼƬ�������� (0,0, BIWIDTH(bi), BIHEIGHT(bi)) 

 

void vBit(HWND hWnd, RECT*rd,  RECT*rs){  //, HPALETTE hPal =0L  =0L  =0L 

CCW_DATA*pcd = (CCW_DATA*)GetWindowLong(hWnd, GWL_USERDATA); 
if (!pcd) { MessageBox(0,"�÷�����Ҫ��������!",0,0);  return;}

POINT pt=pcd->pt;   // GetCursorPos(&pt);    ScreenToClient(hWnd,&pt);        // ��Ļ����. ��ͼƬʵ����ʾ������.   

// SetGraphicsMode(hdc,GM_ADVANCED);   static XFORM g_XFO;  GetWorldTransform(hdc,&g_XFO);   // ��Ҫʱ�ָ���ǰ������� 

// GetDC, WT �� Identity ! 
// XFORM xf =pcd->xf;  matinv(&xf);  POINT po = matx(pt,xf);   // po = pt �� (g_XFO^-1)  

char szt[128]; 

HDC hdc=GetDC(hWnd); 
SetBkMode(hdc,TRANSPARENT);

COLORREF co=GetPixel(hdc, pt.x, pt.y);  // 0x00bbggrr // ��Ȼ�� Rectangle Ӱ�� ! LineTo(hdc,po.x,po.y) ��Ӱ��. Ellipse(hdc,po.x-5,po.y-5,po.x+5,po.y+5) ��Ӱ�� 
int ic=sprintf(szt, "%06X  @(%d,%d)", co, pt.x, pt.y);
SetTextColor(hdc,0xFFFFFF-co);  
TextOut(hdc,pt.x,pt.y, szt,ic);  // GetDC, WT �� Identity ! 


LPBYTE pDib= (LPBYTE) pcd->pData; 
if(pDib==NULL){ ReleaseDC(hWnd, hdc); return; }

POINT*px = LocPixel(hWnd,rd,rs);

RGBQUAD q= getPixel(pDib, px->x,   px->y);
DWORD c = (q.rgbBlue << 16) | (q.rgbGreen<<8) | q.rgbRed ; 

int dy=24; 
 
ic=sprintf(szt, "%06X  @[%d, %d]", c,  px->x, px->y);   
//c = GetPixel(hdc,pt.x,pt.y+dy);  c=0xFFFFFF-c;   
SetTextColor(hdc,0xFF0000); 
TextOut(hdc,pt.x,pt.y+dy, szt,ic);  

ReleaseDC(hWnd, hdc); 
return;
}







void vBit(HDC hdc, BYTE*pDib, RECT*rd,  RECT*rs){  //, HPALETTE hPal =0L  =0L  =0L 

RECT rc[2];
HWND hWnd=WindowFromDC(hdc); 

if (rd == 0){ GetClientRect(hWnd, rc);  rd =&rc[0];} 

POINT pt;            // ��Ļ����. ��ͼƬʵ����ʾ������.   
GetCursorPos(&pt);    
ScreenToClient(hWnd,&pt);

// SetGraphicsMode(hdc,GM_ADVANCED);  
static XFORM g_XFO;  GetWorldTransform(hdc,&g_XFO);   // ��Ҫʱ�ָ���ǰ������� 
XFORM xf = matinv(g_XFO);  POINT po = matx(pt,xf);   // po = pt �� (g_XFO^-1)  // һ����˵, po �ڼӱ��û��� 


COLORREF co=GetPixel(hdc, po.x, po.y);  // 0x00bbggrr // ��Ȼ�� Rectangle Ӱ�� ! LineTo(hdc,po.x,po.y) ��Ӱ��. Ellipse(hdc,po.x-5,po.y-5,po.x+5,po.y+5) ��Ӱ�� 
char szt[128]; 
int ic=sprintf(szt, "%02X%02X%02X  @(%d,%d)", 0xFF&(co>>16),  0xFF&(co>>8) ,  0xFF&co, pt.x, pt.y);
SetTextColor(hdc,0xFFFFFF-co); SetBkMode(hdc,TRANSPARENT);
TextOut(hdc,po.x,po.y, szt,ic);

if(pDib==NULL)  return;  


if (!rs) { rc[1]= { 0,0, (long)BiWidth(pDib), (long)BiHeight(pDib) };  rs=&rc[1]; }

XFORM xsd;  mkTransform(*rd,*rs,xsd);  // ������������
POINT pm=matx(po,xsd);


RGBQUAD bgr;  // getPixel �� GetPixel ��λ����, �л��п��ܴ� 1 ���� 2  
RGBQUAD q= getPixel(pDib, pm.x,   pm.y);
DWORD c=0;    // COLORREF,  0x00bbggrr   

int io=pm.y, jo=pm.x; 


for(int i = 4; i<9+4; i++){  // ���ȼ�����ĵ� 
bgr = getPixel(pDib, pm.x + i/3-1,   pm.y + i%3 -1  );  // bgr[i]= getPixel(pDib,pm.x + i/3,   pm.y + i%3 );   

c = (bgr.rgbBlue << 16) | (bgr.rgbGreen<<8) | bgr.rgbRed ; 
if (c==co) { io += i/3-1; jo += i%3-1; break; }
}  // for i 


int dy=24; 
 
// ic=sprintf(szt, "@[%3d,%3d]  %06X /@[%d,%d]  %6X",  io, jo, c, pm.y, pm.x, (q.rgbBlue << 16) | (q.rgbGreen<<8) | q.rgbRed );  // ��ʱ c �� co ���ܲ���� 
ic=sprintf(szt, "%06X  @[%d, %d]", c,  io, jo);   
c = GetPixel(hdc,po.x,po.y+dy);  c=0xFFFFFF-c;   SetTextColor(hdc,c); 
TextOut(hdc,po.x,po.y+dy, szt,ic);  

return;
}








#if IMAGE_PROCESS|1













// ����ֽ�. ��ȡ��ͨ����,  ��ȡ���ؼ���, ���ڵ� 8 ������������һ����ɫ(�Ҷ�ֵ<=cri, criĬ��=0)

BYTE* c256_ps(LPBYTE pbi, int cri ){  // cri = threshold = 0
if (pbi == NULL) return false;

// ׼����ɫλͼ���  

LPBITMAPINFOHEADER bi= (LPBITMAPINFOHEADER)pbi;  
if (bi->biBitCount != 8) {MessageBox(0,"Ŀǰ��֧��8λ�Ҷ�ͼ",0,0); return 0L;}

//bi->biClrUsed=2;  // 0��0xFF


// 4-bytes aligning  

int wb  =  ((bi->biWidth*bi->biBitCount/8+3)/4)*4;  // WIDTHBYTES(bi->biWidth*bi->biBitCount);  //  bi->biBitCount = 8  

int clrUsed=bi->biClrUsed;
if (clrUsed==0) clrUsed=256; 

int bc = bi->biHeight*wb;  
int hc= sizeof(BITMAPINFOHEADER);  // +sizeof(BITMAPFILEHEADER);
int pc = clrUsed *sizeof(RGBQUAD);     

BYTE*pr = (BYTE*)malloc(hc+pc+bc); 
memcpy(pr,pbi,hc+pc); 

BYTE* pi=pbi+hc+pc;   // LocBits(pbi); 
BYTE*rpi=pr+hc+pc; 
 
memset(rpi,0xFF,bc);   // ����ͼ��  


LPBITMAPINFOHEADER rbi=(LPBITMAPINFOHEADER)pr; 

RGBQUAD* pal = (RGBQUAD*)(pbi+hc);

int ir=0; 
int W=0, H=0;  // ��ͼ��Ĵ�С  H��W pixels 



for( int i=0; i<bi->biHeight; i++ ){

for( int j=0; j<bi->biWidth; j++ ){

int x= j, y=i, d=0; 
 
BYTE r = pi[ y*bi->biWidth+x ]; r=pal[r%clrUsed].rgbBlue;  

if (r>cri) continue;    // [i,j] �ǰ�ɫ, ������. ע��, rgbBlue=rgbGreen=rgbRed

if (ir == 0){ rpi[ i*bi->biWidth+j ] = pi[ i*bi->biWidth+j]; ir++; W=j,H=i; continue; }  // ��һ����ѡ�� 

r = rpi[ y*bi->biWidth+x ]; r=pal[r%clrUsed].rgbBlue;  

if (r<=cri)continue;  // ��ͼ��, [i,j] �Ѿ��Ǻ�ɫ, ���ٴ���.  


d=0;  // [i,j] ��Χ�� 8 ��, �Ƿ�����ѡ�� 
for (int k = 0; k<9; k++){ 

x= j+k%3-1, y=i+k/3-1; 

//if (x==j && y==i) continue;  // ��ʵֻҪ��� 4 ��������� 


if (x>=0 && y>=0)  // ͼ������֮��ĵ�Ĭ��Ϊ��ɫ; 
if (x<wb && y<bi->biHeight){ r = rpi[y*bi->biWidth+x]; r=pal[r%clrUsed].rgbBlue; if (r<=cri){ d++; break; }  }    // ifif 

}  // for k

if (d>0){ rpi[ i*bi->biWidth+j ] = pi[ i*bi->biWidth+j]; ir++;  if(j>W) W=j;  if(i>H) H=i; } // ��Χ����ѡ��, ѡ��˵� 
 
}  // for j  
 
}  // for i 


// ������ͼƬ�Ĵ�С ...... 




qTrace("ir=%d",ir);

return pr;
}











// ͼ����ǿ -- ��� 256 λ 2 ɫͼ.  cri=0 -- 9, Ĭ�� = 5    

// Ч������  

BYTE* c256p(LPBYTE pbi, int cri, int dri){  //=0=5. cri = threshold = 128, dri �ܶ���ֵ = 5 
if (pbi == NULL) return 0;

LPBITMAPINFOHEADER bi= (LPBITMAPINFOHEADER)pbi;  
if (bi->biBitCount != 8) {MessageBox(0,"Ŀǰ��֧��8λ�Ҷ�ͼ",0,0); return 0L;}

// 4-bytes aligning  
int wb  =  ((bi->biWidth*bi->biBitCount/8+3)/4)*4;  // WIDTHBYTES(bi->biWidth*bi->biBitCount);  //  bi->biBitCount = 8  
// int rwb =  ((bi->biWidth + 31) / 32 * 4);  // ((bi->biWidth*1+3)/4) *4;  // WIDTHBYTES(bits);   //  Bytes -- 1 λͼ, ÿ������ 1 bit  

int clrUsed=bi->biClrUsed;
if (clrUsed==0) clrUsed=256; 


int bc = bi->biHeight*wb;  
int hc= sizeof(BITMAPINFOHEADER);  // +sizeof(BITMAPFILEHEADER);
int pc = clrUsed *sizeof(RGBQUAD);     // assert( bi->biClrUsed==256);
RGBQUAD* pal = (RGBQUAD*)(pbi+hc);    

BYTE* pi=pbi+hc+pc;   // LocBits(pbi); 
int ir=0; 

for( int i=0; i<bi->biHeight; i++ ){

//BYTE*sp=pi + i*wb -1;      // ָ��� i �� 

for( int j=0; j<bi->biWidth; j++ ){

int x= j, y=i; 
 
BYTE r = pi[ y*bi->biWidth+x ]; r=pal[r%clrUsed].rgbBlue;  if (r<=cri) continue;   // [i,j] �Ѿ��Ǻ�ɫ, ������. ע��, rgbBlue=rgbGreen=rgbRed

int d=0; 
for (int k = 0; k<9; k++){  // [i,j] ��Χ�� 8 ������ 

x= j+k%3-1, y=i+k/3-1; 

if (x>=0 && y>=0)  // ͼ������֮��ĵ�Ĭ��Ϊ��ɫ; 
if (x<wb && y<bi->biHeight){ 
r = pi[y*bi->biWidth+x];
r=pal[r%clrUsed].rgbBlue;
if (r<=cri) d++; 
}    // ifif 

}  // for k

if (d>=dri){ pi[ i*bi->biWidth+j ] = 0; ir++;} // ��Ϊ��ɫ 
 
}  // for j  
 
}  // for i 


qTrace("ir=%d",ir);
return pbi;
}



// ͼ��ָ� -- ��� 256 λ 2 ɫͼ.  cri  Ĭ�� =0     


BYTE* c256_line(LPBYTE pbi, int cri){  //=0=5. cri = threshold = 128, dri �ܶ���ֵ = 5 
if (pbi == NULL) return 0;

LPBITMAPINFOHEADER bi= (LPBITMAPINFOHEADER)pbi;  
if (bi->biBitCount != 8) { MessageBox(0,"Ŀǰ��֧��8λ�Ҷ�ͼ",0,0); return 0L; }

// 4-bytes aligning  
int wb  =  ((bi->biWidth*bi->biBitCount/8+3)/4)*4;  // WIDTHBYTES(bi->biWidth*bi->biBitCount);  //  bi->biBitCount = 8  
// int rwb =  ((bi->biWidth + 31) / 32 * 4);  // ((bi->biWidth*1+3)/4) *4;  // WIDTHBYTES(bits);   //  Bytes -- 1 λͼ, ÿ������ 1 bit  

int clrUsed=bi->biClrUsed;
if (clrUsed==0) clrUsed=256; 


int bc = bi->biHeight*wb;  
int hc= sizeof(BITMAPINFOHEADER);  // +sizeof(BITMAPFILEHEADER);
int pc = clrUsed *sizeof(RGBQUAD);    
RGBQUAD* pal = (RGBQUAD*)(pbi+hc);    

BYTE* pi=pbi+hc+pc;   // LocBits(pbi); 
int ir=0; 






#if VERTICAL_LINE |1

for( int i=0; i<bi->biWidth; i++ ){


int d=0;  // ���߳��� 

for( int j=0; j<bi->biHeight; j++ ){

BYTE r=0, t=0, s = pi[ j*wb+i ]; s=pal[s%clrUsed].rgbBlue;    // r,s,t 

if (i+1<bi->biWidth){ t = pi[ j*wb+i+1 ];  t=pal[t%clrUsed].rgbBlue;  }
if (i-1>=0){ r = pi[ j*wb+i-1 ];  r=pal[r%clrUsed].rgbBlue;  }

if (r<=cri && s<=cri && t<=cri)break;    // [i,j]�������� �Ǻ�ɫ, �ж�. ע��, rgbBlue=rgbGreen=rgbRed
 
d++;
}  // for j  

 
if (d>=bi->biHeight/2){ ir++; for(int k=0; k<d; k++){ pi[ i+k*wb ] = 0; }} // ��Ϊ��ɫ 

}  // for i 



#else


for( int i=0; i<bi->biHeight; i++ ){


int d=0;  // ���߳��� 

for( int j=0; j<bi->biWidth; j++ ){

int x= j, y=i; 
 
BYTE r = pi[ y*bi->biWidth+x ]; r=pal[r%clrUsed].rgbBlue;  if (r<=cri) break;   // [i,j] �Ǻ�ɫ, �ж�. ע��, rgbBlue=rgbGreen=rgbRed
d++;
}  // for j  
 
if (d==bi->biWidth)for(int k=0; k<bi->biWidth; k++){ pi[ i*bi->biWidth+k ] = 0; ir++;} // ��Ϊ��ɫ 

}  // for i 

#endif  



qTrace("ir=%d",ir);
return pbi;
}





#endif  // IMAGE_PROCESS




 


// ������� rc �ڵ���ɫ co -- Ŀǰ����� 8��16��24λλͼ. 


int dib_cls(LPBYTE pbi, RECT* re, int co){   
if (pbi == NULL) return 0;

LPBITMAPINFOHEADER bi= (LPBITMAPINFOHEADER)pbi;  
// if (bi->biBitCount != 8) { MessageBox(0,"Ŀǰ��֧��8λ�Ҷ�ͼ",0,0); return 0L; }

// 4-bytes aligning  
int wb  = ((bi->biWidth*bi->biBitCount/8+3)/4)*4;  //  WIDTHBYTES(bi->biWidth*bi->biBitCount);  //  int rwb =  ((bi->biWidth + 31) / 32 * 4);   

int clrUsed=bi->biClrUsed;  
if (clrUsed == 0) clrUsed = (1<<bi->biBitCount);  // pow(2, bi->biBitCount);  // math.h 
if (bi->biBitCount>8) clrUsed=0;  

//int bc = bi->biHeight*wb;  
int hc= sizeof(BITMAPINFOHEADER);      // sizeof(BITMAPFILEHEADER) + 
int pc = clrUsed *sizeof(RGBQUAD);     // assert( bi->biClrUsed==256);  //RGBQUAD* pal = (RGBQUAD*)(pbi+hc);     // ������λ���� ...... 

BYTE* p, *pi=pbi+hc+pc;   // LocBits(pbi); 
// int ir=0; 

BYTE b,g,r;
DWORD c=0; 



for( int i=0; i<bi->biHeight; i++ ){  

p=pi+i*wb;  // �� i ��    

for( int j=0; j<bi->biWidth; j++ ){  // pi[ i*bi->biWidth+j ] = cm- pi[ i*bi->biWidth+j ] ;    // ��Ӧ��ʹ��  bi->biWidth 
 

if (i>=re->top && i<re->bottom  && j>=re->left && j< re->right)  {

c=0; b=g=r=0; 
b=*p;  
if ( bi->biBitCount > 8 ){ g = *(p+1);    }
if ( bi->biBitCount > 16 ){  r = *(p+2);   }

c= r | (g<<8) | (b<<16); 

if (co == -1){

*p=0xFF; 
if ( bi->biBitCount > 8 ){  *(p+1)=0xFF;    }
if ( bi->biBitCount > 16 ){  *(p+2)=0xFF;   }

}else if (c == co){

*p=0xFF; 
if ( bi->biBitCount > 8 ){  *(p+1)=0xFF;    }
if ( bi->biBitCount > 16 ){  *(p+2)=0xFF;   }
}  // if (c == co)

}  //  if i>=re->top...



p+=bi->biBitCount/8; 
}  // for j  

}  // for i 

return 1;
}


// ���ָ������: icls=0,1,2--�ֱ���� b,g,r ����; icls=-1,-2,-3 -- �ֱ������ b,g,r ����   

int dib_clr(LPBYTE pbi, RECT* rc, int iMethod){  // =8   = 0

if (pbi == NULL) return 0;
LPBITMAPINFOHEADER bi= (LPBITMAPINFOHEADER)pbi;  
if (bi->biBitCount != 24) { MessageBox(0,"��֧��24λ���ͼ",0,0); return 0L; }
 

FILE*fp =0;  



int wb  =  ((bi->biWidth*bi->biBitCount/8+3)/4)*4;  // WIDTHBYTES(bi->biWidth*bi->biBitCount); // 4-bytes aligning  
int bc = bi->biHeight*wb;  
int hc= sizeof(BITMAPINFOHEADER);   // +sizeof(BITMAPFILEHEADER);
int pc = bi->biClrUsed *sizeof(RGBQUAD);    assert( bi->biClrUsed==0);

BYTE* pi=pbi+hc+pc, b,g,r;   // LocBits(pbi); 


RECT re={0,0,bi->biWidth, bi->biHeight}; 
if (rc!=0) re=*rc; 
if (re.left<0) re.left = 0;  if (re.top<0)  re.top = 0;
if (re.right>bi->biWidth) re.right=bi->biWidth;  if (re.bottom>bi->biHeight) re.bottom=bi->biHeight; 



for( int i=re.top; i<re.bottom; i++ ){

BYTE*sp=pi+ i*wb +re.left*bi->biBitCount/8;   // ָ��� i �� 


for( int j=re.left; j<re.right; j++ ){
 

b=*sp, g=*(sp+1), r=*(sp+2); 
//c = r | (g<<8) | (b<<16); 

switch (iMethod){
case 0:  b = 0;  break; 
case 1:  g = 0;  break; 
case 2:  r = 0;  break; 


case -1:{g=r=0;}break; 
case -2:{b=r=0;}break; 
case -3:{b=g=0;}break; 

default: 
assert(false);  // Ҳ�����������㷨    
break; 
}  // switch  iMethod  


*sp=b, *(sp+1)=g,  *(sp+2)=r; 

 

sp+=bi->biBitCount/8; 
}  // for j  

}  // for i 


  
return 1;
}








// ��ǿ�Աȶ�  amplify,     
// ��ɫӳ�� y = C/2 + C/2 * (2(x-A)/(B-A)-1)^3 ,  x��[A,B]
// ��Ϊʵ��, Ҳ����ȡ 5 �� 7 �η�. 

 
int dib_amp(LPBYTE pbi,  RECT* rc){  

if (pbi == NULL) return 0;
LPBITMAPINFOHEADER bi= (LPBITMAPINFOHEADER)pbi;  
if (bi->biBitCount != 24) { MessageBox(0,"Ŀǰ��֧��24λ���ͼ",0,0); return 0L; }
 
FILE*fp = fopen( "dipr_amp.txt","wb");  // if (!fp) return 0;

int wb  =  ((bi->biWidth*bi->biBitCount/8+3)/4)*4;  // WIDTHBYTES(bi->biWidth*bi->biBitCount);  // 4-bytes aligning  
int bc = bi->biHeight*wb;  
int hc= sizeof(BITMAPINFOHEADER);   // +sizeof(BITMAPFILEHEADER);
int pc = bi->biClrUsed *sizeof(RGBQUAD);    assert( bi->biClrUsed==0);

BYTE* pi=pbi+hc+pc;   // LocBits(pbi); 




RECT re={ 0,0,bi->biWidth, bi->biHeight }; 
if (rc!=0) re=*rc; 

if (re.left<0) re.left = 0;  if (re.top<0)  re.top = 0;
if (re.right>bi->biWidth) re.right=bi->biWidth;  if (re.bottom>bi->biHeight) re.bottom=bi->biHeight; 


DWORD c=0; 
BYTE  b,g,r;  

#if COLOR_SCOPE |1

DWORD A=0xFFFFFF, B=0;    // at=0xFF, bt=0;   // ���������� 

for( int i=re.top; i<re.bottom; i++ ){ // for( int i=0; i<bi->biHeight; i++ ){

BYTE*sp=pi+ i*wb + re.left*bi->biBitCount/8;    // ָ��� i ��   re.left �� 

for( int j=re.left; j<re.right; j++ ){// for( int j=0; j<bi->biWidth; j++ ){


b=*sp, g=*(sp+1), r=*(sp+2);   

c = r | (g<<8) | (b<<16);  

if (A>c) A = c;  if (B<c) B=c;  // ... Ҳ���Կ��ǰ���ĳ�������� 


sp+=bi->biBitCount/8; 
}  // for j  
 
}  // for i 

if (A>B) { qTrace("A=%X, B=%X",A, B); A=0; B=0xFFFFFF; }

#endif  // COLOR_SCOPE



fprintf(fp, "\r\n���з�Χ [%d,%d, %d, %d] / [0,0, %d,%d] \r\n\r\n", re.left, re.top, re.right, re.bottom, bi->biWidth, bi->biHeight); 

fprintf(fp, "\r\n��ɫ���� [%X, %X] --> [0, 0xFFFFFF] \r\n", A, B); 


int C=0xFFFFFF; 
double t; 

for( int i=re.top; i<re.bottom; i++ ){ // for( int i=0; i<bi->biHeight; i++ ){

BYTE*sp=pi+ i*wb + re.left*bi->biBitCount/8;    // ָ��� i ��   re.left �� 

for( int j=re.left; j<re.right; j++ ){// for( int j=0; j<bi->biWidth; j++ ){


b=*sp, g=*(sp+1), r=*(sp+2);  

c = r | (g<<8) | (b<<16);  

t=2.*(c-A)/(B-A)-1;
c= C/2+ C/2* t ;  // y = C/2 + C/2 * (2(x-A)/(B-A)-1)^1 ,  x��[A,B]
// c= C/2+ C/2* t*t*t ;  // y = C/2 + C/2 * (2(x-A)/(B-A)-1)^3 ,  x��[A,B]

r=c&0xFF; 
g=(c&0xFF00)>>8;
b=(c&0xFF0000)>>16;

*sp=b, *(sp+1)=g, *(sp+2)=r;  

sp+=bi->biBitCount/8; 
}  // for j  
 
}  // for i 


fprintf(fp, "\r\n ת���������� %d \r\n", t); 

fclose(fp);

if((int) ShellExecute(0, "open", "dipr_amp.txt", 0, 0, SW_SHOW)<=32) eInfo("ShellExecute");   

return t;
}



// ��� 24 λ�Ҷ�ͼ��ǿ�Աȶ� 
int dib_amp24g(LPBYTE pbi,  RECT* rc){  

if (pbi == NULL) return 0;
LPBITMAPINFOHEADER bi= (LPBITMAPINFOHEADER)pbi;  
if (bi->biBitCount != 24) { MessageBox(0,"Ŀǰ��֧��24λ���ͼ",0,0); return 0L; }
 
FILE*fp = fopen( "dipr_amp24g.txt","wb");  // if (!fp) return 0;

int wb  =  ((bi->biWidth*bi->biBitCount/8+3)/4)*4;  // WIDTHBYTES(bi->biWidth*bi->biBitCount);  // 4-bytes aligning  
int bc = bi->biHeight*wb;  
int hc= sizeof(BITMAPINFOHEADER);   // +sizeof(BITMAPFILEHEADER);
int pc = bi->biClrUsed *sizeof(RGBQUAD);    assert( bi->biClrUsed==0);

BYTE* pi=pbi+hc+pc;   // LocBits(pbi); 




RECT re={ 0,0,bi->biWidth, bi->biHeight }; 
if (rc!=0) re=*rc; 

if (re.left<0) re.left = 0;  if (re.top<0)  re.top = 0;
if (re.right>bi->biWidth) re.right=bi->biWidth;  if (re.bottom>bi->biHeight) re.bottom=bi->biHeight; 


DWORD c=0; 
BYTE  b,g,r;  

#if COLOR_SCOPE |1

DWORD A=0xFF, B=0;    // at=0xFF, bt=0;   // ���������� 

for( int i=re.top; i<re.bottom; i++ ){ // for( int i=0; i<bi->biHeight; i++ ){

BYTE*sp=pi+ i*wb + re.left*bi->biBitCount/8;    // ָ��� i ��   re.left �� 

for( int j=re.left; j<re.right; j++ ){// for( int j=0; j<bi->biWidth; j++ ){


b=*sp, g=*(sp+1), r=*(sp+2);   // assert(b==g && g==r);  

//c = r | (g<<8) | (b<<16);  


if (A>b) A = b;  if (B<b) B=b;  // ... Ҳ���Կ��ǰ���ĳ�������� 


sp+=bi->biBitCount/8; 
}  // for j  
 
}  // for i 

if (A>B) { qTrace("A=%X, B=%X",A, B); A=0; B=0xFF; }

#endif  // COLOR_SCOPE



fprintf(fp, "\r\n���з�Χ [%d,%d, %d, %d] / [0,0, %d,%d] \r\n\r\n", re.left, re.top, re.right, re.bottom, bi->biWidth, bi->biHeight); 
fprintf(fp, "\r\n��ɫ���� [%X, %X] --> [0, 0xFF] \r\n", A, B); 


int C=0xFF; 
double t; 

for( int i=re.top; i<re.bottom; i++ ){ // for( int i=0; i<bi->biHeight; i++ ){

BYTE*sp=pi+ i*wb + re.left*bi->biBitCount/8;    // ָ��� i ��   re.left �� 

for( int j=re.left; j<re.right; j++ ){// for( int j=0; j<bi->biWidth; j++ ){


b=*sp, g=*(sp+1), r=*(sp+2);  

c = r | (g<<8) | (b<<16);  

t=2.*(b-A)/(B-A)-1;
// c= C/2+ C/2* t ;  // y = C/2 + C/2 * (2(x-A)/(B-A)-1)^1 ,  x��[A,B]
c= C/2+ C/2* t*t*t;  // y = C/2 + C/2 * (2(x-A)/(B-A)-1)^3 ,  x��[A,B]
// c= C/2+ C/2* t*t*t*t*t ;  // y = C/2 + C/2 * (2(x-A)/(B-A)-1)^3 ,  x��[A,B]

// r=c&0xFF;  g=(c&0xFF00)>>8;  b=(c&0xFF0000)>>16;
r=g=b=c; 
*sp=b, *(sp+1)=g, *(sp+2)=r;  

sp+=bi->biBitCount/8; 
}  // for j  
 
}  // for i 


fprintf(fp, "\r\n ת���������� %d \r\n", t); 

fclose(fp);

if((int) ShellExecute(0, "open", "dipr_amp24g.txt", 0, 0, SW_SHOW)<=32) eInfo("ShellExecute");   

return t;
}





// ͼ��ɫ -- Ŀǰ����� 8��16��24λλͼ. 


int dib_invert(LPBYTE pbi, RECT*rc){   
if (pbi == NULL) return 0;

LPBITMAPINFOHEADER bi= (LPBITMAPINFOHEADER)pbi;  
// if (bi->biBitCount != 8) { MessageBox(0,"Ŀǰ��֧��8λ�Ҷ�ͼ",0,0); return 0L; }

// 4-bytes aligning  
int wb  = ((bi->biWidth*bi->biBitCount/8+3)/4)*4;  //  WIDTHBYTES(bi->biWidth*bi->biBitCount);  //  int rwb =  ((bi->biWidth + 31) / 32 * 4);   

int clrUsed=bi->biClrUsed;  
if (clrUsed == 0) clrUsed = (1<<bi->biBitCount);  // pow(2, bi->biBitCount);  // math.h 
if (bi->biBitCount>8) clrUsed=0;  

//int bc = bi->biHeight*wb;  
int hc= sizeof(BITMAPINFOHEADER);      // sizeof(BITMAPFILEHEADER) + 
int pc = clrUsed *sizeof(RGBQUAD);     // assert( bi->biClrUsed==256);  //RGBQUAD* pal = (RGBQUAD*)(pbi+hc);     // ������λ���� ...... 

BYTE* p, *pi=pbi+hc+pc;   // LocBits(pbi); 
// int ir=0; 

// DWORD cm = (1<<bi->biBitCount)-1; 

RECT re={ 0,0,bi->biWidth, bi->biHeight }; 
if (rc!=0) re=*rc; 

if (re.left<0) re.left = 0;  if (re.top<0)  re.top = 0;
if (re.right>bi->biWidth) re.right=bi->biWidth;  if (re.bottom>bi->biHeight) re.bottom=bi->biHeight; 



for( int i=re.top; i<re.bottom; i++ ){  

p=pi+i*wb + re.left*bi->biBitCount/8;  // �� i �� j ��  

for( int j=re.left; j<re.right; j++ ){


// pi[ i*bi->biWidth+j ] = cm- pi[ i*bi->biWidth+j ] ;    // ��Ӧ��ʹ��  bi->biWidth 
 
*p  = 0xFF -  *p;  p++; 
if ( bi->biBitCount > 8 ){ *p  = 0xFF -  *p;  p++;  }
if ( bi->biBitCount > 16 ){ *p  = 0xFF -  *p;  p++;  }

}  // for j  
}  // for i 

return 1;
}



















#if BACK_UP




// ��������. // ע��, ����ʱ������Ҫӳ�䵽����λ��  


DWORD WINAPI thr_grow(LPVOID Param){
	
if (!Param) return 0; 

struct PARAM{ LPBYTE pDIB; RECT* rc; LPBYTE pSrc; int x; int y; } *pa = (PARAM*)Param; 

BYTE* cDIB= pa->pSrc;  if (cDIB == NULL ){ MessageBox(0,"No Source DIB!",0,0); return 0; } 
BYTE*pbi=pa->pDIB;  if (pbi == NULL ){ MessageBox(0,"Ŀ��λͼ��!",0,0); return 0; }



LPBITMAPINFOHEADER bi= (LPBITMAPINFOHEADER)pbi;  // if (bi->biBitCount != 24) { MessageBox(0,"Ŀǰ��֧��24λ���ͼ",0,0); return 0L; }
 
int x=pa->x, y=pa->y;    y=bi->biHeight-y;
if ( x < 0 || x >=bi->biWidth || y < 0 || y >=bi->biHeight)  { qTrace("pt (%d, %d)", x,  y); return 0; }

int wb  =  ((bi->biWidth*bi->biBitCount/8+3)/4)*4;  // WIDTHBYTES(bi->biWidth*bi->biBitCount); // 4-bytes aligning  
int bc = bi->biHeight*wb;  
int hc = sizeof(BITMAPINFOHEADER);   // +sizeof(BITMAPFILEHEADER);
int pc = bi->biClrUsed *sizeof(RGBQUAD);    assert( bi->biClrUsed==0);
int mc = hc+pc+bc; 


BYTE* pi=pbi+hc+pc, b,g,r;   // LocBits(pbi); 
const BYTE* cpi=cDIB+hc+pc;  


#if GROW_COLOR|1

b  = *(cpi + y*wb + x*3),
g  = *(cpi + y*wb + x*3 +1 ),
r  = *(cpi + y*wb + x*3 +2 );    // getPixel  

if (bi->biBitCount<24) r=b; 
if (bi->biBitCount<16){ r=b, g=b; }


DWORD c=0, co = r| (g << 8) | (b << 16) ; 

*( pi + y*wb + x*3 ) = b; 
if(bi->biBitCount>8)  *( pi + y*wb + x*3 + 1 ) = g; 
if(bi->biBitCount>16) *( pi + y*wb + x*3 + 2 ) = r;     // ��һ������ 


int iC=1, ic=0;  

int iLoop=0;  

do{

// InvalidateRect(pa->hWnd_TR,0,1);   // ���� pbi �ǵ�ǰ��ʾ�� DIB ʱ������ 

ic=0;   //  ic ����Ϊ0, ��ζ����Ҳû�п������ӵ��� 

 

for( int i=0; i<bi->biHeight; i++ ){            // �����ڽ����� i--iy, j--ix

//BYTE* dp=pi+ i*wb;   // ָ��� i �� 
//const BYTE* sp=cpi+i*wb; 
 
for( int j=0; j<bi->biWidth; j++ ){


b  = *(cpi + i*wb + j*3),
g  = *(cpi + i*wb + j*3 +1 ),
r  = *(cpi + i*wb + j*3 +2 );   

if (bi->biBitCount<24) r=b; 
if (bi->biBitCount<16){ r=b, g=b; }


c = r| (g << 8) | (b << 16) ; 

// if(j==x && i==y) qTrace("b=%X, g=%X, r=%X,  c=%X, co=%X, i=%d, j=%d", b,g,r, c,co, i,j)


if (c!=co)  continue; 

 

b  = *(pi + i*wb + j*3);
g  = *(pi + i*wb + j*3 +1 );
r  = *(pi + i*wb + j*3 +2 );   

if (bi->biBitCount<24) r=b; 
if (bi->biBitCount<16){ r=b, g=b; }

c = r| (g << 8) | (b << 16) ; 

if (c==co) continue; 






#if READ_PIXELS |1  // ��ȡ�ڽ��� 9 ������  

int jc=0; 

for (int v=-1; v<2; v++){

jc=0; 

for (int u=-1; u<2; u++){

if (i+v<0 || i+v>= bi->biHeight) continue; 
if (j+u<0 || j+u>= bi->biWidth) continue; 

b  = *(pi + (i+v)*wb + (j+u)*3),
g  = *(pi + (i+v)*wb + (j+u)*3 +1),
r  = *(pi + (i+v)*wb + (j+u)*3 +2);    // getPixel  

if (bi->biBitCount<24) r=b; 
if (bi->biBitCount<16){ r=b, g=b; }


c = r| (g << 8) | (b << 16) ; 

if (c == co) {

*(pi + i*wb + j*3) = b;
if (bi->biBitCount>8) *(pi + i*wb + j*3 +1) = g;
if (bi->biBitCount>16) *(pi + i*wb + j*3 +2) = r;    

iC++;  ic++; jc++; 
break; 
}  // if c==co   

}  // for u  

if (jc>0) break; 
}  // for v

#endif  // READ_PIXELS



// sp+=3; dp+=3; 
}  // for j  
 
}  // for i 




// HDC hdc = GetDC(pa->hWnd_TR);  \
RECT rc; GetClientRect(pa->hWnd_TR, &rc);   \
char sz[128];    \
int it = sprintf(sz, "%X (%d,%d), ic=%d, iC=%d, iLoop=%d", co,   x, bi->biHeight-y, ic, iC, iLoop++);   \
TextOut(hdc, 0,rc.bottom-32,sz,it);  \
ReleaseDC(pa->hWnd_TR, hdc); 

// Sleep(10); 


} while (ic>0); 


#endif  // GROW_COLOR



// qTrace("iC=%d", iC)

//setTik(0); 
return iC; 
}




// (x,y)=pt=LocPixel(hWnd) �ǹ���Ӧ������λ�� [j,i] 

HANDLE dipr_grow(LPBYTE pDIB, RECT* rc, LPBYTE pSrc, int x, int y){

static  // ����! 
struct PARAM{ LPBYTE pDIB; RECT* rc;LPBYTE pSrc; int x; int y; } pa = 
{ pDIB,  rc, pSrc,  x,  y };   

DWORD thID;   // DWORD (WINAPI*)(LPVOID);   
return CreateThread(0, 0, thr_grow, &pa,  0,    &thID);   // (LPTHREAD_START_ROUTINE) 
}



#endif   // BACK_UP






// ͳ��ָ��������ʵ�ʳ��ֵ���ɫֵ����Ƶ��.   
// ���� rc ����ɫ����, �Լ���С�������ɫֵ.   
// mn�ǿ�ʱ, ��¼��С�����ɫ����С���Ƶ�� 

int dib_ct(LPBYTE pbi, RECT* rc, int*mn){  // =0   = 0

if (pbi == NULL) return 0;
LPBITMAPINFOHEADER bi= (LPBITMAPINFOHEADER)pbi;  
// if (bi->biBitCount != 24) { MessageBox(0,"Ŀǰ��֧��24λ���ͼ",0,0); return 0L; }
 


int wb  =  ((bi->biWidth*bi->biBitCount/8+3)/4)*4;  // WIDTHBYTES(bi->biWidth*bi->biBitCount); // 4-bytes aligning  
int bc = bi->biHeight*wb;  
int hc= sizeof(BITMAPINFOHEADER);   // +sizeof(BITMAPFILEHEADER);
int pc = bi->biClrUsed *sizeof(RGBQUAD);    assert( bi->biClrUsed==0);

BYTE* pi=pbi+hc+pc, b,g,r;   // LocBits(pbi); 
int to= bi->biWidth*bi->biHeight; 


DWORD MAXPIXEL = 0xFFFFFF;      // ���ĸ�BYTE����, ��0   MAXPIXEL<MAXDWORD32   
DWORD c=0, co=0; 

int N=MAXPIXEL+1; 

int* cs = new int[N];   memset(cs, 0, N*sizeof(int)); 
 

RECT re={0,0,bi->biWidth, bi->biHeight}; 
if (rc!=0) re=*rc; 
if (re.left<0) re.left = 0;  if (re.top<0)  re.top = 0;
if (re.right>bi->biWidth) re.right=bi->biWidth;  if (re.bottom>bi->biHeight) re.bottom=bi->biHeight; 



for( int i=re.top; i<re.bottom; i++ ){

BYTE*sp=pi+ i*wb+re.left*bi->biBitCount/8;   // ָ��� i �� j ��

for( int j=re.left; j<re.right; j++ ){
 
c=0;  b=g=r=0; 
b=*sp;
if (bi->biBitCount>8) g=*(sp+1);
if(bi->biBitCount>16) r=*(sp+2); 

c = r | (g<<8) | (b<<16); 

 
cs[c]++; 


sp+=bi->biBitCount/8; 
}  // for j  

}  // for i 


int t=0, ct=0, CT=0;

int cn=bi->biWidth*bi->biHeight, cN=0;  // ��С/��Ƶ��   
 
int mc=0xFFFFFF, Mc=0;  // // ��С/�� (Ƶ������)��ɫֵ

int bI=100;  // ��ҪƵ������  




for (int k=0; k<N; k++){
	
if (cs[k]<1) continue; 

t += cs[k];  // ��������

if (cn>cs[k]) cn = cs[k];  if (cN<cs[k]) cN = cs[k]; 

if (mc>k) mc=k;  if (Mc<k) Mc=k; 

ct++;   // ʵ��ʹ�õ���ɫ����
}  // for k  



delete[] cs; 


if (mn) { mn[0]=mc, mn[1]=Mc; mn[2]=cn; mn[3]=cN;  }

return ct;
}


 



// ̽�� rc ��Χ�ڵ�, [c,C] ��ɫ��Χ�ڵ����ص�ȷ�б߽� 
// rc, [in/out] ���ؽ������.
// ���� 24 λͼ, ������ɫ�����Ƚ�, ���, �˺��������ڻҶ�ͼ��ʵ��

int dib_border(BYTE*pbi, RECT*rc, int co, int CO){

if (pbi == NULL || rc==0L) return 0;
LPBITMAPINFOHEADER bi= (LPBITMAPINFOHEADER)pbi;  

int wb = ((bi->biWidth*bi->biBitCount/8+3)/4)*4;  // WIDTHBYTES(bi->biWidth*bi->biBitCount); // 4-bytes aligning  
int bc = bi->biHeight*wb;  
int hc = sizeof(BITMAPINFOHEADER);   // +sizeof(BITMAPFILEHEADER);
int pc = bi->biClrUsed *sizeof(RGBQUAD);    assert( bi->biClrUsed==0);

BYTE c, b,g,r,  *pi=pbi+hc+pc;   // LocBits(pbi); 


RECT re={0,0,bi->biWidth, bi->biHeight}; 
if (rc!=0) re=*rc; 
if (re.left<0) re.left = 0;  if (re.top<0)  re.top = 0;
if (re.right>bi->biWidth) re.right=bi->biWidth;  if (re.bottom>bi->biHeight) re.bottom=bi->biHeight; 





BYTE*p;   

int cp=0;  // ���������Ŀ�ѡ���ظ���. 
int er=1;  // ����. �������� er ���ϸ�����, ȷ�Ͽ�ѡ. 

RECT rs=re;   // ������ѡ�� break; 


// qTrace("[%d,%d]",co,CO);  // ע��, Ĭ�ϲ����� dib_Exec Ϊ׼ 


for( int i=re.top; i<re.bottom; i++ ){

cp=0;

for( int j=re.left; j<re.right; j++ ){
 
c=0;  b=g=r=0; 

p=pi + i*wb+j*bi->biBitCount/8;   // ָ��� i �� j ��

b=*p; c=b;
if (bi->biBitCount>8){ g=*(p+1); c=g; }
if(bi->biBitCount>16){ r=*(p+2); c=r; }

// c = r | (g<<8) | (b<<16); 
if ( !(c>=co && c<=CO) ){ cp=0; continue; }
 

cp++;  
if (cp>=er)break;

p+=bi->biBitCount/8; 
}  // for j  

if (cp>=er) break; 

rs.top++; 
}  // for i 





//rs.bottom = re.bottom;  // ������ѡ�� break; 

for( int i=re.bottom-1; i>=re.top; i-- ){

cp=0;

for( int j=re.left; j<re.right; j++ ){
 
c=0;  b=g=r=0; 

p=pi + i*wb+j*bi->biBitCount/8;   // ָ��� i �� j ��

b=*p; c=b;
if (bi->biBitCount>8){ g=*(p+1); c=g; }
if(bi->biBitCount>16){ r=*(p+2); c=r; }

// c = r | (g<<8) | (b<<16); 
if ( !(c>=co && c<=CO) ){ cp=0; continue; }
 

cp++;  
if (cp>=er)break;

p+=bi->biBitCount/8; 
}  // for j  


if (cp>=er) break; 
rs.bottom--; 
}  // for i 



//rs.left = re.left;  // ������ѡ�� break; 

for( int j=re.left; j<re.right; j++ ){

cp=0;

for( int i=re.top; i<re.bottom; i++ ){
 
c=0;  b=g=r=0; 

p=pi + i*wb+j*bi->biBitCount/8;   // ָ��� i �� j ��

b=*p; c=b;
if (bi->biBitCount>8){ g=*(p+1); c=g; }
if(bi->biBitCount>16){ r=*(p+2); c=r; }

// c = r | (g<<8) | (b<<16); 
if ( !(c>=co && c<=CO) ){ cp=0; continue; }
 

cp++;  
if (cp>=er)break;

p+=bi->biBitCount/8; 
}  // for i  

if (cp>=er) break; 
rs.left++; 
}  // for j 





//rs.right = re.right;  

for( int j=re.right-1; j>=re.left; j--){

cp=0;

for( int i=re.top; i<re.bottom; i++ ){
 
c=0;  b=g=r=0; 

p=pi + i*wb+j*bi->biBitCount/8;   // ָ��� i �� j ��

b=*p; c=b;
if (bi->biBitCount>8){ g=*(p+1); c=g; }
if(bi->biBitCount>16){ r=*(p+2); c=r; }

// c = r | (g<<8) | (b<<16); 
if ( !(c>=co && c<=CO) ){ cp=0; continue; }
 

cp++;  
if (cp>=er)break;

p+=bi->biBitCount/8; 
}  // for i  

if (cp>=er) break; 

rs.right--; 
}  // for j 







*rc=rs; 

// qTrace("[%d,%d,  %d,%d] /[%d,%d,  %d,%d]", rs.left, rs.top, rs.right, rs.bottom,  re.left, re.top, re.right, re.bottom); 

return 1;
}