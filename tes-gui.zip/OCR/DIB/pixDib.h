

// PIXDIB.h
#ifndef _PIXDIB_H_
#define _PIXDIB_H_    // #endif  // _PIXDIB_H_ //

// �ṹ���� PIXDIB.CPP ��ʵ��
#ifdef  _PIXDIB_CPP_    // #define _PIXDIB_CPP_ // #include "pixDib.h"    
#define PIXDIB_EXTERN 
#else 
#define PIXDIB_EXTERN extern 
#endif  // _PIXDIB_CPP_ //



#include <Windows.h>

#include "pix.h"  



// #define BPL(biWidth,biBitCount)    ( (biWidth * biBitCount + 31) & ~31 ) >> 3       //   λ������32ȡ�������� 8   
// #define BPL(bits)                  (((bits) + 31) / 32 * 4)                         //   2^5=32   2^2=4  

// pbi->biSizeImage = ( ( (biWidth*biBitCount + 31) & ~31 ) >> 3) * biHeight; 

// pixCreateHeader  wpl= (l_int32)wpl64,  wpl64= ((l_uint64)width * (l_uint64)depth + 31) / 32;    // û�� *4, ��ÿ�� DWORD (32-λ) ����  




int show_data(BYTE *pDib,  const char* file="show_data.log"); 



PIX * pixReadDib(const char  *filename);  

BYTE * pixToDib(const PIX  *pix);  


#endif  // _PIXDIB_H_ //


