
#pragma warning(disable:4996)



#ifndef _DIPR_H_
#define _DIPR_H_    // #endif  // _DIPR_H_ //

#include <Windows.h>
#include "Dib.h"


// �ṹ����DIPR.cpp��ʵ��;
#ifdef  _DIPR_CPP_    // #endif  // _DIPR_CPP_ //
#define DIPR_EXTERN 
#else 
#define DIPR_EXTERN extern 
#endif  // _DIPR_CPP_ //


// #pragma pack( push, 1 )  // n=1,2,4, 8-default
  


int dipr_area(BYTE* pbi, RECT*rc); 
bool dipr_Equ(DWORD c, DWORD co, int er); 


#if CONVOLUTION_TEMPLATE|1 

typedef struct CONVO_KERNEL{
 
int    w,  h;      // ����� w��h
int    cx, cy;     // ����Ԫ������ (�б�,�б�)
float  divisor;    // ���Ϊ0, ����Ҫ�Ѿ��������Ԫ�ؼ�������ΪĬ��ֵ    
float* mat;        // ����Ԫ�� 

} KERNEL, TEMPLATE;  



#endif  




BOOL ThresholdDIB(LPSTR lpDIBBits,LONG lWidth, LONG lHeight); 
LPBYTE dipr_binv(BYTE*pDib); 
float  getThreshold(BYTE*pDib); 






int* getHistogram(BYTE*pDib, int* pH); 

int* getMargin(BYTE*pDib, int cri=127,  bool bh=0);




void drawHistogram(HDC hdc, BYTE*pH, RECT*prc=0);  














#if IMAGE_SPLIT |1 

// ��� a,�ھ��� rc ��  
 
inline bool  InRect(int x, int y, RECT* rc){ return x>=rc->left && x<=rc->right && y>=rc->top && y<=rc->bottom; }





// ���֮��ľ��� 
inline int _GD(int xo, int yo, int x, int y)  {  

int dy=y  - yo; 
if(dy<0) dy=-dy;  
int dx=x - xo;
if (dx<0) dx=-dx; 
return dx>dy ? dx:dy;  
}


// ��� a,b ֮��ľ��� 
inline int _GD(int a, int b, int W)  {  
int dy=a / W  - b / W; 
if(dy<0) dy=-dy;  
int dx=a%W - b%W;
if (dx<0) dx=-dx; 
return dx>dy ? dx:dy;  
}


// ��� a,b ֮��ľ��� 
inline int _GD(int a, int b, BYTE*pDib)  {  

int W= ((LPBITMAPINFOHEADER)pDib)->biWidth;
W =  ( W*((LPBITMAPINFOHEADER)pDib)->biBitCount +31 )/32 * 4;  

int dy=a / W  - b / W; 
if(dy<0) dy=-dy;  
int dx=a%W - b%W;
if (dx<0) dx=-dx; 
return dx>dy ? dx:dy;  
}






// �㵽���ϵĸ�����. ���ϱ�����: λͼ + ���α߽�������, �þ����ǰ�����������'��ɫ'���ص���С����

inline int _GD(int x, int y, BYTE*pDib, RECT*rb,int cri)  {   // >cri, ��ɫ��׼, Ĭ�� 100��127 

LPBITMAPINFOHEADER pih = (LPBITMAPINFOHEADER)pDib;

BYTE*pi = LocBits(pDib); 

int H=pih->biHeight;

LPBITMAPINFOHEADER bi=(LPBITMAPINFOHEADER)pDib; 

int W= bi->biWidth;
W =  ( W*bi->biBitCount +31 )/32 * 4;  

int w=rb->right-rb->left, h=rb->bottom-rb->top;  


//assert(  0<=w<=W && 0<h<=H);  assert(rb->right<=bi->biWidth  && rb->bottom<=bi->biHeight );  

int c, t, D=(W>H) ? W:H;  // �� 
int d=D;
 
for (int j = rb->top; j <= rb->bottom; j++)
for (int i=rb->left; i<=rb->right; i++){

	c = pi[i+j*W];
	if (c<=cri) continue; 

	d = i - x;  if (d<0) d=-d; 

	t = j - y; if (t<0) t=-t;
	if (d<t) d=t; 

	if (D>d) D=d; 

}  // for j,i 

return D;  
}



#endif  // IMAGE_SPLIT |1 




void  OnEdgeRobert(LPBYTE pDIB);
bool edge_Robert(BYTE*pDib); 

BYTE* dipr_sp0(LPBYTE pbi, int cri, float dri=0);    // dri -- reserved 



void dipr_draw(HDC hdc, BYTE*pDib, RECT*rd=0,  RECT*rs=0);  















// Templates  


#if CPP_TEMPLATES |1

template <class T>
void drawDistribution(HDC hdc, T*pH, int ic, RECT*prc=0){  
	
if (!pH) return; 
if (ic<=0) return; 


RECT rc;
if (prc == 0){ GetClientRect(WindowFromDC(hdc), &rc);  prc =&rc;} 

float w=prc->right-prc->left, h=prc->bottom-prc->top; 

int m=pH[0], M=pH[0]; 
for (int i = 0; i<ic; i++) {
	if (M<pH[i]) M = pH[i]; 
	if (m>pH[i]) m = pH[i]; 
}

// int H = M - m;  if (H==0) H=1; 
int H = M;  if (-m>M) H = -m;  if (H==0) H=1;  

float dx=w/ic,  dy=h/(H+1);  
float xo=prc->left, yo=prc->bottom; 
float x=prc->right, y=yo; 


x=xo, y=yo;
for (int i=0; i<ic; i++){
y= yo- pH[i]*dy ;
 
MoveToEx(hdc, x, yo, 0); LineTo(hdc,x,y); 
x+=dx; 
}  // for i 


HPEN hPen = (HPEN)GetStockObject(DC_PEN); 
HPEN hPenO= (HPEN)SelectObject(hdc, hPen); 
SetDCPenColor(hdc, 0xFF0000); 

char sz[4]={'O',0x20, 0, 0}; 
SetBkMode(hdc,TRANSPARENT);
SetTextColor(hdc, 0xFF0000); 
TextOut(hdc, xo,yo, sz,2); 

x=prc->right, y=yo; 
MoveToEx(hdc, xo, yo, 0); LineTo(hdc,x,y); 
sz[0] = 'x'; 
TextOut(hdc, x,yo, sz,2); 


x=xo, y=prc->top; 
//MoveToEx(hdc, xo, yo, 0); LineTo(hdc,x,y); 
MoveToEx(hdc, xo-2, yo, 0); LineTo(hdc,x-2,y); 
sz[0] = 'y'; 
TextOut(hdc, xo,y, sz,2); 

SelectObject(hdc, hPenO); 
}




#if DO_STATISTICS|1

template <class T>
int dipr_stati(T*pH, int ic){

FILE*fp = fopen("Statistics.txt","w+b");
if(!fp){ qTrace("ic=%d",ic);  return 0; }
// int*pH=g_pSt; 


 


T m=pH[0], M=pH[0];   // ���� T ��Ϊ int ����. 
for (int i = 0; i<ic; i++) {
	if (M<pH[i]) M = pH[i]; 
	if (m>pH[i]) m = pH[i]; 
}

fprintf(fp, "\r\n���ݸ���\t %d\r\n", ic);
fprintf(fp, "��С�����ֵ\t m=%d, M=%d\r\n", m,M);




fprintf(fp, "\r\n�����Է�������\r\n");

int id=10;  // �����Բ��
T t, to; 

T*gp = (T*)malloc(sizeof(T)*ic); 
memset(gp, 0, sizeof(T)*ic);  

int ir = 0; gp[0]=0;  

to=pH[0];

for (int i=0; i<ic; i++){
t=pH[i];
if (t> to+id || t<to-id){ ir++; to=t; }

gp[ir]++; 
}

fprintf(fp, "������\t%d\r\n", ir);

qTrace("ir=%d",  ir);

for (int i=0; i<=ir; i++)fprintf(fp, "[%2d]\t%d\r\n", i,  gp[i]);


fprintf(fp, "\r\n��������\r\n");


int ig=(M-m)/id+1;   // 0--256 ÿ�� 10  ����һ�� 


gp=(T*)realloc(gp,ig*sizeof(T));

for (int k=0; k<ig; k++)gp[k] =0; 


for (int i=0; i<ic; i++){
t=pH[i];
t-=m; 
for (int k=0; k<ig; k++){
	if (t>=(k-1)*id && t<k*id)  gp[k]++; 
}
}


for (int k=0; k<ig; k++)fprintf(fp, "[%2d-%2d]\t%d\r\n", id*k+m,id*(k+1)+m,  gp[k]);

free(gp); 









fprintf(fp, "\r\n����\r\n");


ir=0; 
to=pH[0];  

for (int i=0; i<ic; i++){

t = pH[i]; 
 
if (t>to + id || t<to - id){ 
ir++; 
fprintf(fp, "\r\n...... %3d ......\r\n", ir);
to=t; 
}

fprintf(fp, "[%3d]\t%d\r\n", i,t);

}  // for i 





fflush(fp); 
fclose(fp); 


//if((int)ShellExecute(0, "open", "Statistics.txt", 0, 0, SW_SHOW)<=32) eInfo("ShellExecute");   
return 0;  
}

















#endif  // DO_STATISTICS





#endif  // CPP_TEMPLATES  








BYTE* dipr_msk24(LPBYTE pbi, DWORD* cs =0, bool bErase=false);  



int getHisto24(LPBYTE pbi, DWORD*sc=0, int n=16, const char*szFile = 0); 

int dipr_cs(LPBYTE pbi, RECT* rc=0L,  const char*szFile=0);   // =8   = 0


int dipr_addPixel(BYTE*pDIB, const BYTE* cDIB,  DWORD* sc, bool bErase=false); 


// DWORD WINAPI thr_anim(LPVOID Param); 
HANDLE dipr_anim(LPBYTE pbi, const LPBYTE cbi, RECT* rc=0); 


int dipr_ct(LPBYTE pbi, RECT* rc=0,  DWORD*MC=0);
int* dipr_hg(LPBYTE pbi, RECT* rc, int *hg, int n);



int dipr_cut(LPBYTE pbi, RECT* rc,  const char*szFile);  // =0   = 0
int dipr_Cut(HWND hWnd,  const char*szFile=0);



int dipr_amp(LPBYTE pbi,  RECT* rc=0, DWORD sc[4]=0); 



HANDLE dipr_grow(HWND hWnd_src,  HWND hWnd_tr); 


int dipr_sp(BYTE*pbi, RECT*rc, BYTE*pSrc, int g);   


#endif  // _DIPR_H_ //





