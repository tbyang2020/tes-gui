




#ifndef _VMATH_H_
#define _VMATH_H_    // #endif  // _VMATH_H_ //

#include <Windows.h>


// �ṹ����VMATH.cpp��ʵ��;
#ifdef  _VMATH_CPP_    // #endif  // _VMATH_CPP_ //
#define VMATH_EXTERN 
#else 
#define VMATH_EXTERN extern 
#endif  // _VMATH_CPP_ //



template<class T> T maxi(T a, T b, T c){  T d=max(a,b);  return d>c ? d:c; }   // max �� #define �� 
template<class T> T mini(T a, T b, T c){  T d=min(a,b);  return d>c ? c:d; }    
 


XFORM matinv(const XFORM& A); 
XFORM* matinv(XFORM*A);  

POINT matx(const POINT x,XFORM&A);
POINT* matx(XFORM&A, POINT* x); 
RECT* matx(XFORM&A, RECT*rc);  




XFORM* mkTransform( RECT rs, RECT tr, XFORM&xm); 


POINT* transPoint(POINT*pt, RECT*bmR, RECT* bcR, XFORM* gXF=0);  

// POINT* retPoint(POINT*pt, RECT*bmR, RECT* bcR, XFORM* gXF);  


RECT*intr(RECT*rt, RECT*rs);   // ���� rt��rs֮����, ��������� rt, ���� rt.  




#endif  // _VMATH_H_ //





