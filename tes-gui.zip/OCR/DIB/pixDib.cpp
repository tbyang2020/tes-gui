




#define _PIXDIB_CPP_ 
#include "pixDib.h"  

#include "pix.h"  
#include "imageio.h"  


#include <Windows.h>    // wingdi.h  BITMAPFILEHEADER ...  
#include <stdio.h>

#include "qTrace.h"


#define   BMP_FH  BITMAPFILEHEADER   //  BMP_FileHeader  = BITMAPFILEHEADER    see bmp.h  
#define   BMP_IH  BITMAPINFOHEADER   //  BMP_InfoHeader  = BITMAPINFOHEADER
#define   BMP_ID  0x4d42             //  DIB_MARKER,    ((WORD) ('M' << 8) | 'B'),      "BM",     0x4D42,  42 4D 




#ifdef __cplusplus
extern "C" {
#endif  //  __cplusplus  
LEPT_DLL extern PIX * pixReadMemBmp ( const l_uint8 *cdata, size_t size );

LEPT_DLL extern PIX * pixCreate ( l_int32 width, l_int32 height, l_int32 depth );

// LEPT_DLL extern l_int32 pixSetXRes ( PIX *pix, l_int32 res );

// LEPT_DLL extern l_int32 pixSetYRes ( PIX *pix, l_int32 res );

// LEPT_DLL extern l_int32 pixSetInputFormat ( PIX *pix, l_int32 informat );

// LEPT_DLL extern l_int32 pixGetWpl ( PIX *pix );

LEPT_DLL extern PIXCMAP * pixcmapCreate ( l_int32 depth );
LEPT_DLL extern l_int32 pixSetColormap ( PIX *pix, PIXCMAP *colormap );

// LEPT_DLL extern l_uint32 * pixGetData ( PIX *pix );

LEPT_DLL extern l_int32 pixEndianByteSwap ( PIX *pixs );

LEPT_DLL extern PIX * pixRemoveColormap ( PIX *pixs, l_int32 type );

LEPT_DLL extern void pixDestroy ( PIX **ppix );


#ifdef __cplusplus
}
#endif  // __cplusplus  




 


int show_data(BYTE *pDib,  const char* file){  // ="show_data.log"

if(!pDib) return 0; 


BITMAPINFOHEADER *pBI =(BITMAPINFOHEADER *)pDib;   


FILE *fp=fopen(file, "wb");
fprintf(fp, "\r\n\r\npBI=\r\n\r\n"); 

fprintf(fp, "biSize = %d\r\n", pBI->biSize);   
fprintf(fp, "biWidth = %d\r\n", pBI->biWidth); 
fprintf(fp, "biHeight = %d\r\n", pBI->biHeight); 
fprintf(fp, "biPlanes = %d\r\n", pBI->biPlanes); 
fprintf(fp, "biBitCount = %d\r\n", pBI->biBitCount); 
fprintf(fp, "biCompression = %d\r\n", pBI->biCompression); 
fprintf(fp, "biSizeImage = %d\r\n", pBI->biSizeImage); 
fprintf(fp, "biXPelsPerMeter = %d\r\n", pBI->biXPelsPerMeter); 
fprintf(fp, "biYPelsPerMeter = %d\r\n", pBI->biYPelsPerMeter); 
fprintf(fp, "biClrUsed = %d\r\n", pBI->biClrUsed); 
fprintf(fp, "biClrImportant = %d\r\n", pBI->biClrImportant); 


fprintf(fp, "\r\n"); 
fclose(fp);
ShellExecute(0, "open", file, 0, 0, SW_SHOW);

return true;
}




// pixReadMemBmp �� 

PIX * pixFromDib(const l_uint8  *cdata) {  // , size_t size

if (!cdata) return 0;

// if (size < sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER)) return 0;

BMP_FH*  bmpfh = (BMP_FH *)cdata;        //  Verify this is an uncompressed bmp  
// bftype = bmpfh->bfType;         // = convertOnBigEnd16(bmpfh->bfType);
if (bmpfh->bfType != BMP_ID){  qTrace("bfType=%X\r\nnot bmf format.", bmpfh->bfType);  return 0;  }  

BMP_IH*  bmpih = (BMP_IH *)(cdata + sizeof(BMP_FH));
// if (!bmpih) return 0;  

// compression = bmpih->biCompression;    // convertOnBigEnd32(bmpih->biCompression);
if (bmpih->biCompression != 0){ qTrace("compression=%X\r\ncannot read compressed BMP files", bmpih->biCompression); return 0; } // BI_RGB = 0
                                

l_int32    width  = bmpih->biWidth;      // convertOnBigEnd32(bmpih->biWidth);
l_int32    height = bmpih->biHeight;     // convertOnBigEnd32(bmpih->biHeight);
l_int32    imagebytes = bmpih->biSizeImage;   // convertOnBigEnd32(bmpih->biSizeImage);
 
l_int32 fdatabpl = 4 * ((1LL * width * bmpih->biBitCount + 31)/32);       // bytes per line 
l_int16        d = (bmpih->biBitCount == 24) ? 32 : bmpih->biBitCount;    // Make a 32 bpp pix if depth is 24 bpp 


#if SANITY_CHECK

// Some sanity ��ȫ checking.  We impose limits on the image dimensions and number of pixels.  
// We make sure the file  is the correct size to hold the amount of uncompressed data that is specified in the header.  
// The number of colormap entries is checked: it can be either 0 (no cmap) or some number between 2 and 256.
//  Note that the imagebytes for uncompressed images is either  0 or the size of the file data.  (The fact that it can be 0 is perhaps some legacy glitch).  С����; Сë��; С���

if (width < 1){  qTrace("width=%d < 1", width); return 0; } 

if (width > 1000000) { qTrace("width=%d , too large", width); return 0; } 
        
if (height < 1){  qTrace("height=%d < 1", height); return 0; } 

if (height > 1000000){ qTrace("height=%d , too large", height); return 0; } 

l_int64 npixels = 1LL * width * height;

if (npixels > 400000000LL){     // L_MAX_ALLOWED_PIXELS = 400000000LL 
qTrace("npixels=%d , too large", npixels); 
return 0;
}

if (depth != 1 && depth != 2 && depth != 4 && depth != 8 && depth != 16 && depth != 24 && depth != 32) {
qTrace("depth not in {1, 2, 4, 8, 16, 24, 32}", depth); 
return 0;
}

if(imagebytes != 0 && imagebytes != fdatabpl * height) {
qTrace("imagebytes=%d, invalid imagebytes\r\nfdatabpl * height=%d", imagebytes,  fdatabpl * height); 
return 0;
}

if(size != 1LL * offset + 1LL * fdatabpl * height){
qTrace("size=%d incommensurate with image data, %d", size,  1LL * offset + 1LL * fdatabpl * height); 
return 0; 
}


#endif  // SANITY_CHECK



#if COPY_PAL|1        // Handle the colormap  

l_int32  cmapbytes = bmpfh->bfOffBits - sizeof(BMP_FH)-  sizeof(BMP_IH);      // bmp.h
l_int32  cmapEntries = cmapbytes / sizeof(RGBA_QUAD);

if (cmapEntries > 256 || cmapEntries < 0 || cmapEntries == 1){
qTrace("invalid: cmap size =%d too large, or < 0 or 1", cmapEntries); 
return 0; 
}
 
l_uint8* cmapBuf = NULL;
if (cmapEntries > 0) {
if ((cmapBuf = (l_uint8 *)calloc(cmapEntries, sizeof(RGBA_QUAD))) == NULL){ qTrace("cmapBuf alloc fail"); return 0;}
memcpy(cmapBuf, cdata + sizeof(BMP_FH) + sizeof(BMP_IH), sizeof(RGBA_QUAD) * cmapEntries);            // Read the colormap entry data from bmp. The RGBA_QUAD colormap  entries are used for both bmp and leptonica colormaps.  
}

PIXCMAP   *cmap  = NULL;   // Convert the bmp colormap to a pixcmap  

    if (cmapEntries > 0) {  // import the colormap to the pix cmap  
        cmap = pixcmapCreate(L_MIN(d, 8));
        free(cmap->array);  // remove generated cmap array  
        cmap->array  = (void *)cmapBuf;  // and replace  
        cmap->n = L_MIN(cmapEntries, 256);
    }



#endif     //  COPY_PAL



PIX       *pix, *pix1;

if ( ( pix = pixCreate( bmpih->biWidth,  bmpih->biHeight,  (bmpih->biBitCount==24)? 32: bmpih->biBitCount )     ) == NULL) {
qTrace( "pix not made");    
return 0;
}


pix->informat = IFF_BMP;    // pixSetInputFormat(pix, IFF_BMP);

pix->xres = (l_int32)( (l_float32)bmpih->biXPelsPerMeter / 39.37 + 0.5 );  // to ppi   // pixSetXRes(pix, (l_int32)((l_float32)xres / 39.37 + 0.5));   
pix->yres = (l_int32)( (l_float32)bmpih->biYPelsPerMeter / 39.37 + 0.5 );  // to ppi   // pixSetYRes(pix, (l_int32)((l_float32)yres / 39.37 + 0.5));  

// qTrace("bmpih->biXPelsPerMeter=%d\r\npix->xres=%d",  bmpih->biXPelsPerMeter, pix->xres); 

if(cmap) pixSetColormap(pix, cmap);




#if COPY_DATA|1

l_uint32  *line, *pixdata, *pword;

l_uint8   *fdata, *data;

l_int32    extrabytes,  i, j, k;

l_uint8    pel[4];


l_int32 pixWpl = pix->wpl;
l_int32 pixBpl = 4 * pixWpl;

// Acquire the image data.  Image origin for bmp is at lower right. 
fdata = (l_uint8 *)cdata + bmpfh->bfOffBits;    // start of the bmp image data  

pixdata = pix->data;
    if (bmpih->biBitCount != 24) {  /* typ. 1 or 8 bpp */
        data = (l_uint8 *)pixdata + pixBpl * (height - 1);
        for (i = 0; i < height; i++) {
            memcpy(data, fdata, fdatabpl);
            fdata += fdatabpl;
            data -= pixBpl;
        }
    } else {  /*  24 bpp file; 32 bpp pix
             *  Note: for bmp files, pel[0] is blue, pel[1] is green,
             *  and pel[2] is red.  This is opposite to the storage
             *  in the pix, which puts the red pixel in the 0 byte,
             *  the green in the 1 byte and the blue in the 2 byte.
             *  Note also that all words are endian flipped after
             *  assignment on L_LITTLE_ENDIAN platforms.
             *
             *  We can then make these assignments for little endians:
             *      SET_DATA_BYTE(pword, 1, pel[0]);      blue
             *      SET_DATA_BYTE(pword, 2, pel[1]);      green
             *      SET_DATA_BYTE(pword, 3, pel[2]);      red
             *  This looks like:
             *          3  (R)     2  (G)        1  (B)        0
             *      |-----------|------------|-----------|-----------|
             *  and after byte flipping:
             *           3          2  (B)     1  (G)        0  (R)
             *      |-----------|------------|-----------|-----------|
             *
             *  For big endians we set:
             *      SET_DATA_BYTE(pword, 2, pel[0]);      blue
             *      SET_DATA_BYTE(pword, 1, pel[1]);      green
             *      SET_DATA_BYTE(pword, 0, pel[2]);      red
             *  This looks like:
             *          0  (R)     1  (G)        2  (B)        3
             *      |-----------|------------|-----------|-----------|
             *  so in both cases we get the correct assignment in the PIX.
             *
             *  Can we do a platform-independent assignment?
             *  Yes, set the bytes without using macros:
             *      *((l_uint8 *)pword) = pel[2];           red
             *      *((l_uint8 *)pword + 1) = pel[1];       green
             *      *((l_uint8 *)pword + 2) = pel[0];       blue
             *  For little endians, before flipping, this looks again like:
             *          3  (R)     2  (G)        1  (B)        0
             *      |-----------|------------|-----------|-----------|
             */
        extrabytes = fdatabpl - 3 * width;
        line = pixdata + pixWpl * (height - 1);
        for (i = 0; i < height; i++) {
            for (j = 0; j < width; j++) {
                pword = line + j;
                memcpy(&pel, fdata, 3);
                fdata += 3;
                *((l_uint8 *)pword + COLOR_RED) = pel[2];
                *((l_uint8 *)pword + COLOR_GREEN) = pel[1];
                *((l_uint8 *)pword + COLOR_BLUE) = pel[0];
            }
            if (extrabytes) {
                for (k = 0; k < extrabytes; k++) {
                    memcpy(&pel, fdata, 1);
                    fdata++;
                }
            }
            line -= pixWpl;
        }
    }

#endif  // COPY_DATA



//  pixEndianByteSwap(pix);   // Ĭ�� little-endian  

// We have no need for a 1 bpp pix with a colormap!

if (bmpih->biBitCount == 1 && cmap) {
        pix1 = pixRemoveColormap(pix, REMOVE_CMAP_TO_BINARY);
        pixDestroy(&pix);
        pix = pix1;  // rename  
    }

return pix;
}





// PIX �� DIB ע���ֽ�˳�����:if (depth <= 16)  pixEndianByteSwap(pixt);

// ע��  pixGetWindowsHBITMAP �������� pix->d=1 ��λͼ������ pixInvert ����, �ڰ�ɫ�ߵ�.  


BYTE * pixToDib(const PIX  *pix) {   

if (!pix) return 0;

if(pix->informat != IFF_BMP ) {  if(0)qTrace("informat=%d�� pix->d=%d", pix->informat, pix->d);  }

// pix->informat = IFF_BMP;  // =0? ����

BMP_FH bmpfh;            
bmpfh.bfType  = BMP_ID;    
bmpfh.bfOffBits=sizeof(BMP_FH)+sizeof(BMP_IH) +0;   // pix �Ƿ��� colormap 



int palSize=0;  // Handle the colormap  

if(pix->colormap){
palSize=sizeof(RGBQUAD)* pix->colormap->n;  
bmpfh.bfOffBits+= palSize;   // RGBQUAD ����, ֱ�� copy   
}


if (pix->d == 1) {
assert(palSize==0); 
palSize=sizeof(RGBQUAD)* 2;  
bmpfh.bfOffBits+= palSize;   // RGBQUAD ����, ֱ�� copy   
}







BYTE* pDIB= (BYTE*)malloc( sizeof(BMP_IH)+palSize+ pix->h*pix->wpl*4 );    //  pix->wpl ÿ�� 32-λ word ����  


BMP_IH* bmpih=(BMP_IH* )pDIB;     memset(bmpih,0, sizeof(BMP_IH));    // �������Ҫ  

bmpih->biSize=sizeof(BMP_IH); 
bmpih->biWidth=pix->w;
bmpih->biHeight=pix->h;

bmpih->biPlanes = 1; 

bmpih->biBitCount=pix->d;   // ���� 16 λֻ�� 32λ, û�� 24 λ.  
bmpih->biCompression=0;     // uncompressed bmp  0=BI_RGB  
 

bmpih->biXPelsPerMeter = ( pix->xres  - 0.5*0 )*39.37;           \
bmpih->biYPelsPerMeter = ( pix->yres  - 0.5*0 )*39.37;  
  


// l_uint64 bpl64 = ((l_uint64)pix->w * pix->d + 31) / 32 *4;  bmpih->biSizeImage= pix->h* bpl64;    // ������С��λ����!  
bmpih->biSizeImage= pix->h* pix->wpl*4;     

bmpih->biClrImportant=0;  


// memcpy( pDIB+ sizeof(BMP_IH)+palSize, pix->data,  pix->h*pix->wpl*4 );   // ������ߵ�ͼ�� 

assert(pix->colormap==0);


BYTE* p= pDIB+ sizeof(BMP_IH);
 
RGBQUAD*qu= (RGBQUAD*)p; 
if(pix->colormap){  // copy color table  



}else if(pix->d==1){
*qu++  = {0,0,0,0}; 
*qu={0xFF,0xFF,0xFF,0}; 
}






p= pDIB+ sizeof(BMP_IH)+palSize;
l_uint32* q= pix->data +  (pix->h-1)* pix->wpl;


#if SWAP_ENDIAN|1    

for(int i=0; i<pix->h; i++){



if(pix->d >16 ) memcpy(p,q, pix->wpl*4);  
else{

for(int j=0; j<pix->wpl; j++){     //  swap the bytes within a word; bytes 0 and 3 are swapped, and bytes 1 and 2 are swapped.

            DWORD dw = *(q+j);
            *(DWORD*)(p+j*4) = (dw >> 24) |
                    ((dw >> 8) & 0x0000ff00) |
                    ((dw << 8) & 0x00ff0000) |
                    (dw << 24);


}  // for j 



}  // if ... else 




p+=pix->wpl*4;
q-=pix->wpl;
}  // for  

#else





for(int i=0; i<pix->h; i++){
memcpy(p,q, pix->wpl*4);  
p+=pix->wpl*4;
q-=pix->wpl;
}  // for  


#endif  // SWAP_ENDIAN 





return pDIB;
}






PIX * pixReadDib(const char  *filename) {

if (!filename){ qTrace("filename not defineds");  return 0; }  


FILE  *fp  = fopen(filename, "rb"); 
if(fp== NULL) {  qTrace("error %d:\r\n%s\r\n%s", errno,  strerror(errno), filename); return NULL; }



PIX   * pix =  0;  // pixReadStreamBmp(fp);
    
#if PIX_READSTREAM|1

l_uint8  *data;

// rewind(fp);  // Read data from file and decode into Y,U,V arrays  
// if ((data = l_binaryReadStream(fp, &size)) == NULL){  pix=0;  }
   
fseek(fp, 0, SEEK_END);  // EOF //   // Verify and adjust the parameters if necessary /
size_t bytestoread = ftell(fp);
if ((data = (l_uint8 *)calloc(1, bytestoread + 1)) == NULL){ qTrace("calloc failed!"); fclose(fp); return 0; } 

fseek(fp, 0, SEEK_SET);
size_t nread = fread(data, 1, bytestoread, fp);

if (bytestoread != nread) {
qTrace("%lu bytes requested; %lu bytes read\n",   (unsigned long)bytestoread, (unsigned long)nread);
}
 






   

// pix = pixReadMemBmp(data, nread);

pix = pixFromDib(data);   // , nread


free(data);
return pix;






#endif  // PIX_READSTREAM










fclose(fp);

if (!pix) qTrace("pix not read:\r\n%s", filename);  
return pix;
}





// CreateDoc(getWnd(), DT_DIB,  pDib ); 


