




#define    _MINITES_CPP_ 

#include "miniTes.h"



#include "InterfaceMDI/qTrace.h"








using namespace tesseract;  


void position_outline(  C_OUTLINE *outline,       C_OUTLINE_LIST *destlist  );

 
namespace tesseract {

Pix* RemoveEnclosingCircle(Pix* pixs);    //  pagesegmain.cpp  

}
 






#if CONST_DEFS|1



enum OVERLAP_STATE
{
  ASSIGN,                        //assign it to row
  REJECT,                        //reject it - dual overlap
  NEW_ROW
};



// The number of points to consider at each end.
const int kNumEndPoints = 3;


const int kMaxRealDistance = 2.0;

const int kMinPointsForErrorCount = 16;




int textord_test_x= -MAX_INT32;  
int textord_test_y= -MAX_INT32; 

int textord_min_xheight= 10; 

double textord_excess_blobsize = 1.3; 



double textord_skew_lag = 0.75;  

double textord_overlap_x = 0.375;  

double textord_skew_ile = 0.5; 
double textord_occupancy_threshold = 0.4; 
double textord_linespace_iqrlimit = 0.2; 

double textord_min_blob_height_fraction = 0.75; 
double textord_underline_width = 2.0; 
double textord_underline_threshold = 0.9; 




bool  textord_show_final_rows = false; 

const int kMinSize = 8;  // Min pixels to be xheight.
const double kNoiseSize = 0.5;  // Fraction of xheight.


#endif    // CONST_DEFS






#if MAKEROW_CPP|1

static 
class DetLineFit {
 public:


DetLineFit::DetLineFit() : square_length_(0.0) {}

  ~DetLineFit(){};

// Delete all Added points.
void DetLineFit::Clear() {
  pts_.clear();
  distances_.clear();
}










// Add a new point. Takes a copy - the pt doesn't need to stay in scope.
void DetLineFit::Add(const ICOORD& pt) {
  pts_.push_back(PointWidth(pt, 0));
}






// Associates a half-width with the given point if a point overlaps the
// previous point by more than half the width, and its distance is further
// than the previous point, then the more distant point is ignored in the
// distance calculation. Useful for ignoring i dots and other diacritics.
void DetLineFit::Add(const ICOORD& pt, int halfwidth) {
  pts_.push_back(PointWidth(pt, halfwidth));
}






  // Fits a line to the points, returning the fitted line as a pair of
  // points, and the upper quartile error.
  double Fit(ICOORD* pt1, ICOORD* pt2) {    return Fit(0, 0, pt1, pt2);  }






// Fits a line to the points, ignoring the skip_first initial points and the
// skip_last final points, returning the fitted line as a pair of points,
// and the upper quartile error.
double DetLineFit::Fit(int skip_first, int skip_last,
                       ICOORD* pt1, ICOORD* pt2) {
  // Do something sensible with no points.
  if (pts_.empty()) {
    pt1->set_x(0);
    pt1->set_y(0);
    *pt2 = *pt1;
    return 0.0;
  }
  // Count the points and find the first and last kNumEndPoints.
  int pt_count = pts_.size();
  ICOORD* starts[kNumEndPoints];
  if (skip_first >= pt_count) skip_first = pt_count - 1;
  int start_count = 0;
  int end_i = MIN(skip_first + kNumEndPoints, pt_count);
  for (int i = skip_first; i < end_i; ++i) {
    starts[start_count++] = &pts_[i].pt;
  }
  ICOORD* ends[kNumEndPoints];
  if (skip_last >= pt_count) skip_last = pt_count - 1;
  int end_count = 0;
  end_i = MAX(0, pt_count - kNumEndPoints - skip_last);
  for (int i = pt_count - 1 - skip_last; i >= end_i; --i) {
    ends[end_count++] = &pts_[i].pt;
  }
  // 1 or 2 points need special treatment.
  if (pt_count <= 2) {
    *pt1 = *starts[0];
    if (pt_count > 1)
      *pt2 = *ends[0];
    else
      *pt2 = *pt1;
    return 0.0;
  }
  // Although with between 2 and 2*kNumEndPoints-1 points, there will be
  // overlap in the starts, ends sets, this is OK and taken care of by the
  // if (*start != *end) test below, which also tests for equal input points.
  double best_uq = -1.0;
  // Iterate each pair of points and find the best fitting line.
  for (int i = 0; i < start_count; ++i) {
    ICOORD* start = starts[i];
    for (int j = 0; j < end_count; ++j) {
      ICOORD* end = ends[j];
      if (*start != *end) {
        ComputeDistances(*start, *end);
        // Compute the upper quartile error from the line.
        double dist = EvaluateLineFit();
        if (dist < best_uq || best_uq < 0.0) {
          best_uq = dist;
          *pt1 = *start;
          *pt2 = *end;
        }
      }
    }
  }
  // Finally compute the square root to return the true distance.
  return best_uq > 0.0 ? sqrt(best_uq) : best_uq;
}








double DetLineFit::ConstrainedFit(const FCOORD& direction,
                                  double min_dist, double max_dist,
                                  bool debug, ICOORD* line_pt) {
  ComputeConstrainedDistances(direction, min_dist, max_dist);
  // Do something sensible with no points or computed distances.
  if (pts_.empty() || distances_.empty()) {
    line_pt->set_x(0);
    line_pt->set_y(0);
    return 0.0;
  }
  int median_index = distances_.choose_nth_item(distances_.size() / 2);
  *line_pt = distances_[median_index].data;
  if (debug) {
    tprintf("Constrained fit to dir %g, %g = %d, %d :%d distances:\n",
            direction.x(), direction.y(),
            line_pt->x(), line_pt->y(), distances_.size());
    for (int i = 0; i < distances_.size(); ++i) {
      tprintf("%d: %d, %d -> %g\n", i, distances_[i].data.x(),
              distances_[i].data.y(), distances_[i].key);
    }
    tprintf("Result = %d\n", median_index);
  }
  // Center distances on the fitted point.
  double dist_origin = direction * *line_pt;
  for (int i = 0; i < distances_.size(); ++i) {
    distances_[i].key -= dist_origin;
  }
  return sqrt(EvaluateLineFit());
}





// Returns true if there were enough points at the last call to Fit or
// ConstrainedFit for the fitted points to be used on a badly fitted line.
bool DetLineFit::SufficientPointsForIndependentFit() const {
  return distances_.size() >= kMinPointsForErrorCount;
}




  // Backwards compatible fit returning a gradient and constant.
  // Deprecated. Prefer Fit(ICOORD*, ICOORD*) where possible, but use this
  // function in preference to the LMS class.



double DetLineFit::Fit(float* m, float* c) {
  ICOORD start, end;
  double error = Fit(&start, &end);
  if (end.x() != start.x()) {
    *m = static_cast<float>(end.y() - start.y()) / (end.x() - start.x());
    *c = start.y() - *m * start.x();
  } else {
    *m = 0.0f;
    *c = 0.0f;
  }
  return error;
}




  // Backwards compatible constrained fit with a supplied gradient.
  // Deprecated. Use ConstrainedFit(const FCOORD& direction) where possible
  // to avoid potential difficulties with infinite gradients.



double DetLineFit::ConstrainedFit(double m, float* c) {
  // Do something sensible with no points.
  if (pts_.empty()) {
    *c = 0.0f;
    return 0.0;
  }
  double cos = 1.0 / sqrt(1.0 + m * m);
  FCOORD direction(cos, m * cos);
  ICOORD line_pt;
  double error = ConstrainedFit(direction, -MAX_FLOAT32, MAX_FLOAT32, false,
                                &line_pt);
  *c = line_pt.y() - line_pt.x() * m;
  return error;
}







 private:
  // Simple struct to hold an ICOORD point and a halfwidth representing half
  // the "width" (supposedly approximately parallel to the direction of the
  // line) of each point, such that distant points can be discarded when they
  // overlap nearer points. (Think i dot and other diacritics or noise.)
  struct PointWidth {
    PointWidth() : pt(ICOORD(0, 0)), halfwidth(0) {}
    PointWidth(const ICOORD& pt0, int halfwidth0)
      : pt(pt0), halfwidth(halfwidth0) {}

    ICOORD pt;
    int halfwidth;
  };
  // Type holds the of each point from the fitted line and the point
  // itself. Use of double allows integer distances from ICOORDs to be stored
  // exactly, and also the floating point results from ConstrainedFit.
  typedef KDPairInc<double, ICOORD> DistPointPair;




// Computes and returns the squared evaluation metric for a line fit.
double DetLineFit::EvaluateLineFit() {
  // Compute the upper quartile error from the line.
  double dist = ComputeUpperQuartileError();
  if (distances_.size() >= kMinPointsForErrorCount &&
      dist > kMaxRealDistance * kMaxRealDistance) {
    // Use the number of mis-fitted points as the error metric, as this
    // gives a better measure of fit for badly fitted lines where more
    // than a quarter are badly fitted.
    double threshold = kMaxRealDistance * sqrt(square_length_);
    dist = NumberOfMisfittedPoints(threshold);
  }
  return dist;
}









// Computes the absolute error distances of the points from the line,
// and returns the squared upper-quartile error distance.
double DetLineFit::ComputeUpperQuartileError() {
  int num_errors = distances_.size();
  if (num_errors == 0) return 0.0;
  // Get the absolute values of the errors.
  for (int i = 0; i < num_errors; ++i) {
    if (distances_[i].key < 0) distances_[i].key = -distances_[i].key;
  }
  // Now get the upper quartile distance.
  int index = distances_.choose_nth_item(3 * num_errors / 4);
  double dist = distances_[index].key;
  // The true distance is the square root of the dist squared / square_length.
  // Don't bother with the square root. Just return the square distance.
  return square_length_ > 0.0 ? dist * dist / square_length_ : 0.0;
}





// Returns the number of sample points that have an error more than threshold.
int DetLineFit::NumberOfMisfittedPoints(double threshold) const {
  int num_misfits = 0;
  int num_dists = distances_.size();
  // Get the absolute values of the errors.
  for (int i = 0; i < num_dists; ++i) {
    if (distances_[i].key > threshold)
      ++num_misfits;
  }
  return num_misfits;
}











// Computes all the cross product distances of the points from the line,
// storing the actual (signed) cross products in distances.
// Ignores distances of points that are further away than the previous point,
// and overlaps the previous point by at least half.
void DetLineFit::ComputeDistances(const ICOORD& start, const ICOORD& end) {
  distances_.truncate(0);
  ICOORD line_vector = end;
  line_vector -= start;
  square_length_ = line_vector.sqlength();
  int line_length = IntCastRounded(sqrt(square_length_));
  // Compute the distance of each point from the line.
  int prev_abs_dist = 0;
  int prev_dot = 0;
  for (int i = 0; i < pts_.size(); ++i) {
    ICOORD pt_vector = pts_[i].pt;
    pt_vector -= start;
    int dot = line_vector % pt_vector;
    // Compute |line_vector||pt_vector|sin(angle between)
    int dist = line_vector * pt_vector;
    int abs_dist = dist < 0 ? -dist : dist;
    if (abs_dist > prev_abs_dist && i > 0) {
      // Ignore this point if it overlaps the previous one.
      int separation = abs(dot - prev_dot);
      if (separation < line_length * pts_[i].halfwidth ||
          separation < line_length * pts_[i - 1].halfwidth)
        continue;
    }
    distances_.push_back(DistPointPair(dist, pts_[i].pt));
    prev_abs_dist = abs_dist;
    prev_dot = dot;
  }
}



















  
void DetLineFit::ComputeConstrainedDistances(const FCOORD& direction,
                                             double min_dist, double max_dist) {
  distances_.truncate(0);
  square_length_ = direction.sqlength();
  // Compute the distance of each point from the line.
  for (int i = 0; i < pts_.size(); ++i) {
    FCOORD pt_vector = pts_[i].pt;
    // Compute |line_vector||pt_vector|sin(angle between)
    double dist = direction * pt_vector;
    if (min_dist <= dist && dist <= max_dist)
      distances_.push_back(DistPointPair(dist, pts_[i].pt));
  }
}








  // Stores all the source points in the order they were given and their
  // halfwidths, if any.
  GenericVector<PointWidth> pts_;
  // Stores the computed perpendicular distances of (some of) the pts_ from a
  // given vector (assuming it goes through the origin, making it a line).
  // Since the distances may be a subset of the input points, and get
  // re-ordered by the nth_item function, the original point is stored
  // along side the distance.
  GenericVector<DistPointPair> distances_;  // Distances of points.
  // The squared length of the vector used to compute distances_.
  double square_length_;
};















//  @name blob_x_order    Sort function to sort blobs in x from page left.


//static 
int blob_x_order(                    //sort function
                 const void *item1,  //items to compare
                 const void *item2) {
                                 //converted ptr
  BLOBNBOX *blob1 = *(BLOBNBOX **) item1;
                                 //converted ptr
  BLOBNBOX *blob2 = *(BLOBNBOX **) item2;

  if (blob1->bounding_box ().left () < blob2->bounding_box ().left ())
    return -1;
  else if (blob1->bounding_box ().left () > blob2->bounding_box ().left ())
    return 1;
  else
    return 0;
}






//  @name row_y_order  Sort function to sort rows in y from page top.

static 
int row_y_order(                    //sort function
                const void *item1,  //items to compare
                const void *item2) {
                                 //converted ptr
  TO_ROW *row1 = *(TO_ROW **) item1;
                                 //converted ptr
  TO_ROW *row2 = *(TO_ROW **) item2;

  if (row1->parallel_c () > row2->parallel_c ())
    return -1;
  else if (row1->parallel_c () < row2->parallel_c ())
    return 1;
  else
    return 0;
}






// @name row_spacing_order  Qsort style function to compare 2 TO_ROWS based on their spacing value.

static 
int row_spacing_order(                    //sort function
                      const void *item1,  //items to compare
                      const void *item2) {
                                 //converted ptr
  TO_ROW *row1 = *(TO_ROW **) item1;
                                 //converted ptr
  TO_ROW *row2 = *(TO_ROW **) item2;

  if (row1->spacing < row2->spacing)
    return -1;
  else if (row1->spacing > row2->spacing)
    return 1;
  else
    return 0;
}







//  adjust_row_limits  Change the limits of rows to suit the default fractions.


static  
void adjust_row_limits(                 //tidy limits
                       TO_BLOCK *block  //block to do
                      ) {
  TO_ROW *row;                   //current row
  float size;                    //size of row
  float ymax;                    //top of row
  float ymin;                    //bottom of row
  TO_ROW_IT row_it = block->get_rows ();

  if (false)    // textord_show_expanded_rows = false
    tprintf("Adjusting row limits for block(%d,%d)\n",
            block->block->bounding_box().left(),
            block->block->bounding_box().top());
  for (row_it.mark_cycle_pt (); !row_it.cycled_list (); row_it.forward ()) {
    row = row_it.data ();
    size = row->max_y () - row->min_y ();
    if (false)    // textord_show_expanded_rows = false  
      tprintf("Row at %f has min %f, max %f, size %f\n",
              row->intercept(), row->min_y(), row->max_y(), size);
    size /= tesseract::CCStruct::kXHeightFraction +
        tesseract::CCStruct::kAscenderFraction +
        tesseract::CCStruct::kDescenderFraction;
    ymax = size * (tesseract::CCStruct::kXHeightFraction +
                   tesseract::CCStruct::kAscenderFraction);
    ymin = -size * tesseract::CCStruct::kDescenderFraction;
    row->set_limits (row->intercept () + ymin, row->intercept () + ymax);
    row->merged = FALSE;
  }
}





//  @name compute_row_stats  Compute the linespacing and offset.

static
void compute_row_stats(                  //find lines
                       TO_BLOCK *block,  //block to do
                       BOOL8 testing_on  //correct orientation
                      ) {
  inT32 row_index;               //of median
  TO_ROW *row;                   //current row
  TO_ROW *prev_row;              //previous row
  float iqr;                     //inter quartile range
  TO_ROW_IT row_it = block->get_rows ();
                                 //number of rows
  inT16 rowcount = row_it.length ();
  TO_ROW **rows;                 //for choose nth

  rows = (TO_ROW **) alloc_mem (rowcount * sizeof (TO_ROW *));
 //\\ if (rows == NULL)    MEMORY_OUT.error ("compute_row_stats", ABORT, NULL);
  rowcount = 0;
  prev_row = NULL;
  row_it.move_to_last ();        //start at bottom
  do {
    row = row_it.data ();
    if (prev_row != NULL) {
      rows[rowcount++] = prev_row;
      prev_row->spacing = row->intercept () - prev_row->intercept ();
      if (testing_on)
        tprintf ("Row at %g yields spacing of %g\n",
          row->intercept (), prev_row->spacing);
    }
    prev_row = row;
    row_it.backward ();
  }
  while (!row_it.at_last ());
  block->key_row = prev_row;
  block->baseline_offset =
    fmod (prev_row->parallel_c (), block->line_spacing);
  if (testing_on)
    tprintf ("Blob based spacing=(%g,%g), offset=%g",
      block->line_size, block->line_spacing, block->baseline_offset);
  if (rowcount > 0) {
    row_index = choose_nth_item (rowcount * 3 / 4, rows, rowcount,
      sizeof (TO_ROW *), row_spacing_order);
    iqr = rows[row_index]->spacing;
    row_index = choose_nth_item (rowcount / 4, rows, rowcount,
      sizeof (TO_ROW *), row_spacing_order);
    iqr -= rows[row_index]->spacing;
    row_index = choose_nth_item (rowcount / 2, rows, rowcount,
      sizeof (TO_ROW *), row_spacing_order);
    block->key_row = rows[row_index];
    if (testing_on)
      tprintf (" row based=%g(%g)", rows[row_index]->spacing, iqr);
    if (rowcount > 2
    && iqr < rows[row_index]->spacing * textord_linespace_iqrlimit) {
      if (!true) {
        if (rows[row_index]->spacing < block->line_spacing
          && rows[row_index]->spacing > block->line_size)
          //within range
          block->line_size = rows[row_index]->spacing;
        //spacing=size
        else if (rows[row_index]->spacing > block->line_spacing)
          block->line_size = block->line_spacing;
        //too big so use max
      }
      else {
        if (rows[row_index]->spacing < block->line_spacing)
          block->line_size = rows[row_index]->spacing;
        else
          block->line_size = block->line_spacing;
        //too big so use max
      }
      if (block->line_size < textord_min_xheight)
        block->line_size = (float) textord_min_xheight;
      block->line_spacing = rows[row_index]->spacing;
      block->max_blob_size =
        block->line_spacing * textord_excess_blobsize;
    }
    block->baseline_offset = fmod (rows[row_index]->intercept (),
      block->line_spacing);
  }
  if (testing_on)
    tprintf ("\nEstimate line size=%g, spacing=%g, offset=%g\n",
      block->line_size, block->line_spacing, block->baseline_offset);
  free_mem(rows);
}









// @name most_overlapping_row     Return the row which most overlaps the blob.


static  
OVERLAP_STATE most_overlapping_row(                    //find best row
                                   TO_ROW_IT *row_it,  //iterator
                                   TO_ROW *&best_row,  //output row
                                   float top,          //top of blob
                                   float bottom,       //bottom of blob
                                   float rowsize,      //max row size
                                   BOOL8 testing_blob  //test stuff
                                  ) {
  OVERLAP_STATE result;          //result of tests
  float overlap;                 //of blob & row
  float bestover;                //nearest row
  float merge_top, merge_bottom; //size of merged row
  ICOORD testpt;                 //testing only
  TO_ROW *row;                   //current row
  TO_ROW *test_row;              //for multiple overlaps
  BLOBNBOX_IT blob_it;           //for merging rows

  result = ASSIGN;
  row = row_it->data ();
  bestover = top - bottom;
  if (top > row->max_y ())
    bestover -= top - row->max_y ();
  if (bottom < row->min_y ())
                                 //compute overlap
    bestover -= row->min_y () - bottom;



   

  test_row = row;
  do {
    if (!row_it->at_last ()) {
      row_it->forward ();
      test_row = row_it->data ();
      if (test_row->min_y () <= top && test_row->max_y () >= bottom) {
        merge_top =
          test_row->max_y () >
          row->max_y ()? test_row->max_y () : row->max_y ();
        merge_bottom =
          test_row->min_y () <
          row->min_y ()? test_row->min_y () : row->min_y ();
        if (merge_top - merge_bottom <= rowsize) {
          if (testing_blob) {
            tprintf ("Merging rows at (%g,%g), (%g,%g)\n",
              row->min_y (), row->max_y (),
              test_row->min_y (), test_row->max_y ());
          }
          test_row->set_limits (merge_bottom, merge_top);
          blob_it.set_to_list (test_row->blob_list ());
          blob_it.add_list_after (row->blob_list ());
          blob_it.sort (blob_x_order);
          row_it->backward ();
          delete row_it->extract ();
          row_it->forward ();
          bestover = -1.0f;      //force replacement
        }
        overlap = top - bottom;
        if (top > test_row->max_y ())
          overlap -= top - test_row->max_y ();
        if (bottom < test_row->min_y ())
          overlap -= test_row->min_y () - bottom;
        if (bestover >= rowsize - 1 && overlap >= rowsize - 1) {
          result = REJECT;
        }
        if (overlap > bestover) {
          bestover = overlap;    //find biggest overlap
          row = test_row;
        }



       



      }
    }
  }
  while (!row_it->at_last ()
    && test_row->min_y () <= top && test_row->max_y () >= bottom);
  while (row_it->data () != row)
    row_it->backward ();         //make it point to row
                                 //doesn't overlap much
  if (top - bottom - bestover > rowsize * textord_overlap_x &&
      (!true || bestover < rowsize * textord_overlap_x)
    && result == ASSIGN)
    result = NEW_ROW;            //doesn't overlap enough
  best_row = row;
  return result;
}










//  @name assign_blobs_to_rows   Make enough rows to allocate all the given blobs to one.   If a block skew is given, use that, else attempt to track it.

static 
void assign_blobs_to_rows(                      //find lines
                          TO_BLOCK *block,      //block to do
                          float *gradient,      //block skew
                          int pass,             //identification
                          BOOL8 reject_misses,  //chuck big ones out
                          BOOL8 make_new_rows,  //add rows for unmatched
                          BOOL8 drawing_skew    //draw smoothed skew
                         ) {
  OVERLAP_STATE overlap_result;  //what to do with it
  float ycoord;                  //current y
  float top, bottom;             //of blob
  float g_length = 1.0f;         //from gradient
  inT16 row_count;               //no of rows
  inT16 left_x;                  //left edge
  inT16 last_x;                  //previous edge
  float block_skew;              //y delta
  float smooth_factor;           //for new coords
  float near_dist;               //dist to nearest row
  ICOORD testpt;                 //testing only
  BLOBNBOX *blob;                //current blob
  TO_ROW *row;                   //current row
  TO_ROW *dest_row = NULL;       //row to put blob in
                                 //iterators
  BLOBNBOX_IT blob_it = &block->blobs;
  TO_ROW_IT row_it = block->get_rows ();

  ycoord =
    (block->block->bounding_box ().bottom () +
    block->block->bounding_box ().top ()) / 2.0f;
  if (gradient != NULL)
    g_length = sqrt (1 + *gradient * *gradient);
#ifndef GRAPHICS_DISABLED
  if (drawing_skew)
    to_win->SetCursor(block->block->bounding_box ().left (), ycoord);
#endif
  testpt = ICOORD (textord_test_x, textord_test_y);
  blob_it.sort (blob_x_order);
  smooth_factor = 1.0;
  block_skew = 0.0f;
  row_count = row_it.length ();  //might have rows
  if (!blob_it.empty ()) {
    left_x = blob_it.data ()->bounding_box ().left ();
  }
  else {
    left_x = block->block->bounding_box ().left ();
  }
  last_x = left_x;
  for (blob_it.mark_cycle_pt (); !blob_it.cycled_list (); blob_it.forward ()) {
    blob = blob_it.data ();
    if (gradient != NULL) {
      block_skew = (1 - 1 / g_length) * blob->bounding_box ().bottom ()
        + *gradient / g_length * blob->bounding_box ().left ();
    }
    else if (blob->bounding_box ().left () - last_x > block->line_size / 2
      && last_x - left_x > block->line_size * 2
    && true) {    // textord_interpolating_skew = true
      //                      tprintf("Interpolating skew from %g",block_skew);
      block_skew *= (float) (blob->bounding_box ().left () - left_x)
        / (last_x - left_x);
      //                      tprintf("to %g\n",block_skew);
    }
    last_x = blob->bounding_box ().left ();
    top = blob->bounding_box ().top () - block_skew;
    bottom = blob->bounding_box ().bottom () - block_skew;
#ifndef GRAPHICS_DISABLED
    if (drawing_skew)
      to_win->DrawTo(blob->bounding_box ().left (), ycoord + block_skew);
#endif
    if (!row_it.empty ()) {
      for (row_it.move_to_first ();
        !row_it.at_last () && row_it.data ()->min_y () > top;
        row_it.forward ());
      row = row_it.data ();
      if (row->min_y () <= top && row->max_y () >= bottom) {
      //any overlap
        dest_row = row;
        overlap_result = most_overlapping_row (&row_it, dest_row,
          top, bottom,
          block->line_size,
          blob->bounding_box ().
          contains (testpt));
        if (overlap_result == NEW_ROW && !reject_misses)
          overlap_result = ASSIGN;
      }
      else {
        overlap_result = NEW_ROW;
        if (!make_new_rows) {
          near_dist = row_it.data_relative (-1)->min_y () - top;
                                 //below bottom
          if (bottom < row->min_y ()) {
            if (row->min_y () - bottom <=
              (block->line_spacing -
            block->line_size) * tesseract::CCStruct::kDescenderFraction) {
                                 //done it
              overlap_result = ASSIGN;
              dest_row = row;
            }
          }
          else if (near_dist > 0
          && near_dist < bottom - row->max_y ()) {
            row_it.backward ();
            dest_row = row_it.data ();
            if (dest_row->min_y () - bottom <=
              (block->line_spacing -
            block->line_size) * tesseract::CCStruct::kDescenderFraction) {
                                 //done it
              overlap_result = ASSIGN;
            }
          }
          else {
            if (top - row->max_y () <=
              (block->line_spacing -
              block->line_size) * (textord_overlap_x +
            tesseract::CCStruct::kAscenderFraction)) {
                                 //done it
              overlap_result = ASSIGN;
              dest_row = row;
            }
          }
        }
      }
      if (overlap_result == ASSIGN)
        dest_row->add_blob (blob_it.extract (), top, bottom,
          block->line_size);
      if (overlap_result == NEW_ROW) {
        if (make_new_rows && top - bottom < block->max_blob_size) {
          dest_row =
            new TO_ROW (blob_it.extract (), top, bottom,
            block->line_size);
          row_count++;
          if (bottom > row_it.data ()->min_y ())
            row_it.add_before_then_move (dest_row);
          //insert in right place
          else
            row_it.add_after_then_move (dest_row);
          smooth_factor =
            1.0 / (row_count * textord_skew_lag +
            4);    // textord_skewsmooth_offset = 4 
        }
        else
          overlap_result = REJECT;
      }
    }
    else if (make_new_rows && top - bottom < block->max_blob_size) {
      overlap_result = NEW_ROW;
      dest_row =
        new TO_ROW(blob_it.extract(), top, bottom, block->line_size);
      row_count++;
      row_it.add_after_then_move(dest_row);
      smooth_factor = 1.0 / (row_count * textord_skew_lag +
                             1);    // textord_skewsmooth_offset2 = 1
    }
    else
      overlap_result = REJECT;
    if (blob->bounding_box ().contains(testpt) && false) {    // textord_debug_blob=false 
      if (overlap_result != REJECT) {
        tprintf("Test blob assigned to row at (%g,%g) on pass %d\n",
          dest_row->min_y(), dest_row->max_y(), pass);
      }
      else {
        tprintf("Test blob assigned to no row on pass %d\n", pass);
      }
    }
    if (overlap_result != REJECT) {
      while (!row_it.at_first() &&
             row_it.data()->min_y() > row_it.data_relative(-1)->min_y()) {
        row = row_it.extract();
        row_it.backward();
        row_it.add_before_then_move(row);
      }
      while (!row_it.at_last() &&
             row_it.data ()->min_y() < row_it.data_relative (1)->min_y()) {
        row = row_it.extract();
        row_it.forward();
                                 // Keep rows in order.
        row_it.add_after_then_move(row);
      }
      BLOBNBOX_IT added_blob_it(dest_row->blob_list());
      added_blob_it.move_to_last();
      TBOX prev_box = added_blob_it.data_relative(-1)->bounding_box();
      if (dest_row->blob_list()->singleton() ||
          !prev_box.major_x_overlap(blob->bounding_box())) {
        block_skew = (1 - smooth_factor) * block_skew
            + smooth_factor * (blob->bounding_box().bottom() -
            dest_row->initial_min_y());
      }
    }
  }
  for (row_it.mark_cycle_pt(); !row_it.cycled_list(); row_it.forward()) {
    if (row_it.data()->blob_list()->empty())
      delete row_it.extract();  // Discard empty rows.
  }
}








//   @name fit_parallel_lms  Fit an LMS line to a row.   Make the fit parallel to the given gradient and set the  row accordingly.

static 
void fit_parallel_lms(float gradient, TO_ROW *row) {
  float c;                       // fitted line
  int blobcount;                 // no of blobs
   DetLineFit lms;
  BLOBNBOX_IT blob_it = row->blob_list();

  blobcount = 0;
  for (blob_it.mark_cycle_pt(); !blob_it.cycled_list(); blob_it.forward()) {
    if (!blob_it.data()->joined_to_prev()) {
      const TBOX& box = blob_it.data()->bounding_box();
      lms.Add(ICOORD((box.left() + box.right()) / 2, box.bottom()));
      blobcount++;
    }
  }
  double error = lms.ConstrainedFit(gradient, &c);
  row->set_parallel_line(gradient, c, error);
  if (false && blobcount > 12) {    // textord_straight_baselines = false     textord_lms_line_trials= 12  
    error = lms.Fit(&gradient, &c);
  }
                                 //set the other too
  row->set_line(gradient, c, error);
}






//  @name fit_parallel_rows  Re-fit the rows in the block to the given gradient.

static 
void fit_parallel_rows(                   //find lines
                       TO_BLOCK *block,   //block to do
                       float gradient,    //gradient to fit
                       FCOORD rotation,   //for drawing
                       inT32 block_edge,  //edge of block
                       BOOL8 testing_on   //correct orientation
                      ) {
#ifndef GRAPHICS_DISABLED
  ScrollView::Color colour;                 //of row
#endif
  TO_ROW_IT row_it = block->get_rows ();

  row_it.move_to_first ();
  for (row_it.mark_cycle_pt (); !row_it.cycled_list (); row_it.forward ()) {
    if (row_it.data ()->blob_list ()->empty ())
      delete row_it.extract ();  //nothing in it
    else
      fit_parallel_lms (gradient, row_it.data ());
  }
#ifndef GRAPHICS_DISABLED
  if (testing_on) {
    colour = ScrollView::RED;
    for (row_it.mark_cycle_pt (); !row_it.cycled_list (); row_it.forward ()) {
      plot_parallel_row (row_it.data (), gradient,
        block_edge, colour, rotation);
      colour = (ScrollView::Color) (colour + 1);
      if (colour > ScrollView::MAGENTA)
        colour = ScrollView::RED;
    }
  }
#endif
  row_it.sort (row_y_order);     //may have gone out of order
}









//   @name expand_rows  Expand each row to the least of its allowed size and touching its  neighbours. If the expansion would entirely swallow a neighbouring row  then do so.

static
void expand_rows(                   //find lines
                 ICOORD page_tr,    //top right
                 TO_BLOCK *block,   //block to do
                 float gradient,    //gradient to fit
                 FCOORD rotation,   //for drawing
                 inT32 block_edge,  //edge of block
                 BOOL8 testing_on   //correct orientation
                ) {
  BOOL8 swallowed_row;           //eaten a neighbour
  float y_max, y_min;            //new row limits
  float y_bottom, y_top;         //allowed limits
  TO_ROW *test_row;              //next row
  TO_ROW *row;                   //current row
                                 //iterators
  BLOBNBOX_IT blob_it = &block->blobs;
  TO_ROW_IT row_it = block->get_rows ();

#ifndef GRAPHICS_DISABLED
  if (textord_show_expanded_rows && testing_on) {
    if (to_win == NULL)
      create_to_win(page_tr);
  }
#endif

  adjust_row_limits(block);  //shift min,max.
  if (true) {   // textord_new_initial_xheight = true  
    if (block->get_rows ()->length () == 0)
      return;
    compute_row_stats(block, false &&testing_on);    // textord_show_expanded_rows = false
  }
  assign_blobs_to_rows (block, &gradient, 4, TRUE, FALSE, FALSE);
  //get real membership
  if (block->get_rows ()->length () == 0)
    return;
  fit_parallel_rows(block,
                    gradient,
                    rotation,
                    block_edge,
                    false &&testing_on);    // // textord_show_expanded_rows = false 
  if (!true)
    compute_row_stats(block, false &&testing_on);
  row_it.move_to_last ();
  do {
    row = row_it.data ();
    y_max = row->max_y ();       //get current limits      textord_expansion_factor=1.0  
    y_min = row->min_y ();
    y_bottom = row->intercept () - block->line_size * 1.0 *
      tesseract::CCStruct::kDescenderFraction;
    y_top = row->intercept () + block->line_size * 1.0 *
        (tesseract::CCStruct::kXHeightFraction +
         tesseract::CCStruct::kAscenderFraction);
    if (y_min > y_bottom) {      //expansion allowed
      if (false && testing_on)
        tprintf("Expanding bottom of row at %f from %f to %f\n",
                row->intercept(), y_min, y_bottom);
                                 //expandable
      swallowed_row = TRUE;
      while (swallowed_row && !row_it.at_last ()) {
        swallowed_row = FALSE;
                                 //get next one
        test_row = row_it.data_relative (1);
                                 //overlaps space
        if (test_row->max_y () > y_bottom) {
          if (test_row->min_y () > y_bottom) {
            if (false && testing_on)
              tprintf("Eating row below at %f\n", test_row->intercept());
            row_it.forward ();
#ifndef GRAPHICS_DISABLED
            if (textord_show_expanded_rows && testing_on)
              plot_parallel_row(test_row,
                                gradient,
                                block_edge,
                                ScrollView::WHITE,
                                rotation);
#endif
            blob_it.set_to_list (row->blob_list ());
            blob_it.add_list_after (test_row->blob_list ());
                                 //swallow complete row
            delete row_it.extract ();
            row_it.backward ();
            swallowed_row = TRUE;
          }
          else if (test_row->max_y () < y_min) {
                                 //shorter limit
            y_bottom = test_row->max_y ();
            if (false && testing_on)
              tprintf("Truncating limit to %f due to touching row at %f\n",
                      y_bottom, test_row->intercept());
          }
          else {
            y_bottom = y_min;    //can't expand it
            if (false && testing_on)
              tprintf("Not expanding limit beyond %f due to touching row at %f\n",
                      y_bottom, test_row->intercept());
          }
        }
      }
      y_min = y_bottom;          //expand it
    }
    if (y_max < y_top) {         //expansion allowed
      if (false && testing_on)
        tprintf("Expanding top of row at %f from %f to %f\n",
                row->intercept(), y_max, y_top);
      swallowed_row = TRUE;
      while (swallowed_row && !row_it.at_first ()) {
        swallowed_row = FALSE;
                                 //get one above
        test_row = row_it.data_relative (-1);
        if (test_row->min_y () < y_top) {
          if (test_row->max_y () < y_top) {
            if (false && testing_on)
              tprintf("Eating row above at %f\n", test_row->intercept());
            row_it.backward ();
            blob_it.set_to_list (row->blob_list ());
#ifndef GRAPHICS_DISABLED
            if (textord_show_expanded_rows && testing_on)
              plot_parallel_row(test_row,
                                gradient,
                                block_edge,
                                ScrollView::WHITE,
                                rotation);
#endif
            blob_it.add_list_after (test_row->blob_list ());
                                 //swallow complete row
            delete row_it.extract ();
            row_it.forward ();
            swallowed_row = TRUE;
          }
          else if (test_row->min_y () < y_max) {
                                 //shorter limit
            y_top = test_row->min_y ();
            if (false && testing_on)
              tprintf("Truncating limit to %f due to touching row at %f\n",
                      y_top, test_row->intercept());
          }
          else {
            y_top = y_max;       //can't expand it
            if (false && testing_on)
              tprintf("Not expanding limit beyond %f due to touching row at %f\n",
                      y_top, test_row->intercept());
          }
        }
      }
      y_max = y_top;
    }
                                 //new limits
    row->set_limits (y_min, y_max);
    row_it.backward ();
  }
  while (!row_it.at_last ());
}















//  @name deskew_block_coords  Compute the bounding box of all the blobs in the block  if they were deskewed without actually doing it.

static  
TBOX deskew_block_coords(                  //block box
                        TO_BLOCK *block,  //block to do
                        float gradient    //global skew
                       ) {
  TBOX result;                    //block bounds
  TBOX blob_box;                  //of block
  FCOORD rotation;               //deskew vector
  float length;                  //of gradient vector
  TO_ROW_IT row_it = block->get_rows ();
  TO_ROW *row;                   //current row
  BLOBNBOX *blob;                //current blob
  BLOBNBOX_IT blob_it;           //iterator

  length = sqrt (gradient * gradient + 1);
  rotation = FCOORD (1 / length, -gradient / length);
  for (row_it.mark_cycle_pt (); !row_it.cycled_list (); row_it.forward ()) {
    row = row_it.data ();
    blob_it.set_to_list (row->blob_list ());
    for (blob_it.mark_cycle_pt (); !blob_it.cycled_list ();
    blob_it.forward ()) {
      blob = blob_it.data ();
      blob_box = blob->bounding_box ();
      blob_box.rotate (rotation);//de-skew it
      result += blob_box;
    }
  }
  return result;
}

























// compute_occupation_threshold   Compute thresholds for textline or not for the occupation array.

static 
void compute_occupation_threshold(                    //project blobs
                                  inT32 low_window,   //below result point
                                  inT32 high_window,  //above result point
                                  inT32 line_count,   //array sizes
                                  inT32 *occupation,  //input projection
                                  inT32 *thresholds   //output thresholds
                                 ) {
  inT32 line_index;              //of thresholds line
  inT32 low_index;               //in occupation
  inT32 high_index;              //in occupation
  inT32 sum;                     //current average
  inT32 divisor;                 //to get thresholds
  inT32 min_index;               //of min occ
  inT32 min_occ;                 //min in locality
  inT32 test_index;              //for finding min

  divisor =
    (inT32) ceil ((low_window + high_window) / textord_occupancy_threshold);
  if (low_window + high_window < line_count) {
    for (sum = 0, high_index = 0; high_index < low_window; high_index++)
      sum += occupation[high_index];
    for (low_index = 0; low_index < high_window; low_index++, high_index++)
      sum += occupation[high_index];
    min_occ = occupation[0];
    min_index = 0;
    for (test_index = 1; test_index < high_index; test_index++) {
      if (occupation[test_index] <= min_occ) {
        min_occ = occupation[test_index];
        min_index = test_index;  //find min in region
      }
    }
    for (line_index = 0; line_index < low_window; line_index++)
      thresholds[line_index] = (sum - min_occ) / divisor + min_occ;
    //same out to end
    for (low_index = 0; high_index < line_count; low_index++, high_index++) {
      sum -= occupation[low_index];
      sum += occupation[high_index];
      if (occupation[high_index] <= min_occ) {
                                 //find min in region
        min_occ = occupation[high_index];
        min_index = high_index;
      }
                                 //lost min from region
      if (min_index <= low_index) {
        min_occ = occupation[low_index + 1];
        min_index = low_index + 1;
        for (test_index = low_index + 2; test_index <= high_index;
        test_index++) {
          if (occupation[test_index] <= min_occ) {
            min_occ = occupation[test_index];
                                 //find min in region
            min_index = test_index;
          }
        }
      }
      thresholds[line_index++] = (sum - min_occ) / divisor + min_occ;
    }
  }
  else {
    min_occ = occupation[0];
    min_index = 0;
    for (sum = 0, low_index = 0; low_index < line_count; low_index++) {
      if (occupation[low_index] < min_occ) {
        min_occ = occupation[low_index];
        min_index = low_index;
      }
      sum += occupation[low_index];
    }
    line_index = 0;
  }
  for (; line_index < line_count; line_index++)
    thresholds[line_index] = (sum - min_occ) / divisor + min_occ;
  //same out to end
}







//  @name compute_line_occupation  Compute the pixel projection back on the y axis given the global skew. Also compute the 1st derivative.

static 
void compute_line_occupation(                    //project blobs
                             TO_BLOCK *block,    //block to do
                             float gradient,     //global skew
                             inT32 min_y,        //min coord in block
                             inT32 max_y,        //in block
                             inT32 *occupation,  //output projection
                             inT32 *deltas       //derivative
                            ) {
  inT32 line_count;              //maxy-miny+1
  inT32 line_index;              //of scan line
  int index;                     //array index for daft compilers
  TO_ROW *row;                   //current row
  TO_ROW_IT row_it = block->get_rows ();
  BLOBNBOX *blob;                //current blob
  BLOBNBOX_IT blob_it;           //iterator
  float length;                  //of skew vector
  TBOX blob_box;                  //bounding box
  FCOORD rotation;               //inverse of skew

  line_count = max_y - min_y + 1;
  length = sqrt (gradient * gradient + 1);
  rotation = FCOORD (1 / length, -gradient / length);
  for (line_index = 0; line_index < line_count; line_index++)
    deltas[line_index] = 0;
  for (row_it.mark_cycle_pt (); !row_it.cycled_list (); row_it.forward ()) {
    row = row_it.data ();
    blob_it.set_to_list (row->blob_list ());
    for (blob_it.mark_cycle_pt (); !blob_it.cycled_list ();
    blob_it.forward ()) {
      blob = blob_it.data ();
      blob_box = blob->bounding_box ();
      blob_box.rotate (rotation);//de-skew it
      int32_t width = blob_box.right() - blob_box.left();
      index = blob_box.bottom() - min_y;
      ASSERT_HOST(index >= 0 && index < line_count);
                                 //count transitions
      deltas[index] += width;
      index = blob_box.top() - min_y;
      ASSERT_HOST(index >= 0 && index < line_count);
      deltas[index] -= width;
    }
  }
  occupation[0] = deltas[0];
  for (line_index = 1; line_index < line_count; line_index++)
    occupation[line_index] = occupation[line_index - 1] + deltas[line_index];
}







//   @name compute_dropout_distances   Compute the distance from each coordinate to the nearest dropout.

static 
void compute_dropout_distances(                    //project blobs
                               inT32 *occupation,  //input projection
                               inT32 *thresholds,  //output thresholds
                               inT32 line_count    //array sizes
                              ) {
  inT32 line_index;              //of thresholds line
  inT32 distance;                //from prev dropout
  inT32 next_dist;               //to next dropout
  inT32 back_index;              //for back filling
  inT32 prev_threshold;          //before overwrite

  distance = -line_count;
  line_index = 0;
  do {
    do {
      distance--;
      prev_threshold = thresholds[line_index];
                                 //distance from prev
      thresholds[line_index] = distance;
      line_index++;
    }
    while (line_index < line_count
      && (occupation[line_index] < thresholds[line_index]
      || occupation[line_index - 1] >= prev_threshold));
    if (line_index < line_count) {
      back_index = line_index - 1;
      next_dist = 1;
      while (next_dist < -distance && back_index >= 0) {
        thresholds[back_index] = next_dist;
        back_index--;
        next_dist++;
        distance++;
      }
      distance = 1;
    }
  }
  while (line_index < line_count);
}









//  @name find_best_dropout_row  Delete this row if it has a neighbour with better dropout characteristics.    TRUE is returned if the row should be deleted.

static
BOOL8 find_best_dropout_row(                    //find neighbours
                            TO_ROW *row,        //row to test
                            inT32 distance,     //dropout dist
                            float dist_limit,   //threshold distance
                            inT32 line_index,   //index of row
                            TO_ROW_IT *row_it,  //current position
                            BOOL8 testing_on    //correct orientation
                           ) {
  inT32 next_index;              // of neighbouring row
  inT32 row_offset;              //from current row
  inT32 abs_dist;                //absolute distance
  inT8 row_inc;                  //increment to row_index
  TO_ROW *next_row;              //nextious row

  if (testing_on)
    tprintf ("Row at %g(%g), dropout dist=%d,",
      row->intercept (), row->parallel_c (), distance);
  if (distance < 0) {
    row_inc = 1;
    abs_dist = -distance;
  }
  else {
    row_inc = -1;
    abs_dist = distance;
  }
  if (abs_dist > dist_limit) {
    if (testing_on) {
      tprintf (" too far - deleting\n");
    }
    return TRUE;
  }
  if ((distance < 0 && !row_it->at_last ())
  || (distance >= 0 && !row_it->at_first ())) {
    row_offset = row_inc;
    do {
      next_row = row_it->data_relative (row_offset);
      next_index = (inT32) floor (next_row->intercept ());
      if ((distance < 0
        && next_index < line_index
        && next_index > line_index + distance + distance)
        || (distance >= 0
        && next_index > line_index
      && next_index < line_index + distance + distance)) {
        if (testing_on) {
          tprintf (" nearer neighbour (%d) at %g\n",
            line_index + distance - next_index,
            next_row->intercept ());
        }
        return TRUE;             //other is nearer
      }
      else if (next_index == line_index
      || next_index == line_index + distance + distance) {
        if (row->believability () <= next_row->believability ()) {
          if (testing_on) {
            tprintf (" equal but more believable at %g (%g/%g)\n",
              next_row->intercept (),
              row->believability (),
              next_row->believability ());
          }
          return TRUE;           //other is more believable
        }
      }
      row_offset += row_inc;
    }
    while ((next_index == line_index
      || next_index == line_index + distance + distance)
      && row_offset < row_it->length ());
    if (testing_on)
      tprintf (" keeping\n");
  }
  return FALSE;
}
















// delete_non_dropout_rows   Compute the linespacing and offset.

static 
void delete_non_dropout_rows(                   //find lines
                             TO_BLOCK *block,   //block to do
                             float gradient,    //global skew
                             FCOORD rotation,   //deskew vector
                             inT32 block_edge,  //left edge
                             BOOL8 testing_on   //correct orientation
                            ) {
  TBOX block_box;                 //deskewed block
  inT32 *deltas;                 //change in occupation
  inT32 *occupation;             //of pixel coords
  inT32 max_y;                   //in block
  inT32 min_y;
  inT32 line_index;              //of scan line
  inT32 line_count;              //no of scan lines
  inT32 distance;                //to drop-out
  inT32 xleft;                   //of block
  inT32 ybottom;                 //of block
  TO_ROW *row;                   //current row
  TO_ROW_IT row_it = block->get_rows ();
  BLOBNBOX_IT blob_it = &block->blobs;

  if (row_it.length () == 0)
    return;                      //empty block
  block_box = deskew_block_coords (block, gradient);
  xleft = block->block->bounding_box ().left ();
  ybottom = block->block->bounding_box ().bottom ();
  min_y = block_box.bottom () - 1;
  max_y = block_box.top () + 1;
  for (row_it.mark_cycle_pt (); !row_it.cycled_list (); row_it.forward ()) {
    line_index = (inT32) floor (row_it.data ()->intercept ());
    if (line_index <= min_y)
      min_y = line_index - 1;
    if (line_index >= max_y)
      max_y = line_index + 1;
  }
  line_count = max_y - min_y + 1;
  if (line_count <= 0)
    return;                      //empty block
  deltas = (inT32 *) alloc_mem (line_count * sizeof (inT32));
  occupation = (inT32 *) alloc_mem (line_count * sizeof (inT32));

  //\\ if (deltas == NULL || occupation == NULL)    MEMORY_OUT.error ("compute_line_spacing", ABORT, NULL);

  compute_line_occupation(block, gradient, min_y, max_y, occupation, deltas);
  compute_occupation_threshold ((inT32)
    ceil (block->line_spacing *
    (tesseract::CCStruct::kDescenderFraction +
    tesseract::CCStruct::kAscenderFraction)),
    (inT32) ceil (block->line_spacing *
    (tesseract::CCStruct::kXHeightFraction +
    tesseract::CCStruct::kAscenderFraction)),
    max_y - min_y + 1, occupation, deltas);
#ifndef GRAPHICS_DISABLED
  if (testing_on) {
    draw_occupation(xleft, ybottom, min_y, max_y, occupation, deltas);
  }
#endif
  compute_dropout_distances(occupation, deltas, line_count);
  for (row_it.mark_cycle_pt (); !row_it.cycled_list (); row_it.forward ()) {
    row = row_it.data ();
    line_index = (inT32) floor (row->intercept ());
    distance = deltas[line_index - min_y];
    if (find_best_dropout_row (row, distance, block->line_spacing / 2,
    line_index, &row_it, testing_on)) {
#ifndef GRAPHICS_DISABLED
      if (testing_on)
        plot_parallel_row(row, gradient, block_edge,
                          ScrollView::WHITE, rotation);
#endif
      blob_it.add_list_after (row_it.data ()->blob_list ());
      delete row_it.extract ();  //too far away
    }
  }
  for (row_it.mark_cycle_pt (); !row_it.cycled_list (); row_it.forward ()) {
    blob_it.add_list_after (row_it.data ()->blob_list ());
  }

  free_mem(deltas);
  free_mem(occupation);
}















//  @name compute_page_skew  Compute the skew over a full page by averaging the gradients over  all the lines. Get the error of the same row.


static 
void compute_page_skew(                        //get average gradient
                       TO_BLOCK_LIST *blocks,  //list of blocks
                       float &page_m,          //average gradient
                       float &page_err         //average error
                      ) {
  inT32 row_count;               //total rows
  inT32 blob_count;              //total_blobs
  inT32 row_err;                 //integer error
  float *gradients;              //of rows
  float *errors;                 //of rows
  inT32 row_index;               //of total
  TO_ROW *row;                   //current row
  TO_BLOCK_IT block_it = blocks; //iterator
  TO_ROW_IT row_it;

  row_count = 0;
  blob_count = 0;
  for (block_it.mark_cycle_pt (); !block_it.cycled_list ();
       block_it.forward ()) {
    POLY_BLOCK* pb = block_it.data()->block->poly_block();
    if (pb != NULL && !pb->IsText())
      continue;  // Pretend non-text blocks don't exist.
    row_count += block_it.data ()->get_rows ()->length ();
    //count up rows
    row_it.set_to_list (block_it.data ()->get_rows ());
    for (row_it.mark_cycle_pt (); !row_it.cycled_list (); row_it.forward ())
      blob_count += row_it.data ()->blob_list ()->length ();
  }
  if (row_count == 0) {
    page_m = 0.0f;
    page_err = 0.0f;
    return;
  }
  gradients = (float *) alloc_mem (blob_count * sizeof (float));
  //get mem
  errors = (float *) alloc_mem (blob_count * sizeof (float));

  
//\\ if (gradients == NULL || errors == NULL)  MEMORY_OUT.error ("compute_page_skew", ABORT, NULL);

  row_index = 0;
  for (block_it.mark_cycle_pt (); !block_it.cycled_list ();
       block_it.forward ()) {
    POLY_BLOCK* pb = block_it.data()->block->poly_block();
    if (pb != NULL && !pb->IsText())
      continue;  // Pretend non-text blocks don't exist.
    row_it.set_to_list (block_it.data ()->get_rows ());
    for (row_it.mark_cycle_pt (); !row_it.cycled_list (); row_it.forward ()) {
      row = row_it.data ();
      blob_count = row->blob_list ()->length ();
      row_err = (inT32) ceil (row->line_error ());
      if (row_err <= 0)
        row_err = 1;
      if (true) {    // textord_biased_skewcalc = true 
        blob_count /= row_err;
        for (blob_count /= row_err; blob_count > 0; blob_count--) {
          gradients[row_index] = row->line_m ();
          errors[row_index] = row->line_error ();
          row_index++;
        }
      }
      else if (blob_count >= 4) {    // textord_min_blobs_in_row = 4  
                                 //get gradient
        gradients[row_index] = row->line_m ();
        errors[row_index] = row->line_error ();
        row_index++;
      }
    }
  }
  if (row_index == 0) {
                                 //desperate
    for (block_it.mark_cycle_pt (); !block_it.cycled_list ();
         block_it.forward ()) {
      POLY_BLOCK* pb = block_it.data()->block->poly_block();
      if (pb != NULL && !pb->IsText())
        continue;  // Pretend non-text blocks don't exist.
      row_it.set_to_list (block_it.data ()->get_rows ());
      for (row_it.mark_cycle_pt (); !row_it.cycled_list ();
           row_it.forward ()) {
        row = row_it.data ();
        gradients[row_index] = row->line_m ();
        errors[row_index] = row->line_error ();
        row_index++;
      }
    }
  }
  row_count = row_index;
  row_index = choose_nth_item ((inT32) (row_count * textord_skew_ile),
    gradients, row_count);
  page_m = gradients[row_index];
  row_index = choose_nth_item ((inT32) (row_count * textord_skew_ile),
    errors, row_count);
  page_err = errors[row_index];
  free_mem(gradients);
  free_mem(errors);
}














// cleanup_rows_making   Remove overlapping rows and fit all the blobs to what's left.

static 
void cleanup_rows_making(                   //find lines
                  ICOORD page_tr,    //top right
                  TO_BLOCK *block,   //block to do
                  float gradient,    //gradient to fit
                  FCOORD rotation,   //for drawing
                  inT32 block_edge,  //edge of block
                  BOOL8 testing_on  //correct orientation
                 ) {
                                 //iterators
  BLOBNBOX_IT blob_it = &block->blobs;
  TO_ROW_IT row_it = block->get_rows ();

#ifndef GRAPHICS_DISABLED
  if (textord_show_parallel_rows && testing_on) {
    if (to_win == NULL)
      create_to_win(page_tr);
  }
#endif
                                 //get row coords
  fit_parallel_rows(block,
                    gradient,
                    rotation,
                    block_edge,
                    false &&testing_on);    // textord_show_parallel_rows = false
  delete_non_dropout_rows(block,
                          gradient,
                          rotation,
                          block_edge,
                          false &&testing_on);    // textord_show_parallel_rows = false 

  expand_rows(page_tr, block, gradient, rotation, block_edge, testing_on);
  blob_it.set_to_list (&block->blobs);
  row_it.set_to_list (block->get_rows ());
  for (row_it.mark_cycle_pt (); !row_it.cycled_list (); row_it.forward ())
    blob_it.add_list_after (row_it.data ()->blob_list ());
  //give blobs back
  assign_blobs_to_rows (block, &gradient, 1, FALSE, FALSE, FALSE);
  //now new rows must be genuine
  blob_it.set_to_list (&block->blobs);
  blob_it.add_list_after (&block->large_blobs);
  assign_blobs_to_rows (block, &gradient, 2, TRUE, TRUE, FALSE);
  //safe to use big ones now
  blob_it.set_to_list (&block->blobs);
                                 //throw all blobs in
  blob_it.add_list_after (&block->noise_blobs);
  blob_it.add_list_after (&block->small_blobs);
  assign_blobs_to_rows (block, &gradient, 3, FALSE, FALSE, FALSE);
}









//  @name fit_lms_line Fit an LMS line to a row.


static
void fit_lms_line(TO_ROW *row) {
  float m, c;                    // fitted line
  DetLineFit lms;
  BLOBNBOX_IT blob_it = row->blob_list();

  for (blob_it.mark_cycle_pt(); !blob_it.cycled_list(); blob_it.forward()) {
    const TBOX& box = blob_it.data()->bounding_box();
    lms.Add(ICOORD((box.left() + box.right()) / 2, box.bottom()));
  }
  double error = lms.Fit(&m, &c);
  row->set_line(m, c, error);
}



//   @name make_initial_textrows  Arrange the good blobs into rows of text.


static  
void make_initial_textrows(                  //find lines
                           ICOORD page_tr,
                           TO_BLOCK *block,  //block to do
                           FCOORD rotation,  //for drawing
                           BOOL8 testing_on  //correct orientation
                          ) {
  TO_ROW_IT row_it = block->get_rows ();

#ifndef GRAPHICS_DISABLED
  ScrollView::Color colour;                 //of row

  if (textord_show_initial_rows && testing_on) {
    if (to_win == NULL)
      create_to_win(page_tr);
  }
#endif
                                 //guess skew
  assign_blobs_to_rows (block, NULL, 0, TRUE, TRUE, false && testing_on);
  row_it.move_to_first ();
  for (row_it.mark_cycle_pt (); !row_it.cycled_list (); row_it.forward ())
    fit_lms_line (row_it.data ());
#ifndef GRAPHICS_DISABLED
  if (textord_show_initial_rows && testing_on) {
    colour = ScrollView::RED;
    for (row_it.mark_cycle_pt (); !row_it.cycled_list (); row_it.forward ()) {
      plot_to_row (row_it.data (), colour, rotation);
      colour = (ScrollView::Color) (colour + 1);
      if (colour > ScrollView::MAGENTA)
        colour = ScrollView::RED;
    }
  }
#endif
}






//  @name make_rows   Arrange the blobs into rows.


float make_rows(ICOORD page_tr, TO_BLOCK_LIST *port_blocks) {
  float port_m;                  // global skew
  float port_err;                // global noise
  TO_BLOCK_IT block_it;          // iterator

  block_it.set_to_list(port_blocks);
  for (block_it.mark_cycle_pt(); !block_it.cycled_list();
       block_it.forward())
  make_initial_textrows(page_tr, block_it.data(), FCOORD(1.0f, 0.0f),
      !(BOOL8) false );    // textord_test_landscape = false 
                                 // compute globally
  compute_page_skew(port_blocks, port_m, port_err);
  block_it.set_to_list(port_blocks);
  for (block_it.mark_cycle_pt(); !block_it.cycled_list(); block_it.forward()) {
    cleanup_rows_making(page_tr, block_it.data(), port_m, FCOORD(1.0f, 0.0f),
                 block_it.data()->block->bounding_box().left(),
                 !(BOOL8)false);    // textord_test_landscape = false 
  }
  return port_m;                 // global skew
}









#endif    // MAKEROW_CPP 










#if OTSUTH_CPP|1

const int kHistogramSize = 256;  // The size of a histogram of pixel values.








// Computes the histogram for the given image rectangle, and the given
// single channel. Each channel is always one byte per pixel.
// Histogram is always a kHistogramSize(256) element array to count
// occurrences of each pixel value.

void HistogramRect(Pix* src_pix, int channel,
                   int left, int top, int width, int height,
                   int* histogram) {
  //PERF_COUNT_START("HistogramRect")
  int num_channels = pixGetDepth(src_pix) / 8;
  channel = ClipToRange(channel, 0, num_channels - 1);
  int bottom = top + height;
  memset(histogram, 0, sizeof(*histogram) * kHistogramSize);
  int src_wpl = pixGetWpl(src_pix);
  l_uint32* srcdata = pixGetData(src_pix);
  for (int y = top; y < bottom; ++y) {
    const l_uint32* linedata = srcdata + y * src_wpl;
    for (int x = 0; x < width; ++x) {
      int pixel = GET_DATA_BYTE(const_cast<void*>(
          reinterpret_cast<const void *>(linedata)),
          (x + left) * num_channels + channel);
      ++histogram[pixel];
    }
  }
  //PERF_COUNT_END
}






// Computes the Otsu threshold(s) for the given histogram.
// Also returns H = total count in histogram, and
// omega0 = count of histogram below threshold.
static
int OtsuStats(const int* histogram, int* H_out, int* omega0_out) {
  int H = 0;
  double mu_T = 0.0;
  for (int i = 0; i < kHistogramSize; ++i) {
    H += histogram[i];
    mu_T += static_cast<double>(i) * histogram[i];
  }

  // Now maximize sig_sq_B over t.
  // http://www.ctie.monash.edu.au/hargreave/Cornall_Terry_328.pdf
  int best_t = -1;
  int omega_0, omega_1;
  int best_omega_0 = 0;
  double best_sig_sq_B = 0.0;
  double mu_0, mu_1, mu_t;
  omega_0 = 0;
  mu_t = 0.0;
  for (int t = 0; t < kHistogramSize - 1; ++t) {
    omega_0 += histogram[t];
    mu_t += t * static_cast<double>(histogram[t]);
    if (omega_0 == 0)
      continue;
    omega_1 = H - omega_0;
    if (omega_1 == 0)
      break;
    mu_0 = mu_t / omega_0;
    mu_1 = (mu_T - mu_t) / omega_1;
    double sig_sq_B = mu_1 - mu_0;
    sig_sq_B *= sig_sq_B * omega_0 * omega_1;
    if (best_t < 0 || sig_sq_B > best_sig_sq_B) {
      best_sig_sq_B = sig_sq_B;
      best_t = t;
      best_omega_0 = omega_0;
    }
  }
  if (H_out != NULL) *H_out = H;
  if (omega0_out != NULL) *omega0_out = best_omega_0;
  return best_t;
}








#endif    // OTSUTH_CPP


#if BASELNDETECTH|1


// Min fraction of linespacing gaps that should be close to the model before
// we will force the linespacing model on all the lines.
const double kMinFittingLinespacings = 0.25;



// Max fraction of line spacing allowed before a baseline counts as badly fitting.
const double kMaxBaselineError = 3.0 / 64;





const int kNumSkipPoints = 3;






// Copied from textord_excess_blobsize.
const double kMaxBlobSizeMultiple = 1.3;

// Number of displacement modes kept in displacement_modes_;
const int kMaxDisplacementsModes = 3;

// Max angle deviation (in radians) allowed to keep the independent baseline.
const double kMaxSkewDeviation = 1.0 / 64;




// class BaselineBlock;
// ���໥��������鷳!  
double BB_SpacingModelError(double perp_disp, double line_spacing, double line_offset);









//static 
template<typename T> T MedianOfCircularValues(T modulus, GenericVector<T>* v) {
  LLSQ stats;
  T halfrange = static_cast<T>(modulus / 2);
  int num_elements = v->size();
  for (int i = 0; i < num_elements; ++i) {
    stats.add((*v)[i], (*v)[i] + halfrange);
  }
  bool offset_needed = stats.y_variance() < stats.x_variance();
  if (offset_needed) {
    for (int i = 0; i < num_elements; ++i) {
      (*v)[i] += halfrange;
    }
  }
  int median_index = v->choose_nth_item(num_elements / 2);
  if (offset_needed) {
    for (int i = 0; i < num_elements; ++i) {
      (*v)[i] -= halfrange;
    }
  }
  return (*v)[median_index];
}


















static
class LLSQ {
 public:
  LLSQ() {  // constructor
    clear();  // set to zeros
  }
  void clear();  // initialize

  // Adds an element with a weight of 1.
  void add(double x, double y);
  // Adds an element with a specified weight.
  void add(double x, double y, double weight);
  // Adds a whole LLSQ.
  void add(const LLSQ& other);
  // Deletes an element with a weight of 1.
  void remove(double x, double y);
  inT32 count() const {  // no of elements
    return static_cast<int>(total_weight + 0.5);
  }

  double m() const;  // get gradient
  double c(double m) const;            // get constant
  double rms(double m, double c) const;            // get error
  double pearson() const;  // get correlation coefficient.

  // Returns the x,y means as an FCOORD.
  FCOORD mean_point() const;

  // Returns the average sum of squared perpendicular error from a line
  // through mean_point() in the direction dir.
  double rms_orth(const FCOORD &dir) const;

  // Returns the direction of the fitted line as a unit vector, using the
  // least mean squared perpendicular distance. The line runs through the
  // mean_point, i.e. a point p on the line is given by:
  // p = mean_point() + lambda * vector_fit() for some real number lambda.
  // Note that the result (0<=x<=1, -1<=y<=-1) is directionally ambiguous
  // and may be negated without changing its meaning, since a line is only
  // unique to a range of pi radians.
  // Modernists prefer to think of this as an Eigenvalue problem, but
  // Pearson had the simple solution in 1901.
  //
  // Note that this is equivalent to returning the Principal Component in PCA,
  // or the eigenvector corresponding to the largest eigenvalue in the
  // covariance matrix.
  FCOORD vector_fit() const;

  // Returns the covariance.
  double covariance() const {
    if (total_weight > 0.0)
      return (sigxy - sigx * sigy / total_weight) / total_weight;
    else
      return 0.0;
  }
  double x_variance() const {
    if (total_weight > 0.0)
      return (sigxx - sigx * sigx / total_weight) / total_weight;
    else
      return 0.0;
  }
  double y_variance() const {
    if (total_weight > 0.0)
      return (sigyy - sigy * sigy / total_weight) / total_weight;
    else
      return 0.0;
  }

 private:
  double total_weight;         // no of elements or sum of weights.
  double sigx;                 // sum of x
  double sigy;                 // sum of y
  double sigxx;                // sum x squared
  double sigxy;                // sum of xy
  double sigyy;                // sum y squared
};






static    // Class to compute and hold baseline data for a TO_ROW.
class BaselineRow {
 public:




// Fraction of line spacing estimate for quantization of blob displacements.
const double kOffsetQuantizationFactor = 3.0 / 64;
// Fraction of line spacing estimate for computing blob fit error.
const double kFitHalfrangeFactor = 6.0 / 64;
// Max fraction of line spacing allowed before a baseline counts as badly fitting.
const double kMaxBaselineError = 3.0 / 64;







BaselineRow::BaselineRow(double line_spacing, TO_ROW* to_row)
  : blobs_(to_row->blob_list()),
    baseline_pt1_(0.0f, 0.0f), baseline_pt2_(0.0f, 0.0f),
    baseline_error_(0.0), good_baseline_(false) {
  ComputeBoundingBox();
  // Compute a scale factor for rounding to ints.
  disp_quant_factor_ = kOffsetQuantizationFactor * line_spacing;
  fit_halfrange_ = kFitHalfrangeFactor * line_spacing;
  max_baseline_error_ = kMaxBaselineError * line_spacing;
}









  const TBOX& bounding_box() const {
    return bounding_box_;
  }






// Sets the TO_ROW with the output straight line.
void BaselineRow::SetupOldLineParameters(TO_ROW* row) const {
  // TODO(rays) get rid of this when m and c are no longer used.
  double gradient = tan(BaselineAngle());
  // para_c is the actual intercept of the baseline on the y-axis.
  float para_c = StraightYAtX(0.0);
  row->set_line(gradient, para_c, baseline_error_);
  row->set_parallel_line(gradient, para_c, baseline_error_);
}




  // Outputs diagnostic information.
  void Print() const{};




// Returns the skew angle (in radians) of the current baseline in [-pi,pi].
double BaselineRow::BaselineAngle() const {
  FCOORD baseline_dir(baseline_pt2_ - baseline_pt1_);
  double angle = baseline_dir.angle();
  // Baseline directions are only unique in a range of pi so constrain to
  // [-pi/2, pi/2].
  return fmod(angle + M_PI * 1.5, M_PI) - M_PI * 0.5;
}





// Computes and returns the linespacing at the middle of the overlap
// between this and other.
double BaselineRow::SpaceBetween(const BaselineRow& other) const {
  // Find the x-centre of overlap of the lines.
  float x = (MAX(bounding_box_.left(), other.bounding_box_.left()) +
      MIN(bounding_box_.right(), other.bounding_box_.right())) / 2.0f;
  // Find the vertical centre between them.
  float y = (StraightYAtX(x) + other.StraightYAtX(x)) / 2.0f;
  // Find the perpendicular distance of (x,y) from each line.
  FCOORD pt(x, y);
  return PerpDistanceFromBaseline(pt) + other.PerpDistanceFromBaseline(pt);
}



// Computes and returns the displacement of the center of the line
// perpendicular to the given direction.
double BaselineRow::PerpDisp(const FCOORD& direction) const {
  float middle_x = (bounding_box_.left() + bounding_box_.right()) / 2.0f;
  FCOORD middle_pos(middle_x, StraightYAtX(middle_x));
  return direction * middle_pos / direction.length();
}







// Computes the y coordinate at the given x using the straight baseline
// defined by baseline_pt1_ and baseline_pt2__.
double BaselineRow::StraightYAtX(double x) const {
  double denominator = baseline_pt2_.x() - baseline_pt1_.x();
  if (denominator == 0.0)
    return (baseline_pt1_.y() + baseline_pt2_.y()) / 2.0;
  return baseline_pt1_.y() +
      (x - baseline_pt1_.x()) * (baseline_pt2_.y() - baseline_pt1_.y()) /
          denominator;
}






// Fits a straight baseline to the points. Returns true if it had enough
// points to be reasonably sure of the fitted baseline.
// If use_box_bottoms is false, baselines positions are formed by
// considering the outlines of the blobs.
bool BaselineRow::FitBaseline(bool use_box_bottoms) {
  // Deterministic fitting is used wherever possible.
  fitter_.Clear();
  // Linear least squares is a backup if the DetLineFit produces a bad line.
  LLSQ llsq;
  BLOBNBOX_IT blob_it(blobs_);

  for (blob_it.mark_cycle_pt(); !blob_it.cycled_list(); blob_it.forward()) {
    BLOBNBOX* blob = blob_it.data();
    if (!use_box_bottoms) blob->EstimateBaselinePosition();
    const TBOX& box = blob->bounding_box();
    int x_middle = (box.left() + box.right()) / 2;
#ifdef kDebugYCoord
    if (box.bottom() < kDebugYCoord && box.top() > kDebugYCoord) {
      tprintf("Box bottom = %d, baseline pos=%d for box at:",
              box.bottom(), blob->baseline_position());
      box.print();
    }
#endif
    fitter_.Add(ICOORD(x_middle, blob->baseline_position()), box.width() / 2);
    llsq.add(x_middle, blob->baseline_position());
  }
  // Fit the line.
  ICOORD pt1, pt2;
  baseline_error_ = fitter_.Fit(&pt1, &pt2);
  baseline_pt1_ = pt1;
  baseline_pt2_ = pt2;
  if (baseline_error_ > max_baseline_error_ &&
      fitter_.SufficientPointsForIndependentFit()) {
    // The fit was bad but there were plenty of points, so try skipping
    // the first and last few, and use the new line if it dramatically improves
    // the error of fit.
    double error = fitter_.Fit(kNumSkipPoints, kNumSkipPoints, &pt1, &pt2);
    if (error < baseline_error_ / 2.0) {
      baseline_error_ = error;
      baseline_pt1_ = pt1;
      baseline_pt2_ = pt2;
    }
  }
  int debug = 0;
#ifdef kDebugYCoord
  Print();
  debug = bounding_box_.bottom() < kDebugYCoord &&
      bounding_box_.top() > kDebugYCoord
            ? 3 : 2;
#endif
  // Now we obtained a direction from that fit, see if we can improve the
  // fit using the same direction and some other start point.
  FCOORD direction(pt2 - pt1);
  double target_offset = direction * pt1;
  good_baseline_ = false;
  FitConstrainedIfBetter(debug, direction, 0.0, target_offset);
  // Wild lines can be produced because DetLineFit allows vertical lines, but
  // vertical text has been rotated so angles over pi/4 should be disallowed.
  // Near vertical lines can still be produced by vertically aligned components
  // on very short lines.
  double angle = BaselineAngle();
  if (fabs(angle) > M_PI * 0.25) {
    // Use the llsq fit as a backup.
    baseline_pt1_ = llsq.mean_point();
    baseline_pt2_ = baseline_pt1_ + FCOORD(1.0f, llsq.m());
    // TODO(rays) get rid of this when m and c are no longer used.
    double m = llsq.m();
    double c = llsq.c(m);
    baseline_error_ = llsq.rms(m, c);
    good_baseline_ = false;
  }
  return good_baseline_;
}



  




// Modifies an existing result of FitBaseline to be parallel to the given
// direction vector if that produces a better result.
void BaselineRow::AdjustBaselineToParallel(int debug,
                                           const FCOORD& direction) {
  SetupBlobDisplacements(direction);
  if (displacement_modes_.empty())
    return;
#ifdef kDebugYCoord
  if (bounding_box_.bottom() < kDebugYCoord &&
      bounding_box_.top() > kDebugYCoord && debug < 3)
    debug = 3;
#endif
  FitConstrainedIfBetter(debug, direction, 0.0, displacement_modes_[0]);
}













// Modifies the baseline to snap to the textline grid if the existing
// result is not good enough.
double BaselineRow::AdjustBaselineToGrid(int debug,
                                         const FCOORD& direction,
                                         double line_spacing,
                                         double line_offset) {
  if (blobs_->empty()) {
    if (debug > 1) {
      tprintf("Row empty at:");
      bounding_box_.print();
    }
    return line_offset;
  }
  // Find the displacement_modes_ entry nearest to the grid.
  double best_error = 0.0;
  int best_index = -1;
  for (int i = 0; i < displacement_modes_.size(); ++i) {
    double blob_y = displacement_modes_[i];


    // double error = BaselineBlock::SpacingModelError(blob_y, line_spacing,  line_offset);
    double error = BB_SpacingModelError(blob_y, line_spacing,  line_offset);




    if (debug > 1) {
      tprintf("Mode at %g has error %g from model \n", blob_y, error);
    }
    if (best_index < 0 || error < best_error) {
      best_error = error;
      best_index = i;
    }
  }
  // We will move the baseline only if the chosen mode is close enough to the
  // model.
  double model_margin = max_baseline_error_ - best_error;
  if (best_index >= 0 && model_margin > 0.0) {
    // But if the current baseline is already close to the mode there is no
    // point, and only the potential to damage accuracy by changing its angle.
    double perp_disp = PerpDisp(direction);
    double shift = displacement_modes_[best_index] - perp_disp;
    if (fabs(shift) > max_baseline_error_) {
      if (debug > 1) {
        tprintf("Attempting linespacing model fit with mode %g to row at:",
                displacement_modes_[best_index]);
        bounding_box_.print();
      }
      FitConstrainedIfBetter(debug, direction, model_margin,
                             displacement_modes_[best_index]);
    } else if (debug > 1) {
      tprintf("Linespacing model only moves current line by %g for row at:",
              shift);
      bounding_box_.print();
    }
  } else if (debug > 1) {
    tprintf("Linespacing model not close enough to any mode for row at:");
    bounding_box_.print();
  }
  return fmod(PerpDisp(direction), line_spacing);
}















 private:



// Sets up displacement_modes_ with the top few modes of the perpendicular
// distance of each blob from the given direction vector, after rounding.
void BaselineRow::SetupBlobDisplacements(const FCOORD& direction) {
  // Set of perpendicular displacements of the blob bottoms from the required
  // baseline direction.
  GenericVector<double> perp_blob_dists;
  displacement_modes_.truncate(0);
  // Gather the skew-corrected position of every blob.
  double min_dist = MAX_FLOAT32;
  double max_dist = -MAX_FLOAT32;
  BLOBNBOX_IT blob_it(blobs_);
  bool debug = false;
  for (blob_it.mark_cycle_pt(); !blob_it.cycled_list(); blob_it.forward()) {
    BLOBNBOX* blob = blob_it.data();
    const TBOX& box = blob->bounding_box();
#ifdef kDebugYCoord
    if (box.bottom() < kDebugYCoord && box.top() > kDebugYCoord) debug = true;
#endif
    FCOORD blob_pos((box.left() + box.right()) / 2.0f,
                    blob->baseline_position());
    double offset = direction * blob_pos;
    perp_blob_dists.push_back(offset);
    if (debug) {
      tprintf("Displacement %g for blob at:", offset);
      box.print();
    }
    UpdateRange(offset, &min_dist, &max_dist);
  }
  // Set up a histogram using disp_quant_factor_ as the bucket size.
  STATS dist_stats(IntCastRounded(min_dist / disp_quant_factor_),
                   IntCastRounded(max_dist / disp_quant_factor_) + 1);
  for (int i = 0; i < perp_blob_dists.size(); ++i) {
    dist_stats.add(IntCastRounded(perp_blob_dists[i] / disp_quant_factor_), 1);
  }
  GenericVector<KDPairInc<float, int> > scaled_modes;
  dist_stats.top_n_modes(kMaxDisplacementsModes, &scaled_modes);
  if (debug) {
    for (int i = 0; i < scaled_modes.size(); ++i) {
      tprintf("Top mode = %g * %d\n",
              scaled_modes[i].key * disp_quant_factor_, scaled_modes[i].data);
    }
  }
  for (int i = 0; i < scaled_modes.size(); ++i)
    displacement_modes_.push_back(disp_quant_factor_ * scaled_modes[i].key);
}








void BaselineRow::FitConstrainedIfBetter(int debug,
                                         const FCOORD& direction,
                                         double cheat_allowance,
                                         double target_offset) {
  double halfrange = fit_halfrange_ * direction.length();
  double min_dist = target_offset - halfrange;
  double max_dist = target_offset + halfrange;
  ICOORD line_pt;
  double new_error = fitter_.ConstrainedFit(direction, min_dist, max_dist,
                                            debug > 2, &line_pt);
  // Allow cheat_allowance off the new error
  new_error -= cheat_allowance;
  double old_angle = BaselineAngle();
  double new_angle = direction.angle();

 




  bool new_good_baseline = new_error <= max_baseline_error_ &&
      (cheat_allowance > 0.0 || fitter_.SufficientPointsForIndependentFit());
  // The new will replace the old if any are true:
  // 1. the new error is better
  // 2. the old is NOT good, but the new is
  // 3. there is a wild angular difference between them (assuming that the new
  //    is a better guess at the angle.)
  if (new_error <= baseline_error_ ||
      (!good_baseline_ && new_good_baseline) ||
      fabs(new_angle - old_angle) > kMaxSkewDeviation) {
    baseline_error_ = new_error;
    baseline_pt1_ = line_pt;
    baseline_pt2_ = baseline_pt1_ + direction;
    good_baseline_ = new_good_baseline;
    if (debug > 1) {
      tprintf("Replacing with constrained baseline, good = %d\n",
              good_baseline_);
    }
  } else if (debug > 1) {
    tprintf("Keeping old baseline\n");
  }
}










// Returns the perpendicular distance of the point from the straight
// baseline.
double BaselineRow::PerpDistanceFromBaseline(const FCOORD& pt) const {
  FCOORD baseline_vector(baseline_pt2_ - baseline_pt1_);
  FCOORD offset_vector(pt - baseline_pt1_);
  double distance = baseline_vector * offset_vector;
  return sqrt(distance * distance / baseline_vector.sqlength());
}



// Computes the bounding box of the row.
// Computes the bounding box of the row.
void BaselineRow::ComputeBoundingBox() {
  BLOBNBOX_IT it(blobs_);
  TBOX box;
  for (it.mark_cycle_pt(); !it.cycled_list(); it.forward()) {
    box += it.data()->bounding_box();
  }
  bounding_box_ = box;
}










  // The blobs of the row to which this BaselineRow adds extra information
  // during baseline fitting. Note that blobs_ could easily come from either
  // a TO_ROW or a ColPartition.
  BLOBNBOX_LIST* blobs_;
  // Bounding box of all the blobs.
  TBOX bounding_box_;
  // Fitter used to fit lines to the blobs.
  DetLineFit fitter_;
  // 2 points on the straight baseline.
  FCOORD baseline_pt1_;
  FCOORD baseline_pt2_;
  // Set of modes of displacements. They indicate preferable baseline positions.
  GenericVector<double> displacement_modes_;
  // Quantization factor used for displacement_modes_.
  double disp_quant_factor_;
  // Half the acceptance range of blob displacements for computing the
  // error during a constrained fit.
  double fit_halfrange_;
  // Max baseline error before a line is regarded as fitting badly.
  double max_baseline_error_;
  // The error of fit of the baseline.
  double baseline_error_;
  // True if this row seems to have a good baseline.
  bool good_baseline_;
};





static  // Class to compute and hold baseline data for a TO_BLOCK.
class BaselineBlock {
 public:




BaselineBlock::BaselineBlock(int debug_level, bool non_text, TO_BLOCK* block)
  : block_(block), debug_level_(debug_level), non_text_block_(non_text),
    good_skew_angle_(false), skew_angle_(0.0),
    line_spacing_(block->line_spacing), line_offset_(0.0), model_error_(0.0) {
  TO_ROW_IT row_it(block_->get_rows());
  for (row_it.mark_cycle_pt(); !row_it.cycled_list(); row_it.forward()) {
    // Sort the blobs on the rows.
    row_it.data()->blob_list()->sort(blob_x_order);
    rows_.push_back(new BaselineRow(block->line_spacing, row_it.data()));
  }
}






  TO_BLOCK* block() const {
    return block_;
  }
  double skew_angle() const {
    return skew_angle_;
  }






// Computes and returns the absolute error of the given perp_disp from the
// given linespacing model.
static double BaselineBlock::SpacingModelError(double perp_disp, double line_spacing,  double line_offset);









  
// Fits straight line baselines and computes the skew angle from the
// median angle. Returns true if a good angle is found.
// If use_box_bottoms is false, baseline positions are formed by
// considering the outlines of the blobs.
bool BaselineBlock::FitBaselinesAndFindSkew(bool use_box_bottoms) {
  if (non_text_block_) return false;
  GenericVector<double> angles;
  for (int r = 0; r < rows_.size(); ++r) {
    BaselineRow* row = rows_[r];
    if (row->FitBaseline(use_box_bottoms)) {
      double angle = row->BaselineAngle();
      angles.push_back(angle);
    }
    if (debug_level_ > 1)
      row->Print();
  }

  if (!angles.empty()) {
    skew_angle_ = MedianOfCircularValues(M_PI, &angles);
    good_skew_angle_ = true;
  } else {
    skew_angle_ = 0.0f;
    good_skew_angle_ = false;
  }
  if (debug_level_ > 0) {
    tprintf("Initial block skew angle = %g, good = %d\n",
            skew_angle_, good_skew_angle_);
  }
  return good_skew_angle_;
}







// Refits the baseline to a constrained angle, using the stored block
// skew if good enough, otherwise the supplied default skew.
void BaselineBlock::ParallelizeBaselines(double default_block_skew) {
  if (non_text_block_) return;
  if (!good_skew_angle_) skew_angle_ = default_block_skew;
  if (debug_level_ > 0)
    tprintf("Adjusting block to skew angle %g\n", skew_angle_);
  FCOORD direction(cos(skew_angle_), sin(skew_angle_));
  for (int r = 0; r < rows_.size(); ++r) {
    BaselineRow* row = rows_[r];
    row->AdjustBaselineToParallel(debug_level_, direction);
    if (debug_level_ > 1)
      row->Print();
  }
  if (rows_.size() < 3 || !ComputeLineSpacing())
    return;
  // Enforce the line spacing model on all lines that don't yet have a good
  // baseline.
  // Start by finding the row that is best fitted to the model.
  int best_row = 0;
  double best_error = SpacingModelError(rows_[0]->PerpDisp(direction),
                                        line_spacing_, line_offset_);
  for (int r = 1; r < rows_.size(); ++r) {
    double error = SpacingModelError(rows_[r]->PerpDisp(direction),
                                     line_spacing_, line_offset_);
    if (error < best_error) {
      best_error = error;
      best_row = r;
    }
  }
  // Starting at the best fitting row, work outwards, syncing the offset.
  double offset = line_offset_;
  for (int r = best_row + 1; r < rows_.size(); ++r) {
    offset = rows_[r]->AdjustBaselineToGrid(debug_level_, direction,
                                            line_spacing_, offset);
  }
  offset = line_offset_;
  for (int r = best_row - 1; r >= 0; --r) {
    offset = rows_[r]->AdjustBaselineToGrid(debug_level_, direction,
                                            line_spacing_, offset);
  }
}











  // Sets the parameters in TO_BLOCK that are needed by subsequent processes.

// Sets the parameters in TO_BLOCK that are needed by subsequent processes.
void BaselineBlock::SetupBlockParameters() const {
  if (line_spacing_ > 0.0) {
    // Where was block_line_spacing set before?
    float min_spacing = MIN(block_->line_spacing, line_spacing_);
    if (min_spacing < block_->line_size)
      block_->line_size = min_spacing;
    block_->line_spacing = line_spacing_;
    block_->baseline_offset = line_offset_;
    block_->max_blob_size = line_spacing_ * kMaxBlobSizeMultiple;
  }
  // Setup the parameters on all the rows.
  TO_ROW_IT row_it(block_->get_rows());
  for (int r = 0; r < rows_.size(); ++r, row_it.forward()) {
    BaselineRow* row = rows_[r];
    TO_ROW* to_row = row_it.data();
    row->SetupOldLineParameters(to_row);
  }
}









//   @name pre_associate_blobs  Associate overlapping blobs and fake chop wide blobs.




//static
void pre_associate_blobs(                  //make rough chars
                         ICOORD page_tr,   //top right
                         TO_BLOCK *block,  //block to do
                         FCOORD rotation,  //inverse landscape
                         BOOL8 testing_on  //correct orientation
                        ) {
#ifndef GRAPHICS_DISABLED
  ScrollView::Color colour;                 //of boxes
#endif
  BLOBNBOX *blob;                //current blob
  BLOBNBOX *nextblob;            //next in list
  TBOX blob_box;
  FCOORD blob_rotation;          //inverse of rotation
  BLOBNBOX_IT blob_it;           //iterator
  BLOBNBOX_IT start_it;          //iterator
  TO_ROW_IT row_it = block->get_rows ();

#ifndef GRAPHICS_DISABLED
  colour = ScrollView::RED;
#endif

  blob_rotation = FCOORD (rotation.x (), -rotation.y ());
  for (row_it.mark_cycle_pt (); !row_it.cycled_list (); row_it.forward ()) {
                                 //get blobs
    blob_it.set_to_list (row_it.data ()->blob_list ());
    for (blob_it.mark_cycle_pt (); !blob_it.cycled_list ();
    blob_it.forward ()) {
      blob = blob_it.data ();
      blob_box = blob->bounding_box ();
      start_it = blob_it;        //save start point
      //                      if (testing_on && textord_show_final_blobs)
      //                      {
      //                              tprintf("Blob at (%d,%d)->(%d,%d), addr=%x, count=%d\n",
      //                                      blob_box.left(),blob_box.bottom(),
      //                                      blob_box.right(),blob_box.top(),
      //                                      (void*)blob,blob_it.length());
      //                      }
      bool overlap;
      do {
        overlap = false;
        if (!blob_it.at_last ()) {
          nextblob = blob_it.data_relative(1);
          overlap = blob_box.major_x_overlap(nextblob->bounding_box());
          if (overlap) {
            blob->merge(nextblob); // merge new blob
            blob_box = blob->bounding_box(); // get bigger box
            blob_it.forward();
          }
        }
      }
      while (overlap);
      blob->chop (&start_it, &blob_it,
        blob_rotation,
        block->line_size * tesseract::CCStruct::kXHeightFraction *
        1.5);    // textord_chop_width =1.5  
      //attempt chop
    }
#ifndef GRAPHICS_DISABLED
    if (testing_on && textord_show_final_blobs) {
      if (to_win == NULL)
        create_to_win(page_tr);
      to_win->Pen(colour);
      for (blob_it.mark_cycle_pt (); !blob_it.cycled_list ();
      blob_it.forward ()) {
        blob = blob_it.data ();
        blob_box = blob->bounding_box ();
        blob_box.rotate (rotation);
        if (!blob->joined_to_prev ()) {
          to_win->Rectangle (blob_box.left (), blob_box.bottom (),
            blob_box.right (), blob_box.top ());
        }
      }
      colour = (ScrollView::Color) (colour + 1);
      if (colour > ScrollView::MAGENTA)
        colour = ScrollView::RED;
    }
#endif
  }
}





// horizontal_coutline_projection   Compute the horizontal projection of a outline from its outlines  and add to the given STATS.

static void horizontal_coutline_projection(                     //project outlines
                                    C_OUTLINE *outline,  //< outline to project
                                    STATS *stats         //< output
                                   ) {
  ICOORD pos;                    //current point
  ICOORD step;                   //edge step
  inT32 length;                  //of outline
  inT16 stepindex;               //current step
  C_OUTLINE_IT out_it = outline->child ();

  pos = outline->start_pos ();
  length = outline->pathlength ();
  for (stepindex = 0; stepindex < length; stepindex++) {
    step = outline->step (stepindex);
    if (step.y () > 0) {
      stats->add (pos.y (), pos.x ());
    }
    else if (step.y () < 0) {
      stats->add (pos.y () - 1, -pos.x ());
    }
    pos += step;
  }

  for (out_it.mark_cycle_pt (); !out_it.cycled_list (); out_it.forward ()) {
    horizontal_coutline_projection (out_it.data (), stats);
  }
}



//   horizontal_cblob_projection  Compute the horizontal projection of a cblob from its outlines  and add to the given STATS.

static void horizontal_cblob_projection(               //project outlines
                                 C_BLOB *blob,  //< blob to project
                                 STATS *stats   //< output
                                ) {
                                 //outlines of blob
  C_OUTLINE_IT out_it = blob->out_list ();

  for (out_it.mark_cycle_pt (); !out_it.cycled_list (); out_it.forward ()) {
    horizontal_coutline_projection (out_it.data (), stats);
  }
}






//  test_underline    Check to see if the blob is an underline.    Return TRUE if it is.

//static
BOOL8 test_underline(                   //look for underlines
                     BOOL8 testing_on,  //< drawing blob
                     C_BLOB *blob,      //< blob to test
                     inT16 baseline,    //< coords of baseline
                     inT16 xheight      //< height of line
                    ) {
  inT16 occ;
  inT16 blob_width;              //width of blob
  TBOX blob_box;                  //bounding box
  inT32 desc_occ;
  inT32 x_occ;
  inT32 asc_occ;
  STATS projection;

  blob_box = blob->bounding_box ();
  blob_width = blob->bounding_box ().width ();
  projection.set_range (blob_box.bottom (), blob_box.top () + 1);
  if (testing_on) {
    //              blob->plot(to_win,GOLDENROD,GOLDENROD);
    //              line_color_index(to_win,GOLDENROD);
    //              move2d(to_win,blob_box.left(),baseline);
    //              draw2d(to_win,blob_box.right(),baseline);
    //              move2d(to_win,blob_box.left(),baseline+xheight);
    //              draw2d(to_win,blob_box.right(),baseline+xheight);
    tprintf
      ("Testing underline on blob at (%d,%d)->(%d,%d), base=%d\nOccs:",
      blob->bounding_box ().left (), blob->bounding_box ().bottom (),
      blob->bounding_box ().right (), blob->bounding_box ().top (),
      baseline);
  }
  horizontal_cblob_projection(blob, &projection);
  desc_occ = 0;
  for (occ = blob_box.bottom (); occ < baseline; occ++)
    if (occ <= blob_box.top () && projection.pile_count (occ) > desc_occ)
                                 //max in region
      desc_occ = projection.pile_count (occ);
  x_occ = 0;
  for (occ = baseline; occ <= baseline + xheight; occ++)
    if (occ >= blob_box.bottom () && occ <= blob_box.top ()
    && projection.pile_count (occ) > x_occ)
                                 //max in region
      x_occ = projection.pile_count (occ);
  asc_occ = 0;
  for (occ = baseline + xheight + 1; occ <= blob_box.top (); occ++)
    if (occ >= blob_box.bottom () && projection.pile_count (occ) > asc_occ)
      asc_occ = projection.pile_count (occ);
  if (testing_on) {
    tprintf ("%d %d %d\n", desc_occ, x_occ, asc_occ);
  }
  if (desc_occ == 0 && x_occ == 0 && asc_occ == 0) {
    tprintf ("Bottom=%d, top=%d, base=%d, x=%d\n",
      blob_box.bottom (), blob_box.top (), baseline, xheight);
    projection.print();
  }
  if (desc_occ > x_occ + x_occ
    && desc_occ > blob_width * textord_underline_threshold)
    return TRUE;                 //real underline
  if (asc_occ > x_occ + x_occ
    && asc_occ > blob_width * textord_underline_threshold)
    return TRUE;                 //overline
  return FALSE;                  //neither
}







static int CountOverlaps(const TBOX& box, int min_height,
                         BLOBNBOX_LIST* blobs) {
  int overlaps = 0;
  BLOBNBOX_IT blob_it(blobs);
  for (blob_it.mark_cycle_pt(); !blob_it.cycled_list(); blob_it.forward()) {
    BLOBNBOX* blob = blob_it.data();
    const TBOX &blob_box = blob->bounding_box();
    if (blob_box.height() >= min_height && box.major_overlap(blob_box)) {
      ++overlaps;
    }
  }
  return overlaps;
}














//  Return true if the dot looks like it is part of the i.   Doesn't work for any other diacritical.

static bool dot_of_i(BLOBNBOX* dot, BLOBNBOX* i, TO_ROW* row) {
  const TBOX& ibox = i->bounding_box();
  const TBOX& dotbox = dot->bounding_box();

  // Must overlap horizontally by enough and be high enough.
  int overlap = MIN(dotbox.right(), ibox.right()) -
                MAX(dotbox.left(), ibox.left());
  if (ibox.height() <= 2 * dotbox.height() ||
      (overlap * 2 < ibox.width() && overlap < dotbox.width()))
    return false;

  // If the i is tall and thin then it is good.
  if (ibox.height() > ibox.width() * 2)
    return true;  // The i or ! must be tall and thin.

  // It might still be tall and thin, but it might be joined to something.
  // So search the outline for a piece of large height close to the edges
  // of the dot.
  const double kHeightFraction = 0.6;
  double target_height = MIN(dotbox.bottom(), ibox.top());
  target_height -= row->line_m()*dotbox.left() + row->line_c();
  target_height *= kHeightFraction;
  int left_min = dotbox.left() - dotbox.width();
  int middle = (dotbox.left() + dotbox.right())/2;
  int right_max = dotbox.right() + dotbox.width();
  int left_miny = 0;
  int left_maxy = 0;
  int right_miny = 0;
  int right_maxy = 0;
  bool found_left = false;
  bool found_right = false;
  bool in_left = false;
  bool in_right = false;
  C_BLOB* blob = i->cblob();
  C_OUTLINE_IT o_it = blob->out_list();
  for (o_it.mark_cycle_pt(); !o_it.cycled_list(); o_it.forward()) {
    C_OUTLINE* outline = o_it.data();
    int length = outline->pathlength();
    ICOORD pos = outline->start_pos();
    for (int step = 0; step < length; pos += outline->step(step++)) {
      int x = pos.x();
      int y = pos.y();
      if (x >= left_min && x < middle && !found_left) {
        // We are in the left part so find min and max y.
        if (in_left) {
          if (y > left_maxy) left_maxy = y;
          if (y < left_miny) left_miny = y;
        } else {
          left_maxy = left_miny = y;
          in_left = true;
        }
      } else if (in_left) {
        // We just left the left so look for size.
        if (left_maxy - left_miny > target_height) {
          if (found_right)
            return true;
          found_left = true;
        }
        in_left = false;
      }
      if (x <= right_max && x > middle && !found_right) {
        // We are in the right part so find min and max y.
        if (in_right) {
          if (y > right_maxy) right_maxy = y;
          if (y < right_miny) right_miny = y;
        } else {
          right_maxy = right_miny = y;
          in_right = true;
        }
      } else if (in_right) {
        // We just left the right so look for size.
        if (right_maxy - right_miny > target_height) {
          if (found_left)
            return true;
          found_right = true;
        }
        in_right = false;
      }
    }
  }
  return false;
}





//static 
void vigorous_noise_removal(TO_BLOCK* block) {
  TO_ROW_IT row_it = block->get_rows ();
  for (row_it.mark_cycle_pt (); !row_it.cycled_list (); row_it.forward ()) {
    TO_ROW* row = row_it.data();
    BLOBNBOX_IT b_it = row->blob_list();
    // Estimate the xheight on the row.
    int max_height = 0;
    for (b_it.mark_cycle_pt(); !b_it.cycled_list(); b_it.forward()) {
      BLOBNBOX* blob = b_it.data();
      if (blob->bounding_box().height() > max_height)
        max_height = blob->bounding_box().height();
    }
    STATS hstats(0, max_height + 1);
    for (b_it.mark_cycle_pt(); !b_it.cycled_list(); b_it.forward()) {
      BLOBNBOX* blob = b_it.data();
      int height = blob->bounding_box().height();
      if (height >= kMinSize)
        hstats.add(blob->bounding_box().height(), 1);
    }
    float xheight = hstats.median();
    // Delete small objects.
    BLOBNBOX* prev = NULL;
    for (b_it.mark_cycle_pt(); !b_it.cycled_list(); b_it.forward()) {
      BLOBNBOX* blob = b_it.data();
      const TBOX& box = blob->bounding_box();
      if (box.height() < kNoiseSize * xheight) {
        // Small so delete unless it looks like an i dot.
        if (prev != NULL) {
          if (dot_of_i(blob, prev, row))
            continue;  // Looks OK.
        }
        if (!b_it.at_last()) {
          BLOBNBOX* next = b_it.data_relative(1);
          if (dot_of_i(blob, next, row))
            continue;  // Looks OK.
        }
        // It might be noise so get rid of it.
        delete blob->cblob();
        delete b_it.extract();
      } else {
        prev = blob;
      }
    }
  }
}











//  @name separate_underlines  Test wide objects for being potential underlines. If they are then   put them in a separate list in the block.

// static
void separate_underlines(TO_BLOCK *block,  // block to do
                         float gradient,   // skew angle
                         FCOORD rotation,  // inverse landscape
                         BOOL8 testing_on) {  // correct orientation
  BLOBNBOX *blob;                // current blob
  C_BLOB *rotated_blob;          // rotated blob
  TO_ROW *row;                   // current row
  float length;                  // of g_vec
  TBOX blob_box;
  FCOORD blob_rotation;          // inverse of rotation
  FCOORD g_vec;                  // skew rotation
  BLOBNBOX_IT blob_it;           // iterator
                                 // iterator
  BLOBNBOX_IT under_it = &block->underlines;
  BLOBNBOX_IT large_it = &block->large_blobs;
  TO_ROW_IT row_it = block->get_rows();
  int min_blob_height = static_cast<int>(textord_min_blob_height_fraction *
                                         block->line_size + 0.5);

                                 // length of vector
  length = sqrt(1 + gradient * gradient);
  g_vec = FCOORD(1 / length, -gradient / length);
  blob_rotation = FCOORD(rotation.x(), -rotation.y());
  blob_rotation.rotate(g_vec);  // undoing everything
  for (row_it.mark_cycle_pt(); !row_it.cycled_list(); row_it.forward()) {
    row = row_it.data();
                                 // get blobs
    blob_it.set_to_list(row->blob_list());
    for (blob_it.mark_cycle_pt(); !blob_it.cycled_list();
         blob_it.forward()) {
      blob = blob_it.data();
      blob_box = blob->bounding_box();
      if (blob_box.width() > block->line_size * textord_underline_width) {
        ASSERT_HOST(blob->cblob() != NULL);
        rotated_blob = crotate_cblob (blob->cblob(),
          blob_rotation);
        if (test_underline(
            testing_on && textord_show_final_rows,
            rotated_blob, static_cast<inT16>(row->intercept()),
            static_cast<inT16>(
                block->line_size *
                (tesseract::CCStruct::kXHeightFraction +
                 tesseract::CCStruct::kAscenderFraction / 2.0f)))) {
          under_it.add_after_then_move(blob_it.extract());
          if (testing_on && textord_show_final_rows) {
            tprintf("Underlined blob at:");
              rotated_blob->bounding_box().print();
            tprintf("Was:");
              blob_box.print();
          }
        } else if (CountOverlaps(blob->bounding_box(), min_blob_height,
                                 row->blob_list()) >
                   4) {
          large_it.add_after_then_move(blob_it.extract());
          if (testing_on && textord_show_final_rows) {
            tprintf("Large blob overlaps %d blobs at:",
                    CountOverlaps(blob_box, min_blob_height,
                                  row->blob_list()));
            blob_box.print();
          }
        }
        delete rotated_blob;
      }
    }
  }
}









void BaselineBlock::PrepareForSplineFitting(ICOORD page_tr, bool remove_noise) {
  if (non_text_block_) return;
  if (remove_noise) {
    vigorous_noise_removal(block_);
  }
  FCOORD rotation(1.0f, 0.0f);
  double gradient = tan(skew_angle_);
  separate_underlines(block_, gradient, rotation, true);
  pre_associate_blobs(page_tr, block_, rotation, true);
}






 

void BaselineBlock::FitBaselineSplines(bool enable_splines,
                                       bool show_final_rows,
                                       Textord* textord) {
  double gradient = tan(skew_angle_);
  FCOORD rotation(1.0f, 0.0f);

  if (enable_splines) {
    textord->make_spline_rows(block_, gradient, show_final_rows);
  } else {
    // Make a fake spline from the existing line.
    TBOX block_box= block_->block->bounding_box();
    TO_ROW_IT row_it = block_->get_rows();
    for (row_it.mark_cycle_pt(); !row_it.cycled_list(); row_it.forward()) {
      TO_ROW* row = row_it.data();
      inT32 xstarts[2] = { block_box.left(), block_box.right() };
      double coeffs[3] = { 0.0, row->line_m(), row->line_c() };
      row->baseline = QSPLINE(1, xstarts, coeffs);
      textord->compute_row_xheight(row, block_->block->classify_rotation(),
                                   row->line_m(), block_->line_size);
    }
  }
  textord->compute_block_xheight(block_, gradient);
  block_->block->set_xheight(block_->xheight);
  



}















  // Draws the (straight) baselines and final blobs colored according to
  // what was discarded as noise and what is associated with each row.
  void DrawFinalRows(const ICOORD& page_tr){};




  // Render the generated spline baselines for this block on pix_in.

void BaselineBlock::DrawPixSpline(Pix* pix_in) {
  if (non_text_block_) return;
  TO_ROW_IT row_it = block_->get_rows();
  for (row_it.mark_cycle_pt(); !row_it.cycled_list(); row_it.forward()) {
    row_it.data()->baseline.plot(pix_in);
  }
}












 private:


// Top-level line-spacing calculation. Computes an estimate of the line-
// spacing, using the current baselines in the TO_ROWS of the block, and
// then refines it by fitting a regression line to the baseline positions
// as a function of their integer index.
// Returns true if it seems that the model is a reasonable fit to the
// observations.
bool BaselineBlock::ComputeLineSpacing() {
  FCOORD direction(cos(skew_angle_), sin(skew_angle_));
  GenericVector<double> row_positions;
  ComputeBaselinePositions(direction, &row_positions);
  if (row_positions.size() < 2) return false;
  EstimateLineSpacing();
  RefineLineSpacing(row_positions);
  // Verify that the model is reasonable.
  double max_baseline_error = kMaxBaselineError * line_spacing_;
  int non_trivial_gaps = 0;
  int fitting_gaps = 0;
  for (int i = 1; i < row_positions.size(); ++i) {
    double row_gap = fabs(row_positions[i - 1] - row_positions[i]);
    if (row_gap > max_baseline_error) {
      ++non_trivial_gaps;
      if (fabs(row_gap - line_spacing_) <= max_baseline_error)
        ++fitting_gaps;
    }
  }
  if (debug_level_ > 0) {
    tprintf("Spacing %g, in %d rows, %d gaps fitted out of %d non-trivial\n",
            line_spacing_, row_positions.size(), fitting_gaps,
            non_trivial_gaps);
  }
  return fitting_gaps > non_trivial_gaps * kMinFittingLinespacings;
}
















// Computes the deskewed vertical position of each baseline in the block and
// stores them in the given vector.
// This is calculated as the perpendicular distance of the middle of each
// baseline (in case it has a different skew angle) from the line passing
// through the origin parallel to the block baseline angle.
// NOTE that "distance" above is a signed quantity so we can tell which side
// of the block baseline a line sits, hence the function and argument name
// positions not distances.
void BaselineBlock::ComputeBaselinePositions(const FCOORD& direction,
                                             GenericVector<double>* positions) {
  positions->clear();
  for (int r = 0; r < rows_.size(); ++r) {
    BaselineRow* row = rows_[r];
    const TBOX& row_box = row->bounding_box();
    float x_middle = (row_box.left() + row_box.right()) / 2.0f;
    FCOORD row_pos(x_middle, static_cast<float>(row->StraightYAtX(x_middle)));
    float offset = direction * row_pos;
    positions->push_back(offset);
  }
}











// Computes an estimate of the line spacing of the block from the median
// of the spacings between adjacent overlapping textlines.
void BaselineBlock::EstimateLineSpacing() {
  GenericVector<float> spacings;
  for (int r = 0; r < rows_.size(); ++r) {
    BaselineRow* row = rows_[r];
    // Exclude silly lines.
    if (fabs(row->BaselineAngle()) > M_PI * 0.25) continue;
    // Find the first row after row that overlaps it significantly.
    const TBOX& row_box = row->bounding_box();
    int r2;
    for (r2 = r + 1; r2 < rows_.size() &&
         !row_box.major_x_overlap(rows_[r2]->bounding_box());
         ++r2);
    if (r2 < rows_.size()) {
      BaselineRow* row2 = rows_[r2];
      // Exclude silly lines.
      if (fabs(row2->BaselineAngle()) > M_PI * 0.25) continue;
      float spacing = row->SpaceBetween(*row2);
      spacings.push_back(spacing);
    }
  }
  // If we have at least one value, use it, otherwise leave the previous
  // value unchanged.
  if (!spacings.empty()) {
    line_spacing_ = spacings[spacings.choose_nth_item(spacings.size() / 2)];
    if (debug_level_ > 1)
      tprintf("Estimate of linespacing = %g\n", line_spacing_);
  }
}






// Refines the line spacing of the block by fitting a regression
// line to the deskewed y-position of each baseline as a function of its
// estimated line index, allowing for a small error in the initial linespacing
// and choosing the best available model.
void BaselineBlock::RefineLineSpacing(const GenericVector<double>& positions) {
  double spacings[3], offsets[3], errors[3];
  int index_range;
  errors[0] = FitLineSpacingModel(positions, line_spacing_,
                                  &spacings[0], &offsets[0], &index_range);
  if (index_range > 1) {
    double spacing_plus = line_spacing_ / (1.0 + 1.0 / index_range);
    // Try the hypotheses that there might be index_range +/- 1 line spaces.
    errors[1] = FitLineSpacingModel(positions, spacing_plus,
                                    &spacings[1], &offsets[1], NULL);
    double spacing_minus = line_spacing_ / (1.0 - 1.0 / index_range);
    errors[2] = FitLineSpacingModel(positions, spacing_minus,
                                    &spacings[2], &offsets[2], NULL);
    for (int i = 1; i <= 2; ++i) {
      if (errors[i] < errors[0]) {
        spacings[0] = spacings[i];
        offsets[0] = offsets[i];
        errors[0] = errors[i];
      }
    }
  }
  if (spacings[0] > 0.0) {
    line_spacing_ = spacings[0];
    line_offset_ = offsets[0];
    model_error_ = errors[0];
    if (debug_level_ > 0) {
      tprintf("Final linespacing model = %g + offset %g, error %g\n",
              line_spacing_, line_offset_, model_error_);
    }
  }
}







// Given an initial estimate of line spacing (m_in) and the positions of each
// baseline, computes the line spacing of the block more accurately in m_out,
// and the corresponding intercept in c_out, and the number of spacings seen
// in index_delta. Returns the error of fit to the line spacing model.
// Uses a simple linear regression, but optimized the offset using the median.
double BaselineBlock::FitLineSpacingModel(
    const GenericVector<double>& positions, double m_in,
    double* m_out, double* c_out, int* index_delta) {
  if (m_in == 0.0f || positions.size() < 2) {
    *m_out = m_in;
    *c_out = 0.0;
    if (index_delta != NULL) *index_delta = 0;
    return 0.0;
  }
  GenericVector<double> offsets;
  // Get the offset (remainder) linespacing for each line and choose the median.
  for (int i = 0; i < positions.size(); ++i)
    offsets.push_back(fmod(positions[i], m_in));
  // Get the median offset.
  double median_offset = MedianOfCircularValues(m_in, &offsets);
  // Now fit a line to quantized line number and offset.
  LLSQ llsq;
  int min_index = MAX_INT32;
  int max_index = -MAX_INT32;
  for (int i = 0; i < positions.size(); ++i) {
    double y_pos = positions[i];
    int row_index = IntCastRounded((y_pos - median_offset) / m_in);
    UpdateRange(row_index, &min_index, &max_index);
    llsq.add(row_index, y_pos);
  }
  // Get the refined line spacing.
  *m_out = llsq.m();
  // Use the median offset rather than the mean.
  offsets.truncate(0);
  for (int i = 0; i < positions.size(); ++i)
    offsets.push_back(fmod(positions[i], *m_out));
  // Get the median offset.
  if (debug_level_ > 2) {
    for (int i = 0; i < offsets.size(); ++i)
      tprintf("%d: %g\n", i, offsets[i]);
  }
  *c_out = MedianOfCircularValues(*m_out, &offsets);
  if (debug_level_ > 1) {
    tprintf("Median offset = %g, compared to mean of %g.\n",
            *c_out, llsq.c(*m_out));
  }
  // Index_delta is the number of hypothesized line gaps present.
  if (index_delta != NULL)
    *index_delta = max_index - min_index;
  // Use the regression model's intercept to compute the error, as it may be
  // a full line-spacing in disagreement with the median.
  double rms_error = llsq.rms(*m_out, llsq.c(*m_out));
  if (debug_level_ > 1) {
    tprintf("Linespacing of y=%g x + %g improved to %g x + %g, rms=%g\n",
            m_in, median_offset, *m_out, *c_out, rms_error);
  }
  return rms_error;
}















  // The block to which this class adds extra information used during baseline
  // calculation.
  TO_BLOCK* block_;
  // The rows in the block that we will be working with.
  PointerVector<BaselineRow> rows_;
  // Amount of debugging output to provide.
  int debug_level_;
  // True if the block is non-text (graphic).
  bool non_text_block_;
  // True if the block has at least one good enough baseline to compute the
  // skew angle and therefore skew_angle_ is valid.
  bool good_skew_angle_;
  // Angle of skew in radians using the conventional anticlockwise from x-axis.
  double skew_angle_;
  // Current best estimate line spacing in pixels perpendicular to skew_angle_.
  double line_spacing_;
  // Offset for baseline positions, in pixels. Each baseline is at
  // line_spacing_ * n + line_offset_ for integer n, which represents
  // [textline] line number in a line numbering system that has line 0 on or
  // at least near the x-axis. Not equal to the actual line number of a line
  // within a block as most blocks are not near the x-axis.
  double line_offset_;
  // The error of the line spacing model.
  double model_error_;
};














































static
class BaselineDetect {
 public:







BaselineDetect::BaselineDetect(int debug_level, const FCOORD& page_skew,
                               TO_BLOCK_LIST* blocks)
    : page_skew_(page_skew), debug_level_(debug_level), pix_debug_(NULL),
      debug_file_prefix_("") {
  TO_BLOCK_IT it(blocks);
  for (it.mark_cycle_pt(); !it.cycled_list(); it.forward()) {
    TO_BLOCK* to_block = it.data();
    BLOCK* block = to_block->block;
    POLY_BLOCK* pb = block->poly_block();
    // A note about non-text blocks.
    // On output, non-text blocks are supposed to contain a single empty word
    // in each incoming text line. These mark out the polygonal bounds of the
    // block. Ideally no baselines should be required, but currently
    // make_words crashes if a baseline and xheight are not provided, so we
    // include non-text blocks here, but flag them for special treatment.
    bool non_text = pb != NULL && !pb->IsText();
    blocks_.push_back(new BaselineBlock(debug_level_, non_text, to_block));
  }
}







  ~BaselineDetect(){ pixDestroy(&pix_debug_); };

  // Finds the initial baselines for each TO_ROW in each TO_BLOCK, gathers
  // block-wise and page-wise data to smooth small blocks/rows, and applies
  // smoothing based on block/page-level skew and block-level linespacing.
  



void BaselineDetect::ComputeStraightBaselines(bool use_box_bottoms) {
  GenericVector<double> block_skew_angles;
  for (int i = 0; i < blocks_.size(); ++i) {
    BaselineBlock* bl_block = blocks_[i];
    if (debug_level_ > 0)
      tprintf("Fitting initial baselines...\n");
    if (bl_block->FitBaselinesAndFindSkew(use_box_bottoms)) {
      block_skew_angles.push_back(bl_block->skew_angle());
    }
  }
  // Compute a page-wide default skew for blocks with too little information.
  double default_block_skew = page_skew_.angle();
  if (!block_skew_angles.empty()) {
    default_block_skew = MedianOfCircularValues(M_PI, &block_skew_angles);
  }
  if (debug_level_ > 0) {
    tprintf("Page skew angle = %g\n", default_block_skew);
  }
  // Set bad lines in each block to the default block skew and then force fit
  // a linespacing model where it makes sense to do so.
  for (int i = 0; i < blocks_.size(); ++i) {
    BaselineBlock* bl_block = blocks_[i];
    bl_block->ParallelizeBaselines(default_block_skew);
    bl_block->SetupBlockParameters();  // This replaced compute_row_stats.
  }
}













  // Computes the baseline splines for each TO_ROW in each TO_BLOCK and
  // other associated side-effects, including pre-associating blobs, computing
  // x-heights and displaying debug information.
  // NOTE that ComputeStraightBaselines must have been called first as this
  // sets up data in the TO_ROWs upon which this function depends.
  void ComputeBaselineSplinesAndXheights(const ICOORD& page_tr,
                                         bool enable_splines,
                                         bool remove_noise,
                                         bool show_final_rows,
                                         Textord* textord);

  // Set up the image and filename, so that a debug image with the detected
  // baseline rendered will be saved.
  void SetDebugImage(Pix* pixIn, const STRING& output_path);

 private:
  // Average (median) skew of the blocks on the page among those that have
  // a good angle of their own.
  FCOORD page_skew_;
  // Amount of debug output to produce.
  int debug_level_;
  // The blocks that we are working with.
  PointerVector<BaselineBlock> blocks_;

  Pix* pix_debug_;
  STRING debug_file_prefix_;
};













void BaselineDetect::ComputeBaselineSplinesAndXheights(const ICOORD& page_tr,
                                                       bool enable_splines,
                                                       bool remove_noise,
                                                       bool show_final_rows,
                                                      Textord* textord) {
  Pix* pix_spline = pix_debug_ ? pixConvertTo32(pix_debug_) : NULL;
  for (int i = 0; i < blocks_.size(); ++i) {
    BaselineBlock* bl_block = blocks_[i];
    if (enable_splines)
      bl_block->PrepareForSplineFitting(page_tr, remove_noise);
    bl_block->FitBaselineSplines(enable_splines, show_final_rows, textord);
    if (pix_spline) {
      bl_block->DrawPixSpline(pix_spline);
    }
    if (show_final_rows) {
      bl_block->DrawFinalRows(page_tr);
    }
  }

  if (pix_spline) {
    STRING outfile_name = debug_file_prefix_ + "_spline.png";
    pixWrite(outfile_name.string(), pix_spline, IFF_PNG);
    pixDestroy(&pix_spline);
  }
}







// Computes and returns the absolute error of the given perp_disp from the
// given linespacing model.
 
double BaselineBlock::SpacingModelError(double perp_disp, double line_spacing,
                                        double line_offset) {
  // Round to the nearest multiple of line_spacing + line offset.
  int multiple = IntCastRounded((perp_disp - line_offset) / line_spacing);
  double model_y = line_spacing * multiple + line_offset;
  return fabs(perp_disp - model_y);
}



// ���໥��������鷳!  
double BB_SpacingModelError(double perp_disp, double line_spacing, double line_offset) {
  // Round to the nearest multiple of line_spacing + line offset.
  int multiple = IntCastRounded((perp_disp - line_offset) / line_spacing);
  double model_y = line_spacing * multiple + line_offset;
  return fabs(perp_disp - model_y);
}




#endif  //  BASELNDETECTH












#if EDGBLOBH|1


static   // ��ĺ����� -- C��������߾�Ȼ������������!  
class OL_BUCKETS
{
  public:
    OL_BUCKETS(               //constructor
               ICOORD bleft,  //corners
               ICOORD tright);

    ~OL_BUCKETS () {             //cleanup
      delete[]buckets;
    }
    C_OUTLINE_LIST *operator () (//array access
      inT16 x,                   //image coords
      inT16 y);
                                 //first non-empty bucket
    C_OUTLINE_LIST *start_scan() {
      for (index = 0; buckets[index].empty () && index < bxdim * bydim - 1;
        index++);
      return &buckets[index];
    }
                                 //next non-empty bucket
    C_OUTLINE_LIST *scan_next() {
      for (; buckets[index].empty () && index < bxdim * bydim - 1; index++);
      return &buckets[index];
    }
    inT32 count_children(                     //recursive sum
                         C_OUTLINE *outline,  //parent outline
                         inT32 max_count);    // max output
    inT32 outline_complexity(                 // new version of count_children
                         C_OUTLINE *outline,  // parent outline
                         inT32 max_count,     // max output
                         inT16 depth);        // level of recursion
    void extract_children(                     //single level get
                          C_OUTLINE *outline,  //parent outline
                          C_OUTLINE_IT *it);   //destination iterator

  private:
    C_OUTLINE_LIST * buckets;    //array of buckets
    inT16 bxdim;                 //size of array
    inT16 bydim;
    ICOORD bl;                   //corners
    ICOORD tr;
    inT32 index;                 //for extraction scan
};




#endif   // EDGBLOBH




#if WORDSEG_CPP|1




//  make_words  Arrange the blobs into words.

static
void make_words(tesseract::Textord *textord,
                ICOORD page_tr,                // top right
                float gradient,                // page skew
                BLOCK_LIST *blocks,            // block list
                TO_BLOCK_LIST *port_blocks) {  // output list
  
TO_BLOCK_IT block_it;          // iterator
TO_BLOCK *block;               // current block


TO_ROW_IT row_it;              //row iterator
TO_ROW *row;                   //current row


block_it.set_to_list (port_blocks);
   

for (block_it.mark_cycle_pt(); !block_it.cycled_list();  block_it.forward()) {

    block = block_it.data ();
  
    row_it.set_to_list (block->get_rows ());

    
for (row_it.mark_cycle_pt (); !row_it.cycled_list (); row_it.forward ()) {
row = row_it.data ();
row->pitch_decision = PITCH_CORR_PROP;
}

  
}

 

textord->to_spacing(page_tr, port_blocks);

block_it.set_to_list(port_blocks);

for (block_it.mark_cycle_pt(); !block_it.cycled_list(); block_it.forward()) { 
    
block = block_it.data();
    

ROW *real_row = NULL;          //output row
ROW_IT real_row_it = block->block->row_list ();

  
if (row_it.empty ()) return;                    
  
for (row_it.mark_cycle_pt (); !row_it.cycled_list (); row_it.forward ()) {
    
row = row_it.data ();
    
if (!row->blob_list()->empty())   real_row = textord->make_prop_words (row, FCOORD(1.0f, 0.0f));

if (real_row != NULL)  real_row_it.add_after_then_move (real_row);
     
}




}



}






#endif    // WORDSEG_CPP






// #include "scanedg.h"       // block_edges  line_edges   
#if SCANEDG_CPP|1

//#include "edgloop.h"    //  check_path_legal  

struct CrackPos {
  CRACKEDGE** free_cracks;   // Freelist for fast allocation.
  int x,y;
};






//  loop_bounding_box.  edgloop.cpp 


static 

inT16 loop_bounding_box(  CRACKEDGE *&start,  
                        ICOORD &botleft,    
                        ICOORD &topright) {
  inT16 length;                  //length of loop
  inT16 leftmost;                //on top row
  CRACKEDGE *edgept;             //current point
  CRACKEDGE *realstart;          //topleft start

  edgept = start;
  realstart = start;
  botleft = topright = ICOORD (edgept->pos.x (), edgept->pos.y ());
  leftmost = edgept->pos.x ();
  length = 0; 
                   
  do {
    edgept = edgept->next;
    if (edgept->pos.x () < botleft.x ())
                                  
      botleft.set_x (edgept->pos.x ());
    else if (edgept->pos.x () > topright.x ())
      topright.set_x (edgept->pos.x ());
    if (edgept->pos.y () < botleft.y ())
                                  
      botleft.set_y (edgept->pos.y ());
    else if (edgept->pos.y () > topright.y ()) {
      realstart = edgept;
      leftmost = edgept->pos.x ();
      topright.set_y (edgept->pos.y ());
    }
    else if (edgept->pos.y () == topright.y ()
    && edgept->pos.x () < leftmost) {
                                
      leftmost = edgept->pos.x (); //leftmost on line
      realstart = edgept;
    }
    length++;                    //count elements
  }
  while (edgept != start);
  start = realstart;             //shift it to topleft
  
return length;
}




// complete_edge  Complete the edge by cleaning it up.  edgloop.cpp 

static 
void complete_edge(CRACKEDGE *start,    C_OUTLINE_IT* outline_it) {

 ScrollView::Color colour;                 //colour to draw in
  inT16 looplength;              //steps in loop
  ICOORD botleft;                //bounding box
  ICOORD topright;
  C_OUTLINE *outline;            //new outline

                                 //check length etc.
  colour = ScrollView::RED;  // check_path_legal (start);

  if (colour == ScrollView::RED || colour == ScrollView::BLUE) {
    looplength =  loop_bounding_box (start, botleft, topright);
    outline = new C_OUTLINE (start, botleft, topright, looplength);
                                 
    outline_it->add_after_then_move (outline);
  }

}






// h_edge,  Create a new horizontal CRACKEDGE and join it to the given edge.

static
CRACKEDGE *h_edge(int sign,   CRACKEDGE* join,  CrackPos* pos) {
  CRACKEDGE *newpt;              // return value

  if (*pos->free_cracks != NULL) { 
    newpt = *pos->free_cracks;
    *pos->free_cracks = newpt->next;  // get one fast
  } else {
    newpt = new CRACKEDGE;
  }
  newpt->pos.set_y(pos->y + 1);       // coords of pt
  newpt->stepy = 0;              // edge is horizontal

  if (sign > 0) {
    newpt->pos.set_x(pos->x + 1);     // start location
    newpt->stepx = -1;
    newpt->stepdir = 0;
  } else { 
    newpt->pos.set_x(pos->x);        // start location
    newpt->stepx = 1;
    newpt->stepdir = 2;
  }

  if (join == NULL) {
    newpt->next = newpt;         // ptrs to other ends
    newpt->prev = newpt;
  } else { 
    if (newpt->pos.x() + newpt->stepx == join->pos.x()
    && newpt->pos.y() == join->pos.y()) {
      newpt->prev = join->prev;  // update other ends
      newpt->prev->next = newpt;
      newpt->next = join;        // join up
      join->prev = newpt;
    } else {
      newpt->next = join->next;  // update other ends
      newpt->next->prev = newpt;
      newpt->prev = join;        // join up
      join->next = newpt;
    }
  }
  return newpt;
}


// v_edge  Create a new vertical CRACKEDGE and join it to the given edge.

static
CRACKEDGE *v_edge(int sign, CRACKEDGE* join, CrackPos* pos) {
  CRACKEDGE *newpt;              // return value

  if (*pos->free_cracks != NULL) {
    newpt = *pos->free_cracks;
    *pos->free_cracks = newpt->next;  // get one fast
  } else {
    newpt = new CRACKEDGE;
  }
  newpt->pos.set_x(pos->x);           // coords of pt
  newpt->stepx = 0;              // edge is vertical

  if (sign > 0) {
    newpt->pos.set_y(pos->y);         // start location
    newpt->stepy = 1;
    newpt->stepdir = 3;
  } else {
    newpt->pos.set_y(pos->y + 1);     // start location
    newpt->stepy = -1;
    newpt->stepdir = 1;
  }

  if (join == NULL) {
    newpt->next = newpt;         //ptrs to other ends
    newpt->prev = newpt;
  } else {
    if (newpt->pos.x() == join->pos.x()
    && newpt->pos.y() + newpt->stepy == join->pos.y()) {
      newpt->prev = join->prev;  // update other ends
      newpt->prev->next = newpt;
      newpt->next = join;        // join up
      join->prev = newpt;
    } else {
      newpt->next = join->next;  // update other ends
      newpt->next->prev = newpt;
      newpt->prev = join;        // join up
      join->next = newpt;
    }
  }
  
return newpt;
}







// join_edges  Join 2 edges together. Send the outline for approximation when a  closed loop is formed.

static
void join_edges(CRACKEDGE *edge1,    CRACKEDGE *edge2,    CRACKEDGE **free_cracks, C_OUTLINE_IT* outline_it) {
  if (edge1->pos.x() + edge1->stepx != edge2->pos.x()
  || edge1->pos.y() + edge1->stepy != edge2->pos.y()) {
    CRACKEDGE *tempedge = edge1;
    edge1 = edge2;               // swap around
    edge2 = tempedge;
  }

  if (edge1->next == edge2) {
                                 // already closed
    complete_edge(edge1, outline_it);
                                 // attach freelist to end
    edge1->prev->next = *free_cracks;
    *free_cracks = edge1;         // and free list
  } else {
                                 // update opposite ends
    edge2->prev->next = edge1->next;
    edge1->next->prev = edge2->prev;
    edge1->next = edge2;         // make joins
    edge2->prev = edge1;
  }
}










// line_edges can a line for edges and update the edges in progress.  When edges close into loops, send them for approximation.

void line_edges(inT16 x,                         // coord of line start
                inT16 y,                         // coord of line
                inT16 xext,                      // width of line
                uinT8 uppercolour,               // start of prev line
                uinT8 * bwpos,                   // thresholded line
                CRACKEDGE ** prevline,           // edges in progress
                CRACKEDGE **free_cracks,
                C_OUTLINE_IT* outline_it) {

  CrackPos pos = {free_cracks, x, y };
  int xmax;                      // max x coord
  int colour;                    // of current pixel
  int prevcolour;                // of previous pixel
  CRACKEDGE *current;            // current h edge
  CRACKEDGE *newcurrent;         // new h edge

  xmax = x + xext;               // max allowable coord
  prevcolour = uppercolour;      // forced plain margin
  current = NULL;                // nothing yet

                                  
  
for (; pos.x < xmax; pos.x++, prevline++) {

    colour = *bwpos++;           // current pixel
    if (*prevline != NULL) {    
                                 // changed above
                                 // change colour
      uppercolour = 1-uppercolour;

      if (colour == prevcolour) {
        if (colour == uppercolour) { 
                                 
          join_edges(current, *prevline, free_cracks, outline_it);
          current = NULL;       
        } else {   
                                  
          current = h_edge(uppercolour - colour, *prevline, &pos);
        }
        *prevline = NULL;     
      } else {   
       
if (colour == uppercolour)  *prevline = v_edge(colour - prevcolour, *prevline, &pos);
        prevcolour = colour;     // remember new colour
      }


    } else { 

      if (colour != prevcolour) {  
        *prevline = current = v_edge(colour - prevcolour, current, &pos);
        prevcolour = colour;
      }

      if (colour != uppercolour) current = h_edge(uppercolour - colour, current, &pos);
      else current = NULL;          // no edge now
    }



  }
  

}










//  make_margins   Get an image line and set to margin non-text pixels.  see scanedg.cpp 

static 
void make_margins(                         //get a line
                  PDBLK *block,            //block in image
                  BLOCK_LINE_IT *line_it,  //for old style
                  uinT8 *pixels,           //pixels to strip
                  uinT8 margin,            //white-out pixel
                  inT16 left,              //block edges
                  inT16 right,
                  inT16 y                  //line coord
                 ) {
  PB_LINE_IT *lines;
  ICOORDELT_LIST *segments;      //bits of a line
  ICOORDELT_IT seg_it;
  inT32 start;                   //of segment
  inT16 xext;                    //of segment
  int xindex;                    //index to pixel

  if (block->poly_block () != NULL) {
    lines = new PB_LINE_IT (block->poly_block ());
    segments = lines->get_line (y);
    if (!segments->empty ()) {
      seg_it.set_to_list (segments);
      seg_it.mark_cycle_pt ();
      start = seg_it.data ()->x ();
      xext = seg_it.data ()->y ();
      for (xindex = left; xindex < right; xindex++) {
        if (xindex >= start && !seg_it.cycled_list ()) {
          xindex = start + xext - 1;
          seg_it.forward ();
          start = seg_it.data ()->x ();
          xext = seg_it.data ()->y ();
        }
        else
          pixels[xindex - left] = margin;
      }
    }
    else {
      for (xindex = left; xindex < right; xindex++)
        pixels[xindex - left] = margin;
    }
    delete segments;
    delete lines;
  }
  else {
    start = line_it->get_line (y, xext);
    for (xindex = left; xindex < start; xindex++)
      pixels[xindex - left] = margin;
    for (xindex = start + xext; xindex < right; xindex++)
      pixels[xindex - left] = margin;
  }
}



//  block_edges  Extract edges from a PDBLK.  see scanedg.cpp  

static
void block_edges(Pix *t_pix,           // thresholded image
                 PDBLK *block,         // block in image
                 C_OUTLINE_IT* outline_it) {
  ICOORD bleft;                  // bounding box
  ICOORD tright;
  BLOCK_LINE_IT line_it = block; // line iterator

  int width = pixGetWidth(t_pix);
  int height = pixGetHeight(t_pix);
  int wpl = pixGetWpl(t_pix);
                                 // lines in progress

  block->bounding_box(bleft, tright);  // block box
  int block_width = tright.x() - bleft.x();


  uinT8* bwline = new uinT8[width];

  
  CRACKEDGE **ptrline = new CRACKEDGE*[width + 1];
  for (int x = block_width; x >= 0; x--)  ptrline[x] = NULL;           //  no lines in progress

uinT8 margin = 1;    // WHITE_PIX;

  for (int y = tright.y() - 1; y >= bleft.y() - 1; y--) {    
    if (y >= bleft.y() && y < tright.y()) {
      // Get the binary pixels from the image.
      l_uint32* line = pixGetData(t_pix) + wpl * (height - 1 - y);
      for (int x = 0; x < block_width; ++x) {
        bwline[x] = GET_DATA_BIT(line, x + bleft.x()) ^ 1;
      }
      make_margins(block, &line_it, bwline, margin, bleft.x(), tright.x(), y);
    } else {  
      memset(bwline, margin, block_width * sizeof(bwline[0]));
    }
    
CRACKEDGE *free_cracks = NULL;
line_edges(bleft.x(), y, block_width,  margin, bwline, ptrline, &free_cracks, outline_it);

  }


  
delete[] ptrline, bwline;
}


#endif   //  SCANEDG_CPP





#if TORDMAIN_CPP|1


// SetBlobStrokeWidth Set the horizontal and vertical stroke widths in the blob.

static

void SetBlobStrokeWidth(Pix* pix, BLOBNBOX* blob) {
  // Cut the blob rectangle into a Pix.
  int pix_height = pixGetHeight(pix);
  const TBOX& box = blob->bounding_box();
  int width = box.width();
  int height = box.height();
  Box* blob_pix_box = boxCreate(box.left(), pix_height - box.top(),    width, height);
  Pix* pix_blob = pixClipRectangle(pix, blob_pix_box, NULL);
  boxDestroy(&blob_pix_box);
  Pix* dist_pix = pixDistanceFunction(pix_blob, 4, 8, L_BOUNDARY_BG);
  pixDestroy(&pix_blob);
  // Compute the stroke widths.
  uinT32* data = pixGetData(dist_pix);
  int wpl = pixGetWpl(dist_pix);
  // Horizontal width of stroke.
  STATS h_stats(0, width + 1);
  for (int y = 0; y < height; ++y) {
    uinT32* pixels = data + y*wpl;
    int prev_pixel = 0;
    int pixel = GET_DATA_BYTE(pixels, 0);
    for (int x = 1; x < width; ++x) {
      int next_pixel = GET_DATA_BYTE(pixels, x);
      // We are looking for a pixel that is equal to its vertical neighbours,
      // yet greater than its left neighbour.
      if (prev_pixel < pixel &&
          (y == 0 || pixel == GET_DATA_BYTE(pixels - wpl, x - 1)) &&
          (y == height - 1 || pixel == GET_DATA_BYTE(pixels + wpl, x - 1))) {
        if (pixel > next_pixel) {
          // Single local max, so an odd width.
          h_stats.add(pixel * 2 - 1, 1);
        } else if (pixel == next_pixel && x + 1 < width &&
                 pixel > GET_DATA_BYTE(pixels, x + 1)) {
          // Double local max, so an even width.
          h_stats.add(pixel * 2, 1);
        }
      }
      prev_pixel = pixel;
      pixel = next_pixel;
    }
  }
  // Vertical width of stroke.
  STATS v_stats(0, height + 1);
  for (int x = 0; x < width; ++x) {
    int prev_pixel = 0;
    int pixel = GET_DATA_BYTE(data, x);
    for (int y = 1; y < height; ++y) {
      uinT32* pixels = data + y*wpl;
      int next_pixel = GET_DATA_BYTE(pixels, x);
      // We are looking for a pixel that is equal to its horizontal neighbours,
      // yet greater than its upper neighbour.
      if (prev_pixel < pixel &&
          (x == 0 || pixel == GET_DATA_BYTE(pixels - wpl, x - 1)) &&
          (x == width - 1 || pixel == GET_DATA_BYTE(pixels - wpl, x + 1))) {  
        if (pixel > next_pixel) {  
          // Single local max, so an odd width.
          v_stats.add(pixel * 2 - 1, 1);
        } else if (pixel == next_pixel && y + 1 < height &&
                 pixel > GET_DATA_BYTE(pixels + wpl, x)) {  
          // Double local max, so an even width.
          v_stats.add(pixel * 2, 1);
        }
      }
      prev_pixel = pixel;
      pixel = next_pixel;
    }
  }
  pixDestroy(&dist_pix);
  

  if (h_stats.get_total() >= (width + height) / 4) {  
    blob->set_horz_stroke_width(h_stats.ile(0.5f));
    if (v_stats.get_total() >= (width + height) / 4)
      blob->set_vert_stroke_width(v_stats.ile(0.5f));
    else
      blob->set_vert_stroke_width(0.0f);
  }  

}




// assign_blobs_to_blocks2    Make a list of TO_BLOCKs for portrait and landscape orientation.

static
void assign_blobs_to_blocks2(Pix* pix, BLOCK_LIST *blocks,  TO_BLOCK_LIST *port_blocks) {  // output list
  BLOCK *block;                  // current block
  BLOBNBOX *newblob;             // created blob
  C_BLOB *blob;                  // current blob
  BLOCK_IT block_it = blocks;
  C_BLOB_IT blob_it;             // iterator
  BLOBNBOX_IT port_box_it;       // iterator
                                 // destination iterator
  TO_BLOCK_IT port_block_it = port_blocks;
  TO_BLOCK *port_block;          // created block

  for (block_it.mark_cycle_pt(); !block_it.cycled_list(); block_it.forward()) {
    block = block_it.data();
    port_block = new TO_BLOCK(block);

    // Convert the good outlines to block->blob_list
    port_box_it.set_to_list(&port_block->blobs);
    blob_it.set_to_list(block->blob_list());
    for (blob_it.mark_cycle_pt(); !blob_it.cycled_list(); blob_it.forward()) {   
      blob = blob_it.extract();
      newblob = new BLOBNBOX(blob);  // Convert blob to BLOBNBOX.
      SetBlobStrokeWidth(pix, newblob);
      port_box_it.add_after_then_move(newblob);
    }

     

  port_block_it.add_after_then_move(port_block);
  }


}






#endif    //   TORDMAIN_CPP











// File=0, ָ������� eng.traineddata 
FILE* OpenFile(const char*File, const char*mode){    // =0 ="rb" 

char*ptr=0;
 
if(!File){
ptr= new char[256]; *ptr = 0;        
GetCurrentDirectory(256,ptr);  strcat(ptr,"/Worksite/tessdata3.02/tessdata/eng.traineddata");  // ��ǰ·��һ���� .sln ����λ��, ������׺'\\'.  �����ܱ��������.    
File=ptr;  
}

FILE*fp=fopen(File, mode);  if(!fp) qTrace("%s\r\n%s\r\n", strerror(errno), File)

if(!ptr) delete[] ptr;  
return  fp;  
}


UNICHARSET* Read_Charset(TessdataManager* tdr, UNICHARSET*uchs ){

if(!tdr) return 0; 



if (tdr->offset_table_[TESSDATA_UNICHARSET] < 0) {  qTrace("No data type %d", TESSDATA_UNICHARSET); return 0; } 


if(!uchs) uchs=new   UNICHARSET;  



fseek(tdr->data_file_, tdr->offset_table_[TESSDATA_UNICHARSET],  SEEK_SET);   // assert( fseek(tdr->data_file_,  static_cast<size_t>(tdr->offset_table_[TESSDATA_UNICHARSET]),  SEEK_SET) == 0 );



#if LOAD_FILE|1


int unicharset_size;
char buffer[256];

uchs->clear();


if( ! fgets(buffer,sizeof(buffer), tdr->data_file_)  )  {  qTrace("fgets_cb->Run failed"); return false;  }    // ����'\n'

if ( sscanf( buffer, "%d", &unicharset_size) != 1){ qTrace("No unicharset_size!"); unicharset_size=0;  }       // return false;  


// qTrace("1, unicharset_size=%d", unicharset_size);

uchs->reserve(unicharset_size);

// qTrace("2, unicharset_size=%d", unicharset_size);

  
for (UNICHAR_ID id = 0; id < unicharset_size; ++id) {

    char unichar[256];
    unsigned int properties;
    char script[64];

    //strcpy(script, null_script);

    int min_bottom = 0;
    int max_bottom = MAX_UINT8;
    int min_top = 0;
    int max_top = MAX_UINT8;
    float width = 0.0f;
    float width_sd = 0.0f;
    float bearing = 0.0f;
    float bearing_sd = 0.0f;
    float advance = 0.0f;
    float advance_sd = 0.0f;
    // TODO(eger): check that this default it ok
    // after enabling BiDi iterator for Arabic+Cube.
    int direction = UNICHARSET::U_LEFT_TO_RIGHT;
    UNICHAR_ID other_case = id;
    UNICHAR_ID mirror = id;
    char normed[64];
    int v = -1;



// ÿ�й� 7 ������,  17 +  16  +  10  +  8 +  4 +  3 +  2    =  60 ����  

    if (fgets(buffer, sizeof (buffer), tdr->data_file_) == NULL ||
        ((v = sscanf(buffer,
                     "%s %x %d,%d,%d,%d,%g,%g,%g,%g,%g,%g %63s %d %d %d %63s",
                     unichar, &properties,
                     &min_bottom, &max_bottom, &min_top, &max_top,
                     &width, &width_sd, &bearing, &bearing_sd,
                     &advance, &advance_sd, script, &other_case,
                     &direction, &mirror, normed)) != 17 &&                    
         (v = sscanf(buffer,
                     "%s %x %d,%d,%d,%d,%g,%g,%g,%g,%g,%g %63s %d %d %d",
                     unichar, &properties,
                     &min_bottom, &max_bottom, &min_top, &max_top,
                     &width, &width_sd, &bearing, &bearing_sd,
                     &advance, &advance_sd, script, &other_case,
                     &direction, &mirror)) != 16 &&                            
          (v = sscanf(buffer, "%s %x %d,%d,%d,%d %63s %d %d %d",
                      unichar, &properties,
                      &min_bottom, &max_bottom, &min_top, &max_top,
                      script, &other_case, &direction, &mirror)) != 10 &&
          (v = sscanf(buffer, "%s %x %d,%d,%d,%d %63s %d", unichar, &properties,
                      &min_bottom, &max_bottom, &min_top, &max_top,
                      script, &other_case)) != 8 &&
          (v = sscanf(buffer, "%s %x %63s %d", unichar, &properties,
                      script, &other_case)) != 4 &&
          (v = sscanf(buffer, "%s %x %63s",
                      unichar, &properties, script)) != 3 &&
          (v = sscanf(buffer, "%s %x", unichar, &properties)) != 2)) {
      return false;
    }



#if DONT_KNOW

    // Skip fragments if needed.
    CHAR_FRAGMENT *frag = NULL;

    if (false && (frag = CHAR_FRAGMENT::parse_from_string(unichar))) {

      int num_pieces = frag->get_total();
      delete frag;
      // Skip multi-element fragments, but keep singles like UNICHAR_BROKEN in.
      if (num_pieces > 1)continue;
        
    }

#endif  // DONT_KNOW 


    // Insert unichar into unicharset and set its properties.
    if (strcmp(unichar, "NULL") == 0)
      uchs->unichar_insert(" ");
    else
      uchs->unichar_insert(unichar);



#if DEBUG_MODE

    this->set_isalpha(id, properties & ISALPHA_MASK);
    this->set_islower(id, properties & ISLOWER_MASK);
    this->set_isupper(id, properties & ISUPPER_MASK);
    this->set_isdigit(id, properties & ISDIGIT_MASK);
    this->set_ispunctuation(id, properties & ISPUNCTUATION_MASK);
    this->set_isngram(id, false);
    this->set_script(id, script);
    this->unichars[id].properties.enabled = true;
    this->set_top_bottom(id, min_bottom, max_bottom, min_top, max_top);
    this->set_width_stats(id, width, width_sd);
    this->set_bearing_stats(id, bearing, bearing_sd);
    this->set_advance_stats(id, advance, advance_sd);
    this->set_direction(id, static_cast<UNICHARSET::Direction>(direction));
    ASSERT_HOST(other_case < unicharset_size);
    this->set_other_case(id, (v>3) ? other_case : id);


    ASSERT_HOST(mirror < unicharset_size);
    this->set_mirror(id, (v>8) ? mirror : id);
    this->set_normed(id, (v>16) ? normed : unichar);

#endif     // DEBUG_MODE



}  // for 





//\\post_load_setup();

 





#endif    // LOAD_FILE





return uchs; 
}


INT_TEMPLATES* Read_Template(TessdataManager* tdr, INT_TEMPLATES*tp ){

if(!tdr) return 0; 

if(!tp) tp=new   INT_TEMPLATES;  


fseek(tdr->data_file_, tdr->offset_table_[TESSDATA_INTTEMP],  SEEK_SET);



// tp  = pcf->ReadIntTemplates( tdr->data_file_ ); 

FILE *File=tdr->data_file_;  


        int i, j, w, x, y, z;
        int nread;
        int unicharset_size;
        int version_id = 0;
        INT_TEMPLATES Templates;
        CLASS_PRUNER_STRUCT* Pruner;
        INT_CLASS Class;
        uinT8 *Lengths;
        PROTO_SET ProtoSet;

        /* variables for conversion from older inttemp formats */
        int b, bit_number, last_cp_bit_number, new_b, new_i, new_w;

        // CLASS_ID class_id, max_class_id;


// inT16 *IndexFor = new inT16[MAX_NUM_CLASSES];   // 0x7fff = 32767

  

        
uinT32 SetBitsForMask = (1 << NUM_BITS_PER_CLASS) - 1;  //  = 4-1,   set starting at bit 0
        
uinT32 Mask, NewMask, ClassBits;
        int MaxNumConfigs = MAX_NUM_CONFIGS;
        int WerdsPerConfigVec = WERDS_PER_CONFIG_VEC;



        Templates = NewIntTemplates();      // first read the high level template struct  

        
if (fread(&unicharset_size, sizeof(int), 1, File) != 1)  printf("Bad read of inttemp!\n");      // �������ַ�������ͷ  


if (fread(&Templates->NumClasses, sizeof(Templates->NumClasses), 1, File) != 1 ||
    fread(&Templates->NumClassPruners, sizeof(Templates->NumClassPruners), 1, File) != 1)  printf("Bad read of inttemp!\n");  // pruner �޼�
            



// Swap status is determined automatically.

// BOOL8 swap = Templates->NumClassPruners < 0 || Templates->NumClassPruners > MAX_NUM_CLASS_PRUNERS;


        if (Templates->NumClasses < 0) {                  //  qTrace("Templates->NumClasses=%d", Templates->NumClasses);

            version_id = -Templates->NumClasses;          // This file has a version id!

            if (fread(&Templates->NumClasses, sizeof(Templates->NumClasses), 1, File) != 1) qTrace("Bad read of inttemp!\n");

        }


// qTrace("NumClasses=%d,  NumClassPruners=%d\r\n ",  Templates->NumClasses,  Templates->NumClassPruners); 


        for (i = 0; i < Templates->NumClassPruners; i++) {      // then read in the class pruners  

            Pruner = new CLASS_PRUNER_STRUCT;
            if ((nread = fread(Pruner, 1, sizeof(CLASS_PRUNER_STRUCT),  File)) != sizeof(CLASS_PRUNER_STRUCT))  printf("Bad read of inttemp!\n");

            Templates->ClassPruners[i] = Pruner;


        }  // for 







        // then read in each class

        for (i = 0; i < Templates->NumClasses; i++) {



            /* first read in the high level struct for the class */
            Class = (INT_CLASS)malloc(sizeof(INT_CLASS_STRUCT));

            if (fread(&Class->NumProtos, sizeof(Class->NumProtos), 1, File) != 1 ||
                fread(&Class->NumProtoSets, sizeof(Class->NumProtoSets), 1, File) != 1 ||
                fread(&Class->NumConfigs, sizeof(Class->NumConfigs), 1, File) != 1)
                printf("Bad read of inttemp!\n");







            assert(Class->NumConfigs < MaxNumConfigs);

            for (j = 0; j < Class->NumConfigs; ++j) {
                if (fread(&Class->ConfigLengths[j], sizeof(uinT16), 1, File) != 1)
                    printf("Bad read of inttemp!\n");
            }





            Templates->Class[i] = Class;    // #define ClassForClassId(T,c) ((T)->Class[c])





            
// then read in the proto lengths  // #define MaxNumIntProtosIn(C)  (C->NumProtoSets * PROTOS_PER_PROTO_SET)

            Lengths = NULL;
            if (Class->NumProtoSets*PROTOS_PER_PROTO_SET > 0) {
                Lengths = (uinT8 *)malloc(sizeof(uinT8) * Class->NumProtoSets*PROTOS_PER_PROTO_SET);
                if ((nread =  fread((char *)Lengths, sizeof(uinT8),  Class->NumProtoSets*PROTOS_PER_PROTO_SET, File)) != Class->NumProtoSets*PROTOS_PER_PROTO_SET)
                    printf("Bad read of inttemp!\n");
            }

            Class->ProtoLengths = Lengths;



            //  then read in the proto sets  

            for (j = 0; j < Class->NumProtoSets; j++) {
                ProtoSet = (PROTO_SET)malloc(sizeof(PROTO_SET_STRUCT));
                

#if LOW_VERSIN

if (version_id < 3) {   alert("!!!");
                    if ((nread = fread((char *)&ProtoSet->ProtoPruner, 1, sizeof(PROTO_PRUNER), File)) != sizeof(PROTO_PRUNER)) printf("Bad read of inttemp!\n");
                       
                    for (x = 0; x < PROTOS_PER_PROTO_SET; x++) {
                        if ((nread = fread((char *)&ProtoSet->Protos[x].A, 1,
                            sizeof(inT8), File)) != sizeof(inT8) ||
                            (nread = fread((char *)&ProtoSet->Protos[x].B, 1,
                                sizeof(uinT8), File)) != sizeof(uinT8) ||
                                (nread = fread((char *)&ProtoSet->Protos[x].C, 1,
                                    sizeof(inT8), File)) != sizeof(inT8) ||
                                    (nread = fread((char *)&ProtoSet->Protos[x].Angle, 1,
                                        sizeof(uinT8), File)) != sizeof(uinT8))
                            printf("Bad read of inttemp!\n");
                        for (y = 0; y < WerdsPerConfigVec; y++)
                            if ((nread = fread((char *)&ProtoSet->Protos[x].Configs[y], 1,
                                sizeof(uinT32), File)) != sizeof(uinT32))
                                printf("Bad read of inttemp!\n");
                    }
                }
                else
 
#endif    // LOW_VERSIN

if ((nread =  fread((char *)ProtoSet, 1, sizeof(PROTO_SET_STRUCT),  File)) != sizeof(PROTO_SET_STRUCT)) printf("Bad read of inttemp!\n");
                        
 


                Class->ProtoSets[j] = ProtoSet;
            }  // for 


            if (version_id < 4)   Class->font_set_id = -1;
            else  fread(&Class->font_set_id, sizeof(int), 1, File);



        }







        if (version_id >= 4) {

         //   this->fontinfo_table_.read(File, NewPermanentTessCallback(read_info), swap);

          //  if (version_id >= 5) this->fontinfo_table_.read(File, NewPermanentTessCallback(read_spacing_info), swap);

          //  this->fontset_table_.read(File, NewPermanentTessCallback(read_set), swap);
        }




// delete[] IndexFor;

       
*tp=Templates;  // return (Templates);




return tp; 
}




Classify*  LoadData(const char*File){



Classify* pcf=new Classify;  


TessdataManager tessdata_manager;  

// Init  
tessdata_manager.data_file_=OpenFile(File); 
fread(&tessdata_manager.actual_tessdata_num_entries_, sizeof(int), 1, tessdata_manager.data_file_);
fread(tessdata_manager.offset_table_, sizeof(INT64), tessdata_manager.actual_tessdata_num_entries_, tessdata_manager.data_file_);

 
Read_Charset(&tessdata_manager, &pcf->unicharset);  
// show_data(&pcf->unicharset); 
 
Read_Template(&tessdata_manager,  &pcf->PreTrainedTemplates); 
// show_data(pcf->PreTrainedTemplates); 



return pcf;  
}










bool LoadData(Tesseract* tesseract_ ){    

char* lang= "eng";
char* datapath = new char[256]; *datapath = 0;         // �����ļ�λ��   ��Ҫ�� + /tessdata/ + [eng].traineddata
//strcpy(datapath, "C:/Worksite/����ʶ��/tesseract/tessdata3.02");   \
strcpy(datapath, "d:/Tbyang20/����ʶ��/Worksite/tessdata3.02");   //  ���� "../"

GetCurrentDirectory(256,datapath);  strcat(datapath,"/Worksite/tessdata3.02");  // ��ǰ·��һ���� .sln ����λ��, ������׺'\\'.  �����ܱ��������. 


std::string tpath=datapath;  tpath+="/tessdata/";   tpath+=lang;   tpath+=".";   tpath+="traineddata";    // kTrainedDataSuffix


// TessdataManager tessdata_manager;  

tesseract_->tessdata_manager=*new TessdataManager; 

if( !tesseract_->tessdata_manager.Init(tpath.c_str(), 0)) return false;
 

tesseract_->tessdata_manager.SeekToStart(TESSDATA_UNICHARSET);  // ���� .config 



if ( !tesseract_->unicharset.load_from_file(tesseract_->tessdata_manager.data_file_, false) ) { qTrace("load_from_file failed"); return false; }


assert(tesseract_->tessdata_manager.SeekToStart(TESSDATA_INTTEMP));
            
tesseract_->PreTrainedTemplates = tesseract_->ReadIntTemplates(tesseract_->tessdata_manager.GetDataFilePtr());   //   GetDataFilePtr() = data_file_  
      



assert(tesseract_->tessdata_manager.SeekToStart(TESSDATA_PFFMTABLE)); \
tesseract_->ReadNewCutoffs(tesseract_->tessdata_manager.GetDataFilePtr(), tesseract_->tessdata_manager.swap_, tesseract_->tessdata_manager.GetEndOffset(TESSDATA_PFFMTABLE),  tesseract_->CharNormCutoffs);
        
     

tesseract_->static_classifier_ = new TessClassifier(false, tesseract_);   
tesseract_->im_.Init(0);    // &tesseract_->classify_debug_level 


tesseract_->AllProtosOn = NewBitVector(MAX_NUM_PROTOS);
tesseract_->AllConfigsOn = NewBitVector(MAX_NUM_CONFIGS);
 

set_all_bits(tesseract_->AllProtosOn, WordsInVectorOfSize(MAX_NUM_PROTOS));

 
qTrace("OK!");
}




bool LoadData(TessBaseAPI&api){ 

api.tesseract_->language_data_path_prefix += ".";

char* datapath = new char[256]; *datapath = 0;         // �����ļ�λ�� 

GetCurrentDirectory(256,datapath);  strcat(datapath,"/Worksite/tessdata3.02/tessdata/eng.traineddata");
api.tesseract_->tessdata_manager.data_file_name_ =  datapath;
api.tesseract_->tessdata_manager.data_file_ = OpenFile(datapath);  // fopen(tessdata_path.string(), "rb");


fread(&api.tesseract_->tessdata_manager.actual_tessdata_num_entries_, sizeof(inT32), 1, api.tesseract_->tessdata_manager.data_file_);
  
api.tesseract_->tessdata_manager.swap_ = (api.tesseract_->tessdata_manager.actual_tessdata_num_entries_ > kMaxNumTessdataEntries);
 

fread(api.tesseract_->tessdata_manager.offset_table_, sizeof(inT64),  api.tesseract_->tessdata_manager.actual_tessdata_num_entries_, api.tesseract_->tessdata_manager.data_file_);


if (api.tesseract_->tessdata_manager.SeekToStart(TESSDATA_LANG_CONFIG))  
ParamUtils::ReadParamsFromFp(api.tesseract_->tessdata_manager.GetDataFilePtr(), api.tesseract_->tessdata_manager.GetEndOffset(TESSDATA_LANG_CONFIG), SET_PARAM_CONSTRAINT_NONE, api.tesseract_->params()); // 
            

if (!api.tesseract_->unicharset.load_from_file(api.tesseract_->tessdata_manager.GetDataFilePtr())) { qTrace("load_from_file failed"); return false; }
if (!api.tesseract_->tessdata_manager.SeekToStart(TESSDATA_UNICHARSET)) { qTrace("No Data!"); return false; }


InitFeatureDefs(&api.tesseract_->feature_defs_);  \
api.tesseract_->InitAdaptiveClassifier(true);

api.tesseract_->getDict().SetupForLoad(Dict::GlobalDawgCache());  
api.tesseract_->getDict().Load(api.tesseract_->tessdata_manager.GetDataFileName().string(), "");  // api.tesseract_->lang = ""
api.tesseract_->getDict().FinishLoad();



return true;  
}



int ProcessImage(TessBaseAPI&api){

Pix** pix=  api.tesseract_->mutable_pix_binary();   // mutable �ɱ�� 

if (*pix != NULL) pixDestroy(pix);

int y_res = api.thresholder_->yres_;  // Zero resolution messes up the algorithms, so make sure it is credible.





int   num_channels = pixGetDepth(api.thresholder_->pix_) / 8;

int* thresholds = new int[num_channels];
int* hi_values = new int[num_channels];


for (int ch = 0; ch < num_channels; ++ch) {

      thresholds[ch] = -1;
      hi_values[ch] = -1;
      int histogram[kHistogramSize];      // Compute the histogram of the image rectangle.

      


HistogramRect(api.thresholder_->pix_, ch, api.thresholder_->rect_left_, api.thresholder_->rect_top_, api.thresholder_->rect_width_, api.thresholder_->rect_height_, histogram);

      int H;
      int best_omega_0;




int best_t = OtsuStats(histogram, &H, &best_omega_0);




if (best_omega_0 == 0 || best_omega_0 == H)  continue;
      
      thresholds[ch] = best_t;

      if (best_omega_0 > H * 0.75)        hi_values[ch] = 0;
      else if (best_omega_0 < H * 0.25)   hi_values[ch] = 1;
         
}




   

  *pix = pixCreate(api.thresholder_->rect_width_, api.thresholder_->rect_height_, 1);
  uinT32* pixdata = pixGetData(*pix);
  int wpl = pixGetWpl(*pix);
  int src_wpl = pixGetWpl(api.thresholder_->pix_);
  uinT32* srcdata = pixGetData(api.thresholder_->pix_);

  for (int y = 0; y < api.thresholder_->rect_height_; ++y) {
    const uinT32* linedata = srcdata + (y + api.thresholder_->rect_top_) * src_wpl;
    uinT32* pixline = pixdata + y * wpl;
    for (int x = 0; x < api.thresholder_->rect_width_; ++x) {
      bool white_result = true;
      for (int ch = 0; ch < num_channels; ++ch) {
        int pixel = GET_DATA_BYTE(const_cast<void*>(  reinterpret_cast<const void *>(linedata)),
                                  (x + api.thresholder_->rect_left_) * num_channels + ch);
        if (hi_values[ch] >= 0 &&
            (pixel > thresholds[ch]) == (hi_values[ch] == 0)) {
          white_result = false;
          break;
        }
      }
      if (white_result)        CLEAR_DATA_BIT(pixline, x);
      else                     SET_DATA_BIT(pixline, x);
    }
  }





delete thresholds, hi_values;


     
 


BLOCK* block = new BLOCK("", TRUE, 0, 0, 0, 0, api.tesseract_->pix_binary_->w, api.tesseract_->pix_binary_->h);

   
  C_OUTLINE_LIST outlines;       // outlines in block
  C_OUTLINE_IT out_it = &outlines;

  block_edges(api.tesseract_->pix_binary_, block, &out_it);
  
ICOORD bleft, tright; block->bounding_box(bleft, tright);
                                 



 

OL_BUCKETS buckets(bleft, tright);

  TBOX ol_box;                     // outline box
  C_OUTLINE_IT bucket_it;          // iterator in bucket
  C_OUTLINE *outline;              // current outline

  for (out_it.mark_cycle_pt(); !out_it.cycled_list(); out_it.forward()) {
    outline = out_it.extract();   
                                 
    ol_box = outline->bounding_box();
    bucket_it.set_to_list((buckets) (ol_box.left(), ol_box.bottom()));
    bucket_it.add_to_end(outline);
  }

 

 
bucket_it = buckets.start_scan();
  C_OUTLINE_IT parent_it;        // parent outline
  C_BLOB_IT good_blobs = block->blob_list();
  C_BLOB_IT junk_blobs = block->reject_blobs();

  while (!bucket_it.empty()) { 
    out_it.set_to_list(&outlines);
    do {
      parent_it = bucket_it;     // find outermost
      do {
        bucket_it.forward();
      } while (!bucket_it.at_first() && !(*parent_it.data() < *bucket_it.data()));
    } while (!bucket_it.at_first());

                                  
    out_it.add_after_then_move(parent_it.extract());

                               
C_OUTLINE_LIST nested_outlines;

for (C_OUTLINE_IT ol_it(&outlines); !ol_it.empty(); ol_it.forward()) {
  
C_OUTLINE* outline = ol_it.extract();

C_OUTLINE_IT it =  &nested_outlines;
it.add_to_end (outline);     
 
}




for (C_OUTLINE_IT ol_it(&nested_outlines); !ol_it.empty(); ol_it.forward()) {

C_OUTLINE* outline = ol_it.extract();

C_BLOB* blob = new C_BLOB(outline);
    
good_blobs.add_after_then_move(blob);
}











                        

    bucket_it.set_to_list(buckets.scan_next());
  }





 









 
BLOCK_LIST* blocks=api.block_list_;
BLOCK_IT block_it(blocks); 
block_it.add_to_end(block);


 
TO_BLOCK_LIST to_blocks;

assign_blobs_to_blocks2(api.tesseract_->pix_binary_, blocks, &to_blocks);
ICOORD page_tr(api.tesseract_->pix_binary_->w, api.tesseract_->pix_binary_->h);
api.tesseract_->textord_.filter_blobs(page_tr, &to_blocks, ! false );    // textord_test_landscape = false 
 
















TO_BLOCK_IT to_block_it(&to_blocks);
TO_BLOCK* to_block = to_block_it.data();
  
float gradient= make_rows(api.tesseract_->textord_.page_tr_, &to_blocks);
   

BaselineDetect baseline_detector(api.tesseract_->textord_.textord_baseline_debug,    api.tesseract_->reskew_, &to_blocks);
baseline_detector.ComputeStraightBaselines(true);
  


baseline_detector.ComputeBaselineSplinesAndXheights(    \
      api.tesseract_->textord_.page_tr_,    api.tesseract_->tessedit_pageseg_mode != PSM_RAW_LINE, false,   \
      false , &api.tesseract_->textord_);    // textord_heavy_nr = false    textord_show_final_rows = false 



make_words(&api.tesseract_->textord_, api.tesseract_->textord_.page_tr_, gradient, blocks, &to_blocks);
 


return 0;

}







void Recognize(TessBaseAPI&api){

api.page_res_ = new PAGE_RES;   // qTrace("%d", api.block_list_->length());  

BLOCK_IT block_it(api.block_list_);
BLOCK_RES_IT block_res_it(&api.page_res_->block_res_list);
block_res_it.add_to_end(new BLOCK_RES(0,   block_it.data()   ));




 
GenericVector<WordData> words;   PAGE_RES_IT page_res_it(api.page_res_);  
  

page_res_it.restart_page();      
// for (page_res_it.restart_page(); page_res_it.word() != NULL;  page_res_it.forward())
words.push_back(WordData(page_res_it));   


 WordData* word=&words[0];



    int s=0; 

      // The sub_langs_.size() entry is for the master language.
      Tesseract* lang_t = api.tesseract_;
      WERD_RES* word_res = new WERD_RES;
      word_res->InitForRetryRecognition(*word->word);
      word->lang_words.push_back(word_res);




 
  


           
               
              
              
               


const UNICHARSET& unicharset_in=lang_t->unicharset;

tesseract::Tesseract* tess=lang_t; 


Pix* pix= api.tesseract_->BestPix();

                                   int norm_mode =lang_t->tessedit_ocr_engine_mode;

                                   const TBOX* norm_box=0;
                                   bool numeric_mode =lang_t->classify_bln_numeric_mode;
                                   bool use_body_size =lang_t->textord_use_cjk_fp_model;
                                   bool allow_detailed_fx = lang_t->poly_allow_detailed_fx;  
                                   ROW *row=word->row ;

 const BLOCK* block=word->block;



 tesseract::OcrEngineMode norm_mode_hint =  static_cast<tesseract::OcrEngineMode>(norm_mode);

  word_res->tesseract = tess;
  POLY_BLOCK* pb = block != NULL ? block->poly_block() : NULL;

  
word_res->uch_set = &unicharset_in;


word_res->chopped_word= new TWERD;

C_BLOB_IT b_it(word_res->word->cblob_list());

for (b_it.mark_cycle_pt(); !b_it.cycled_list(); b_it.forward()) {
    C_BLOB* blob = b_it.data();
    TBLOB* tblob = TBLOB::PolygonalCopy(allow_detailed_fx, blob);
    word_res->chopped_word->blobs.push_back(tblob);
}
  



float x_height = use_body_size && row != NULL && row->body_size() > 0.0f  ? row->body_size() : word_res->x_height;
  
bool inverse = word_res->word->flag(W_INVERSE);  


float baseline_shift = word_res->baseline_shift;

                         



TBOX word_box = word_res->chopped_word->bounding_box();

if (norm_box != NULL) word_box = *norm_box;

float word_middle = (word_box.left() + word_box.right()) / 2.0f;

  float input_y_offset = 0.0f;
  float final_y_offset = static_cast<float>(kBlnBaselineOffset);
 float scale = kBlnXHeight / x_height;
  



  
for (int b = 0; b < word_res->chopped_word->blobs.size(); ++b) {

TBLOB* blob = word_res->chopped_word->blobs[b];

TBOX blob_box = blob->bounding_box();
float mid_x = (blob_box.left() + blob_box.right()) / 2.0f;
    
float baseline = input_y_offset;
if (row != NULL )   baseline = row->base_line(mid_x) + baseline_shift;
  
blob->denorm_.x_origin_ = word_middle;     // ��  
blob->denorm_.y_origin_ = baseline;        // ��
blob->denorm_.y_scale_ = scale;            // ��

ICOORD translation(-IntCastRounded(blob->denorm_.x_origin_), -IntCastRounded(blob->denorm_.y_origin_));
blob->Move(translation);
if (blob->denorm_.y_scale_ != 1.0f)    blob->Scale(blob->denorm_.y_scale_);
blob->Move(translation);                   // ��

}    // for 
  




 











int num_blobs = word_res->chopped_word->NumBlobs();

word_res->ratings = new MATRIX(num_blobs,  4);    // 4=kWordrecMaxNumJoinChunks

 








  
WordData* word_data=&words[0];  


int sub = api.tesseract_->sub_langs_.size();

WERD_RES* wr=  word_data->lang_words[sub];  
 


 

 

 num_blobs = wr->chopped_word->blobs.size();
 
  
for (int b = 0; b < num_blobs; ++b) {


BLOB_CHOICE_LIST* choices = api.tesseract_->call_matcher(wr->chopped_word->blobs[b]);

 


wr->ratings->put(b, b, choices);
}

  


BestChoiceBundle best_choice_bundle(wr->ratings->dimension());




   
 
#if CHOOSE_BEST|1





GenericVector<SegSearchPending> pending;
pending.init_to_size(wr->ratings->dimension(), SegSearchPending());
pending[0].column_classified_ = true;


LMPainPoints pain_points;  pain_points.dict_=&api.tesseract_->getDict();
float rating_cert_scale = -1.0 * api.tesseract_->getDict().certainty_scale / api.tesseract_->rating_scale;



for (int col = 0; col < wr->ratings->dimension(); ++col) {


    int first_row = col;
    int last_row = MIN(wr->ratings->dimension() - 1,  col + wr->ratings->bandwidth() - 1);



for (int row = first_row; row <= last_row; ++row) {

      BLOB_CHOICE_LIST *current_node = wr->ratings->get(col, row);
      LanguageModelState *parent_node =    col == 0 ? NULL : best_choice_bundle.beam[col - 1];



 if (current_node){ 


 bool just_classified=  pending[col].IsRowJustClassified(row);  

    int curr_col=col,  curr_row=row;

    BLOB_CHOICE_LIST *curr_list=current_node;

 
    WERD_RES *word_res=wr;  

    BlamerBundle *blamer_bundle = wr->blamer_bundle;  


 


  bool word_end = (curr_row+1 >= word_res->ratings->dimension());
  bool new_changed = false;

  const UNICHARSET& unicharset = api.tesseract_->language_model_->dict_->getUnicharset();
  BLOB_CHOICE *first_lower = NULL;
  BLOB_CHOICE *first_upper = NULL;
  BLOB_CHOICE *first_digit = NULL;
  bool has_alnum_mix = false;




if (!api.tesseract_->language_model_->GetTopLowerUpperDigit(curr_list, &first_lower, &first_upper, &first_digit)) has_alnum_mix = false;    // ����9���? 
   

  

  LanguageModelState *curr_state = best_choice_bundle.beam[curr_row];

  ViterbiStateEntry_IT vit;
  BLOB_CHOICE_IT c_it(curr_list);
  

for (c_it.mark_cycle_pt(); !c_it.cycled_list(); c_it.forward()) {

BLOB_CHOICE* choice = c_it.data();

UNICHAR_ID unichar_id = choice->unichar_id();

    
LanguageModelFlagsType blob_choice_flags = api.tesseract_->language_model_->kXhtConsistentFlag;

if (first_digit == choice) blob_choice_flags |= api.tesseract_->language_model_->kDigitFlag;     // ��  

    if (parent_node == NULL) {
  
      new_changed |= api.tesseract_->language_model_->m_AddViterbiStateEntry(
          blob_choice_flags,   word_end, curr_col, curr_row,
          choice, curr_state, NULL, &pain_points,
          word_res, &best_choice_bundle, blamer_bundle);

    } else {

      vit.set_to_list(&parent_node->viterbi_state_entries);
      int vit_counter = 0;
      vit.mark_cycle_pt();
      ViterbiStateEntry* parent_vse = NULL;
    LanguageModelFlagsType top_choice_flags;


while ((parent_vse = api.tesseract_->language_model_->GetNextParentVSE(just_classified, has_alnum_mix,
                                            c_it.data(), blob_choice_flags,
                                            unicharset, word_res, &vit,
                                            &top_choice_flags)) != NULL) {  
        

         
        
new_changed |= api.tesseract_->language_model_->m_AddViterbiStateEntry(    \
            top_choice_flags,         word_end, curr_col, curr_row,    \
            c_it.data(), curr_state, parent_vse, &pain_points,    \
            word_res, &best_choice_bundle, blamer_bundle);
      }
    }
  
}  // for  
 


// return new_changed;
}


















}  // end for row.


}  // end for col.
  


   


#endif    //  CHOOSE_BEST


 








word_data->word->uch_set = wr->uch_set;    

word_data->word->best_choice =wr->best_choice; 

WERD_CHOICE_IT wc_it(&word_data->word->best_choices);  wc_it.add_list_after(&wr->best_choices);

return;// wr->best_choice->length_; 
}














char* GetText(PAGE_RES*pr){


PAGE_RES_IT* rt=new PAGE_RES_IT; 
// rt->page_res=api.page_res_;

rt->block_res_it=&pr->block_res_list;

#if GET_UTF8TEXT|0
 

 

auto i_f=[&](bool n_ok, bool e_ok){

rt->row_res_it = &rt->block_res_it.data()->row_res_list;
rt->word_res_it = &rt->row_res_it.data()->word_res_list ;
rt->word_res = rt->word_res_it.data();

return rt->word_res;
};


i_f(true, true);
//i_f(false, true);       
 


#endif    //  GET_UTF8TEXT

rt->row_res_it = &rt->block_res_it.data()->row_res_list;
rt->word_res_it = &rt->row_res_it.data()->word_res_list ;
rt->word_res = rt->word_res_it.data();


WERD_RES* wr=rt->word_res; 


int ic=wr->best_choice->length_;

int len=0;  
for (int i = 0; i < ic; i++)  
len +=  strlen( wr->uch_set->id_to_unichar_ext(  wr->best_choice->unichar_id(i)  )  );



char *s=new char[len+1];  *s=0;  

for (int i = 0; i < ic; i++)  
strcat(s, wr->uch_set->id_to_unichar_ext(  wr->best_choice->unichar_id(i) ) ) ;

 



return s; 
}













#if LOCAL_CODE|1




bool LanguageModel::m_AddViterbiStateEntry(
    LanguageModelFlagsType top_choice_flags,

    bool word_end,
    int curr_col, int curr_row,
    BLOB_CHOICE *b,
    LanguageModelState *curr_state,
    ViterbiStateEntry *parent_vse,
    LMPainPoints *pain_points,
    WERD_RES *word_res,
    BestChoiceBundle *best_choice_bundle,
    BlamerBundle *blamer_bundle) {

// if(parent_vse==0) qTrace("!!!"); 
LMConsistencyInfo consistency_info;  // ( parent_vse != NULL ? &parent_vse->consistency_info : NULL);


if(parent_vse != NULL) consistency_info = parent_vse->consistency_info;
else{

consistency_info.num_alphas = 0;   // ��  
consistency_info.num_digits = 0;   // ��  
consistency_info.num_punc = 0;     // ��  
consistency_info.num_other = 0;    // ��  
consistency_info.num_inconsistent_spaces = 0;    // ��  
 
consistency_info.punc_ref = NO_EDGE;       // ��  
consistency_info.num_non_first_upper = 0;  // ��  
consistency_info.num_lower = 0;            // ��  

}   
   
 



const UNICHARSET &unicharset = dict_->getUnicharset();
UNICHAR_ID unichar_id = b->unichar_id();

if (unicharset.get_ispunctuation(unichar_id)) consistency_info.num_punc++;  // Check punctuation validity.

  
   
AssociateStats associate_stats;


ViterbiStateEntry *new_vse = new ViterbiStateEntry( parent_vse, b, 0.0, 0, consistency_info, associate_stats, top_choice_flags, 0, 0, 0);

 
float adjustment=0; 
if (consistency_info.NumInconsistentPunc() != 0) adjustment= language_model_penalty_punc;

new_vse->cost= new_vse->ratings_sum *(1+adjustment);
  


if (word_end)  {
     

  BLOB_CHOICE *curr_b = new_vse->curr_b;
  ViterbiStateEntry *curr_vse = new_vse;



WERD_CHOICE *word = new WERD_CHOICE(word_res->uch_set, new_vse->length);  // Construct a WERD_CHOICE by tracing parent pointers.

word->set_length(new_vse->length);
  

for ( int i = (new_vse->length-1); i >= 0; --i) {

int num_blobs = curr_b->matrix_cell().row - curr_b->matrix_cell().col + 1;

word->set_blob_choice(i, num_blobs, curr_b);

curr_vse = curr_vse->parent_vse;    if (curr_vse == NULL) break;   curr_b = curr_vse->curr_b;

}





word->set_rating(new_vse->cost);


int max_num_choices=dict_->tessedit_truncate_wordchoice_log;

WERD_CHOICE_IT it(&word_res->best_choices);
int num_choices = 0;


if (!it.empty()) {

do {
WERD_CHOICE* choice = it.data();
++num_choices;
it.forward();    
} while (!it.at_first());

}
  

if ( num_choices < max_num_choices) {  it.add_to_end(word);  if (num_choices == 0) word_res->best_choice = word;   }
   
 
}



curr_state->viterbi_state_entries.add_sorted(ViterbiStateEntry::Compare,  false, new_vse);  // �� Add the new ViterbiStateEntry and to curr_state->viterbi_state_entries.


return true;
}





#endif    // LOCAL_CODE














int main32(char*image, char*outputbase, char* lang) {  //  = "eng" �ض���Ĭ��ֵ!

Pix *pix = pixRead(image);
if (pix == NULL) {  qTrace("pixRead(%s) failed", image); return false; }


tesseract::TessBaseAPI api;      // // static  Avoid memory leak caused by auto variable when exit() is called.
api.tesseract_ = new Tesseract;

api.thresholder_ = new ImageThresholder;  
api.block_list_ = new BLOCK_LIST;

api.thresholder_->SetImage(pix);

 
  
int ic=ProcessImage(api); 
 
 
LoadData(api);  // LoadData(api.tesseract_); 

Recognize(api); 


char*s=GetText(api.page_res_);    // qTrace("%s, length=%d", s, strlen( s ) );

Printf("\r\n[%s],    length=%d",   s,  strlen( s ) );


pixDestroy(&pix);    // Clean up memory as needed


// if( 0!=access(outputbase,0) ) qTrace("%s is not present!", outputbase);
//ShellExecute(0, "open", outputbase, 0, 0, SW_SHOW);
// ShellExecute(0, "open", "D:\\Tbyang20\\����ʶ��\\tes-gui/worksite/result.txt", 0, 0, SW_SHOW);  // ����'./' !       

return 0;
}





